import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import VetSidebar from "./VetSidebar";
import type { User } from "../../types";

const mockNavigate = vi.fn();
vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual("react-router-dom");
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

const vetUser: User = {
  id: "vet-1",
  name: "Dr. Rodrigo Silva",
  email: "rodrigo@petlife.test",
  role: "Veterinário",
  crmv: "54321",
};

describe("VetSidebar", () => {
  it("renderiza todos os links de navegação do veterinário e dados do profissional", () => {
    render(
      <AuthContext.Provider
        value={{
          user: vetUser,
          setUser: vi.fn(),
          login: vi.fn(),
          logout: vi.fn(),
        }}
      >
        <MemoryRouter>
          <VetSidebar activePath="/vet" />
        </MemoryRouter>
      </AuthContext.Provider>,
    );

    expect(screen.getByText("Início")).toBeInTheDocument();
    expect(screen.getByText("Pacientes")).toBeInTheDocument();
    expect(screen.getByText("Novo Paciente")).toBeInTheDocument();
    expect(screen.getByText("Calendário")).toBeInTheDocument();
    expect(screen.getByText("Perfil")).toBeInTheDocument();
    expect(screen.getByText("Relatórios")).toBeInTheDocument();
    expect(screen.getByText("Dr. Rodrigo Silva")).toBeInTheDocument();
    expect(screen.getByText("CRMV 54321")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /sair/i })).toBeInTheDocument();
  });

  it("chama logout e redireciona para login ao clicar no botão Sair", async () => {
    const user = userEvent.setup();
    const logoutMock = vi.fn();
    mockNavigate.mockClear();

    render(
      <AuthContext.Provider
        value={{
          user: vetUser,
          setUser: vi.fn(),
          login: vi.fn(),
          logout: logoutMock,
        }}
      >
        <MemoryRouter>
          <VetSidebar activePath="/vet" />
        </MemoryRouter>
      </AuthContext.Provider>,
    );

    const logoutBtn = screen.getByRole("button", { name: /sair/i });
    await user.click(logoutBtn);

    expect(logoutMock).toHaveBeenCalledTimes(1);
    expect(mockNavigate).toHaveBeenCalledWith("/login", { replace: true });
  });
});
