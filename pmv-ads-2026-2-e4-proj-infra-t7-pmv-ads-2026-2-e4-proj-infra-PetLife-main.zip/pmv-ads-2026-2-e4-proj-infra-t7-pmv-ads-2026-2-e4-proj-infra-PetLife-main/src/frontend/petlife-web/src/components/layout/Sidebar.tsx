import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  Home,
  Dog,
  Calendar,
  Bell,
  Search,
  User as UserIcon,
  PawPrint,
  LogOut,
} from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";
import styles from "./Sidebar.module.css";

interface SidebarProps {
  activePath?: string;
}

export default function Sidebar({ activePath }: SidebarProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const currentPath = activePath ?? location.pathname;
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    localStorage.removeItem("hasPickedRole");
    navigate("/login", { replace: true });
  };

  const userName = user?.name || "Tutor";

  const navItems = [
    { label: "Início", path: "/tutor", icon: Home },
    { label: "Meus Pets", path: "/tutor/pets", icon: Dog },
    { label: "Calendário", path: "/tutor/calendario", icon: Calendar },
    { label: "Notificações", path: "/tutor/notificacoes", icon: Bell },
    { label: "Buscar", path: "/tutor/buscar", icon: Search },
    { label: "Perfil", path: "/tutor/perfil", icon: UserIcon },
  ];

  return (
    <aside className={styles.sidebar}>
      <Link to="/tutor" className={styles.logoContainer} aria-label="PetLife Início">
        <div className={styles.logoIconWrapper}>
          <PawPrint size={20} strokeWidth={2.4} />
        </div>
        <span className={styles.logoText}>
          <span className={styles.logoPet}>Pet</span>
          <span className={styles.logoLife}>Life</span>
        </span>
      </Link>

      <nav className={styles.nav} aria-label="Menu principal">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive =
            item.path === "/tutor"
              ? currentPath === "/tutor"
              : currentPath === item.path || currentPath.startsWith(`${item.path}/`);

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`${styles.navItem} ${isActive ? styles.active : ""}`}
            >
              <Icon className={styles.navIcon} strokeWidth={isActive ? 2.5 : 2} />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className={styles.footerContainer}>
        <Link to="/tutor/perfil" className={styles.userFooter} title="Ver Perfil">
          <div className={styles.avatar}>
            {user?.imagem ? (
              <img src={user.imagem} alt={userName} className={styles.avatarImg} />
            ) : (
              <span>{userName.charAt(0).toUpperCase()}</span>
            )}
          </div>
          <div className={styles.userInfo}>
            <span className={styles.userName}>{userName}</span>
            <span className={styles.userRole}>{user?.role || "Tutor"}</span>
          </div>
        </Link>

        <button
          type="button"
          onClick={handleLogout}
          className={styles.logoutBtn}
          title="Sair"
          aria-label="Sair"
        >
          <LogOut className={styles.logoutIcon} size={18} />
          <span>Sair</span>
        </button>
      </div>
    </aside>
  );
}
