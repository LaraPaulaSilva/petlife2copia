import { type ReactNode } from "react";
import Sidebar from "./Sidebar";
import styles from "./TutorLayout.module.css";

interface TutorLayoutProps {
  children: ReactNode;
}

export default function TutorLayout({ children }: TutorLayoutProps) {
  return (
    <div className={styles.layout}>
      <Sidebar />
      <main className={styles.mainContent}>
        {children}
      </main>
    </div>
  );
}
