import { PawPrint } from "lucide-react";
import styles from "./SiteFooter.module.css";

interface SiteFooterProps {
  showBrand?: boolean;
}

export default function SiteFooter({ showBrand = true }: SiteFooterProps) {
  return (
    <footer
      className={`${styles.footer} ${showBrand ? "" : styles.footerNoBrand}`}
    >
      {showBrand && (
        <div className={styles.footerBrand}>
          <PawPrint className={styles.logoIcon} />
          <span className={styles.logoText}>
            <span className={styles.logoPet}>Pet</span>
            <span className={styles.logoLife}>Life</span>
          </span>
          <p>Tecnologia e carinho para uma vida melhor.</p>
        </div>
      )}
      <img
        className={styles.footerPets}
        src="/images/pet-footer.png"
        alt="Cães e gatos"
      />
      <nav className={styles.footerLinks}>
        <a href="/#funcionalidades">Funcionalidades</a>
        <a href="/#veterinarios">Para Veterinários</a>
        <a href="/#sobre">Suporte</a>
        <a href="/#sobre">Privacidade</a>
      </nav>
    </footer>
  );
}
