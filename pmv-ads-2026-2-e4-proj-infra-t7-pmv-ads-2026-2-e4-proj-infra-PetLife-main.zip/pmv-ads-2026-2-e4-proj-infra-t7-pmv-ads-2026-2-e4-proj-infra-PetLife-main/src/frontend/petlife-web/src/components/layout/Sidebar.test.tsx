import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import Sidebar from "./Sidebar";
import type { User } from "../../types";

const mockNavigate = vi.fn();
vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual("react-router-dom");
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

const tutorUser: User = {
  id: "tutor-1",
  name: "Mariana Souza",
  email: "mariana@petlife.test",
  role: "Tutor",
};

describe("Sidebar", () => {
  it("renderiza todos os links de navegação e as informações do usuário", () => {
    render(
      <AuthContext.Provider
        value={{
          user: tutorUser,
          setUser: vi.fn(),
          login: vi.fn(),
          logout: vi.fn(),
        }}
      >
        <MemoryRouter>
          <Sidebar activePath="/tutor" />
        </MemoryRouter>
      </AuthContext.Provider>,
    );

    expect(screen.getByText("Início")).toBeInTheDocument();
    expect(screen.getByText("Meus Pets")).toBeInTheDocument();
    expect(screen.getByText("Calendário")).toBeInTheDocument();
    expect(screen.getByText("Buscar")).toBeInTheDocument();
    expect(screen.getByText("Perfil")).toBeInTheDocument();
    expect(screen.getByText("Mariana Souza")).toBeInTheDocument();
    expect(screen.getByText("Tutor")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /sair/i })).toBeInTheDocument();
  });

  it("chama logout e redireciona para login ao clicar no botão Sair", async () => {
    const user = userEvent.setup();
    const logoutMock = vi.fn();
    mockNavigate.mockClear();

    render(
      <AuthContext.Provider
        value={{
          user: tutorUser,
          setUser: vi.fn(),
          login: vi.fn(),
          logout: logoutMock,
        }}
      >
        <MemoryRouter>
          <Sidebar activePath="/tutor" />
        </MemoryRouter>
      </AuthContext.Provider>,
    );

    const logoutBtn = screen.getByRole("button", { name: /sair/i });
    await user.click(logoutBtn);

    expect(logoutMock).toHaveBeenCalledTimes(1);
    expect(mockNavigate).toHaveBeenCalledWith("/login", { replace: true });
  });
});
