import { type ReactNode } from "react";
import VetSidebar from "./VetSidebar";
import styles from "./TutorLayout.module.css";

interface VetLayoutProps {
  children: ReactNode;
}

export default function VetLayout({ children }: VetLayoutProps) {
  return (
    <div className={styles.layout}>
      <VetSidebar />
      <main className={styles.mainContent}>
        {children}
      </main>
    </div>
  );
}
