import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  Home,
  PawPrint,
  Plus,
  Calendar,
  Bell,
  User as UserIcon,
  FileText,
  LogOut,
} from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";
import styles from "./VetSidebar.module.css";

interface VetSidebarProps {
  activePath?: string;
}

export default function VetSidebar({ activePath }: VetSidebarProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const currentPath = activePath ?? location.pathname;
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    localStorage.removeItem("hasPickedRole");
    navigate("/login", { replace: true });
  };

  const vetName = user?.name || "Veterinário";
  const userRole = user?.crmv ? `CRMV ${user.crmv}` : "Veterinário";

  const navItems = [
    { label: "Início", path: "/vet", icon: Home },
    { label: "Pacientes", path: "/vet/pacientes", icon: PawPrint },
    { label: "Novo Paciente", path: "/vet/pacientes/novo", icon: Plus },
    { label: "Calendário", path: "/vet/calendario", icon: Calendar },
    { label: "Notificações", path: "/vet/notificacoes", icon: Bell },
    { label: "Perfil", path: "/vet/perfil", icon: UserIcon },
    { label: "Relatórios", path: "/vet/relatorios", icon: FileText },
  ];

  return (
    <aside className={styles.sidebar}>
      <Link to="/vet" className={styles.logoContainer} aria-label="PetLife Veterinário">
        <div className={styles.logoIconWrapper}>
          <PawPrint size={20} strokeWidth={2.4} />
        </div>
        <span className={styles.logoText}>
          <span className={styles.logoPet}>Pet</span>
          <span className={styles.logoLife}>Life</span>
        </span>
      </Link>

      <nav className={styles.nav} aria-label="Menu principal veterinário">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive =
            currentPath === item.path ||
            (item.path === "/vet" && currentPath === "/vet") ||
            (item.path === "/vet/pacientes" &&
              currentPath.startsWith("/vet/pacientes") &&
              currentPath !== "/vet/pacientes/novo");

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`${styles.navItem} ${isActive ? styles.active : ""}`}
            >
              <Icon className={styles.navIcon} strokeWidth={isActive ? 2.5 : 2} />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className={styles.footerContainer}>
        <Link to="/vet/perfil" className={styles.userFooter} title="Ver Perfil">
          <div className={styles.avatar}>
            {user?.imagem ? (
              <img src={user.imagem} alt={vetName} className={styles.avatarImg} />
            ) : (
              <UserIcon size={20} />
            )}
          </div>
          <div className={styles.userInfo}>
            <span className={styles.userName}>{vetName}</span>
            <span className={styles.userRole}>{userRole}</span>
          </div>
        </Link>

        <button
          type="button"
          onClick={handleLogout}
          className={styles.logoutBtn}
          title="Sair"
          aria-label="Sair"
        >
          <LogOut className={styles.logoutIcon} size={18} />
          <span>Sair</span>
        </button>
      </div>
    </aside>
  );
}
