import { type ReactNode } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import TutorLayout from "./TutorLayout";
import VetLayout from "./VetLayout";
import styles from "./ProntuarioLayout.module.css";

export type ProntuarioTab =
  | "consultas"
  | "vacinas"
  | "tratamentos"
  | "diario"
  | "documentos";

interface ProntuarioLayoutProps {
  children: ReactNode;
  title?: string;
  icon?: string;
  activeTab?: ProntuarioTab;
  showHeaderAndTabs?: boolean; // false nas telas de formulário ("Novo Tratamento", "Nova Vacina", etc.)
  petSummary?: string;
  petPhoto?: string | null;
  fullWidth?: boolean; // true para o conteúdo ocupar toda a largura disponível
}

const TABS: { label: string; slug: ProntuarioTab }[] = [
  { label: "Consulta", slug: "consultas" },
  { label: "Vacinas", slug: "vacinas" },
  { label: "Tratamentos", slug: "tratamentos" },
  { label: "Diário", slug: "diario" },
  { label: "Documentos", slug: "documentos" },
];

export default function ProntuarioLayout({
  children,
  title = "Prontuário",
  icon = "🐾",
  activeTab,
  showHeaderAndTabs = true,
  petSummary = "Lulu • Gato • Vira-lata",
  petPhoto,
  fullWidth = false,
}: ProntuarioLayoutProps) {
  const { petId = "pet-1" } = useParams<{ petId: string }>();
  const location = useLocation();
  const { user } = useAuth();

  const isVet =
    location.pathname.startsWith("/vet") || user?.role === "Veterinário";
  const RoleLayout = isVet ? VetLayout : TutorLayout;
  const basePath = isVet ? `/vet/pacientes/${petId}` : `/tutor/pets/${petId}`;

  return (
    <RoleLayout>
      <div
        className={`${styles.pageContainer} ${
          fullWidth ? styles.pageContainerFull : ""
        }`}
      >
        {showHeaderAndTabs && (
          <>
            <section className={styles.heroBanner} aria-label={`Cabeçalho de ${title}`}>
              {petPhoto ? (
                <img
                  className={styles.petAvatarImg}
                  src={petPhoto}
                  alt={petSummary}
                />
              ) : (
                <div className={styles.petAvatarBox} aria-hidden="true" />
              )}
              <div className={styles.bannerTextCol}>
                <h1 className={styles.bannerTitle}>
                  <span aria-hidden="true">{icon}</span> {title}
                </h1>
                <p className={styles.bannerSubtitle}>{petSummary}</p>
              </div>
            </section>

            <nav className={styles.tabsBar} aria-label="Abas do prontuário">
              {TABS.map((tab) => {
                const isActive = tab.slug === activeTab;
                return (
                  <Link
                    key={tab.slug}
                    to={`${basePath}/${tab.slug}`}
                    className={`${styles.tabPill} ${
                      isActive ? styles.tabPillActive : ""
                    }`}
                  >
                    {tab.label}
                  </Link>
                );
              })}
            </nav>
          </>
        )}

        {children}
      </div>
    </RoleLayout>
  );
}