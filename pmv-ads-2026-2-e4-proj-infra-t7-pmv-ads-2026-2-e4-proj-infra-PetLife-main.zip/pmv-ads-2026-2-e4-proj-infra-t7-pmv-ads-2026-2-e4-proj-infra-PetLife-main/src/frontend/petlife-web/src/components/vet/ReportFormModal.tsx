import { useEffect, useRef, useState, type FormEvent } from "react";
import { X } from "lucide-react";
import {
  DEFAULT_REPORT_FILTERS,
  type PetSummary,
  type ReportFilters,
  type ReportTemplate,
} from "../../services/reportService";
import ReportFiltersFields from "./ReportFiltersFields";
import styles from "./ReportFormModal.module.css";

type Step = 1 | 2 | 3;

interface ReportFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: "create_template" | "edit_template" | "ad_hoc" | "prontuario_pet";
  initialTemplate?: ReportTemplate | null;
  availablePets?: PetSummary[];
  onSubmitTemplate?: (dados: {
    nome: string;
    descricao?: string;
    filtros: ReportFilters;
  }) => void;
  onUpdateTemplate?: (
    id: string,
    dados: { nome: string; descricao?: string; filtros: ReportFilters },
  ) => void;
  onExecuteReport?: (titulo: string, filtros: ReportFilters) => void;
}

const stepTitles = ["Identificação", "Escopo", "Filtros e revisão"];

export default function ReportFormModal({
  isOpen,
  onClose,
  mode,
  initialTemplate,
  availablePets = [],
  onSubmitTemplate,
  onUpdateTemplate,
  onExecuteReport,
}: ReportFormModalProps) {
  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [filters, setFilters] = useState<ReportFilters>(DEFAULT_REPORT_FILTERS);
  const [step, setStep] = useState<Step>(1);
  const [error, setError] = useState("");
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (!isOpen) return;

    setStep(1);
    setError("");

    if ((mode === "edit_template" || mode === "ad_hoc") && initialTemplate) {
      setNome(initialTemplate.nome);
      setDescricao(initialTemplate.descricao ?? "");
      setFilters({ ...DEFAULT_REPORT_FILTERS, ...initialTemplate.filtros });
    } else if (mode === "prontuario_pet") {
      setNome("Prontuário Clínico Completo");
      setDescricao("");
      setFilters({
        ...DEFAULT_REPORT_FILTERS,
        modoRelatorio: "prontuario_pet",
        tipoModulo: "Todos",
        tipoPeriodo: "todos",
        ordenacao: "antigo_recente",
      });
    } else if (mode === "ad_hoc") {
      setNome("Relatório Clínico Personalizado");
      setDescricao("");
      setFilters(DEFAULT_REPORT_FILTERS);
    } else {
      setNome("");
      setDescricao("");
      setFilters(DEFAULT_REPORT_FILTERS);
    }
  }, [mode, initialTemplate, isOpen]);

  if (!isOpen) return null;

  const isTemplateMode =
    mode === "create_template" || mode === "edit_template";
  const isProntuario = mode === "prontuario_pet";

  const handleNext = () => {
    setError("");

    if (step === 1 && !formRef.current?.reportValidity()) return;

    if (step === 2 && isProntuario && !filters.petId && !filters.petNome?.trim()) {
      setError("Selecione um pet ou informe o nome para emitir o prontuário.");
      return;
    }

    setStep((current) => Math.min(3, current + 1) as Step);
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError("");

    const payload = {
      nome: nome.trim(),
      descricao: descricao.trim() || undefined,
      filtros: filters,
    };

    if (mode === "create_template" && onSubmitTemplate) {
      onSubmitTemplate(payload);
    } else if (mode === "edit_template" && initialTemplate && onUpdateTemplate) {
      onUpdateTemplate(initialTemplate.id, payload);
    } else if ((mode === "ad_hoc" || isProntuario) && onExecuteReport) {
      onExecuteReport(nome.trim() || "Relatório Clínico", filters);
    }

    onClose();
  };

  const selectedPet = availablePets.find((pet) => pet.id === filters.petId);
  const moduleName = filters.tipoModulo ?? "Todos";

  const periodName =
    filters.tipoPeriodo === "personalizado"
      ? `${filters.dataInicio || "Sem início"} a ${filters.dataFim || "Sem fim"}`
      : filters.tipoPeriodo === "predefinido"
        ? `Últimos ${filters.periodoDias ?? 30} dias`
        : "Todo o histórico";

  const orderName =
    filters.ordenacao === "recente_antigo"
      ? "Mais recentes primeiro"
      : "Mais antigos primeiro";

  const selectedDetails = [
    filters.medicamento && `Medicamento: ${filters.medicamento}`,
    filters.vacinaTipo && `Vacina: ${filters.vacinaTipo}`,
    filters.vacinaFabricante && `Fabricante/lote: ${filters.vacinaFabricante}`,
    filters.termoConsulta && `Consulta: ${filters.termoConsulta}`,
    filters.termoDiario && `Diário: ${filters.termoDiario}`,
    filters.documentoTitulo && `Documento: ${filters.documentoTitulo}`,
  ].filter((value): value is string => Boolean(value));

  const modalTitle = isTemplateMode
    ? mode === "create_template"
      ? "Novo modelo de relatório"
      : "Editar modelo de relatório"
    : isProntuario
      ? "Emitir prontuário completo"
      : "Emitir relatório sem modelo";

  const submitLabel = isTemplateMode
    ? mode === "create_template"
      ? "Salvar modelo"
      : "Salvar alterações"
    : "Gerar PDF";

  return (
    <div className={styles.overlay} onClick={onClose} role="presentation">
      <div
        className={styles.modal}
        role="dialog"
        aria-modal="true"
        aria-labelledby="report-modal-title"
        onClick={(event) => event.stopPropagation()}
      >
        <div className={styles.header}>
          <div>
            <h2 id="report-modal-title" className={styles.title}>
              {modalTitle}
            </h2>
            <p className={styles.stepCaption}>
              Etapa {step} de 3: {stepTitles[step - 1]}
            </p>
          </div>

          <button
            type="button"
            className={styles.closeBtn}
            onClick={onClose}
            aria-label="Fechar"
          >
            <X size={20} />
          </button>
        </div>

        <div className={styles.stepper} aria-label="Progresso do formulário">
          {stepTitles.map((title, index) => {
            const number = index + 1;
            const active = number === step;
            const complete = number < step;

            return (
              <div
                key={title}
                className={[
                  styles.stepItem,
                  active ? styles.stepItemActive : "",
                  complete ? styles.stepItemComplete : "",
                ].join(" ")}
                aria-current={active ? "step" : undefined}
              >
                <span className={styles.stepNumber}>{number}</span>
                <span>{title}</span>
              </div>
            );
          })}
        </div>

        <form ref={formRef} onSubmit={handleSubmit}>
          <div className={styles.body}>
            {step === 1 && (
              <section className={styles.sectionBlock}>
                <h3 className={styles.sectionHeading}>Identificação</h3>
                <p className={styles.helperText}>
                  {isTemplateMode
                    ? "Dê um nome fácil de reconhecer. Você poderá reutilizar este modelo depois."
                    : "Confira o título que aparecerá no relatório."}
                </p>

                <div className={styles.topFields}>
                  <div className={styles.fieldGroup}>
                    <label htmlFor="titulo" className={styles.label}>
                      {isTemplateMode ? "Nome do modelo" : "Título do relatório"}
                      {" *"}
                    </label>
                    <input
                      id="titulo"
                      type="text"
                      className={styles.input}
                      placeholder="Ex.: Vacinas da Nina"
                      value={nome}
                      required
                      maxLength={80}
                      onChange={(event) => setNome(event.target.value)}
                    />
                  </div>

                  {isTemplateMode && (
                    <div className={styles.fieldGroup}>
                      <label htmlFor="descricao" className={styles.label}>
                        Descrição curta <span>(opcional)</span>
                      </label>
                      <input
                        id="descricao"
                        type="text"
                        className={styles.input}
                        placeholder="Ex.: Acompanhamento anual de vacinação"
                        value={descricao}
                        maxLength={140}
                        onChange={(event) => setDescricao(event.target.value)}
                      />
                    </div>
                  )}
                </div>
              </section>
            )}

            {step === 2 && (
              <>
                <div className={styles.sectionIntro}>
                  <h3>Defina o escopo</h3>
                  <p>Escolha quais pets, áreas e datas devem entrar no relatório.</p>
                </div>

                <ReportFiltersFields
                  filters={filters}
                  onChange={setFilters}
                  availablePets={availablePets}
                  step="scope"
                />
              </>
            )}

            {step === 3 && (
              <>
                <div className={styles.sectionIntro}>
                  <h3>Filtros específicos</h3>
                  <p>
                    Refine os registros da área escolhida. Campos vazios não adicionam
                    restrições.
                  </p>
                </div>

                <ReportFiltersFields
                  filters={filters}
                  onChange={setFilters}
                  availablePets={availablePets}
                  step="details"
                />

                <section className={styles.summaryCard}>
                  <h3 className={styles.sectionHeading}>Resumo do modelo</h3>
                  <dl className={styles.summaryList}>
                    <div>
                      <dt>Nome</dt>
                      <dd>{nome || "Relatório clínico"}</dd>
                    </div>
                    <div>
                      <dt>Pet</dt>
                      <dd>
                        {selectedPet?.nome ||
                          filters.petNome ||
                          (isProntuario ? "Selecione um pet" : "Todos os pets acessíveis")}
                      </dd>
                    </div>
                    {!isProntuario && (
                      <>
                        <div>
                          <dt>Área</dt>
                          <dd>{moduleName === "Todos" ? "Todas as áreas" : moduleName}</dd>
                        </div>
                        <div>
                          <dt>Período</dt>
                          <dd>{periodName}</dd>
                        </div>
                        <div>
                          <dt>Ordenação</dt>
                          <dd>{orderName}</dd>
                        </div>
                      </>
                    )}
                  </dl>

                  {selectedDetails.length > 0 && (
                    <div className={styles.summaryDetails}>
                      <strong>Filtros adicionais</strong>
                      <ul>
                        {selectedDetails.map((detail) => (
                          <li key={detail}>{detail}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <p className={styles.summaryNote}>
                    {isTemplateMode
                      ? "O modelo salva estas preferências. Os registros serão consultados quando você emitir o relatório."
                      : "Confira os filtros acima antes de gerar o PDF."}
                  </p>
                </section>
              </>
            )}

            {error && <p className={styles.errorMessage}>{error}</p>}
          </div>

          <div className={styles.footer}>
            {step > 1 ? (
              <button
                type="button"
                className={styles.cancelBtn}
                onClick={() => {
                  setError("");
                  setStep((current) => (current - 1) as Step);
                }}
              >
                Voltar
              </button>
            ) : (
              <button type="button" className={styles.cancelBtn} onClick={onClose}>
                Cancelar
              </button>
            )}

            {step < 3 ? (
              <button type="button" className={styles.submitBtn} onClick={handleNext}>
                Continuar
              </button>
            ) : (
              <button type="submit" className={styles.submitBtn}>
                {submitLabel}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}