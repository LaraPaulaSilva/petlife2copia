import type { PetSummary, ReportFilters } from "../../services/reportService";
import styles from "./ReportFormModal.module.css";

type FilterStep = "scope" | "details" | "all";

interface ReportFiltersFieldsProps {
  filters: ReportFilters;
  onChange: (updated: ReportFilters) => void;
  availablePets?: PetSummary[];
  step?: FilterStep;
}

export default function ReportFiltersFields({
  filters,
  onChange,
  availablePets = [],
  step = "all",
}: ReportFiltersFieldsProps) {
  const handleChange = <K extends keyof ReportFilters>(
    key: K,
    value: ReportFilters[K],
  ) => {
    onChange({ ...filters, [key]: value });
  };

  const isProntuario = filters.modoRelatorio === "prontuario_pet";
  const modulo = filters.tipoModulo ?? "Todos";
  const showScope = step === "scope" || step === "all";
  const showDetails = step === "details" || step === "all";

  const handleSelectPet = (petId: string) => {
    const found = availablePets.find((pet) => pet.id === petId);

    onChange({
      ...filters,
      petId,
      petNome: found ? found.nome : petId ? filters.petNome : "",
    });
  };

  return (
    <div className={styles.filtersContainer}>
      {showScope && (
        <>
          <div className={styles.sectionBlock}>
            <h4 className={styles.sectionHeading}>Finalidade e ordenação</h4>

            <div className={styles.grid3}>
              <div className={styles.fieldGroup}>
                <label htmlFor="modoRelatorio" className={styles.label}>
                  Tipo de emissão
                </label>
                <select
                  id="modoRelatorio"
                  className={styles.select}
                  value={filters.modoRelatorio ?? "filtros"}
                  onChange={(event) => {
                    const modo = event.target.value as ReportFilters["modoRelatorio"];

                    onChange({
                      ...filters,
                      modoRelatorio: modo,
                      tipoModulo: modo === "prontuario_pet" ? "Todos" : filters.tipoModulo,
                      tipoPeriodo: modo === "prontuario_pet" ? "todos" : filters.tipoPeriodo,
                      ordenacao:
                        modo === "prontuario_pet" ? "antigo_recente" : filters.ordenacao,
                    });
                  }}
                >
                  <option value="filtros">Relatório por filtros</option>
                  <option value="prontuario_pet">
                    Prontuário completo do pet
                  </option>
                </select>
              </div>

              <div className={styles.fieldGroup}>
                <label htmlFor="ordenacao" className={styles.label}>
                  Ordem cronológica
                </label>
                <select
                  id="ordenacao"
                  className={styles.select}
                  value={
                    isProntuario
                      ? "antigo_recente"
                      : filters.ordenacao ?? "antigo_recente"
                  }
                  disabled={isProntuario}
                  onChange={(event) =>
                    handleChange(
                      "ordenacao",
                      event.target.value as ReportFilters["ordenacao"],
                    )
                  }
                >
                  <option value="antigo_recente">
                    Do mais antigo ao mais recente
                  </option>
                  <option value="recente_antigo">
                    Do mais recente ao mais antigo
                  </option>
                </select>
              </div>
            </div>
          </div>

          <div className={styles.sectionBlock}>
            <h4 className={styles.sectionHeading}>Pet e tutor</h4>

            <div className={styles.grid3}>
              {availablePets.length > 0 && (
                <div className={styles.fieldGroup}>
                  <label htmlFor="petSelect" className={styles.label}>
                    Pet cadastrado
                  </label>
                  <select
                    id="petSelect"
                    className={styles.select}
                    value={filters.petId ?? ""}
                    onChange={(event) => handleSelectPet(event.target.value)}
                  >
                    <option value="">Todos os pets</option>
                    {availablePets.map((pet) => (
                      <option key={pet.id} value={pet.id}>
                        {pet.nome} ({pet.especie} · Tutor: {pet.tutorNome})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className={styles.fieldGroup}>
                <label htmlFor="petNome" className={styles.label}>
                  Nome do pet {isProntuario ? "*" : ""}
                </label>
                <input
                  id="petNome"
                  type="text"
                  className={styles.input}
                  placeholder="Ex.: Nina, Lulu"
                  required={isProntuario && !filters.petId}
                  value={filters.petNome ?? ""}
                  onChange={(event) => {
                    handleChange("petNome", event.target.value);
                    if (filters.petId) handleChange("petId", "");
                  }}
                />
              </div>

              {!isProntuario && (
                <div className={styles.fieldGroup}>
                  <label htmlFor="tutorNome" className={styles.label}>
                    Nome do tutor
                  </label>
                  <input
                    id="tutorNome"
                    type="text"
                    className={styles.input}
                    placeholder="Ex.: Maria, Carlos"
                    value={filters.tutorNome ?? ""}
                    onChange={(event) =>
                      handleChange("tutorNome", event.target.value)
                    }
                  />
                </div>
              )}
            </div>
          </div>

          {!isProntuario && (
            <div className={styles.sectionBlock}>
              <h4 className={styles.sectionHeading}>Área e período</h4>

              <div className={styles.grid3}>
                <div className={styles.fieldGroup}>
                  <label htmlFor="tipoModulo" className={styles.label}>
                    Área do prontuário
                  </label>
                  <select
                    id="tipoModulo"
                    className={styles.select}
                    value={modulo}
                    onChange={(event) =>
                      handleChange(
                        "tipoModulo",
                        event.target.value as ReportFilters["tipoModulo"],
                      )
                    }
                  >
                    <option value="Todos">Todas as áreas</option>
                    <option value="Consulta">Consultas</option>
                    <option value="Vacina">Vacinas</option>
                    <option value="Tratamento">Tratamentos e medicamentos</option>
                    <option value="Diario">Diário do tutor</option>
                    <option value="Documento">Documentos</option>
                  </select>
                </div>

                <div className={styles.fieldGroup}>
                  <label htmlFor="tipoPeriodo" className={styles.label}>
                    Período
                  </label>
                  <select
                    id="tipoPeriodo"
                    className={styles.select}
                    value={filters.tipoPeriodo ?? "todos"}
                    onChange={(event) =>
                      handleChange(
                        "tipoPeriodo",
                        event.target.value as ReportFilters["tipoPeriodo"],
                      )
                    }
                  >
                    <option value="todos">Todo o histórico</option>
                    <option value="predefinido">Últimos dias</option>
                    <option value="personalizado">Datas específicas</option>
                  </select>
                </div>

                {filters.tipoPeriodo === "predefinido" && (
                  <div className={styles.fieldGroup}>
                    <label htmlFor="periodoDias" className={styles.label}>
                      Intervalo
                    </label>
                    <select
                      id="periodoDias"
                      className={styles.select}
                      value={filters.periodoDias ?? 30}
                      onChange={(event) =>
                        handleChange("periodoDias", Number(event.target.value))
                      }
                    >
                      <option value={7}>Últimos 7 dias</option>
                      <option value={15}>Últimos 15 dias</option>
                      <option value={30}>Últimos 30 dias</option>
                      <option value={90}>Últimos 90 dias</option>
                      <option value={365}>Último ano</option>
                    </select>
                  </div>
                )}
              </div>

              {filters.tipoPeriodo === "personalizado" && (
                <div className={styles.grid3}>
                  <div className={styles.fieldGroup}>
                    <label htmlFor="dataInicio" className={styles.label}>
                      Data inicial
                    </label>
                    <input
                      id="dataInicio"
                      type="date"
                      className={styles.input}
                      value={filters.dataInicio ?? ""}
                      onChange={(event) =>
                        handleChange("dataInicio", event.target.value)
                      }
                    />
                  </div>

                  <div className={styles.fieldGroup}>
                    <label htmlFor="dataFim" className={styles.label}>
                      Data final
                    </label>
                    <input
                      id="dataFim"
                      type="date"
                      className={styles.input}
                      value={filters.dataFim ?? ""}
                      onChange={(event) =>
                        handleChange("dataFim", event.target.value)
                      }
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </>
      )}

      {showDetails && !isProntuario && (
        <>
          {(modulo === "Todos" || modulo === "Vacina") && (
            <div className={styles.sectionBlock}>
              <h4 className={styles.sectionHeading}>Filtros de vacinas</h4>

              <div className={styles.grid3}>
                <div className={styles.fieldGroup}>
                  <label htmlFor="vacinaTipo" className={styles.label}>
                    Tipo da vacina
                  </label>
                  <input
                    id="vacinaTipo"
                    type="text"
                    className={styles.input}
                    placeholder="Ex.: V10, Antirrábica"
                    value={filters.vacinaTipo ?? ""}
                    onChange={(event) =>
                      handleChange("vacinaTipo", event.target.value)
                    }
                  />
                </div>

                <div className={styles.fieldGroup}>
                  <label htmlFor="vacinaFabricante" className={styles.label}>
                    Fabricante ou lote
                  </label>
                  <input
                    id="vacinaFabricante"
                    type="text"
                    className={styles.input}
                    placeholder="Ex.: Zoetis, LT-2026"
                    value={filters.vacinaFabricante ?? ""}
                    onChange={(event) =>
                      handleChange("vacinaFabricante", event.target.value)
                    }
                  />
                </div>

                <div className={styles.fieldGroup}>
                  <label htmlFor="vacinaOrigem" className={styles.label}>
                    Origem do registro
                  </label>
                  <select
                    id="vacinaOrigem"
                    className={styles.select}
                    value={filters.vacinaOrigem ?? "Todas"}
                    onChange={(event) =>
                      handleChange(
                        "vacinaOrigem",
                        event.target.value as ReportFilters["vacinaOrigem"],
                      )
                    }
                  >
                    <option value="Todas">Todas</option>
                    <option value="Tutor">Tutor</option>
                    <option value="Veterinário">Veterinário</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {(modulo === "Todos" || modulo === "Tratamento") && (
            <div className={styles.sectionBlock}>
              <h4 className={styles.sectionHeading}>Filtros de tratamentos</h4>

              <div className={styles.grid3}>
                <div className={styles.fieldGroup}>
                  <label htmlFor="medicamento" className={styles.label}>
                    Medicamento
                  </label>
                  <input
                    id="medicamento"
                    type="text"
                    className={styles.input}
                    placeholder="Ex.: Loratadina, Omeprazol"
                    value={filters.medicamento ?? ""}
                    onChange={(event) =>
                      handleChange("medicamento", event.target.value)
                    }
                  />
                </div>

                <div className={styles.fieldGroup}>
                  <label htmlFor="statusTratamento" className={styles.label}>
                    Status do tratamento
                  </label>
                  <select
                    id="statusTratamento"
                    className={styles.select}
                    value={filters.statusTratamento ?? "Todos"}
                    onChange={(event) =>
                      handleChange(
                        "statusTratamento",
                        event.target.value as ReportFilters["statusTratamento"],
                      )
                    }
                  >
                    <option value="Todos">Todos</option>
                    <option value="Ativo">Ativo</option>
                    <option value="Concluído">Concluído</option>
                    <option value="Encerrado">Encerrado</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {(modulo === "Todos" ||
            modulo === "Consulta" ||
            modulo === "Diario" ||
            modulo === "Documento") && (
            <div className={styles.sectionBlock}>
              <h4 className={styles.sectionHeading}>
                Filtros de consultas, diário e documentos
              </h4>

              <div className={styles.grid3}>
                {(modulo === "Todos" || modulo === "Consulta") && (
                  <div className={styles.fieldGroup}>
                    <label htmlFor="termoConsulta" className={styles.label}>
                      Consulta (motivo ou diagnóstico)
                    </label>
                    <input
                      id="termoConsulta"
                      type="text"
                      className={styles.input}
                      placeholder="Ex.: Check-up, dermatologia"
                      value={filters.termoConsulta ?? ""}
                      onChange={(event) =>
                        handleChange("termoConsulta", event.target.value)
                      }
                    />
                  </div>
                )}

                {(modulo === "Todos" || modulo === "Diario") && (
                  <div className={styles.fieldGroup}>
                    <label htmlFor="termoDiario" className={styles.label}>
                      Diário (relato do tutor)
                    </label>
                    <input
                      id="termoDiario"
                      type="text"
                      className={styles.input}
                      placeholder="Ex.: Apetite, comportamento"
                      value={filters.termoDiario ?? ""}
                      onChange={(event) =>
                        handleChange("termoDiario", event.target.value)
                      }
                    />
                  </div>
                )}

                {(modulo === "Todos" || modulo === "Documento") && (
                  <>
                    <div className={styles.fieldGroup}>
                      <label htmlFor="documentoTitulo" className={styles.label}>
                        Título do documento
                      </label>
                      <input
                        id="documentoTitulo"
                        type="text"
                        className={styles.input}
                        placeholder="Ex.: Exame de sangue"
                        value={filters.documentoTitulo ?? ""}
                        onChange={(event) =>
                          handleChange("documentoTitulo", event.target.value)
                        }
                      />
                    </div>

                    <div className={styles.fieldGroup}>
                      <label htmlFor="documentoTipo" className={styles.label}>
                        Tipo de documento
                      </label>
                      <select
                        id="documentoTipo"
                        className={styles.select}
                        value={filters.documentoTipo ?? "Todos"}
                        onChange={(event) =>
                          handleChange(
                            "documentoTipo",
                            event.target.value as ReportFilters["documentoTipo"],
                          )
                        }
                      >
                        <option value="Todos">Todos</option>
                        <option value="Exame">Exame</option>
                        <option value="Receita">Receita</option>
                        <option value="Laudo">Laudo</option>
                        <option value="Atestado">Atestado</option>
                        <option value="Outro">Outro</option>
                      </select>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </>
      )}

      {showDetails && (
        <label className={styles.checkboxRow}>
          <input
            type="checkbox"
            checked={filters.incluirObservacoes ?? true}
            onChange={(event) =>
              handleChange("incluirObservacoes", event.target.checked)
            }
          />
          <span>Incluir observações clínicas e relatos do tutor no PDF</span>
        </label>
      )}
    </div>
  );
}