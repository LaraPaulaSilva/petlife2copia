import { Play, Trash2, Pencil } from "lucide-react";
import type { ReportTemplate } from "../../services/reportService";
import styles from "./ReportCard.module.css";

interface ReportCardProps {
  template: ReportTemplate;
  onRun: (template: ReportTemplate) => void;
  onEdit: (template: ReportTemplate) => void;
  onDelete: (template: ReportTemplate) => void;
}

export default function ReportCard({
  template,
  onRun,
  onEdit,
  onDelete,
}: ReportCardProps) {
  const { filtros } = template;
  const isProntuario = filtros.modoRelatorio === "prontuario_pet";

  const resumoPeriodo =
    filtros.tipoPeriodo === "personalizado"
      ? `${filtros.dataInicio || "Início"} até ${filtros.dataFim || "Hoje"}`
      : filtros.tipoPeriodo === "predefinido"
      ? `Últimos ${filtros.periodoDias ?? 30} dias`
      : "Todo o histórico";

  return (
    <article className={styles.card}>
      <div className={styles.header}>
        <div className={styles.iconBox} aria-hidden="true">
          📊
        </div>
        <div className={styles.headerInfo}>
          <h3 className={styles.title}>{template.nome}</h3>
          {template.descricao && <p className={styles.meta}>{template.descricao}</p>}
        </div>
      </div>

      <div className={styles.badges}>
        {isProntuario ? (
          <span className={styles.badge}>Prontuário Completo (Antigo → Recente)</span>
        ) : (
          <span className={styles.badge}>Área: {filtros.tipoModulo ?? "Todos"}</span>
        )}
        <span className={styles.badge}>Período: {resumoPeriodo}</span>
        {filtros.petNome && <span className={styles.badge}>Pet: {filtros.petNome}</span>}
        {filtros.tutorNome && <span className={styles.badge}>Tutor: {filtros.tutorNome}</span>}
        {filtros.medicamento && (
          <span className={styles.badge}>Med.: {filtros.medicamento}</span>
        )}
        {filtros.vacinaTipo && <span className={styles.badge}>Vacina: {filtros.vacinaTipo}</span>}
        {filtros.documentoTipo && filtros.documentoTipo !== "Todos" && (
          <span className={styles.badge}>Doc.: {filtros.documentoTipo}</span>
        )}
      </div>

      <div className={styles.actions}>
        <button
          type="button"
          className={styles.editBtn}
          onClick={() => onEdit(template)}
        >
          <Pencil size={14} />
          Editar
        </button>
        <button
          type="button"
          className={styles.deleteBtn}
          onClick={() => onDelete(template)}
        >
          <Trash2 size={15} />
          Excluir
        </button>
        <button
          type="button"
          className={styles.runBtn}
          onClick={() => onRun(template)}
        >
          <Play size={14} />
          Emitir Relatório
        </button>
      </div>
    </article>
  );
}