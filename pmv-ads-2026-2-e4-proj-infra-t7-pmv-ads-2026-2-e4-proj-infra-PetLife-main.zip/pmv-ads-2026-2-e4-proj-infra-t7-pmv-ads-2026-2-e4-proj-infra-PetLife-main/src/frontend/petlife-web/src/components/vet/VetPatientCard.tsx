import { Link } from "react-router-dom";
import { PawPrint } from "lucide-react";
import type { VetPatient } from "../../services/vetHomeService";
import styles from "./VetPatientCard.module.css";

interface VetPatientCardProps {
  patient: VetPatient;
}

export default function VetPatientCard({ patient }: VetPatientCardProps) {
  const metaText = `${patient.species} • ${patient.breed} • ${patient.age} • ${patient.weight}`;

  return (
    <Link
      to={`/vet/pacientes/${patient.id}`}
      className={styles.card}
      aria-label={`Ver prontuário de ${patient.name}`}
    >
      <div className={styles.photoWrapper}>
        {patient.photo ? (
          <img
            src={patient.photo}
            alt={patient.name}
            className={styles.photo}
            onError={(e) => {
              (e.target as HTMLElement).style.display = "none";
            }}
          />
        ) : (
          <PawPrint size={28} strokeWidth={2} />
        )}
      </div>

      <div className={styles.info}>
        <h4 className={styles.name}>{patient.name}</h4>
        <span className={styles.meta} title={metaText}>{metaText}</span>
        <span className={styles.tutor}>Tutor: {patient.tutor}</span>
      </div>
    </Link>
  );
}
