import { useEffect, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useLocation, useNavigate } from "react-router-dom";
import api, { baseURL } from "../api/client";

interface AuthHandler {
  children: React.ReactNode;
}

const AuthHandler = ({ children }: AuthHandler) => {
  const [loading, setLoading] = useState<boolean>(true);
  const { setUser, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const unloggedUrls = [
    "/register",
    "/login",
    "/forgot-password",
    "/reset-password",
  ];
  const publicUrls = ["/", ...unloggedUrls];

  const getUserData = async () => {
    const token = localStorage.getItem("petlife_token");
    if (!token) {
      setLoading(false);
      if (!publicUrls.includes(location.pathname)) {
        navigate("/login", { replace: true });
      }
      return;
    }
    api
      .get(`${baseURL}/api/users/me`)
      .then((data) => {
        setUser(data.data);
        return data.data;
      })
      .then((data) => {
        if (unloggedUrls.includes(location.pathname)) {
          setLoading(false);
          const url = data.role === "Tutor" ? "/tutor" : "/vet";
          return navigate(url, { replace: true });
        }
      })
      .catch((error) => {
        console.log(error);
        logout();
        if (!publicUrls.includes(location.pathname)) {
          navigate("/login", { replace: true });
        }
      })
      .finally(() => {
        setLoading(false);
      });
  };

  useEffect(() => {
    getUserData();
  }, []);

  if (loading) return <p>...</p>;

  return children;
};

export default AuthHandler;
