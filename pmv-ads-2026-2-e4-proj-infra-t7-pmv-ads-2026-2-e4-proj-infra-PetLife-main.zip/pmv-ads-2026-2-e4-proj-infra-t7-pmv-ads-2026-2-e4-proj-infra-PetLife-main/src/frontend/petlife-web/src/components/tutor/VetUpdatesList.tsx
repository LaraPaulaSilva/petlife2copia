import { FileText, Syringe, Stethoscope } from "lucide-react";
import type { HomeVetUpdate } from "../../services/tutorHomeService";
import styles from "./VetUpdatesList.module.css";

interface VetUpdatesListProps {
  updates: HomeVetUpdate[];
}

export default function VetUpdatesList({ updates }: VetUpdatesListProps) {
  const getIcon = (type: HomeVetUpdate["type"]) => {
    switch (type) {
      case "vaccine":
        return <Syringe size={20} strokeWidth={2.2} />;
      case "consultation":
        return <Stethoscope size={20} strokeWidth={2.2} />;
      case "document":
      default:
        return <FileText size={20} strokeWidth={2.2} />;
    }
  };

  return (
    <section className={styles.section} aria-labelledby="vet-updates-title">
      <div className={styles.sectionHeader}>
        <span className={styles.sectionIcon} role="img" aria-label="Atualizações">📄</span>
        <h3 id="vet-updates-title" className={styles.sectionTitle}>
          Atualizações do Veterinário
        </h3>
      </div>

      <div className={styles.updatesList}>
        {updates.length === 0 ? (
          <p className={styles.emptyState}>Nenhuma atualização veterinária recente.</p>
        ) : (
          updates.map((item) => (
            <div key={item.id} className={styles.updateCard}>
              <div className={styles.iconCircle}>
                {getIcon(item.type)}
              </div>
              <div className={styles.contentCol}>
                <span className={styles.petName}>{item.pet}</span>
                <span className={styles.description}>{item.description}</span>
                <span className={styles.date}>{item.date}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}
