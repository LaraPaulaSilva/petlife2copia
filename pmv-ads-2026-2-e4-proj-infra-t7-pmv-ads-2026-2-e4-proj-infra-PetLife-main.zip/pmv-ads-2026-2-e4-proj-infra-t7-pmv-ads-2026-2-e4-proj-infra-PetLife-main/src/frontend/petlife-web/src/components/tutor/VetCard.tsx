import { Calendar, MapPin, User as UserImage } from "lucide-react";
import styles from "./VetCard.module.css";
import { User } from "../../types";
import { useState } from "react";
import { Modal } from "../Modal";
import SharePetList from "../../pages/tutor/SharePetList";
const VetCard = ({ vet }: { vet: User }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div key={vet.id} className={styles.vetCard}>
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Compartilhar perfil de pet"
        size="lg"
      >
        <SharePetList vetId={vet.id} />
      </Modal>

      <div className={styles.vetInfoLeft}>
        <div className={styles.avatarContainer}>
          {vet.imagem ? (
            <img src={vet.imagem} alt={vet.name} className={styles.avatarImg} />
          ) : (
            <div className={styles.noImage}>
              <UserImage width={35} height={35} color="grey" />
            </div>
          )}
        </div>

        <div className={styles.vetDetails}>
          <div className={styles.vetNameRow}>
            <h3 className={styles.vetName}>{vet.name}</h3>
            <span className={styles.crmvBadge}>
              CRMV: {vet.crmv ?? "Não cadastrado"}
            </span>
          </div>

          <div className={styles.vetLocationRow}>
            <span className={styles.flexCenter}>
              <MapPin className={styles.tinyIconGray} />{" "}
              {vet.endereço ?? "Endereço não cadastrado"}
            </span>
          </div>
        </div>
      </div>
      <div className={styles.vetActionRight}>
        <button
          className={styles.selectBtn}
          onClick={() => setIsModalOpen(true)}
        >
          <Calendar className={styles.btnIcon} /> Selecionar profissional
        </button>
      </div>
    </div>
  );
};

export default VetCard;
