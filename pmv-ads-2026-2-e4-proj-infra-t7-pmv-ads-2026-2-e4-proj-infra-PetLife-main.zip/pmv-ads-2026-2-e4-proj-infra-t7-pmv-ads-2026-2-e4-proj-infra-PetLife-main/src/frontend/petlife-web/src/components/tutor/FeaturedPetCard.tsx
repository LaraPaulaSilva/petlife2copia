import { Link } from "react-router-dom";
import { Plus, PawPrint } from "lucide-react";
import type { FeaturedPetHome } from "../../services/tutorHomeService";
import styles from "./FeaturedPetCard.module.css";

interface FeaturedPetCardProps {
  featuredPet: FeaturedPetHome | null;
}

export default function FeaturedPetCard({ featuredPet }: FeaturedPetCardProps) {
  if (!featuredPet) {
    return (
      <Link to="/tutor/pets/novo" className={styles.cardContainer} aria-label="Cadastrar primeiro pet">
        <div className={styles.petCard}>
          <div className={styles.emptyIconWrapper}>
            <Plus size={44} color="#ffffff" strokeWidth={2.5} />
          </div>
          <div className={styles.petInfo}>
            <div className={styles.headerRow}>
              <h2 className={styles.petName}>Adicionar primeiro pet</h2>
            </div>
            <p className={styles.petLine}>
              Clique aqui para cadastrar seu companheiro e acompanhar a saúde dele.
            </p>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      to={`/tutor/pets/${featuredPet.id}/editar`}
      className={styles.cardContainer}
      aria-label={`Abrir perfil de ${featuredPet.name}`}
    >
      <div className={styles.petCard}>
        <div className={styles.petImageWrapper}>
          {featuredPet.image ? (
            <img
              src={featuredPet.image}
              alt={featuredPet.name}
              className={styles.petImage}
              onError={(e) => {
                // Caso a imagem não carregue, esconde e deixa o fundo coral sólido
                (e.target as HTMLElement).style.display = "none";
              }}
            />
          ) : (
            <PawPrint size={48} className={styles.petPlaceholder} />
          )}
        </div>

        <div className={styles.petInfo}>
          <div className={styles.headerRow}>
            <h2 className={styles.petName}>{featuredPet.name}</h2>
            <span className={styles.petBadge}>Pet do Dia</span>
          </div>

          <div className={`${styles.petLine} ${styles.petSubtext}`}>
            {featuredPet.breedAge}
          </div>
          <div className={styles.petLine}>{featuredPet.weightLabel}</div>
          <div className={styles.petLine}>{featuredPet.nextVaccineLine}</div>
          <div className={styles.petLine}>{featuredPet.medicationLine}</div>
        </div>
      </div>
    </Link>
  );
}
