import { Link } from "react-router-dom";
import type { Pet } from "../../types";
import { formatPetCardMeta } from "../../services/petService";
import styles from "./PetCard.module.css";

interface PetCardProps {
  pet: Pet;
  onDelete: (id: string) => void;
}

export default function PetCard({ pet, onDelete }: PetCardProps) {
  const meta = formatPetCardMeta(pet);

  const handleDelete = () => {
    const confirmed = window.confirm(
      `Excluir ${pet.nome}? Esta ação não pode ser desfeita.`,
    );
    if (confirmed) onDelete(pet.id);
  };

  return (
    <article className={styles.card}>
      <div className={styles.photoStrip} aria-hidden={pet.foto_url ? undefined : true}>
        {pet.foto_url ? (
          <img
            src={pet.foto_url}
            alt={pet.nome}
            className={styles.photo}
            onError={(e) => {
              (e.target as HTMLElement).style.display = "none";
            }}
          />
        ) : null}
      </div>

      <div className={styles.body}>
        <h2 className={styles.name}>{pet.nome}</h2>
        {meta ? <p className={styles.meta}>{meta}</p> : null}
        <div className={styles.actions}>
          <Link
            to={`/tutor/pets/${pet.id}/tratamentos`}
            className={styles.prontuarioBtn}
          >
            Ver prontuário
          </Link>
          <Link
            to={`/tutor/pets/${pet.id}/editar`}
            className={styles.editBtn}
          >
            Editar
          </Link>
          <button type="button" className={styles.deleteBtn} onClick={handleDelete}>
            Excluir
          </button>
        </div>
      </div>
    </article>
  );
}
