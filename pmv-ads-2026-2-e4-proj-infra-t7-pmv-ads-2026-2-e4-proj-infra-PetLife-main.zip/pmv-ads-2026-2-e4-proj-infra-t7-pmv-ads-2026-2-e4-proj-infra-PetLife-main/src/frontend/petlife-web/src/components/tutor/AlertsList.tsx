import { ChevronRight } from "lucide-react";
import type { HomeAlert } from "../../services/tutorHomeService";
import styles from "./AlertsList.module.css";

interface AlertsListProps {
  alerts: HomeAlert[];
}

export default function AlertsList({ alerts }: AlertsListProps) {
  return (
    <section className={styles.section} aria-labelledby="alerts-title">
      <div className={styles.sectionHeader}>
        <span className={styles.sectionIcon} role="img" aria-label="Alerta">⚠️</span>
        <h3 id="alerts-title" className={styles.sectionTitle}>
          Alertas e Lembretes
        </h3>
      </div>

      <div className={styles.alertList}>
        {alerts.length === 0 ? (
          <p className={styles.emptyState}>Nenhum alerta ou lembrete pendente.</p>
        ) : (
          alerts.map((item) => (
            <div
              key={item.id}
              className={`${styles.alertCard} ${
                item.accent === "pink" ? styles.borderPink : styles.borderBlue
              }`}
            >
              <div className={styles.contentCol}>
                <span className={styles.petName}>{item.pet}</span>
                <span className={styles.message}>{item.message}</span>
              </div>
              <ChevronRight className={styles.chevronIcon} size={20} strokeWidth={2.2} />
            </div>
          ))
        )}
      </div>
    </section>
  );
}
