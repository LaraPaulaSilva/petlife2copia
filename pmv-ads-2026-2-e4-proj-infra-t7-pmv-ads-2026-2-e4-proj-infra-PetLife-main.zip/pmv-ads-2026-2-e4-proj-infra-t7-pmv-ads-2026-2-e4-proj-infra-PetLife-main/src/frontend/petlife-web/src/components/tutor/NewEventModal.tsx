import { useState, type FormEvent } from "react";
import { Trash2, X } from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";
import {
  criarEvento,
  atualizarEvento,
  apagarEvento,
} from "../../services/eventoRotinaService";
import type { Pet } from "../../types";
import styles from "./NewEventModal.module.css";

export type EventoParaEditar = {
  id: string;
  petId: string;
  tipo: string;
  data: string;
  hora: string;
  observacoes: string;
  status: string;
};

type Props = {
  pets: Pet[];
  evento?: EventoParaEditar;
  aoFechar: () => void;
  aoSalvar: () => void;
};

function somarDias(data: string, hora: string, dias: number) {
  const d = new Date(`${data}T${hora}:00`);
  d.setDate(d.getDate() + dias);
  const p = (n: number) => String(n).padStart(2, "0");
  return (
    d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) +
    "T" + p(d.getHours()) + ":" + p(d.getMinutes()) + ":00"
  );
}

export default function NewEventModal({
  pets,
  evento,
  aoFechar,
  aoSalvar,
}: Props) {
  const { user } = useAuth();
  const editando = evento !== undefined;

  const [petId, setPetId] = useState(
    evento ? evento.petId : pets.length > 0 ? pets[0].id : ""
  );
  const [tipo, setTipo] = useState(evento ? evento.tipo.toLowerCase() : "vacina");
  const [data, setData] = useState(evento ? evento.data : "");
  const [hora, setHora] = useState(evento ? evento.hora : "");
  const [recorrente, setRecorrente] = useState(false);
  const [intervaloDias, setIntervaloDias] = useState("30");
  const [quantidade, setQuantidade] = useState("6");
  const [observacoes, setObservacoes] = useState(evento ? evento.observacoes : "");
  const [salvando, setSalvando] = useState(false);
  const [confirmando, setConfirmando] = useState(false);
  const [erro, setErro] = useState("");

  async function enviar(e: FormEvent) {
    e.preventDefault();

    if (!petId) {
      setErro("Escolha um pet.");
      return;
    }

    if (!data) {
      setErro("Escolha a data do evento.");
      return;
    }

    if (!hora) {
      setErro("Escolha o horário do evento.");
      return;
    }

    const intervalo = Number(intervaloDias);
    const vezes = recorrente && !editando ? Number(quantidade) : 1;

    if (recorrente && !editando && (intervalo < 1 || vezes < 1 || vezes > 24)) {
      setErro("Use um intervalo de 1 dia ou mais e de 1 a 24 repetições.");
      return;
    }

    setSalvando(true);
    setErro("");

    try {
      if (editando && evento) {
        await atualizarEvento(evento.id, {
          userId: user?.id ?? "",
          petId: petId,
          tipo: tipo,
          dataHora: `${data}T${hora}:00`,
          recorrente: false,
          intervaloDias: null,
          observacoes: observacoes,
          status: evento.status,
        });
      } else {
        for (let i = 0; i < vezes; i++) {
          await criarEvento({
            userId: user?.id ?? "",
            petId: petId,
            tipo: tipo,
            dataHora: i === 0 ? `${data}T${hora}:00` : somarDias(data, hora, intervalo * i),
            recorrente: false,
            intervaloDias: null,
            observacoes: observacoes,
            status: "agendado",
          });
        }
      }

      aoSalvar();
    } catch {
      setErro("Não foi possível salvar o evento. Tente novamente.");
      setSalvando(false);
    }
  }

  async function confirmarApagar() {
    if (!evento) return;

    setSalvando(true);
    setErro("");

    try {
      await apagarEvento(evento.id);
      aoSalvar();
    } catch {
      setConfirmando(false);
      setErro("Não foi possível apagar o evento. Tente novamente.");
      setSalvando(false);
    }
  }

  return (
    <div className={styles.fundo} onClick={aoFechar}>
      <div
        className={styles.janela}
        onClick={(e) => e.stopPropagation()}
      >
        <div className={styles.cabecalho}>
          <div className={styles.infoCabecalho}>
            <h2 className={styles.titulo}>
              {editando ? "Editar evento" : "Novo evento"}
            </h2>
            <p className={styles.subtitulo}>
              {editando
                ? "Altere os dados ou apague este compromisso."
                : "Adicione um novo compromisso para o seu pet."}
            </p>
          </div>

          <button
            type="button"
            className={styles.btnFechar}
            onClick={aoFechar}
            aria-label="Fechar modal"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={enviar} className={styles.formulario}>
          <label className={`${styles.campo} ${styles.cheio}`}>
            Pet

            <select
              value={petId}
              onChange={(e) => setPetId(e.target.value)}
              required
            >
              {pets.length === 0 && (
                <option value="">Nenhum pet cadastrado</option>
              )}

              {pets.map((pet) => (
                <option key={pet.id} value={pet.id}>
                  {pet.nome}
                </option>
              ))}
            </select>
          </label>

          <label className={`${styles.campo} ${styles.cheio}`}>
            Tipo

            <select
              value={tipo}
              onChange={(e) => setTipo(e.target.value)}
              required
            >
              <option value="vacina">Vacina</option>
              <option value="vermifugo">Vermífugo</option>
              <option value="antipulgas">Antipulgas</option>
              <option value="consulta">Consulta</option>
              <option value="tosa">Tosa</option>
            </select>
          </label>

          <label className={styles.campo}>
            Data do evento

            <input
              type="date"
              value={data}
              onChange={(e) => setData(e.target.value)}
              required
            />
          </label>

          <label className={styles.campo}>
            Horário do evento

            <input
              type="time"
              value={hora}
              onChange={(e) => setHora(e.target.value)}
              required
            />
          </label>

          {!editando && (
            <label className={`${styles.checkbox} ${styles.cheio}`}>
              <input
                type="checkbox"
                checked={recorrente}
                onChange={(e) => setRecorrente(e.target.checked)}
              />

              Evento recorrente
            </label>
          )}

          {recorrente && !editando && (
            <>
              <label className={styles.campo}>
                Repetir a cada quantos dias?

                <input
                  type="number"
                  min="1"
                  step="1"
                  value={intervaloDias}
                  onChange={(e) => setIntervaloDias(e.target.value)}
                  required
                />
              </label>

              <label className={styles.campo}>
                Quantas vezes no total?

                <input
                  type="number"
                  min="1"
                  max="24"
                  step="1"
                  value={quantidade}
                  onChange={(e) => setQuantidade(e.target.value)}
                  required
                />
              </label>
            </>
          )}

          <label className={`${styles.campo} ${styles.cheio}`}>
            Observações

            <textarea
              rows={3}
              value={observacoes}
              onChange={(e) => setObservacoes(e.target.value)}
              placeholder="Adicione detalhes sobre o evento..."
            />
          </label>

          {erro && (
            <p className={`${styles.erro} ${styles.cheio}`} role="alert">
              {erro}
            </p>
          )}

          <div className={`${styles.botoes} ${styles.cheio}`}>
            {editando && (
              <button
                type="button"
                className={styles.btnApagar}
                onClick={() => setConfirmando(true)}
                disabled={salvando}
              >
                Apagar
              </button>
            )}

            <button
              type="button"
              className={styles.btnCancelar}
              onClick={aoFechar}
              disabled={salvando}
            >
              Cancelar
            </button>

            <button
              type="submit"
              className={styles.btnSalvar}
              disabled={salvando || pets.length === 0}
            >
              {salvando ? "Salvando..." : editando ? "Salvar alterações" : "Salvar"}
            </button>
          </div>
        </form>
      </div>

      {confirmando && (
        <div
          className={styles.fundoConfirmacao}
          onClick={(e) => {
            e.stopPropagation();
            setConfirmando(false);
          }}
        >
          <div
            className={styles.confirmacao}
            onClick={(e) => e.stopPropagation()}
          >
            <div className={styles.iconeConfirmacao}>
              <Trash2 size={26} />
            </div>

            <h3 className={styles.tituloConfirmacao}>Apagar evento?</h3>
            <p className={styles.textoConfirmacao}>
              Esta ação não pode ser desfeita. O evento será removido do calendário.
            </p>

            <div className={styles.botoesConfirmacao}>
              <button
                type="button"
                className={styles.btnCancelar}
                onClick={() => setConfirmando(false)}
                disabled={salvando}
              >
                Cancelar
              </button>

              <button
                type="button"
                className={styles.btnConfirmarApagar}
                onClick={confirmarApagar}
                disabled={salvando}
              >
                {salvando ? "Apagando..." : "Sim, apagar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}