import type { Pet, Share } from "../../types";
import { formatPetCardMeta } from "../../services/petService";
import styles from "./SharePetCard.module.css";
import SharePetButton from "./SharePetButton";

interface SharePetCardProps {
  pet: Pet;
  vetId: string;
  shares: Share[];
}

export default function SharePetCard({
  pet,
  vetId,
  shares,
}: SharePetCardProps) {
  const meta = formatPetCardMeta(pet);

  const alreadyShared =
    shares.find((s: Share) => s.pet_id === pet.id && s.vet_id === vetId) ??
    null;

  return (
    <article className={styles.card}>
      <div
        className={styles.photoStrip}
        aria-hidden={pet.foto_url ? undefined : true}
      >
        {pet.foto_url ? (
          <img
            src={pet.foto_url}
            alt={pet.nome}
            className={styles.photo}
            onError={(e) => {
              (e.target as HTMLElement).style.display = "none";
            }}
          />
        ) : null}
      </div>

      <div className={styles.body}>
        <h2 className={styles.name}>{pet.nome}</h2>
        {meta ? <p className={styles.meta}>{meta}</p> : null}
        <div className={styles.actions}>
          <SharePetButton id={pet.id} vetId={vetId} share={alreadyShared} />
        </div>
      </div>
    </article>
  );
}
