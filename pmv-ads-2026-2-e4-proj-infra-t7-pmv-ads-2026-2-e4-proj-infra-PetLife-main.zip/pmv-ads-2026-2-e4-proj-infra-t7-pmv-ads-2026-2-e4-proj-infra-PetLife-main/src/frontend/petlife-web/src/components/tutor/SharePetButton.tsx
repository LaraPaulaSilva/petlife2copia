import { Share as ShareIcon } from "lucide-react";
import styles from "./SharePetButton.module.css";
import api, { baseURL } from "../../api/client";
import { useState } from "react";
import { Share } from "../../types";

const SharePetButton = ({
  id,
  vetId,
  share,
}: {
  id: string;
  vetId: string;
  share: Share | null;
}) => {
  const [isShared, setIsShared] = useState(!!share);
  const [shareId, setShareId] = useState<string | null>(share?.id ?? null);
  const [loading, setLoading] = useState(false);

  const handleShare = () => {
    setLoading(true);
    if (isShared) {
      return api.delete(`${baseURL}/api/shares/${shareId}`).then(() => {
        setIsShared(false);
        setLoading(false);
      });
    }
    api
      .post(`${baseURL}/api/shares/createshare`, {
        vet_id: vetId,
        pet_id: id,
      })
      .then((data) => {
        setIsShared(true);
        setShareId(data.data.id);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <button
      className={`${styles.sharePetBtn} ${isShared ? styles.shareActive : ""}`}
      onClick={handleShare}
      disabled={loading}
    >
      {isShared ? "Remover compartilhamento" : "Compartilhar"}
      <ShareIcon width={15} className={styles.shareIcon} />
    </button>
  );
};

export default SharePetButton;
