import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import Popup from "./Popup";

describe("Popup", () => {
  it("não renderiza nada quando fechado", () => {
    render(
      <Popup
        isOpen={false}
        title="Erro"
        message="Algo deu errado"
        onClose={vi.fn()}
      />,
    );
    expect(screen.queryByRole("alertdialog")).not.toBeInTheDocument();
  });

  it("exibe título e mensagem quando aberto", () => {
    render(
      <Popup
        isOpen
        title="Não foi possível salvar"
        message="O tutor só pode cadastrar registros históricos."
        onClose={vi.fn()}
      />,
    );
    expect(screen.getByRole("alertdialog")).toBeInTheDocument();
    expect(screen.getByText("Não foi possível salvar")).toBeInTheDocument();
    expect(
      screen.getByText("O tutor só pode cadastrar registros históricos."),
    ).toBeInTheDocument();
  });

  it("dispara onClose ao clicar no botão de confirmação", async () => {
    const user = userEvent.setup();
    const onClose = vi.fn();
    render(
      <Popup isOpen title="Erro" message="Mensagem" onClose={onClose} />,
    );

    await user.click(screen.getByRole("button", { name: "Entendi" }));
    expect(onClose).toHaveBeenCalled();
  });

  it("usa o rótulo de confirmação customizado", () => {
    render(
      <Popup
        isOpen
        title="Pronto"
        message="Salvo com sucesso"
        variant="success"
        confirmLabel="Ok, continuar"
        onClose={vi.fn()}
      />,
    );
    expect(
      screen.getByRole("button", { name: "Ok, continuar" }),
    ).toBeInTheDocument();
  });
});
