import { useEffect } from "react";
import { AlertTriangle } from "lucide-react";
import styles from "./Popup.module.css";

type PopupVariant = "error" | "info" | "success";

interface PopupProps {
  isOpen: boolean;
  title: string;
  message: string;
  variant?: PopupVariant;
  confirmLabel?: string;
  onClose: () => void;
}

export default function Popup({
  isOpen,
  title,
  message,
  variant = "error",
  confirmLabel = "Entendi",
  onClose,
}: PopupProps) {
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className={styles.overlay} role="presentation" onClick={onClose}>
      <div
        className={styles.popup}
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="popup-title"
        aria-describedby="popup-message"
        onClick={(e) => e.stopPropagation()}
      >
        <div className={`${styles.iconBox} ${styles[variant]}`} aria-hidden="true">
          <AlertTriangle size={24} />
        </div>

        <h2 id="popup-title" className={styles.title}>
          {title}
        </h2>
        <p id="popup-message" className={styles.message}>
          {message}
        </p>

        <button type="button" className={styles.confirmBtn} onClick={onClose}>
          {confirmLabel}
        </button>
      </div>
    </div>
  );
}
