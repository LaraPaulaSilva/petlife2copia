import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import type { Consulta } from "../../types";
import ConsultaCard from "./ConsultaCard";

const consulta: Consulta = {
  id: "consulta-1",
  pet_id: "pet-1",
  clinica: "Clínica PetLife Centro",
  data: "2026-10-05",
  hora: "14:30",
  tipo_atendimento: "Consulta de rotina",
  motivo: "Check-up anual",
  status: "REALIZADA",
  origem_registro: "VETERINARIO",
  autor_id: "vet-1",
  valor: 150,
};

describe("ConsultaCard", () => {
  it("exibe tipo, clínica, status e motivo", () => {
    render(<ConsultaCard consulta={consulta} />);

    expect(screen.getByText("Consulta de rotina")).toBeInTheDocument();
    expect(screen.getByText("Clínica PetLife Centro")).toBeInTheDocument();
    expect(screen.getByText("Realizada")).toBeInTheDocument();
    expect(screen.getByText("Check-up anual")).toBeInTheDocument();
    expect(screen.getByText(/05\/10\/2026/)).toBeInTheDocument();
  });

  it("dispara onDelete ao clicar em excluir", async () => {
    const user = userEvent.setup();
    const onDelete = vi.fn();
    render(<ConsultaCard consulta={consulta} onDelete={onDelete} />);

    await user.click(screen.getByRole("button", { name: "Excluir" }));
    expect(onDelete).toHaveBeenCalledWith(consulta);
  });

  it("não renderiza excluir sem callback", () => {
    render(<ConsultaCard consulta={consulta} />);
    expect(screen.queryByRole("button", { name: "Excluir" })).not.toBeInTheDocument();
  });
});
