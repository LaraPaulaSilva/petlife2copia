import { useEffect, useRef, useState, type FormEvent } from "react";
import { X, Paperclip } from "lucide-react";
import FormSection from "./FormSection";
import Popup from "../common/Popup";
import {
  createDocument,
  uploadDocumentFile,
} from "../../services/documentService";
import { fetchConsultasByPet, formatConsultaDate } from "../../services/consultaService";
import { getApiErrorMessage } from "../../utils/apiError";
import type { Consulta, Document } from "../../types";
import styles from "./DocumentFormModal.module.css";

interface DocumentFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated: (document: Document) => void;
  petId: string;
  petName?: string;
  isVet: boolean;
  userId?: string | null;
}

export default function DocumentFormModal({
  isOpen,
  onClose,
  onCreated,
  petId,
  petName,
  isVet,
  userId,
}: DocumentFormModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [titulo, setTitulo] = useState("");
  const [tipoDoc, setTipoDoc] = useState("Exame");
  const [consultaId, setConsultaId] = useState("");
  const [arquivoUrl, setArquivoUrl] = useState("");
  const [fileName, setFileName] = useState("");
  const [consultas, setConsultas] = useState<Consulta[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [errorDialog, setErrorDialog] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (isOpen) {
      setTitulo("");
      setTipoDoc("Exame");
      setConsultaId("");
      setArquivoUrl("");
      setFileName("");
      setError(null);

      if (petId) {
        fetchConsultasByPet(petId)
          .then(setConsultas)
          .catch(() => setConsultas([]));
      }
    }
  }, [isOpen, petId]);

  if (!isOpen) return null;

  const handleFileSelected = async (file: File | undefined) => {
    if (!file) return;

    setError(null);
    setIsUploading(true);
    setFileName(file.name);

    try {
      const url = await uploadDocumentFile(file);
      setArquivoUrl(url);
      if (!titulo.trim()) {
        setTitulo(file.name.replace(/\.[^/.]+$/, ""));
      }
    } catch (err) {
      console.error("Erro ao enviar arquivo:", err);
      setFileName("");
      setErrorDialog(
        getApiErrorMessage(
          err,
          "Não foi possível enviar o arquivo. Tente novamente.",
        ),
      );
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    if (!titulo.trim() || !arquivoUrl.trim()) {
      setError("Preencha o título e envie um arquivo (ou informe a URL).");
      return;
    }

    setError(null);
    setIsSubmitting(true);

    try {
      const created = await createDocument({
        pet_id: petId,
        usuario_id: userId ?? "",
        perfil_autor: isVet ? "Veterinário" : "Tutor",
        consulta_id: consultaId || null,
        titulo: titulo.trim(),
        tipo_doc: tipoDoc.trim() || null,
        arquivo_url: arquivoUrl.trim(),
      });

      onCreated(created);
      onClose();
    } catch (err) {
      console.error("Erro ao salvar documento:", err);
      setErrorDialog(
        getApiErrorMessage(
          err,
          "Não foi possível salvar o documento. Tente novamente.",
        ),
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <div className={styles.overlay} role="presentation" onClick={onClose}>
        <div
          className={styles.modal}
          role="dialog"
          aria-modal="true"
          aria-labelledby="document-modal-title"
          onClick={(e) => e.stopPropagation()}
        >
          <header className={styles.header}>
            <div>
              <h2 id="document-modal-title" className={styles.title}>
                Novo Documento
              </h2>
              {petName && <p className={styles.subtitle}>Pet: {petName}</p>}
            </div>
            <button
              type="button"
              className={styles.closeBtn}
              aria-label="Fechar"
              onClick={onClose}
            >
              <X size={20} />
            </button>
          </header>

          <form className={styles.form} onSubmit={handleSubmit}>
            <div className={styles.body}>
              <button
                type="button"
                className={styles.dropzone}
                onClick={() => fileInputRef.current?.click()}
              >
                <Paperclip size={28} className={styles.dropzoneIcon} />
                <span className={styles.dropzoneTitle}>
                  {isUploading
                    ? "Enviando..."
                    : fileName || "Clique para enviar"}
                </span>
                <span className={styles.dropzoneHint}>PDF, JPG ou PNG</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                className={styles.hiddenInput}
                onChange={(e) => handleFileSelected(e.target.files?.[0])}
              />

              <FormSection title="Dados do documento" badge="Identificação">
                <div className={styles.fieldGroup}>
                  <label htmlFor="titulo" className={styles.label}>
                    Título
                  </label>
                  <input
                    id="titulo"
                    type="text"
                    className={styles.input}
                    placeholder="Ex: Exame de sangue"
                    value={titulo}
                    onChange={(e) => setTitulo(e.target.value)}
                  />
                </div>
                <div className={styles.fieldGroup}>
                  <label htmlFor="tipoDoc" className={styles.label}>
                    Tipo de documento
                  </label>
                  <select
                    id="tipoDoc"
                    className={styles.input}
                    value={tipoDoc}
                    onChange={(e) => setTipoDoc(e.target.value)}
                  >
                    <option value="Exame">Exame</option>
                    <option value="Carteirinha">Carteirinha</option>
                    <option value="Receita">Receita</option>
                    <option value="Atestado">Atestado</option>
                    <option value="Outro">Outro</option>
                  </select>
                </div>
              </FormSection>

              <FormSection title="Vínculo e arquivo" badge="Documentação">
                <div className={styles.fieldGroup}>
                  <label htmlFor="consultaId" className={styles.label}>
                    Vincular à consulta (opcional)
                  </label>
                  <select
                    id="consultaId"
                    className={styles.input}
                    value={consultaId}
                    onChange={(e) => setConsultaId(e.target.value)}
                  >
                    <option value="">Nenhuma</option>
                    {consultas.map((consulta) => (
                      <option key={consulta.id} value={consulta.id}>
                        {consulta.tipo_atendimento} —{" "}
                        {formatConsultaDate(consulta.data)}
                      </option>
                    ))}
                  </select>
                </div>
                <div className={styles.fieldGroup}>
                  <label htmlFor="arquivoUrl" className={styles.label}>
                    URL do arquivo
                  </label>
                  <input
                    id="arquivoUrl"
                    type="url"
                    className={styles.input}
                    placeholder="https://..."
                    value={arquivoUrl}
                    onChange={(e) => setArquivoUrl(e.target.value)}
                  />
                </div>
              </FormSection>

              {error && <p className={styles.errorMsg}>{error}</p>}
            </div>

            <footer className={styles.footer}>
              <button
                type="button"
                className={styles.cancelBtn}
                onClick={onClose}
              >
                Cancelar
              </button>
              <button
                type="submit"
                className={styles.submitBtn}
                disabled={isSubmitting || isUploading}
              >
                {isSubmitting ? "Salvando..." : "Salvar documento"}
              </button>
            </footer>
          </form>
        </div>
      </div>

      <Popup
        isOpen={errorDialog !== null}
        title="Não foi possível salvar"
        message={errorDialog ?? ""}
        variant="error"
        onClose={() => setErrorDialog(null)}
      />
    </>
  );
}
