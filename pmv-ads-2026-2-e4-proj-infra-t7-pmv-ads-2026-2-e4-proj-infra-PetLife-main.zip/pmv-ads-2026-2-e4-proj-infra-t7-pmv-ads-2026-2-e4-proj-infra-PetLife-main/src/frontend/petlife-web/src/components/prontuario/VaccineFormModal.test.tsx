import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import type { Vaccine } from "../../types";
import VaccineFormModal from "./VaccineFormModal";
import { createVaccine } from "../../services/vaccineService";

vi.mock("../../services/vaccineService", async () => {
  const actual = await vi.importActual<typeof import("../../services/vaccineService")>(
    "../../services/vaccineService",
  );
  return {
    ...actual,
    createVaccine: vi.fn(),
  };
});

const mockedCreate = vi.mocked(createVaccine);

const createdVaccine: Vaccine = {
  id: "vaccine-1",
  pet_id: "pet-1",
  tipo: "V10 (Polivalente)",
  data_aplicacao: "2026-10-05",
  origem_registro: "TUTOR",
  alerta_reforco: true,
};

function setup(overrides: Partial<Parameters<typeof VaccineFormModal>[0]> = {}) {
  const onClose = vi.fn();
  const onCreated = vi.fn();
  render(
    <VaccineFormModal
      isOpen
      onClose={onClose}
      onCreated={onCreated}
      petId="pet-1"
      petName="Lulu"
      isVet={false}
      vetId={null}
      {...overrides}
    />,
  );
  return { onClose, onCreated };
}

describe("VaccineFormModal", () => {
  beforeEach(() => {
    mockedCreate.mockReset();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("não renderiza nada quando fechado", () => {
    const onClose = vi.fn();
    const onCreated = vi.fn();
    render(
      <VaccineFormModal
        isOpen={false}
        onClose={onClose}
        onCreated={onCreated}
        petId="pet-1"
        isVet={false}
      />,
    );
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("exibe o título e o nome do pet quando aberto", () => {
    setup();
    expect(screen.getByRole("dialog")).toBeInTheDocument();
    expect(screen.getByText("Nova Vacina")).toBeInTheDocument();
    expect(screen.getByText("Pet: Lulu")).toBeInTheDocument();
  });

  it("bloqueia o envio sem o tipo da vacina", async () => {
    const user = userEvent.setup();
    setup();

    await user.click(screen.getByRole("button", { name: "Salvar vacina" }));

    expect(
      screen.getByText(
        "Preencha pelo menos o tipo da vacina e a data de aplicação.",
      ),
    ).toBeInTheDocument();
    expect(mockedCreate).not.toHaveBeenCalled();
  });

  it("cria a vacina e dispara onCreated e onClose", async () => {
    const user = userEvent.setup();
    mockedCreate.mockResolvedValue(createdVaccine);
    const { onClose, onCreated } = setup();

    await user.type(screen.getByLabelText("Vacina"), "V10 (Polivalente)");
    await user.clear(screen.getByLabelText("Data de aplicação"));
    await user.type(screen.getByLabelText("Data de aplicação"), "2026-10-05");
    await user.type(screen.getByLabelText("Intervalo de reforço (dias)"), "365");
    await user.click(screen.getByRole("button", { name: "Salvar vacina" }));

    await waitFor(() => {
      expect(mockedCreate).toHaveBeenCalledWith({
        pet_id: "pet-1",
        veterinario_id: null,
        tipo: "V10 (Polivalente)",
        data_aplicacao: "2026-10-05",
        intervalo_reforco_dias: 365,
        data_proxima_dose: null,
        comprovante_url: null,
        lote: null,
        fabricante: null,
        laboratorio: null,
        dose: null,
        via_administracao: null,
        local_aplicacao: null,
        situacao: null,
        origem_registro: "TUTOR",
        alerta_reforco: true,
        observacoes: null,
      });
    });

    expect(onCreated).toHaveBeenCalledWith(createdVaccine);
    expect(onClose).toHaveBeenCalled();
  });

  it("fecha ao clicar em cancelar sem gravar", async () => {
    const user = userEvent.setup();
    const { onClose } = setup();

    await user.type(screen.getByLabelText("Vacina"), "Não salva");
    await user.click(screen.getByRole("button", { name: "Cancelar" }));

    expect(onClose).toHaveBeenCalled();
    expect(mockedCreate).not.toHaveBeenCalled();
  });

  it("usa origem veterinário e o id do vet", async () => {
    const user = userEvent.setup();
    mockedCreate.mockResolvedValue({
      ...createdVaccine,
      origem_registro: "VETERINARIO",
    });
    setup({ isVet: true, vetId: "vet-1" });

    await user.type(screen.getByLabelText("Vacina"), "Antirrábica");
    await user.clear(screen.getByLabelText("Data de aplicação"));
    await user.type(screen.getByLabelText("Data de aplicação"), "2026-08-10");
    await user.click(screen.getByRole("button", { name: "Salvar vacina" }));

    await waitFor(() => {
      expect(mockedCreate).toHaveBeenCalledWith(
        expect.objectContaining({
          veterinario_id: "vet-1",
          origem_registro: "VETERINARIO",
        }),
      );
    });
  });
});
