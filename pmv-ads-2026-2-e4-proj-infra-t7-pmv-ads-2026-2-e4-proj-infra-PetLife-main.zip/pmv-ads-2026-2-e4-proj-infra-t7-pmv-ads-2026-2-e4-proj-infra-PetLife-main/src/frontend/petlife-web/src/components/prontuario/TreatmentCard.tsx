import {
  formatTreatmentDetails,
  type TreatmentView,
} from "../../services/treatmentService";
import styles from "./TreatmentCard.module.css";

interface TreatmentCardProps {
  treatment: TreatmentView;
  onEdit?: (treatment: TreatmentView) => void;
  onDelete?: (treatment: TreatmentView) => void;
}

export default function TreatmentCard({
  treatment,
  onEdit,
  onDelete,
}: TreatmentCardProps) {
  return (
    <article className={styles.card}>
      <div className={styles.cardHead}>
        <div className={styles.iconBox} aria-hidden="true">
          💊
        </div>
        <div className={styles.info}>
          <h3 className={styles.medicationName}>{treatment.medicamento}</h3>
          <span className={styles.medicationMeta}>
            {formatTreatmentDetails(treatment)}
          </span>
        </div>
        <span
          className={`${styles.statusBadge} ${
            treatment.ativo ? styles.statusActive : styles.statusCompleted
          }`}
        >
          {treatment.ativo ? "Ativo" : "Concluído"}
        </span>
      </div>

      {(onEdit || onDelete) && (
        <div className={styles.actionsRow}>
          {onEdit && (
            <button
              type="button"
              className={styles.editBtn}
              onClick={() => onEdit(treatment)}
            >
              Editar
            </button>
          )}
          {onDelete && (
            <button
              type="button"
              className={styles.deleteBtn}
              onClick={() => onDelete(treatment)}
            >
              Excluir
            </button>
          )}
        </div>
      )}
    </article>
  );
}