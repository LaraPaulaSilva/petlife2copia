import type { ReactNode } from "react";
import styles from "./FormSection.module.css";

interface FormSectionProps {
  title: string;
  badge?: string;
  children: ReactNode;
}

export default function FormSection({ title, badge, children }: FormSectionProps) {
  return (
    <section className={styles.section}>
      <header className={styles.header}>
        <h2 className={styles.title}>{title}</h2>
        {badge && <span className={styles.badge}>{badge}</span>}
      </header>
      <div className={styles.body}>{children}</div>
    </section>
  );
}
