import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import type { Vaccine } from "../../types";
import VaccineCard from "./VaccineCard";

const vaccine: Vaccine = {
  id: "vaccine-1",
  pet_id: "pet-1",
  tipo: "V10 (Polivalente)",
  data_aplicacao: "2026-10-05",
  data_proxima_dose: "2027-10-05",
  lote: "LT-2026-0987",
  fabricante: "Zoetis",
  origem_registro: "TUTOR",
  alerta_reforco: true,
};

describe("VaccineCard", () => {
  it("exibe tipo, detalhes e datas formatadas", () => {
    render(<VaccineCard vaccine={vaccine} />);

    expect(screen.getByText("V10 (Polivalente)")).toBeInTheDocument();
    expect(screen.getByText("Zoetis • Lote LT-2026-0987")).toBeInTheDocument();
    expect(screen.getByText("05/10/2026")).toBeInTheDocument();
    expect(screen.getByText("05/10/2027")).toBeInTheDocument();
  });

  it("mostra o badge de reforço quando alerta_reforco é verdadeiro", () => {
    render(<VaccineCard vaccine={vaccine} />);
    expect(screen.getByText("Reforço")).toBeInTheDocument();
  });

  it("não mostra o badge de reforço quando alerta_reforco é falso", () => {
    render(<VaccineCard vaccine={{ ...vaccine, alerta_reforco: false }} />);
    expect(screen.queryByText("Reforço")).not.toBeInTheDocument();
  });

  it("não renderiza ações quando nenhum callback é passado", () => {
    render(<VaccineCard vaccine={vaccine} />);
    expect(screen.queryByRole("button", { name: "Editar" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Excluir" })).not.toBeInTheDocument();
  });

  it("dispara onEdit e onDelete ao clicar nos botões", async () => {
    const user = userEvent.setup();
    const onEdit = vi.fn();
    const onDelete = vi.fn();
    render(<VaccineCard vaccine={vaccine} onEdit={onEdit} onDelete={onDelete} />);

    await user.click(screen.getByRole("button", { name: "Editar" }));
    await user.click(screen.getByRole("button", { name: "Excluir" }));

    expect(onEdit).toHaveBeenCalledWith(vaccine);
    expect(onDelete).toHaveBeenCalledWith(vaccine);
  });
});
