import { useEffect, useState, type FormEvent } from "react";
import { X } from "lucide-react";
import {
  createTreatment,
  updateTreatment,
  type TreatmentView,
} from "../../services/treatmentService";
import Popup from "../common/Popup";
import styles from "./TreatmentFormModal.module.css";

interface TreatmentFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved: (treatment: TreatmentView) => void;
  petId: string;
  petName?: string;
  isVet?: boolean;
  vetId?: string;
  treatmentToEdit?: TreatmentView | null;
}

export default function TreatmentFormModal({
  isOpen,
  onClose,
  onSaved,
  petId,
  petName,
  isVet = false,
  vetId,
  treatmentToEdit,
}: TreatmentFormModalProps) {
  const [medicamento, setMedicamento] = useState("");
  const [dose, setDose] = useState("");
  const [frequenciaHoras, setFrequenciaHoras] = useState("");
  const [dataInicio, setDataInicio] = useState("");
  const [dataFim, setDataFim] = useState("");
  const [status, setStatus] = useState<"Ativo" | "Concluído">("Ativo");
  const [observacoes, setObservacoes] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [popupMessage, setPopupMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (treatmentToEdit) {
      setMedicamento(treatmentToEdit.medicamento || "");
      setDose(treatmentToEdit.dose || "");
      setFrequenciaHoras(
        treatmentToEdit.frequencia_horas
          ? String(treatmentToEdit.frequencia_horas)
          : ""
      );
      setDataInicio(treatmentToEdit.data_inicio ? treatmentToEdit.data_inicio.split("T")[0] : "");
      setDataFim(treatmentToEdit.data_fim ? treatmentToEdit.data_fim.split("T")[0] : "");
      setStatus(treatmentToEdit.ativo ? "Ativo" : "Concluído");
      setObservacoes(treatmentToEdit.observacoes || "");
    } else {
      setMedicamento("");
      setDose("");
      setFrequenciaHoras("");
      setDataInicio("");
      setDataFim("");
      setStatus("Ativo");
      setObservacoes("");
    }
    setError(null);
  }, [treatmentToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    if (!medicamento.trim() || !dose.trim() || !dataInicio) {
      setError("Preencha pelo menos o medicamento, a dose e a data de início.");
      return;
    }

    setError(null);
    setIsSubmitting(true);

    try {
      const payload = {
        pet_id: petId,
        veterinario_id: isVet ? vetId ?? null : null,
        medicamento: medicamento.trim(),
        dose: dose.trim(),
        frequencia_horas: frequenciaHoras ? Number(frequenciaHoras) : null,
        data_inicio: dataInicio,
        data_fim: dataFim || null,
        ativo: status === "Ativo",
        observacoes: observacoes.trim() || null,
      };

      let result: TreatmentView;
      if (treatmentToEdit) {
        result = await updateTreatment(treatmentToEdit.id, payload);
      } else {
        result = await createTreatment(payload);
      }

      onSaved(result);
      onClose();
    } catch {
      setPopupMessage("Não foi possível salvar o tratamento. Tente novamente.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <div className={styles.overlay} role="presentation" onClick={onClose}>
        <div
          className={styles.modal}
          role="dialog"
          aria-modal="true"
          onClick={(e) => e.stopPropagation()}
        >
          <div className={styles.header}>
            <div>
              <h2 className={styles.title}>
                {treatmentToEdit ? "Editar Tratamento" : "Novo Tratamento"}
              </h2>
              <p className={styles.subtitle}>Pet: {petName || "Lulu"}</p>
            </div>
            <button
              type="button"
              className={styles.closeBtn}
              onClick={onClose}
              aria-label="Fechar"
            >
              <X size={18} />
            </button>
          </div>

          <form className={styles.form} onSubmit={handleSubmit}>
            <div className={styles.body}>
              <div className={styles.fieldGroup}>
                <label htmlFor="medicamento" className={styles.label}>
                  Medicamento
                </label>
                <input
                  id="medicamento"
                  type="text"
                  className={styles.input}
                  placeholder="Ex: Omeprazol"
                  value={medicamento}
                  onChange={(e) => setMedicamento(e.target.value)}
                />
              </div>

              <div className={styles.fieldRow}>
                <div className={styles.fieldGroup}>
                  <label htmlFor="dose" className={styles.label}>
                    Dose
                  </label>
                  <input
                    id="dose"
                    type="text"
                    className={styles.input}
                    placeholder="Ex: 10 mg"
                    value={dose}
                    onChange={(e) => setDose(e.target.value)}
                  />
                </div>

                <div className={styles.fieldGroup}>
                  <label htmlFor="frequencia" className={styles.label}>
                    Frequência (horas)
                  </label>
                  <input
                    id="frequencia"
                    type="number"
                    min={1}
                    className={styles.input}
                    placeholder="Ex: 24"
                    value={frequenciaHoras}
                    onChange={(e) => setFrequenciaHoras(e.target.value)}
                  />
                </div>
              </div>

              <div className={styles.fieldRow}>
                <div className={styles.fieldGroup}>
                  <label htmlFor="dataInicio" className={styles.label}>
                    Data de início
                  </label>
                  <input
                    id="dataInicio"
                    type="date"
                    className={styles.input}
                    value={dataInicio}
                    onChange={(e) => setDataInicio(e.target.value)}
                  />
                </div>

                <div className={styles.fieldGroup}>
                  <label htmlFor="dataFim" className={styles.label}>
                    Data de fim
                  </label>
                  <input
                    id="dataFim"
                    type="date"
                    className={styles.input}
                    value={dataFim}
                    onChange={(e) => setDataFim(e.target.value)}
                  />
                </div>
              </div>

              <div className={styles.fieldGroup}>
                <label htmlFor="status" className={styles.label}>
                  Status
                </label>
                <select
                  id="status"
                  className={styles.select}
                  value={status}
                  onChange={(e) =>
                    setStatus(e.target.value as "Ativo" | "Concluído")
                  }
                >
                  <option value="Ativo">Ativo</option>
                  <option value="Concluído">Concluído</option>
                </select>
              </div>

              <div className={styles.fieldGroup}>
                <label htmlFor="observacoes" className={styles.label}>
                  Observações
                </label>
                <textarea
                  id="observacoes"
                  className={styles.textarea}
                  placeholder="Observações sobre o tratamento..."
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                />
              </div>

              {error && <p className={styles.errorMsg}>{error}</p>}
            </div>

            <div className={styles.footer}>
              <button
                type="button"
                className={styles.cancelBtn}
                onClick={onClose}
              >
                Cancelar
              </button>
              <button
                type="submit"
                className={styles.submitBtn}
                disabled={isSubmitting}
              >
                {isSubmitting ? "Salvando..." : "Salvar alterações"}
              </button>
            </div>
          </form>
        </div>
      </div>

      <Popup
        isOpen={Boolean(popupMessage)}
        title="Não foi possível salvar"
        message={popupMessage ?? ""}
        variant="error"
        onClose={() => setPopupMessage(null)}
      />
    </>
  );
}