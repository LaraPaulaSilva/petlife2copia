import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import type { Consulta, Document } from "../../types";
import ConsultaDetailsModal from "./ConsultaDetailsModal";

const consulta: Consulta = {
  id: "consulta-1",
  pet_id: "pet-1",
  clinica: "Clínica PetLife Centro",
  data: "2026-10-05",
  hora: "14:30",
  tipo_atendimento: "Consulta de rotina",
  motivo: "Check-up anual",
  status: "REALIZADA",
  origem_registro: "VETERINARIO",
  autor_id: "vet-1",
  descricao_clinica: "Animal saudável, sem alterações.",
  valor: 150,
};

const documentos: Document[] = [
  {
    id: "doc-1",
    pet_id: "pet-1",
    usuario_id: "vet-1",
    consulta_id: "consulta-1",
    titulo: "Exame de sangue",
    tipo_doc: "Exame",
    arquivo_url: "https://cloudinary.com/exame.pdf",
  },
];

describe("ConsultaDetailsModal", () => {
  it("não renderiza quando fechado", () => {
    render(
      <ConsultaDetailsModal
        isOpen={false}
        onClose={vi.fn()}
        consulta={consulta}
        documentos={[]}
      />,
    );
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("exibe todos os dados da consulta", () => {
    render(
      <ConsultaDetailsModal
        isOpen
        onClose={vi.fn()}
        consulta={consulta}
        documentos={[]}
      />,
    );

    expect(screen.getByText("Detalhes da consulta")).toBeInTheDocument();
    expect(screen.getByText("Clínica PetLife Centro")).toBeInTheDocument();
    expect(screen.getByText("Check-up anual")).toBeInTheDocument();
    expect(
      screen.getByText("Animal saudável, sem alterações."),
    ).toBeInTheDocument();
    expect(screen.getByText("Realizada")).toBeInTheDocument();
  });

  it("lista os documentos vinculados com link", () => {
    render(
      <ConsultaDetailsModal
        isOpen
        onClose={vi.fn()}
        consulta={consulta}
        documentos={documentos}
      />,
    );

    expect(screen.getByText("Exame de sangue")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Abrir" })).toHaveAttribute(
      "href",
      "https://cloudinary.com/exame.pdf",
    );
  });

  it("mostra estado vazio quando não há documentos vinculados", () => {
    render(
      <ConsultaDetailsModal
        isOpen
        onClose={vi.fn()}
        consulta={consulta}
        documentos={[]}
      />,
    );

    expect(
      screen.getByText("Nenhum documento vinculado a esta consulta."),
    ).toBeInTheDocument();
  });
});
