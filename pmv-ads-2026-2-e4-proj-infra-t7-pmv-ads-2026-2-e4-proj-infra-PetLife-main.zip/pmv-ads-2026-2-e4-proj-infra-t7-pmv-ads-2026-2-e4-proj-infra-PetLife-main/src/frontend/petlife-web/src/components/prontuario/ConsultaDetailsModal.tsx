import { useEffect } from "react";
import { X, FileText } from "lucide-react";
import {
  STATUS_CONSULTA_LABEL,
  formatConsultaDate,
  formatConsultaValor,
} from "../../services/consultaService";
import type { Consulta, Document } from "../../types";
import styles from "./ConsultaDetailsModal.module.css";

interface ConsultaDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  consulta: Consulta | null;
  documentos: Document[];
}

export default function ConsultaDetailsModal({
  isOpen,
  onClose,
  consulta,
  documentos,
}: ConsultaDetailsModalProps) {
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !consulta) return null;

  const rows: { label: string; value: string }[] = [
    { label: "Tipo de atendimento", value: consulta.tipo_atendimento || "—" },
    { label: "Status", value: STATUS_CONSULTA_LABEL[consulta.status] },
    { label: "Clínica", value: consulta.clinica || "—" },
    { label: "Data", value: formatConsultaDate(consulta.data) || "—" },
    { label: "Hora", value: consulta.hora || "—" },
    { label: "Valor", value: formatConsultaValor(consulta.valor) || "—" },
    { label: "Motivo", value: consulta.motivo || "—" },
  ];

  // Campos clínicos do veterinário: exibidos apenas quando preenchidos
  const clinicalRows: { label: string; value: string }[] = [];
  if (consulta.peso_kg != null) {
    clinicalRows.push({ label: "Peso (kg)", value: String(consulta.peso_kg) });
  }
  if (consulta.temperatura_c != null) {
    clinicalRows.push({
      label: "Temperatura (°C)",
      value: String(consulta.temperatura_c),
    });
  }
  if (consulta.descricao_clinica) {
    clinicalRows.push({
      label: "Exame clínico",
      value: consulta.descricao_clinica,
    });
  }
  if (consulta.diagnostico) {
    clinicalRows.push({ label: "Diagnóstico", value: consulta.diagnostico });
  }
  if (consulta.conduta) {
    clinicalRows.push({
      label: "Conduta e orientações",
      value: consulta.conduta,
    });
  }
  if (consulta.retorno_previsto) {
    clinicalRows.push({
      label: "Retorno previsto",
      value: formatConsultaDate(consulta.retorno_previsto) || consulta.retorno_previsto,
    });
  }

  rows.push(...clinicalRows);
  rows.push({ label: "Observações", value: consulta.observacoes || "—" });

  return (
    <div className={styles.overlay} role="presentation" onClick={onClose}>
      <div
        className={styles.modal}
        role="dialog"
        aria-modal="true"
        aria-labelledby="consulta-details-title"
        onClick={(e) => e.stopPropagation()}
      >
        <header className={styles.header}>
          <div>
            <h2 id="consulta-details-title" className={styles.title}>
              Detalhes da consulta
            </h2>
            <p className={styles.subtitle}>{consulta.tipo_atendimento}</p>
          </div>
          <button
            type="button"
            className={styles.closeBtn}
            aria-label="Fechar"
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </header>

        <div className={styles.body}>
          <dl className={styles.detailsGrid}>
            {rows.map((row) => (
              <div key={row.label} className={styles.detailItem}>
                <dt className={styles.detailLabel}>{row.label}</dt>
                <dd className={styles.detailValue}>{row.value}</dd>
              </div>
            ))}
          </dl>

          <div className={styles.docsSection}>
            <h3 className={styles.docsTitle}>Documentos vinculados</h3>
            {documentos.length === 0 ? (
              <p className={styles.docsEmpty}>
                Nenhum documento vinculado a esta consulta.
              </p>
            ) : (
              <ul className={styles.docsList}>
                {documentos.map((doc) => (
                  <li key={doc.id} className={styles.docItem}>
                    <FileText size={16} aria-hidden="true" />
                    <span className={styles.docName}>{doc.titulo}</span>
                    <a
                      className={styles.docLink}
                      href={doc.arquivo_url}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Abrir
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <footer className={styles.footer}>
          <button type="button" className={styles.closeActionBtn} onClick={onClose}>
            Fechar
          </button>
        </footer>
      </div>
    </div>
  );
}
