import { useEffect, useState, type FormEvent } from "react";
import { X } from "lucide-react";
import FormSection from "./FormSection";
import Popup from "../common/Popup";
import { createVaccine } from "../../services/vaccineService";
import { getApiErrorMessage } from "../../utils/apiError";
import type { Vaccine } from "../../types";
import styles from "./VaccineFormModal.module.css";

interface VaccineFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated: (vaccine: Vaccine) => void;
  petId: string;
  petName?: string;
  isVet: boolean;
  vetId?: string | null;
}

const SITUACAO_OPTIONS = ["Agendada", "Pendente", "Concluída"] as const;

function todayInputValue(): string {
  return new Date().toISOString().split("T")[0];
}

export default function VaccineFormModal({
  isOpen,
  onClose,
  onCreated,
  petId,
  petName,
  isVet,
  vetId,
}: VaccineFormModalProps) {
  const [tipo, setTipo] = useState("");
  const [dataAplicacao, setDataAplicacao] = useState(todayInputValue());
  const [fabricante, setFabricante] = useState("");
  const [lote, setLote] = useState("");
  const [laboratorio, setLaboratorio] = useState("");
  const [dose, setDose] = useState("");
  const [viaAdministracao, setViaAdministracao] = useState("");
  const [localAplicacao, setLocalAplicacao] = useState("");
  const [intervaloReforco, setIntervaloReforco] = useState("");
  const [dataProximaDose, setDataProximaDose] = useState("");
  const [situacao, setSituacao] = useState<string>("Agendada");
  const [comprovanteUrl, setComprovanteUrl] = useState("");
  const [observacoes, setObservacoes] = useState("");
  const [alertaReforco, setAlertaReforco] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [errorDialog, setErrorDialog] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (isOpen) {
      setTipo("");
      setDataAplicacao(todayInputValue());
      setFabricante("");
      setLote("");
      setLaboratorio("");
      setDose("");
      setViaAdministracao("");
      setLocalAplicacao("");
      setIntervaloReforco("");
      setDataProximaDose("");
      setSituacao("Agendada");
      setComprovanteUrl("");
      setObservacoes("");
      setAlertaReforco(true);
      setError(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    if (!tipo.trim() || !dataAplicacao) {
      setError("Preencha pelo menos o tipo da vacina e a data de aplicação.");
      return;
    }

    setError(null);
    setIsSubmitting(true);

    try {
      const created = await createVaccine({
        pet_id: petId,
        veterinario_id: isVet ? vetId ?? null : null,
        tipo: tipo.trim(),
        data_aplicacao: dataAplicacao,
        intervalo_reforco_dias: intervaloReforco ? Number(intervaloReforco) : null,
        data_proxima_dose: dataProximaDose || null,
        comprovante_url: comprovanteUrl.trim() || null,
        lote: lote.trim() || null,
        fabricante: fabricante.trim() || null,
        // Campos clínicos exclusivos do veterinário
        laboratorio: isVet ? laboratorio.trim() || null : null,
        dose: isVet ? dose.trim() || null : null,
        via_administracao: isVet ? viaAdministracao.trim() || null : null,
        local_aplicacao: isVet ? localAplicacao.trim() || null : null,
        situacao: isVet ? situacao || null : null,
        origem_registro: isVet ? "VETERINARIO" : "TUTOR",
        alerta_reforco: alertaReforco,
        observacoes: observacoes.trim() || null,
      });

      onCreated(created);
      onClose();
    } catch (err) {
      console.error("Erro ao salvar vacina:", err);
      setErrorDialog(
        getApiErrorMessage(
          err,
          "Não foi possível salvar a vacina. Tente novamente.",
        ),
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
    <div
      className={styles.overlay}
      role="presentation"
      onClick={onClose}
    >
      <div
        className={styles.modal}
        role="dialog"
        aria-modal="true"
        aria-labelledby="vaccine-modal-title"
        onClick={(e) => e.stopPropagation()}
      >
        <header className={styles.header}>
          <div>
            <h2 id="vaccine-modal-title" className={styles.title}>
              {isVet ? "Registrar vacinação" : "Nova Vacina"}
            </h2>
            {petName && <p className={styles.subtitle}>Pet: {petName}</p>}
          </div>
          <button
            type="button"
            className={styles.closeBtn}
            aria-label="Fechar"
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </header>

        <form className={styles.form} onSubmit={handleSubmit}>
          <div className={styles.body}>
            <FormSection title="Dados da vacina" badge="Aplicação">
              <div className={styles.fieldRow}>
                <div className={styles.fieldGroup}>
                  <label htmlFor="tipo" className={styles.label}>
                    Vacina
                  </label>
                  <input
                    id="tipo"
                    type="text"
                    className={styles.input}
                    placeholder="Ex: V10 (Polivalente)"
                    value={tipo}
                    onChange={(e) => setTipo(e.target.value)}
                  />
                </div>
                <div className={styles.fieldGroup}>
                  <label htmlFor="dataAplicacao" className={styles.label}>
                    Data de aplicação
                  </label>
                  <input
                    id="dataAplicacao"
                    type="date"
                    className={styles.input}
                    value={dataAplicacao}
                    onChange={(e) => setDataAplicacao(e.target.value)}
                  />
                </div>
              </div>
              <div className={styles.fieldRow}>
                <div className={styles.fieldGroup}>
                  <label htmlFor="fabricante" className={styles.label}>
                    Fabricante
                  </label>
                  <input
                    id="fabricante"
                    type="text"
                    className={styles.input}
                    placeholder="Ex: Zoetis"
                    value={fabricante}
                    onChange={(e) => setFabricante(e.target.value)}
                  />
                </div>
                <div className={styles.fieldGroup}>
                  <label htmlFor="lote" className={styles.label}>
                    Lote
                  </label>
                  <input
                    id="lote"
                    type="text"
                    className={styles.input}
                    placeholder="Ex: LT-2026-0987"
                    value={lote}
                    onChange={(e) => setLote(e.target.value)}
                  />
                </div>
              </div>
              {isVet && (
                <div className={styles.fieldRow}>
                  <div className={styles.fieldGroup}>
                    <label htmlFor="laboratorio" className={styles.label}>
                      Laboratório
                    </label>
                    <input
                      id="laboratorio"
                      type="text"
                      className={styles.input}
                      placeholder="Ex: Laboratório Nacional"
                      value={laboratorio}
                      onChange={(e) => setLaboratorio(e.target.value)}
                    />
                  </div>
                  <div className={styles.fieldGroup}>
                    <label htmlFor="dose" className={styles.label}>
                      Dose
                    </label>
                    <input
                      id="dose"
                      type="text"
                      className={styles.input}
                      placeholder="Ex: Reforço anual"
                      value={dose}
                      onChange={(e) => setDose(e.target.value)}
                    />
                  </div>
                </div>
              )}
              {isVet && (
                <div className={styles.fieldRow}>
                  <div className={styles.fieldGroup}>
                    <label htmlFor="viaAdministracao" className={styles.label}>
                      Via de administração
                    </label>
                    <input
                      id="viaAdministracao"
                      type="text"
                      className={styles.input}
                      placeholder="Ex: Subcutânea"
                      value={viaAdministracao}
                      onChange={(e) => setViaAdministracao(e.target.value)}
                    />
                  </div>
                  <div className={styles.fieldGroup}>
                    <label htmlFor="localAplicacao" className={styles.label}>
                      Local de aplicação
                    </label>
                    <input
                      id="localAplicacao"
                      type="text"
                      className={styles.input}
                      placeholder="Ex: Região interescapular"
                      value={localAplicacao}
                      onChange={(e) => setLocalAplicacao(e.target.value)}
                    />
                  </div>
                </div>
              )}
            </FormSection>

            <FormSection title="Próxima vacinação" badge="Planejamento">
              <div className={styles.fieldRow}>
                <div className={styles.fieldGroup}>
                  <label htmlFor="intervaloReforco" className={styles.label}>
                    Intervalo de reforço (dias)
                  </label>
                  <input
                    id="intervaloReforco"
                    type="number"
                    min={1}
                    className={styles.input}
                    placeholder="Ex: 365"
                    value={intervaloReforco}
                    onChange={(e) => setIntervaloReforco(e.target.value)}
                  />
                </div>
                <div className={styles.fieldGroup}>
                  <label htmlFor="dataProximaDose" className={styles.label}>
                    Data prevista
                  </label>
                  <input
                    id="dataProximaDose"
                    type="date"
                    className={styles.input}
                    value={dataProximaDose}
                    onChange={(e) => setDataProximaDose(e.target.value)}
                  />
                </div>
              </div>
              {isVet && (
                <div className={styles.fieldGroup}>
                  <span className={styles.label}>Situação</span>
                  <div className={styles.radioRow}>
                    {SITUACAO_OPTIONS.map((opt) => (
                      <label key={opt} className={styles.radioOption}>
                        <input
                          type="radio"
                          name="situacao"
                          value={opt}
                          checked={situacao === opt}
                          onChange={(e) => setSituacao(e.target.value)}
                        />
                        {opt}
                      </label>
                    ))}
                  </div>
                </div>
              )}
            </FormSection>

            <FormSection title="Comprovante e origem" badge="Documentação">
              <div className={styles.fieldRow}>
                <div className={styles.fieldGroup}>
                  <label htmlFor="comprovante" className={styles.label}>
                    Comprovante (URL)
                  </label>
                  <input
                    id="comprovante"
                    type="url"
                    className={styles.input}
                    placeholder="Link do comprovante/carteirinha"
                    value={comprovanteUrl}
                    onChange={(e) => setComprovanteUrl(e.target.value)}
                  />
                </div>
                <div className={styles.fieldGroup}>
                  <label htmlFor="origem" className={styles.label}>
                    Origem do registro
                  </label>
                  <input
                    id="origem"
                    type="text"
                    className={styles.input}
                    value={isVet ? "Veterinário" : "Tutor"}
                    readOnly
                  />
                </div>
              </div>
            </FormSection>

            <FormSection title="Observações" badge="Notas">
              <div className={styles.fieldGroup}>
                <label htmlFor="observacoes" className={styles.label}>
                  Observações
                </label>
                <textarea
                  id="observacoes"
                  className={styles.textarea}
                  placeholder="Observações sobre a vacinação..."
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                />
              </div>
            </FormSection>

            <FormSection title="Configurações" badge="Alertas">
              <label className={styles.switchRow}>
                <input
                  type="checkbox"
                  className={styles.switchInput}
                  checked={alertaReforco}
                  onChange={(e) => setAlertaReforco(e.target.checked)}
                />
                <span className={styles.switchLabel}>
                  Emitir alerta de reforço
                </span>
              </label>
            </FormSection>

            {error && <p className={styles.errorMsg}>{error}</p>}
          </div>

          <footer className={styles.footer}>
            <button
              type="button"
              className={styles.cancelBtn}
              onClick={onClose}
            >
              Cancelar
            </button>
            <button
              type="submit"
              className={styles.submitBtn}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Salvando..." : "Salvar vacina"}
            </button>
          </footer>
        </form>
      </div>
    </div>

      <Popup
        isOpen={errorDialog !== null}
        title="Não foi possível salvar"
        message={errorDialog ?? ""}
        variant="error"
        onClose={() => setErrorDialog(null)}
      />
    </>
  );
}
