import type { Vaccine } from "../../types";
import {
  formatVaccineDate,
  formatVaccineDetails,
  formatVaccineApplication,
} from "../../services/vaccineService";
import styles from "./VaccineCard.module.css";

interface VaccineCardProps {
  vaccine: Vaccine;
  onEdit?: (vaccine: Vaccine) => void;
  onDelete?: (vaccine: Vaccine) => void;
}

export default function VaccineCard({
  vaccine,
  onEdit,
  onDelete,
}: VaccineCardProps) {
  const details = formatVaccineDetails(vaccine);
  const application = formatVaccineApplication(vaccine);
  const showActions = Boolean(onEdit || onDelete);

  return (
    <article className={styles.card}>
      <div className={styles.cardHead}>
        <div className={styles.iconBox} aria-hidden="true">
          💉
        </div>
        <div className={styles.info}>
          <h3 className={styles.vaccineName}>{vaccine.tipo}</h3>
          {details && <span className={styles.vaccineMeta}>{details}</span>}
        </div>
        {vaccine.situacao ? (
          <span className={styles.reminderBadge}>{vaccine.situacao}</span>
        ) : (
          vaccine.alerta_reforco && (
            <span className={styles.reminderBadge}>Reforço</span>
          )
        )}
      </div>

      {application && (
        <p className={styles.applicationMeta}>{application}</p>
      )}

      <dl className={styles.datesRow}>
        <div className={styles.dateItem}>
          <dt className={styles.dateLabel}>Aplicação</dt>
          <dd className={styles.dateValue}>
            {formatVaccineDate(vaccine.data_aplicacao) || "—"}
          </dd>
        </div>
        <div className={styles.dateItem}>
          <dt className={styles.dateLabel}>Próxima dose</dt>
          <dd className={styles.dateValue}>
            {formatVaccineDate(vaccine.data_proxima_dose) || "—"}
          </dd>
        </div>
      </dl>

      {showActions && (
        <div className={styles.actionsRow}>
          {onEdit && (
            <button
              type="button"
              className={styles.editBtn}
              onClick={() => onEdit(vaccine)}
            >
              Editar
            </button>
          )}
          {onDelete && (
            <button
              type="button"
              className={styles.deleteBtn}
              onClick={() => onDelete(vaccine)}
            >
              Excluir
            </button>
          )}
        </div>
      )}
    </article>
  );
}
