import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import type { Document } from "../../types";
import DocumentCard from "./DocumentCard";

const document: Document = {
  id: "doc-1",
  pet_id: "pet-1",
  usuario_id: "user-1",
  perfil_autor: "Dra. Paula",
  consulta_id: "consulta-1",
  titulo: "Exame de sangue",
  tipo_doc: "Exame",
  arquivo_url: "https://cloudinary.com/exame.pdf",
  data_upload: "2026-10-20",
};

describe("DocumentCard", () => {
  it("exibe título, tipo e info de upload", () => {
    render(<DocumentCard document={document} />);

    expect(screen.getByText("Exame de sangue")).toBeInTheDocument();
    expect(screen.getByText("Exame")).toBeInTheDocument();
    expect(screen.getByText(/Enviado em 20\/10\/2026/)).toBeInTheDocument();
    expect(screen.getByText(/por Dra\. Paula/)).toBeInTheDocument();
    expect(screen.getByText("Vinculado a uma consulta")).toBeInTheDocument();
  });

  it("mostra 'sem vínculo' quando não há consulta", () => {
    render(<DocumentCard document={{ ...document, consulta_id: null }} />);
    expect(screen.getByText("Sem vínculo com consulta")).toBeInTheDocument();
  });

  it("abre o arquivo pelo link e dispara onDelete", async () => {
    const user = userEvent.setup();
    const onDelete = vi.fn();
    render(<DocumentCard document={document} onDelete={onDelete} />);

    const openLink = screen.getByRole("link", { name: "Abrir" });
    expect(openLink).toHaveAttribute("href", "https://cloudinary.com/exame.pdf");

    await user.click(screen.getByRole("button", { name: "Excluir" }));
    expect(onDelete).toHaveBeenCalledWith(document);
  });
});
