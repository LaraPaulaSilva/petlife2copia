import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import TreatmentFormModal from "./TreatmentFormModal";
import * as treatmentService from "../../services/treatmentService";

// O caminho aqui precisa ter exatamente dois ../ para coincidir com o import acima:
vi.mock("../../services/treatmentService", () => ({
  createTreatment: vi.fn(),
  updateTreatment: vi.fn(),
}));

describe("TreatmentFormModal", () => {
  const onClose = vi.fn();
  const onSaved = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("não deve renderizar quando isOpen for falso", () => {
    const { container } = render(
      <TreatmentFormModal
        isOpen={false}
        onClose={onClose}
        onSaved={onSaved}
        petId="pet-1"
      />
    );
    expect(container).toBeEmptyDOMElement();
  });

  it("deve exibir mensagem de erro se campos obrigatórios não forem preenchidos", async () => {
    render(
      <TreatmentFormModal
        isOpen={true}
        onClose={onClose}
        onSaved={onSaved}
        petId="pet-1"
      />
    );

    const submitBtn = screen.getByRole("button", { name: /salvar/i });
    fireEvent.click(submitBtn);

    expect(
      await screen.findByText(
        /preencha pelo menos o medicamento, a dose e a data de início/i
      )
    ).toBeInTheDocument();
    expect(treatmentService.createTreatment).not.toHaveBeenCalled();
  });

  it("deve chamar createTreatment ao submeter novo tratamento válido", async () => {
    const createdMock = {
      id: "novo-id",
      pet_id: "pet-1",
      medicamento: "Omeprazol",
      dose: "10mg",
      frequencia_horas: 24,
      data_inicio: "2026-11-01",
      ativo: true,
    };

    // Usando vi.spyOn para garantir tipagem e rastreamento direto:
    vi.spyOn(treatmentService, "createTreatment").mockResolvedValueOnce(createdMock);

    render(
      <TreatmentFormModal
        isOpen={true}
        onClose={onClose}
        onSaved={onSaved}
        petId="pet-1"
      />
    );

    fireEvent.change(screen.getByLabelText(/medicamento/i), {
      target: { value: "Omeprazol" },
    });
    fireEvent.change(screen.getByLabelText(/dose/i), {
      target: { value: "10mg" },
    });
    fireEvent.change(screen.getByLabelText(/frequência/i), {
      target: { value: "24" },
    });
    fireEvent.change(screen.getByLabelText(/data de início/i), {
      target: { value: "2026-11-01" },
    });

    const submitBtn = screen.getByRole("button", { name: /salvar/i });
    fireEvent.click(submitBtn);

    await waitFor(() => {
      expect(treatmentService.createTreatment).toHaveBeenCalledTimes(1);
      expect(onSaved).toHaveBeenCalledWith(createdMock);
      expect(onClose).toHaveBeenCalledTimes(1);
    });
  });
});