import { Link2 } from "lucide-react";
import type { Document } from "../../types";
import { formatDocumentDate } from "../../services/documentService";
import styles from "./DocumentCard.module.css";

interface DocumentCardProps {
  document: Document;
  consultaLabel?: string | null;
  onDelete?: (document: Document) => void;
}

export default function DocumentCard({
  document,
  consultaLabel,
  onDelete,
}: DocumentCardProps) {
  const vinculoTexto = document.consulta_id
    ? consultaLabel
      ? `Vinculado à consulta de ${consultaLabel}`
      : "Vinculado a uma consulta"
    : "Sem vínculo com consulta";
  const uploadInfo = [
    formatDocumentDate(document.data_upload)
      ? `Enviado em ${formatDocumentDate(document.data_upload)}`
      : null,
    document.perfil_autor ? `por ${document.perfil_autor}` : null,
  ]
    .filter((part): part is string => Boolean(part))
    .join(" • ");

  return (
    <article className={styles.card}>
      <div className={styles.cardHead}>
        <div className={styles.iconBox} aria-hidden="true">
          📄
        </div>
        <div className={styles.info}>
          <h3 className={styles.title}>{document.titulo}</h3>
          {document.tipo_doc && (
            <span className={styles.typeBadge}>{document.tipo_doc}</span>
          )}
        </div>
      </div>

      {uploadInfo && <p className={styles.uploadInfo}>{uploadInfo}</p>}

      <p className={styles.linkInfo}>
        <Link2 size={14} aria-hidden="true" />
        {vinculoTexto}
      </p>

      <div className={styles.actionsRow}>
        <a
          className={styles.openBtn}
          href={document.arquivo_url}
          target="_blank"
          rel="noopener noreferrer"
        >
          Abrir
        </a>
        {onDelete && (
          <button
            type="button"
            className={styles.deleteBtn}
            onClick={() => onDelete(document)}
          >
            Excluir
          </button>
        )}
      </div>
    </article>
  );
}
