import { useEffect, useRef, useState, type FormEvent } from "react";
import { X, Paperclip } from "lucide-react";
import FormSection from "./FormSection";
import Popup from "../common/Popup";
import { createConsulta } from "../../services/consultaService";
import {
  createDocument,
  uploadDocumentFile,
} from "../../services/documentService";
import { getApiErrorMessage } from "../../utils/apiError";
import type { Consulta, StatusConsulta } from "../../types";
import styles from "./VaccineFormModal.module.css";

interface ConsultaFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  /**
   * Chamado após a consulta ser criada com sucesso.
   * `abrirTratamento` indica que o vet pediu para registrar um tratamento,
   * sinalizando à página para abrir o modal de tratamento em seguida.
   */
  onCreated: (consulta: Consulta, abrirTratamento?: boolean) => void;
  petId: string;
  petName?: string;
  isVet: boolean;
  userId?: string | null;
}

const STATUS_OPTIONS: { value: StatusConsulta; label: string }[] = [
  { value: "SOLICITADA", label: "Solicitada" },
  { value: "CONFIRMADA", label: "Confirmada" },
  { value: "REALIZADA", label: "Realizada" },
  { value: "CANCELADA", label: "Cancelada" },
  { value: "NAO_COMPARECEU", label: "Não compareceu" },
];

const TIPO_VET_OPTIONS = ["Rotina", "Retorno", "Emergência", "Acompanhamento"];

function todayInputValue(): string {
  return new Date().toISOString().split("T")[0];
}

export default function ConsultaFormModal({
  isOpen,
  onClose,
  onCreated,
  petId,
  petName,
  isVet,
  userId,
}: ConsultaFormModalProps) {
  const [tipoAtendimento, setTipoAtendimento] = useState(
    isVet ? "Rotina" : "",
  );
  const [clinica, setClinica] = useState("");
  const [data, setData] = useState(todayInputValue());
  const [hora, setHora] = useState("");
  const [status, setStatus] = useState<StatusConsulta>("SOLICITADA");
  const [valor, setValor] = useState("");
  const [motivo, setMotivo] = useState("");
  const [pesoKg, setPesoKg] = useState("");
  const [temperaturaC, setTemperaturaC] = useState("");
  const [descricaoClinica, setDescricaoClinica] = useState("");
  const [diagnostico, setDiagnostico] = useState("");
  const [conduta, setConduta] = useState("");
  const [retornoPrevisto, setRetornoPrevisto] = useState("");

  // Anexo de documento (opcional): se o vet anexar, salva vinculado à consulta
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [docTitulo, setDocTitulo] = useState("");
  const [docTipo, setDocTipo] = useState("Exame");
  const [docArquivoUrl, setDocArquivoUrl] = useState("");
  const [docFileName, setDocFileName] = useState("");
  const [isUploading, setIsUploading] = useState(false);

  // Bloco opcional: ao salvar, abrir o modal de tratamento (a consulta é salva antes)
  const [incluirTratamento, setIncluirTratamento] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [errorDialog, setErrorDialog] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (isOpen) {
      setTipoAtendimento(isVet ? "Rotina" : "");
      setClinica("");
      setData(todayInputValue());
      setHora("");
      setStatus(isVet ? "REALIZADA" : "SOLICITADA");
      setValor("");
      setMotivo("");
      setPesoKg("");
      setTemperaturaC("");
      setDescricaoClinica("");
      setDiagnostico("");
      setConduta("");
      setRetornoPrevisto("");
      setDocTitulo("");
      setDocTipo("Exame");
      setDocArquivoUrl("");
      setDocFileName("");
      setIsUploading(false);
      setIncluirTratamento(false);
      setError(null);
    }
  }, [isOpen, isVet]);

  const handleFileSelected = async (file: File | undefined) => {
    if (!file) return;
    setError(null);
    setIsUploading(true);
    setDocFileName(file.name);
    try {
      const url = await uploadDocumentFile(file);
      setDocArquivoUrl(url);
      if (!docTitulo.trim()) {
        setDocTitulo(file.name.replace(/\.[^/.]+$/, ""));
      }
    } catch (err) {
      console.error("Erro ao enviar arquivo:", err);
      setDocFileName("");
      setErrorDialog(
        getApiErrorMessage(
          err,
          "Não foi possível enviar o arquivo. Tente novamente.",
        ),
      );
    } finally {
      setIsUploading(false);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    if (!tipoAtendimento.trim() || !data) {
      setError("Preencha pelo menos o tipo de atendimento e a data.");
      return;
    }

    if (isVet && !motivo.trim()) {
      setError("Informe a queixa principal do atendimento.");
      return;
    }

    setError(null);
    setIsSubmitting(true);

    try {
      const created = await createConsulta({
        pet_id: petId,
        autor_id: userId ?? "",
        tutor_id: isVet ? null : userId ?? null,
        veterinario_id: isVet ? userId ?? null : null,
        clinica: clinica.trim() || null,
        data,
        hora: hora || null,
        tipo_atendimento: tipoAtendimento.trim(),
        motivo: motivo.trim() || null,
        status,
        origem_registro: isVet ? "VETERINARIO" : "TUTOR",
        descricao_clinica: isVet ? descricaoClinica.trim() || null : null,
        peso_kg: isVet && pesoKg ? Number(pesoKg) : null,
        temperatura_c: isVet && temperaturaC ? Number(temperaturaC) : null,
        diagnostico: isVet ? diagnostico.trim() || null : null,
        conduta: isVet ? conduta.trim() || null : null,
        retorno_previsto: isVet ? retornoPrevisto || null : null,
        valor: valor ? Number(valor) : null,
      });

      // Documento anexado (opcional): salvo automaticamente ligado à consulta.
      // Título = nome do arquivo (preenchido no upload); tipo padrão "Exame".
      if (isVet && docArquivoUrl.trim()) {
        await createDocument({
          pet_id: petId,
          usuario_id: userId ?? "",
          perfil_autor: "Veterinário",
          consulta_id: created.id,
          titulo: docTitulo.trim() || docFileName || "Documento da consulta",
          tipo_doc: docTipo.trim() || "Exame",
          arquivo_url: docArquivoUrl.trim(),
        });
      }

      // Consulta já salva. Se o vet pediu tratamento, sinaliza para a página
      // abrir o modal de tratamento em seguida.
      onCreated(created, isVet && incluirTratamento);
      onClose();
    } catch (err) {
      console.error("Erro ao salvar consulta:", err);
      setErrorDialog(
        getApiErrorMessage(
          err,
          "Não foi possível salvar a consulta. Tente novamente.",
        ),
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <div className={styles.overlay} role="presentation" onClick={onClose}>
        <div
          className={styles.modal}
          role="dialog"
          aria-modal="true"
          aria-labelledby="consulta-modal-title"
          onClick={(e) => e.stopPropagation()}
        >
          <header className={styles.header}>
            <div>
              <h2 id="consulta-modal-title" className={styles.title}>
                {isVet ? "Registrar consulta" : "Nova Consulta"}
              </h2>
              {petName && <p className={styles.subtitle}>Pet: {petName}</p>}
            </div>
            <button
              type="button"
              className={styles.closeBtn}
              aria-label="Fechar"
              onClick={onClose}
            >
              <X size={20} />
            </button>
          </header>

          <form className={styles.form} onSubmit={handleSubmit}>
            <div className={styles.body}>
              <FormSection title="Atendimento" badge="Informações principais">
                {isVet ? (
                  <>
                    <div className={styles.fieldGroup}>
                      <span className={styles.label}>Tipo de consulta</span>
                      <div className={styles.radioRow}>
                        {TIPO_VET_OPTIONS.map((option) => (
                          <label key={option} className={styles.radioOption}>
                            <input
                              type="radio"
                              name="tipoConsulta"
                              value={option}
                              checked={tipoAtendimento === option}
                              onChange={(e) =>
                                setTipoAtendimento(e.target.value)
                              }
                            />
                            <span>{option}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                    <div className={styles.fieldGroup}>
                      <label htmlFor="clinica" className={styles.label}>
                        Clínica
                      </label>
                      <input
                        id="clinica"
                        type="text"
                        className={styles.input}
                        placeholder="Nome da clínica"
                        value={clinica}
                        onChange={(e) => setClinica(e.target.value)}
                      />
                    </div>
                  </>
                ) : (
                  <div className={styles.fieldRow}>
                    <div className={styles.fieldGroup}>
                      <label htmlFor="tipoAtendimento" className={styles.label}>
                        Tipo de atendimento
                      </label>
                      <input
                        id="tipoAtendimento"
                        type="text"
                        className={styles.input}
                        placeholder="Ex: Consulta de rotina"
                        value={tipoAtendimento}
                        onChange={(e) => setTipoAtendimento(e.target.value)}
                      />
                    </div>
                    <div className={styles.fieldGroup}>
                      <label htmlFor="clinica" className={styles.label}>
                        Clínica
                      </label>
                      <input
                        id="clinica"
                        type="text"
                        className={styles.input}
                        placeholder="Nome da clínica"
                        value={clinica}
                        onChange={(e) => setClinica(e.target.value)}
                      />
                    </div>
                  </div>
                )}
              </FormSection>

              <FormSection title="Agendamento" badge="Data e valor">
                <div className={styles.fieldRow}>
                  <div className={styles.fieldGroup}>
                    <label htmlFor="data" className={styles.label}>
                      Data
                    </label>
                    <input
                      id="data"
                      type="date"
                      className={styles.input}
                      value={data}
                      onChange={(e) => setData(e.target.value)}
                    />
                  </div>
                  <div className={styles.fieldGroup}>
                    <label htmlFor="hora" className={styles.label}>
                      Hora
                    </label>
                    <input
                      id="hora"
                      type="time"
                      className={styles.input}
                      value={hora}
                      onChange={(e) => setHora(e.target.value)}
                    />
                  </div>
                </div>
                <div className={styles.fieldRow}>
                  <div className={styles.fieldGroup}>
                    <label htmlFor="status" className={styles.label}>
                      Status
                    </label>
                    <select
                      id="status"
                      className={styles.input}
                      value={status}
                      onChange={(e) =>
                        setStatus(e.target.value as StatusConsulta)
                      }
                    >
                      {STATUS_OPTIONS.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className={styles.fieldGroup}>
                    <label htmlFor="valor" className={styles.label}>
                      Valor (R$)
                    </label>
                    <input
                      id="valor"
                      type="number"
                      min={0}
                      step="0.01"
                      className={styles.input}
                      placeholder="0,00"
                      value={valor}
                      onChange={(e) => setValor(e.target.value)}
                    />
                  </div>
                </div>
              </FormSection>

              {isVet ? (
                <>
                  <FormSection
                    title="Informações clínicas"
                    badge="Preenchido pelo veterinário"
                  >
                    <div className={styles.fieldGroup}>
                      <label htmlFor="motivo" className={styles.label}>
                        Queixa principal
                      </label>
                      <input
                        id="motivo"
                        type="text"
                        className={styles.input}
                        placeholder="Descreva o motivo do atendimento..."
                        value={motivo}
                        onChange={(e) => setMotivo(e.target.value)}
                      />
                    </div>
                    <div className={styles.fieldRow}>
                      <div className={styles.fieldGroup}>
                        <label htmlFor="pesoKg" className={styles.label}>
                          Peso (kg)
                        </label>
                        <input
                          id="pesoKg"
                          type="number"
                          min={0}
                          step="0.1"
                          className={styles.input}
                          placeholder="Ex: 8,5"
                          value={pesoKg}
                          onChange={(e) => setPesoKg(e.target.value)}
                        />
                      </div>
                      <div className={styles.fieldGroup}>
                        <label htmlFor="temperaturaC" className={styles.label}>
                          Temperatura (°C)
                        </label>
                        <input
                          id="temperaturaC"
                          type="number"
                          min={0}
                          step="0.1"
                          className={styles.input}
                          placeholder="Ex: 38,5"
                          value={temperaturaC}
                          onChange={(e) => setTemperaturaC(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className={styles.fieldGroup}>
                      <label htmlFor="descricaoClinica" className={styles.label}>
                        Exame clínico
                      </label>
                      <textarea
                        id="descricaoClinica"
                        className={styles.textarea}
                        placeholder="Observações do veterinário..."
                        value={descricaoClinica}
                        onChange={(e) => setDescricaoClinica(e.target.value)}
                      />
                    </div>
                    <div className={styles.fieldGroup}>
                      <label htmlFor="diagnostico" className={styles.label}>
                        Diagnóstico
                      </label>
                      <textarea
                        id="diagnostico"
                        className={styles.textarea}
                        placeholder="Informe o diagnóstico ou hipótese..."
                        value={diagnostico}
                        onChange={(e) => setDiagnostico(e.target.value)}
                      />
                    </div>
                    <div className={styles.fieldGroup}>
                      <label htmlFor="conduta" className={styles.label}>
                        Conduta e orientações
                      </label>
                      <textarea
                        id="conduta"
                        className={styles.textarea}
                        placeholder="Tratamento, recomendações e cuidados..."
                        value={conduta}
                        onChange={(e) => setConduta(e.target.value)}
                      />
                    </div>
                  </FormSection>

                  <FormSection title="Retorno" badge="Acompanhamento">
                    <div className={styles.fieldGroup}>
                      <label htmlFor="retornoPrevisto" className={styles.label}>
                        Retorno previsto
                      </label>
                      <input
                        id="retornoPrevisto"
                        type="date"
                        className={styles.input}
                        value={retornoPrevisto}
                        onChange={(e) => setRetornoPrevisto(e.target.value)}
                      />
                    </div>
                  </FormSection>

                  <FormSection title="Documento" badge="Opcional">
                    <div className={styles.fieldGroup}>
                      <span className={styles.label}>
                        Anexar um documento a esta consulta
                      </span>
                      <button
                        type="button"
                        className={styles.dropzone}
                        onClick={() => fileInputRef.current?.click()}
                      >
                        <Paperclip size={22} />
                        <span>
                          {isUploading
                            ? "Enviando..."
                            : docFileName || "Clique para anexar (PDF, JPG ou PNG)"}
                        </span>
                      </button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept=".pdf,.jpg,.jpeg,.png"
                        style={{ display: "none" }}
                        onChange={(e) =>
                          handleFileSelected(e.target.files?.[0])
                        }
                      />
                      <p className={styles.helperText}>
                        Opcional. Se anexar, o documento será salvo automaticamente
                        vinculado a esta consulta.
                      </p>
                    </div>
                  </FormSection>

                  <FormSection title="Tratamento" badge="Opcional">
                    <div className={styles.fieldGroup}>
                      <span className={styles.label}>
                        Adicionar um tratamento nesta consulta?
                      </span>
                      <div className={styles.radioRow}>
                        <label className={styles.radioOption}>
                          <input
                            type="radio"
                            name="incluirTratamento"
                            checked={incluirTratamento}
                            onChange={() => setIncluirTratamento(true)}
                          />
                          <span>Sim</span>
                        </label>
                        <label className={styles.radioOption}>
                          <input
                            type="radio"
                            name="incluirTratamento"
                            checked={!incluirTratamento}
                            onChange={() => setIncluirTratamento(false)}
                          />
                          <span>Não</span>
                        </label>
                      </div>
                      {incluirTratamento && (
                        <p className={styles.helperText}>
                          A consulta será salva e, em seguida, abriremos o
                          formulário de tratamento para você preencher.
                        </p>
                      )}
                    </div>
                  </FormSection>
                </>
              ) : (
                <FormSection title="Motivo" badge="Agendamento">
                  <div className={styles.fieldGroup}>
                    <label htmlFor="motivo" className={styles.label}>
                      Motivo
                    </label>
                    <input
                      id="motivo"
                      type="text"
                      className={styles.input}
                      placeholder="Motivo da consulta"
                      value={motivo}
                      onChange={(e) => setMotivo(e.target.value)}
                    />
                  </div>
                </FormSection>
              )}

              {error && <p className={styles.errorMsg}>{error}</p>}
            </div>

            <footer className={styles.footer}>
              <button
                type="button"
                className={styles.cancelBtn}
                onClick={onClose}
              >
                Cancelar
              </button>
              <button
                type="submit"
                className={styles.submitBtn}
                disabled={isSubmitting}
              >
                {isSubmitting
                  ? "Salvando..."
                  : isVet && incluirTratamento
                    ? "Salvar e adicionar tratamento"
                    : "Salvar consulta"}
              </button>
            </footer>
          </form>
        </div>
      </div>

      <Popup
        isOpen={errorDialog !== null}
        title="Não foi possível salvar"
        message={errorDialog ?? ""}
        variant="error"
        onClose={() => setErrorDialog(null)}
      />
    </>
  );
}
