import type { Consulta } from "../../types";
import {
  STATUS_CONSULTA_LABEL,
  formatConsultaDate,
  formatConsultaValor,
} from "../../services/consultaService";
import styles from "./ConsultaCard.module.css";

interface ConsultaCardProps {
  consulta: Consulta;
  onView?: (consulta: Consulta) => void;
  onDelete?: (consulta: Consulta) => void;
}

const STATUS_CLASS: Record<string, string> = {
  SOLICITADA: "statusSolicitada",
  CONFIRMADA: "statusConfirmada",
  REALIZADA: "statusRealizada",
  CANCELADA: "statusCancelada",
  NAO_COMPARECEU: "statusCancelada",
};

export default function ConsultaCard({
  consulta,
  onView,
  onDelete,
}: ConsultaCardProps) {
  const dataHora = [formatConsultaDate(consulta.data), consulta.hora]
    .filter((part): part is string => Boolean(part?.trim()))
    .join(" • ");
  const valor = formatConsultaValor(consulta.valor);
  const statusClass = STATUS_CLASS[consulta.status] ?? "statusSolicitada";

  return (
    <article className={styles.card}>
      <div className={styles.cardHead}>
        <div className={styles.iconBox} aria-hidden="true">
          🩺
        </div>
        <div className={styles.info}>
          <h3 className={styles.consultaTitle}>{consulta.tipo_atendimento}</h3>
          {consulta.clinica && (
            <span className={styles.consultaMeta}>{consulta.clinica}</span>
          )}
        </div>
        <span className={`${styles.statusBadge} ${styles[statusClass]}`}>
          {STATUS_CONSULTA_LABEL[consulta.status]}
        </span>
      </div>

      <dl className={styles.infoRow}>
        <div className={styles.infoItem}>
          <dt className={styles.infoLabel}>Data</dt>
          <dd className={styles.infoValue}>{dataHora || "—"}</dd>
        </div>
        <div className={styles.infoItem}>
          <dt className={styles.infoLabel}>Valor</dt>
          <dd className={styles.infoValue}>{valor || "—"}</dd>
        </div>
      </dl>

      {consulta.motivo && (
        <p className={styles.motivo}>{consulta.motivo}</p>
      )}

      {(onView || onDelete) && (
        <div className={styles.actionsRow}>
          {onView && (
            <button
              type="button"
              className={styles.viewBtn}
              onClick={() => onView(consulta)}
            >
              Ver detalhes
            </button>
          )}
          {onDelete && (
            <button
              type="button"
              className={styles.deleteBtn}
              onClick={() => onDelete(consulta)}
            >
              Excluir
            </button>
          )}
        </div>
      )}
    </article>
  );
}
