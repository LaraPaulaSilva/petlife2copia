import { render, screen, fireEvent } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import TreatmentCard from "./TreatmentCard";
import type { TreatmentView } from "../../services/treatmentService";

const mockTreatment: TreatmentView = {
  id: "tratamento-1",
  pet_id: "pet-1",
  medicamento: "Amoxicilina",
  dose: "250mg",
  frequencia_horas: 12,
  data_inicio: "2026-10-01",
  data_fim: "2026-10-10",
  ativo: true,
  observacoes: "Tomar após a refeição",
};

describe("TreatmentCard", () => {
  it("deve renderizar o nome do medicamento e badge Ativo", () => {
    render(<TreatmentCard treatment={mockTreatment} />);

    expect(screen.getByText("Amoxicilina")).toBeInTheDocument();
    expect(screen.getByText("Ativo")).toBeInTheDocument();
  });

  it("deve renderizar o badge Concluído quando ativo for falso", () => {
    const completedTreatment = { ...mockTreatment, ativo: false };
    render(<TreatmentCard treatment={completedTreatment} />);

    expect(screen.getByText("Concluído")).toBeInTheDocument();
  });

  it("deve disparar os callbacks de edição e exclusão", () => {
    const handleEdit = vi.fn();
    const handleDelete = vi.fn();

    render(
      <TreatmentCard
        treatment={mockTreatment}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />
    );

    const editBtn = screen.getByRole("button", { name: /editar/i });
    const deleteBtn = screen.getByRole("button", { name: /excluir/i });

    fireEvent.click(editBtn);
    expect(handleEdit).toHaveBeenCalledWith(mockTreatment);

    fireEvent.click(deleteBtn);
    expect(handleDelete).toHaveBeenCalledWith(mockTreatment);
  });
});