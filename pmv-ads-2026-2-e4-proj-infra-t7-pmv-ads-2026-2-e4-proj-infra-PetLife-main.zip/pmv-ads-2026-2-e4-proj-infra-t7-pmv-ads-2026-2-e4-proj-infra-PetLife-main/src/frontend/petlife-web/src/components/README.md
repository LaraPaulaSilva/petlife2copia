# components/

Componentes reutilizáveis entre páginas (botões, cards, sidebar, inputs, etc.).

Convenção:
- Um componente por arquivo, em PascalCase: `Sidebar.tsx`, `PetCard.tsx`.
- Estilos em CSS Module ao lado: `Sidebar.module.css`.
- Prefira componentes pequenos e reutilizáveis, usando os tokens de `src/index.css`
  (ex: `var(--color-orange)`, `var(--gradient-brand)`).
