import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  useParams,
} from "react-router-dom";
import HomePage from "../pages/HomePage";
import RegisterPage from "../pages/RegisterPage";
import RegisterRole from "../pages/RegisterRole";
import TutorHomePage from "../pages/tutor/TutorHomePage";
import MyPetsPage from "../pages/tutor/MyPetsPage";
import PetFormPage from "../pages/tutor/PetFormPage";
import VetHomePage from "../pages/vet/VetHomePage";
import VetPatientsPage from "../pages/vet/VetPatientsPage";
import CalendarPage from "../pages/tutor/CalendarPage";
import LoginPage from "../pages/LoginPage";
import AuthHandler from "../components/AuthHandler";
import TreatmentsPage from "../pages/prontuario/TreatmentsPage";
import DiaryPage from "../pages/prontuario/DiaryPage";
import DiaryFormPage from "../pages/prontuario/DiaryFormPage";
import VaccinesPage from "../pages/prontuario/VaccinesPage";
import ConsultasPage from "../pages/prontuario/ConsultasPage";
import DocumentsPage from "../pages/prontuario/DocumentsPage";
import SearchPage from "../pages/tutor/SearchPage";
import ReportsPage from "../pages/vet/ReportsPage";

function VetPatientRedirect() {
  const { petId } = useParams<{ petId: string }>();
  return <Navigate to={`/vet/pacientes/${petId}/consultas`} replace />;
}

export default function AppRouter() {
  return (
    <BrowserRouter>
      <AuthHandler>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/register-role" element={<RegisterRole />} />
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/tutor/pets/:petId/tratamentos"
            element={<TreatmentsPage />}
          />
          <Route
            path="/tutor/pets/:petId/diario/novo"
            element={<DiaryFormPage />}
          />
          <Route path="/tutor/pets/:petId/diario" element={<DiaryPage />} />
          <Route path="/tutor/pets/:petId/vacinas" element={<VaccinesPage />} />
          <Route
            path="/tutor/pets/:petId/consultas"
            element={<ConsultasPage />}
          />
          <Route
            path="/tutor/pets/:petId/documentos"
            element={<DocumentsPage />}
          />
          <Route path="/tutor/pets/novo" element={<PetFormPage />} />
          <Route path="/tutor/pets/:petId/editar" element={<PetFormPage />} />
          <Route path="/tutor/pets" element={<MyPetsPage />} />
          <Route path="/tutor/calendario" element={<CalendarPage />} />
          <Route path="/tutor/buscar" element={<SearchPage />} />
          <Route path="/tutor" element={<TutorHomePage />} />
          <Route path="/tutor/*" element={<TutorHomePage />} />
          <Route
            path="/vet/pacientes/:petId/tratamentos"
            element={<TreatmentsPage />}
          />
          <Route path="/vet/pacientes/:petId/diario" element={<DiaryPage />} />
          <Route
            path="/vet/pacientes/:petId/vacinas"
            element={<VaccinesPage />}
          />
          <Route
            path="/vet/pacientes/:petId/consultas"
            element={<ConsultasPage />}
          />
          <Route
            path="/vet/pacientes/:petId/documentos"
            element={<DocumentsPage />}
          />
          <Route
            path="/vet/pacientes/novo"
            element={<VetPatientsPage defaultOpenNewModal={true} />}
          />
          <Route
            path="/vet/pacientes/:petId"
            element={<VetPatientRedirect />}
          />
          <Route path="/vet/pacientes" element={<VetPatientsPage />} />
          <Route path="/vet" element={<VetHomePage />} />
          <Route path="/vet/*" element={<VetHomePage />} />

          <Route path="/vet/relatorios" element={<ReportsPage />} />
        </Routes>
      </AuthHandler>
    </BrowserRouter>
  );
}
