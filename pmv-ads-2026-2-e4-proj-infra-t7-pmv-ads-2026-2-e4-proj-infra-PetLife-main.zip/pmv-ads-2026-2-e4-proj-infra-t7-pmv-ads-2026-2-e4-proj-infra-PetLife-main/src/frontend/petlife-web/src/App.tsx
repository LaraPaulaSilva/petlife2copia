import { AuthProvider } from "./contexts/AuthContext";
import AppRouter from "./routes/AppRouter";

/**
 * Componente raiz da aplicação PetLife Web.
 * Envolve o roteador com o provedor de autenticação.
 */
export default function App() {
  return (
    <AuthProvider>
      <AppRouter />
    </AuthProvider>
  );
}
