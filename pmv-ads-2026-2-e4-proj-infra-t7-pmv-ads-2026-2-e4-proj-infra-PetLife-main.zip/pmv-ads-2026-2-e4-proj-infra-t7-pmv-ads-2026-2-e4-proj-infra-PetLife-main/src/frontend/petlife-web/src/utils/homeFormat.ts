const MS_PER_DAY = 24 * 60 * 60 * 1000;

export function parseDate(value?: string | null): Date | null {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;
  return date;
}

export function startOfDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

export function daysFromToday(value?: string | null, now = new Date()): number | null {
  const date = parseDate(value);
  if (!date) return null;
  return Math.round((startOfDay(date).getTime() - startOfDay(now).getTime()) / MS_PER_DAY);
}

export function formatPetAge(dataNascimento?: string | null, now = new Date()): string {
  const birth = parseDate(dataNascimento);
  if (!birth) return "Idade não informada";

  let years = now.getFullYear() - birth.getFullYear();
  let months = now.getMonth() - birth.getMonth();
  let days = now.getDate() - birth.getDate();

  if (days < 0) {
    months -= 1;
    const previousMonth = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
    days += previousMonth;
  }
  if (months < 0) {
    years -= 1;
    months += 12;
  }

  if (years < 0) return "Idade não informada";
  if (years >= 1) return years === 1 ? "1 ano" : `${years} anos`;
  if (months >= 1) return months === 1 ? "1 mês" : `${months} meses`;
  if (days <= 1) return "1 dia";
  return `${days} dias`;
}

export function formatWeightKg(peso?: number | null): string {
  if (peso == null || Number.isNaN(peso)) return "Peso não informado";
  return `${peso.toFixed(1).replace(".", ",")} kg`;
}

export function formatDatePt(value?: string | null): string {
  const date = parseDate(value);
  if (!date) return "";
  const day = String(date.getDate()).padStart(2, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  return `${day}/${month}`;
}

export function formatRelativeDate(value?: string | null, now = new Date()): string {
  const date = parseDate(value);
  if (!date) return "";

  const diffMs = now.getTime() - date.getTime();
  const diffMinutes = Math.round(diffMs / (60 * 1000));
  if (Math.abs(diffMinutes) < 1) return "agora";
  if (diffMinutes > 0 && diffMinutes < 60) {
    return diffMinutes === 1 ? "há 1 minuto" : `há ${diffMinutes} minutos`;
  }

  const diffHours = Math.round(diffMs / (60 * 60 * 1000));
  if (diffHours > 0 && diffHours < 24) {
    return diffHours === 1 ? "há 1 hora" : `há ${diffHours} horas`;
  }

  const diffDays = Math.round(diffMs / MS_PER_DAY);
  if (diffDays === 0) return "hoje";
  if (diffDays === 1) return "há 1 dia";
  if (diffDays > 1) return `há ${diffDays} dias`;
  if (diffDays === -1) return "amanhã";
  return formatDatePt(value);
}

export function formatScheduleLabel(value?: string | null, now = new Date()): string {
  const diff = daysFromToday(value, now);
  if (diff == null) return formatDatePt(value) || "data não informada";
  if (diff === 0) return "hoje";
  if (diff === 1) return "amanhã";
  if (diff === -1) return "ontem";
  if (diff > 1) return formatDatePt(value);
  return `há ${Math.abs(diff)} dias`;
}

export function isVeterinarioLabel(value?: string | null): boolean {
  if (!value) return false;
  const normalized = value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
  return normalized.includes("veterinar");
}
