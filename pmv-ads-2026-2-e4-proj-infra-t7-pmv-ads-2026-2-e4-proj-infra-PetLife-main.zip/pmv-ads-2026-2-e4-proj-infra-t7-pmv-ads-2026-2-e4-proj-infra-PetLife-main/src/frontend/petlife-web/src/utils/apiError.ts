import { AxiosError } from "axios";

interface ApiErrorBody {
  Message?: string;
  message?: string;
}

/**
 * Remove o sufixo técnico "(Parameter '...')" que o .NET anexa às mensagens
 * de ArgumentException, deixando apenas o texto voltado ao usuário.
 */
function cleanMessage(message: string): string {
  return message.replace(/\s*\(Parameter '.*?'\)\s*$/, "").trim();
}

/**
 * Extrai uma mensagem de erro legível a partir de um erro do Axios.
 * O backend retorna o corpo no formato { Message: "..." } nas validações,
 * mas aceitamos "message" minúsculo e caímos no fallback quando não houver.
 */
export function getApiErrorMessage(error: unknown, fallback: string): string {
  if (error instanceof AxiosError) {
    const data = error.response?.data as ApiErrorBody | string | undefined;

    if (typeof data === "string" && data.trim()) {
      return cleanMessage(data);
    }

    const message = (data as ApiErrorBody | undefined)?.Message
      ?? (data as ApiErrorBody | undefined)?.message;

    if (message && message.trim()) {
      return cleanMessage(message);
    }
  }

  return fallback;
}
