import { describe, it, expect } from "vitest";
import { AxiosError } from "axios";
import { getApiErrorMessage } from "./apiError";

function makeAxiosError(data: unknown): AxiosError {
  const error = new AxiosError("Request failed");
  error.response = {
    data,
    status: 400,
    statusText: "Bad Request",
    headers: {},
    config: {} as never,
  };
  return error;
}

describe("getApiErrorMessage", () => {
  it("extrai a mensagem do campo Message", () => {
    const error = makeAxiosError({ Message: "Tipo é obrigatório." });
    expect(getApiErrorMessage(error, "fallback")).toBe("Tipo é obrigatório.");
  });

  it("aceita o campo message minúsculo", () => {
    const error = makeAxiosError({ message: "Falha genérica." });
    expect(getApiErrorMessage(error, "fallback")).toBe("Falha genérica.");
  });

  it("remove o sufixo técnico (Parameter '...')", () => {
    const error = makeAxiosError({
      Message:
        "O tutor só pode cadastrar registros históricos. (Parameter 'OrigemRegistro')",
    });
    expect(getApiErrorMessage(error, "fallback")).toBe(
      "O tutor só pode cadastrar registros históricos.",
    );
  });

  it("usa o fallback quando não há corpo de erro", () => {
    const error = makeAxiosError(undefined);
    expect(getApiErrorMessage(error, "fallback")).toBe("fallback");
  });

  it("usa o fallback para erros que não são do Axios", () => {
    expect(getApiErrorMessage(new Error("qualquer"), "fallback")).toBe(
      "fallback",
    );
  });
});
