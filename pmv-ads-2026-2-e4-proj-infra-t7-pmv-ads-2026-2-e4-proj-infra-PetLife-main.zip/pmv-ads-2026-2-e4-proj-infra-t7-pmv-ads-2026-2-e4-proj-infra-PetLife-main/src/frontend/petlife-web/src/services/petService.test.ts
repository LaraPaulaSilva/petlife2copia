import { describe, it, expect, vi, beforeEach } from "vitest";
import api from "../api/client";
import {
  createPet,
  deletePet,
  formatPetCardMeta,
  getPet,
  listPets,
  updatePet,
  uploadPetPhoto,
} from "./petService";
import type { Pet } from "../types";

vi.mock("../api/client", () => ({
  default: {
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    delete: vi.fn(),
  },
}));

const get = vi.mocked(api.get);
const post = vi.mocked(api.post);
const put = vi.mocked(api.put);
const del = vi.mocked(api.delete);

function yearsAgo(years: number): string {
  const date = new Date();
  date.setFullYear(date.getFullYear() - years);
  date.setMonth(date.getMonth() - 1);
  return date.toISOString();
}

const pet: Pet = {
  id: "pet-1",
  nome: "Lulu",
  especie: "Gato",
  raca: "Vira-lata",
  peso_kg: 4.2,
  data_nascimento: yearsAgo(2),
  foto_url: "https://cdn.example/lulu.jpg",
  tutor_id: "tutor-1",
};

describe("petService", () => {
  beforeEach(() => {
    get.mockReset();
    post.mockReset();
    put.mockReset();
    del.mockReset();
  });

  it("lista os pets do tutor autenticado", async () => {
    get.mockResolvedValue({ data: [pet] });

    await expect(listPets()).resolves.toEqual([pet]);
    expect(get).toHaveBeenCalledWith("/api/pets");
  });

  it("devolve lista vazia quando a API não envia um array", async () => {
    get.mockResolvedValue({ data: { message: "ok" } });

    await expect(listPets()).resolves.toEqual([]);
  });

  it("busca um pet por id", async () => {
    get.mockResolvedValue({ data: pet });

    await expect(getPet("pet-1")).resolves.toEqual(pet);
    expect(get).toHaveBeenCalledWith("/api/pets/pet-1");
  });

  it("atualiza um pet sem tutor_id no payload", async () => {
    put.mockResolvedValue({ data: pet });

    const payload = {
      nome: "Lulu",
      especie: "Gato",
      raca: "Vira-lata",
      peso_kg: 4.2,
      data_nascimento: "2024-01-10",
      microchip: "123",
    };

    await expect(updatePet("pet-1", payload)).resolves.toEqual(pet);
    expect(put).toHaveBeenCalledWith("/api/pets/pet-1", payload);
  });

  it("cadastra um pet sem tutor_id no payload", async () => {
    post.mockResolvedValue({ data: pet });

    const payload = {
      nome: "Lulu",
      especie: "Gato",
      raca: "Vira-lata",
      peso_kg: 4.2,
      data_nascimento: "2024-01-10",
      microchip: "123",
    };

    await expect(createPet(payload)).resolves.toEqual(pet);
    expect(post).toHaveBeenCalledWith("/api/pets", payload);
  });

  it("exclui um pet por id", async () => {
    del.mockResolvedValue({ data: undefined });

    await expect(deletePet("pet-1")).resolves.toBeUndefined();
    expect(del).toHaveBeenCalledWith("/api/pets/pet-1");
  });

  it("envia a foto em multipart no campo file", async () => {
    post.mockResolvedValue({ data: pet });
    const file = new File(["foto"], "lulu.jpg", { type: "image/jpeg" });

    await expect(uploadPetPhoto("pet-1", file)).resolves.toEqual(pet);

    expect(post).toHaveBeenCalledTimes(1);
    const [url, body, config] = post.mock.calls[0];
    expect(url).toBe("/api/pets/pet-1/photo");
    expect(body).toBeInstanceOf(FormData);
    expect((body as FormData).get("file")).toBe(file);
    expect(config).toMatchObject({ headers: { "Content-Type": false } });
  });

  it("monta a linha de meta sem raça ou idade ausentes", () => {
    expect(
      formatPetCardMeta({
        ...pet,
        raca: null,
        data_nascimento: null,
      }),
    ).toBe("Gato");

    expect(formatPetCardMeta(pet)).toBe("Gato • Vira-lata • 2 anos");
  });
});
