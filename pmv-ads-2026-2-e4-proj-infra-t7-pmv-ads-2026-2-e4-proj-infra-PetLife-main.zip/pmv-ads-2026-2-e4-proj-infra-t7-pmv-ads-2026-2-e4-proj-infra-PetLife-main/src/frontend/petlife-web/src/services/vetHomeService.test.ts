import { describe, it, expect, vi, beforeEach } from "vitest";
import api from "../api/client";
import { fetchVetHomeData } from "./vetHomeService";
import type { SharedPet } from "../types";

vi.mock("../api/client", () => ({
  default: {
    get: vi.fn(),
  },
}));

const get = vi.mocked(api.get);

function yearsAgo(years: number): string {
  const date = new Date();
  date.setFullYear(date.getFullYear() - years);
  date.setMonth(date.getMonth() - 1);
  return date.toISOString();
}

const sharedPet: SharedPet = {
  id: "pet-1",
  nome: "Mel",
  especie: "Gato",
  raca: "Persa",
  peso_kg: 3,
  data_nascimento: yearsAgo(2),
  foto_url: "https://cdn.example/mel.jpg",
  tutor_id: "tutor-1",
  tutor_nome: "Ana Costa",
  criado_at: new Date().toISOString(),
};

describe("fetchVetHomeData", () => {
  beforeEach(() => {
    get.mockReset();
  });

  it("chama GET /api/pets/shared e devolve lista vazia sem dados de demonstração", async () => {
    get.mockImplementation(async (url) => {
      if (url === "/api/pets/shared") return { data: [] };
      if (url === "/api/Notificacoes") return { data: [] };
      return { data: [] };
    });

    const data = await fetchVetHomeData();

    expect(get).toHaveBeenCalledWith("/api/pets/shared");
    expect(get).toHaveBeenCalledWith("/api/Notificacoes");
    expect(data.patients).toEqual([]);
    expect(data.patientCount).toBe(0);
    expect(data.unreadNotificationsCount).toBe(0);
    expect(JSON.stringify(data)).not.toContain("Lulu");
    expect(JSON.stringify(data)).not.toContain("Dra. Paula");
  });

  it("mapeia pets compartilhados e conta notificações não lidas", async () => {
    get.mockImplementation(async (url) => {
      if (url === "/api/pets/shared") return { data: [sharedPet] };
      if (url === "/api/Notificacoes") {
        return { data: [{ id: "n1", lida: false }, { id: "n2", lida: false }, { id: "n3", lida: true }] };
      }
      return { data: [] };
    });

    const data = await fetchVetHomeData();

    expect(data.patientCount).toBe(1);
    expect(data.unreadNotificationsCount).toBe(2);
    expect(data.patients[0]).toMatchObject({
      id: "pet-1",
      name: "Mel",
      species: "Gato",
      breed: "Persa",
      weight: "3,0 kg",
      tutor: "Ana Costa",
      photo: "https://cdn.example/mel.jpg",
    });
    expect(data.patients[0].age).toBe("2 anos");
  });

  it("usa fallback quando o nome do tutor não vem no payload", async () => {
    get.mockImplementation(async (url) => {
      if (url === "/api/pets/shared") {
        return { data: [{ ...sharedPet, tutor_nome: "" }] };
      }
      if (url === "/api/Notificacoes") return { data: [] };
      return { data: [] };
    });

    const data = await fetchVetHomeData();
    expect(data.patients[0].tutor).toBe("Tutor não informado");
  });

  it("propaga o erro quando a listagem de pacientes falha", async () => {
    get.mockImplementation(async (url) => {
      if (url === "/api/pets/shared") {
        throw new Error("shared offline");
      }
      return { data: [] };
    });

    await expect(fetchVetHomeData()).rejects.toThrow("shared offline");
  });
});
