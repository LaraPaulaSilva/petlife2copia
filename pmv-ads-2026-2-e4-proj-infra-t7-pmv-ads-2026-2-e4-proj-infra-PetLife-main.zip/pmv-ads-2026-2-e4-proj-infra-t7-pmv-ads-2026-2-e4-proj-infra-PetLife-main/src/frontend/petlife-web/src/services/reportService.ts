import api from "../api/client";

export type ReportModuleType =
  | "Todos"
  | "Consulta"
  | "Vacina"
  | "Tratamento"
  | "Diario"
  | "Documento";

export interface PetSummary {
  id: string;
  nome: string;
  especie: string;
  raca?: string;
  peso?: string;
  tutorNome: string;
}

export interface ReportFilters {
  modoRelatorio?: "filtros" | "prontuario_pet";
  tipoModulo?: ReportModuleType;
  tipoRegistro?: string;
  tipoAtendimento?: string;

  tipoPeriodo?: "todos" | "predefinido" | "personalizado";
  periodoDias?: number;
  dataInicio?: string;
  dataFim?: string;

  petId?: string;
  petNome?: string;
  especie?: "Todas" | "Canino" | "Felino" | "Ave" | "Outro";
  tutorNome?: string;

  vacinaTipo?: string;
  vacina?: string;
  vacinaFabricante?: string;
  vacinaLote?: string;
  vacinaOrigem?: "Todas" | "Tutor" | "Veterinário";

  medicamento?: string;
  statusTratamento?:
    | "Todos"
    | "Ativo"
    | "Concluído"
    | "Concluido"
    | "Encerrado"
    | "Cancelado";

  status?: "Todos" | "Ativo" | "Concluido" | "Cancelado" | string;

  termoConsulta?: string;
  tipoConsulta?: "Todas" | "Rotina" | "Retorno" | "Emergência" | "Especialidade";
  termoDiario?: string;

  documentoTitulo?: string;
  documentoTipo?:
    | "Todos"
    | "Exame"
    | "Receita"
    | "Laudo"
    | "Atestado"
    | "Outro";

  ordenacao?:
    | "antigo_recente"
    | "recente_antigo"
    | "data_desc"
    | "data_asc"
    | "pet_asc";

  incluirObservacoes?: boolean;
}

export interface ReportTemplate {
  id: string;
  veterinario_id: string;
  nome: string;
  descricao?: string;
  filtros: ReportFilters;
  criado_em: string;
}

export interface ReportResultItem {
  id: string;
  pacienteNome: string;
  especie: string;
  tutorNome: string;
  categoria: string;
  itemDetalhe: string;
  data: string;
  status: string;
  observacoes: string;
}

export interface GeneratedReportResult {
  titulo: string;
  veterinarioNome: string;
  dataGeracao: string;
  filtrosAplicados: ReportFilters;
  totalRegistros: number;
  itens: ReportResultItem[];
}

const TEMPLATES_STORAGE_KEY = "@petlife:report_templates";

export const DEFAULT_REPORT_FILTERS: ReportFilters = {
  modoRelatorio: "filtros",
  tipoModulo: "Todos",
  tipoRegistro: "Todos",
  tipoPeriodo: "predefinido",
  periodoDias: 30,
  dataInicio: "",
  dataFim: "",

  petId: "",
  petNome: "",
  especie: "Todas",
  tutorNome: "",

  vacinaTipo: "",
  vacina: "",
  vacinaFabricante: "",
  vacinaLote: "",
  vacinaOrigem: "Todas",

  medicamento: "",
  statusTratamento: "Todos",
  status: "Todos",

  termoConsulta: "",
  tipoConsulta: "Todas",
  termoDiario: "",

  documentoTitulo: "",
  documentoTipo: "Todos",

  ordenacao: "antigo_recente",
  incluirObservacoes: true,
};

type RawRecord = Record<string, unknown>;

interface PetRecord {
  id: string;
  nome: string;
  especie: string;
  tutorNome: string;
}

function text(value: unknown): string {
  if (typeof value === "string") return value.trim();
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  return "";
}

function field(record: RawRecord, ...names: string[]): string {
  const entries = Object.entries(record);
  for (const name of names) {
    const wanted = name.toLowerCase().replace(/[_-]/g, "");
    const found = entries.find(
      ([key, value]) =>
        key.toLowerCase().replace(/[_-]/g, "") === wanted &&
        value !== null &&
        value !== undefined,
    );
    if (found) return text(found[1]);
  }
  return "";
}

function asArray(value: unknown): RawRecord[] {
  return Array.isArray(value)
    ? value.filter(
        (item): item is RawRecord =>
          item !== null && typeof item === "object" && !Array.isArray(item),
      )
    : [];
}

function normalize(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
}

function includesText(value: string, search: string): boolean {
  return normalize(value).includes(normalize(search));
}

function normalizeDate(value: string): string {
  if (!value) return "";

  const brDate = value.match(/^(\d{2})\/(\d{2})\/(\d{4})/);
  if (brDate) return `${brDate[3]}-${brDate[2]}-${brDate[1]}`;

  const isoDate = value.match(/^(\d{4}-\d{2}-\d{2})/);
  if (isoDate) return isoDate[1];

  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return "";

  const year = parsed.getFullYear();
  const month = String(parsed.getMonth() + 1).padStart(2, "0");
  const day = String(parsed.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatDate(value: string): string {
  if (!value) return "Sem data";
  const [year, month, day] = value.split("-");
  return year && month && day ? `${day}/${month}/${year}` : value;
}

function parsePet(raw: RawRecord): PetRecord | null {
  const id = field(raw, "id", "_id");
  const nome = field(raw, "nome", "name");
  if (!id || !nome) return null;

  return {
    id,
    nome,
    especie: field(raw, "especie", "species") || "Não informada",
    tutorNome: field(raw, "tutor_nome", "tutorNome", "ownerName") || "Não informado",
  };
}

function parseBoolean(value: unknown): boolean | null {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value !== 0;
  if (typeof value === "string") {
    const normalized = normalize(value);
    if (["true", "1", "sim", "ativo"].includes(normalized)) return true;
    if (["false", "0", "nao", "inativo"].includes(normalized)) return false;
  }
  return null;
}

function mapTreatment(raw: RawRecord, pet: PetRecord): ReportResultItem {
  const medication = field(raw, "medicamento") || "Tratamento";
  const dose = field(raw, "dose");
  const frequency = field(raw, "frequencia_horas", "frequenciaHoras");
  const startDate = normalizeDate(field(raw, "data_inicio", "dataInicio"));
  const endDate = normalizeDate(field(raw, "data_fim", "dataFim"));
  const active = parseBoolean(raw.ativo);
  const status = active === null ? field(raw, "status") || "Não informado" : active ? "Ativo" : "Concluido";

  const details = [
    dose ? `Dose: ${dose}` : "",
    frequency ? `Frequência: a cada ${frequency}h` : "",
    startDate ? `Início: ${formatDate(startDate)}` : "",
    endDate ? `Fim: ${formatDate(endDate)}` : "",
  ]
    .filter(Boolean)
    .join(" | ");

  return {
    id: field(raw, "id", "_id") || `${pet.id}-tratamento-${medication}-${startDate}`,
    pacienteNome: pet.nome,
    especie: pet.especie,
    tutorNome: pet.tutorNome,
    categoria: "Tratamento",
    itemDetalhe: [medication, details].filter(Boolean).join(" — "),
    data: startDate,
    status,
    observacoes: field(raw, "observacoes", "descricao"),
  };
}

function mapVaccine(raw: RawRecord, pet: PetRecord): ReportResultItem {
  const vaccine = field(raw, "tipo", "vacina") || "Vacina";
  const date = normalizeDate(field(raw, "data_aplicacao", "dataAplicacao"));
  const details = [
    field(raw, "fabricante") ? `Fabricante: ${field(raw, "fabricante")}` : "",
    field(raw, "lote") ? `Lote: ${field(raw, "lote")}` : "",
    field(raw, "data_proxima_dose", "dataProximaDose")
      ? `Próxima dose: ${formatDate(normalizeDate(field(raw, "data_proxima_dose", "dataProximaDose")))}`
      : "",
    field(raw, "origem_registro", "origemRegistro")
      ? `Origem: ${field(raw, "origem_registro", "origemRegistro")}`
      : "",
  ]
    .filter(Boolean)
    .join(" | ");

  return {
    id: field(raw, "id", "_id") || `${pet.id}-vacina-${vaccine}-${date}`,
    pacienteNome: pet.nome,
    especie: pet.especie,
    tutorNome: pet.tutorNome,
    categoria: "Vacina",
    itemDetalhe: [vaccine, details].filter(Boolean).join(" — "),
    data: date,
    status: "Concluido",
    observacoes: field(raw, "observacoes"),
  };
}

function mapConsulta(raw: RawRecord, pet: PetRecord): ReportResultItem {
  const type = field(raw, "tipo_atendimento", "tipoAtendimento");
  const reason = field(raw, "motivo");
  const date = normalizeDate(field(raw, "data"));
  const rawStatus = field(raw, "status");
  const normalizedStatus = normalize(rawStatus);

  let status = rawStatus || "Não informado";
  if (["solicitada", "confirmada"].includes(normalizedStatus)) status = "Ativo";
  if (normalizedStatus === "cancelada") status = "Cancelado";
  if (["realizada", "nao_compareceu"].includes(normalizedStatus)) status = "Concluido";

  const category = normalize(type).includes("cirurg") ? "Cirurgia" : "Consulta";
  const details = [
    type ? `Tipo: ${type}` : "",
    reason ? `Motivo: ${reason}` : "",
    field(raw, "descricao_clinica", "descricaoClinica"),
  ]
    .filter(Boolean)
    .join(" | ");

  return {
    id: field(raw, "id", "_id") || `${pet.id}-consulta-${date}-${type}`,
    pacienteNome: pet.nome,
    especie: pet.especie,
    tutorNome: pet.tutorNome,
    categoria: category,
    itemDetalhe: details || "Consulta",
    data: date,
    status,
    observacoes: field(raw, "observacoes"),
  };
}

function mapDocument(raw: RawRecord, pet: PetRecord): ReportResultItem {
  const title = field(raw, "titulo") || "Documento";
  const type = field(raw, "tipo_doc", "tipoDoc") || "Documento";
  const date = normalizeDate(field(raw, "data_upload", "dataUpload"));

  return {
    id: field(raw, "id", "_id") || `${pet.id}-documento-${title}-${date}`,
    pacienteNome: pet.nome,
    especie: pet.especie,
    tutorNome: pet.tutorNome,
    categoria: "Exame",
    itemDetalhe: `${title} — Tipo: ${type}`,
    data: date,
    status: "Concluido",
    observacoes: "",
  };
}

function mapDiary(raw: RawRecord, pet: PetRecord): ReportResultItem {
  const date = normalizeDate(field(raw, "data_registro", "dataRegistro"));
  const entry = field(raw, "Registro", "registro");
  const tags = Array.isArray(raw.tags) ? raw.tags.map(text).filter(Boolean).join(", ") : "";

  return {
    id: field(raw, "id", "_id") || `${pet.id}-diario-${date}`,
    pacienteNome: pet.nome,
    especie: pet.especie,
    tutorNome: pet.tutorNome,
    categoria: "Diário",
    itemDetalhe: [entry, tags ? `Tags: ${tags}` : ""].filter(Boolean).join(" — "),
    data: date,
    status: "Concluido",
    observacoes: field(raw, "suspeita"),
  };
}

async function fetchRecords(
  path: string,
  petId: string,
): Promise<RawRecord[]> {
  const response = await api.get<unknown>(path, { params: { pet_id: petId } });
  return asArray(response.data);
}

async function collectReportItems(): Promise<ReportResultItem[]> {
  const petsResponse = await api.get<unknown>("/api/pets/shared");
  const pets = asArray(petsResponse.data)
    .map(parsePet)
    .filter((pet): pet is PetRecord => pet !== null);

  const perPet = await Promise.all(
    pets.map(async (pet) => {
      const encodedId = encodeURIComponent(pet.id);
      const [treatments, vaccines, consultations, documents, diary] = await Promise.all([
        fetchRecords(`/api/treatments/pet/${encodedId}`, pet.id),
        fetchRecords("/api/vaccines", pet.id),
        fetchRecords("/api/consultas", pet.id),
        fetchRecords("/api/documents", pet.id),
        fetchRecords("/api/pet-diary", pet.id),
      ]);

      return [
        ...treatments.map((record) => mapTreatment(record, pet)),
        ...vaccines.map((record) => mapVaccine(record, pet)),
        ...consultations.map((record) => mapConsulta(record, pet)),
        ...documents.map((record) => mapDocument(record, pet)),
        ...diary.map((record) => mapDiary(record, pet)),
      ];
    }),
  );

  const unique = new Map<string, ReportResultItem>();
  for (const item of perPet.flat()) {
    const key = `${item.categoria}|${item.id}`;
    if (!unique.has(key)) unique.set(key, item);
  }
  return Array.from(unique.values());
}

function normalizeSpecies(value: string): string {
  const species = normalize(value);
  if (["canino", "cao", "cachorro", "dog"].includes(species)) return "canino";
  if (["felino", "gato", "cat"].includes(species)) return "felino";
  if (["ave", "bird"].includes(species)) return "ave";
  return species;
}

function filterReportItems(
  items: ReportResultItem[],
  filters: ReportFilters,
): ReportResultItem[] {
  const now = new Date();
  const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;

  let startDate = "";
  let endDate = "";

  if (filters.tipoPeriodo === "personalizado") {
    startDate = filters.dataInicio || "";
    endDate = filters.dataFim || "";
  } else if (filters.tipoPeriodo === "predefinido") {
    const days = Math.max(1, filters.periodoDias ?? 30);
    const start = new Date(now);
    start.setDate(start.getDate() - (days - 1));
    startDate = `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, "0")}-${String(start.getDate()).padStart(2, "0")}`;
    endDate = today;
  }

  return items.filter((item) => {
      
    const areaSelecionada = filters.tipoModulo ?? filters.tipoRegistro ?? "Todos";

    const categoriasPorArea: Record<string, string[]> = {
     Consulta: ["Consulta"],
     Vacina: ["Vacina"],
     Tratamento: ["Tratamento"],
     Diario: ["Diario", "Diário"],
     Documento: ["Documento", "Exame"],
    };

    if (areaSelecionada !== "Todos") {
     const categoriasAceitas = categoriasPorArea[areaSelecionada] ?? [areaSelecionada];

    if (
     !categoriasAceitas.some(
       (categoria) => normalize(categoria) === normalize(item.categoria),
     )
    ) {
     return false;
     }
    }

    if (filters.petNome && !includesText(item.pacienteNome, filters.petNome)) return false;
    if (filters.tutorNome && !includesText(item.tutorNome, filters.tutorNome)) return false;

    if (
      filters.especie &&
      filters.especie !== "Todas" &&
      normalizeSpecies(item.especie) !== normalizeSpecies(filters.especie)
    ) {
      return false;
    }

    if (startDate && (!item.data || item.data < startDate)) return false;
    if (endDate && (!item.data || item.data > endDate)) return false;

    if (filters.status && filters.status !== "Todos") {
      if (normalize(item.status) !== normalize(filters.status)) return false;
    }

    if (filters.medicamento && item.categoria === "Tratamento") {
      if (!includesText(item.itemDetalhe, filters.medicamento)) return false;
    }

    if (filters.vacina && item.categoria === "Vacina") {
      if (!includesText(item.itemDetalhe, filters.vacina)) return false;
    }

    if (filters.tipoConsulta && filters.tipoConsulta !== "Todas") {
      if (item.categoria !== "Consulta" && item.categoria !== "Cirurgia") return false;
      if (!includesText(item.itemDetalhe, filters.tipoConsulta)) return false;
    }

    return true;
  });
}

export async function getAvailablePets(): Promise<PetSummary[]> {
  const response = await api.get<unknown>("/api/pets/shared");

  return asArray(response.data)
    .map((raw) => ({
      id: field(raw, "id", "_id"),
      nome: field(raw, "nome", "name"),
      especie: field(raw, "especie", "species") || "Não informada",
      raca: field(raw, "raca", "breed"),
      peso: field(raw, "peso_kg", "peso", "weight"),
      tutorNome:
        field(raw, "tutor_nome", "tutorNome", "ownerName") || "Tutor",
    }))
    .filter((pet) => pet.id && pet.nome);
}

function sortReportItems(
  items: ReportResultItem[],
  order: ReportFilters["ordenacao"],
): ReportResultItem[] {
  return [...items].sort((a, b) => {
    if (order === "pet_asc") {
      return normalize(a.pacienteNome).localeCompare(normalize(b.pacienteNome), "pt-BR");
    }

    const dateA = a.data || "";
    const dateB = b.data || "";
    return order === "data_asc"
      ? dateA.localeCompare(dateB)
      : dateB.localeCompare(dateA);
  });
}

function getFallbackTemplates(): ReportTemplate[] {
  try {
    const raw = localStorage.getItem(TEMPLATES_STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as ReportTemplate[]) : [];
  } catch {
    return [];
  }
}

function saveTemplates(templates: ReportTemplate[]): void {
  localStorage.setItem(TEMPLATES_STORAGE_KEY, JSON.stringify(templates));
}

export async function getTemplatesByVet(vetId: string): Promise<ReportTemplate[]> {
  return getFallbackTemplates().filter((template) => template.veterinario_id === vetId);
}

export async function createReportTemplate(
  payload: Omit<ReportTemplate, "id" | "criado_em">,
): Promise<ReportTemplate> {
  const template: ReportTemplate = {
    ...payload,
    id: `tmpl_${Date.now()}`,
    criado_em: new Date().toISOString(),
  };
  saveTemplates([template, ...getFallbackTemplates()]);
  return template;
}

export async function updateReportTemplate(
  id: string,
  payload: { nome: string; descricao?: string; filtros: ReportFilters },
): Promise<ReportTemplate> {
  const templates = getFallbackTemplates();
  const index = templates.findIndex((template) => template.id === id);

  if (index < 0) {
    throw new Error("Modelo de relatório não encontrado.");
  }

  const updated: ReportTemplate = { ...templates[index], ...payload };
  templates[index] = updated;
  saveTemplates(templates);
  return updated;
}

export async function deleteReportTemplate(id: string): Promise<void> {
  saveTemplates(getFallbackTemplates().filter((template) => template.id !== id));
}

export async function executeReport(
  titulo: string,
  filtros: ReportFilters,
  vetNome: string,
): Promise<GeneratedReportResult> {
  // Se a API falhar, propaga o erro. Não gera PDF com dados de demonstração.
  const allItems = await collectReportItems();
  const filteredItems = sortReportItems(
    filterReportItems(allItems, filtros),
    filtros.ordenacao,
  );

  return {
    titulo,
    veterinarioNome: vetNome,
    dataGeracao: new Date().toLocaleDateString("pt-BR"),
    filtrosAplicados: { ...filtros },
    totalRegistros: filteredItems.length,
    itens: filteredItems,
  };
}

function escapePdfString(text: string): string {
  let result = "";

  const winAnsiSpecial: Record<string, number> = {
    "€": 128,
    "‚": 130,
    "ƒ": 131,
    "„": 132,
    "…": 133,
    "†": 134,
    "‡": 135,
    "ˆ": 136,
    "‰": 137,
    "Š": 138,
    "‹": 139,
    "Œ": 140,
    "Ž": 142,
    "‘": 145,
    "’": 146,
    "“": 147,
    "”": 148,
    "•": 149,
    "–": 150,
    "—": 151,
    "˜": 152,
    "™": 153,
    "š": 154,
    "›": 155,
    "œ": 156,
    "ž": 158,
    "Ÿ": 159,
  };

  for (const character of text) {
    const code = character.charCodeAt(0);

    if (character === "(" || character === ")" || character === "\\") {
      result += `\\${character}`;
    } else if (code >= 32 && code <= 126) {
      result += character;
    } else if (code >= 160 && code <= 255) {
      result += `\\${code.toString(8).padStart(3, "0")}`;
    } else if (winAnsiSpecial[character] !== undefined) {
      result += `\\${winAnsiSpecial[character].toString(8).padStart(3, "0")}`;
    } else {
      result += " ";
    }
  }

  return result;
}

function wrapText(value: string, maxLength: number): string[] {
  const words = value.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = "";

  for (const word of words) {
    const next = current ? `${current} ${word}` : word;
    if (next.length > maxLength && current) {
      lines.push(current);
      current = word;
    } else {
      current = next;
    }
  }

  if (current) lines.push(current);
  return lines.length ? lines : [""];
}

export function downloadReportPdf(report: GeneratedReportResult): void {
  const pageWidth = 595;
  const pageHeight = 842;
  const margin = 40;
  const contentWidth = pageWidth - margin * 2;

  const filters = report.filtrosAplicados;
  const pages: string[][] = [];
  let commands: string[] = [];
  let cursorY = 0;

  const colors = {
    navy: "0.06 0.09 0.16",
    muted: "0.39 0.45 0.55",
    border: "0.86 0.89 0.93",
    card: "0.98 0.99 1",
    orange: "1 0.37 0",
    pink: "0.94 0.16 0.55",
    purple: "0.39 0.40 0.93",
    white: "1 1 1",
  };

  const addText = (
    x: number,
    y: number,
    value: string,
    size = 9,
    bold = false,
    color = colors.navy,
  ) => {
    commands.push(
      `BT ${color} rg /${bold ? "F2" : "F1"} ${size} Tf 1 0 0 1 ${x} ${y} Tm (${escapePdfString(value)}) Tj ET`,
    );
  };


  const formatDate = (value: string): string => {
    if (!value) return "Não informada";

    const match = value.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (match) return `${match[3]}/${match[2]}/${match[1]}`;

    return value;
  };

  const uniqueValues = (values: string[]) =>
    [...new Set(values.map((value) => value.trim()).filter(Boolean))];

  const petNames = uniqueValues(report.itens.map((item) => item.pacienteNome));
  const tutorNames = uniqueValues(report.itens.map((item) => item.tutorNome));

  const patientSummary =
    petNames.length === 0
      ? filters.petNome || "Não informado"
      : petNames.length === 1
        ? petNames[0]
        : `${petNames.length} pacientes`;

  const tutorSummary =
    tutorNames.length === 0
      ? filters.tutorNome || "Não informado"
      : tutorNames.length === 1
        ? tutorNames[0]
        : "Múltiplos tutores";

  
 

  const periodLabel =
    filters.tipoPeriodo === "personalizado"
      ? `${formatDate(filters.dataInicio || "")} a ${formatDate(filters.dataFim || "")}`
      : filters.tipoPeriodo === "predefinido"
        ? `Últimos ${filters.periodoDias ?? 30} dias`
        : "Todo o histórico";

  const startPage = (firstPage: boolean) => {
    if (commands.length > 0) pages.push(commands);
    commands = [];

    // Faixa fina com as cores da marca, sem transformar o cabeçalho em um bloco colorido.
    commands.push(`0.94 0.96 0.98 rg 0 0 ${pageWidth} ${pageHeight} re f`);
    commands.push(`${colors.orange} rg 0 836 198 6 re f`);
    commands.push(`${colors.pink} rg 198 836 198 6 re f`);
    commands.push(`${colors.purple} rg 396 836 199 6 re f`);

    addText(40, 811, "PetLife", 17, true, colors.navy);
    addText(430, 811, "RELATÓRIO CLÍNICO", 8, true, colors.muted);
    addText(40, 783, report.titulo.slice(0, 55), 18, true, colors.navy);
    addText(
      40,
      764,
      "Documento de acompanhamento veterinário",
      9,
      false,
      colors.muted,
    );

    commands.push(`${colors.border} RG 1 w 40 748 m 555 748 l S`);

    if (firstPage) {
      // Resumo do paciente e do período.
      commands.push(`${colors.card} rg 40 666 515 64 re f`);
      commands.push(`${colors.border} RG 1 w 40 666 515 64 re S`);

      addText(54, 713, "PACIENTE", 7, true, colors.muted);
      addText(54, 694, patientSummary.slice(0, 30), 10, true, colors.navy);

      addText(225, 713, "TUTOR", 7, true, colors.muted);
      addText(225, 694, tutorSummary.slice(0, 32), 10, true, colors.navy);

      addText(405, 713, "PERÍODO", 7, true, colors.muted);
      addText(405, 694, periodLabel.slice(0, 26), 9, true, colors.navy);

      addText(
        42,
        647,
        `Veterinário: ${report.veterinarioNome}   |   Emissão: ${report.dataGeracao}   |   Registros: ${report.totalRegistros}`,
        8,
        false,
        colors.muted,
      );

      addText(42, 620, "REGISTROS CLÍNICOS", 8, true, colors.purple);
      cursorY = 603;
    } else {
      addText(42, 725, `${report.titulo.slice(0, 50)} — continuação`, 9, true, colors.muted);
      cursorY = 704;
    }
  };

  startPage(true);

  if (report.itens.length === 0) {
    commands.push(`${colors.card} rg 40 520 515 66 re f`);
    commands.push(`${colors.border} RG 1 w 40 520 515 66 re S`);
    commands.push(`${colors.pink} rg 40 520 4 66 re f`);

    addText(58, 558, "Nenhum registro encontrado", 12, true, colors.navy);
    addText(
      58,
      539,
      "Não foram encontrados registros para o paciente e período selecionados.",
      9,
      false,
      colors.muted,
    );
  } else {
    report.itens.forEach((item) => {
      const category = item.categoria || "Registro";
      const normalizedCategory = category.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

      const categoryColor = normalizedCategory.includes("consulta")
        ? colors.purple
        : normalizedCategory.includes("vacina")
          ? colors.orange
          : colors.pink;

      const rows: Array<{ text: string; bold?: boolean }> = [
        {
          text: `Paciente: ${item.pacienteNome} (${item.especie})`,
          bold: true,
        },
        { text: `Tutor: ${item.tutorNome || "Não informado"}` },
        { text: `Registro: ${item.itemDetalhe || "Não informado"}` },
        {
          text: `Status: ${item.status || "Não informado"}`,
        },
      ];

      if (filters.incluirObservacoes && item.observacoes?.trim()) {
        rows.push({ text: `Observações: ${item.observacoes.trim()}` });
      }

      const wrappedRows = rows.flatMap((row) =>
        wrapText(row.text, 88).map((text) => ({ ...row, text })),
      );

      const cardHeight = 43 + wrappedRows.length * 13;

      if (cursorY - cardHeight < 60) {
        startPage(false);
      }

      const cardBottom = cursorY - cardHeight;

      commands.push(`${colors.white} rg ${margin} ${cardBottom} ${contentWidth} ${cardHeight} re f`);
      commands.push(`${colors.border} RG 1 w ${margin} ${cardBottom} ${contentWidth} ${cardHeight} re S`);
      commands.push(`${categoryColor} rg ${margin} ${cardBottom} 4 ${cardHeight} re f`);

      // Etiqueta da categoria e data do registro.
      commands.push(`${categoryColor} rg 54 ${cursorY - 24} 84 16 re f`);
      addText(60, cursorY - 18, category.slice(0, 20), 7, true, colors.white);
      addText(
        445,
        cursorY - 18,
        formatDate(item.data),
        8,
        true,
        colors.muted,
      );

      let textY = cursorY - 40;
      for (const row of wrappedRows) {
        addText(
          56,
          textY,
          row.text,
          row.bold ? 9 : 8.5,
          row.bold ?? false,
          row.bold ? colors.navy : colors.muted,
        );
        textY -= 13;
      }

      cursorY = cardBottom - 11;
    });
  }

  pages.push(commands);

  // Rodapé consistente com número de página.
  pages.forEach((pageCommands, index) => {
    pageCommands.push(`${colors.border} RG 1 w 40 46 m 555 46 l S`);
    pageCommands.push(
      `BT ${colors.muted} rg /F1 8 Tf 1 0 0 1 40 30 Tm (${escapePdfString("PetLife | Relatório clínico veterinário")}) Tj ET`,
    );
    pageCommands.push(
      `BT ${colors.muted} rg /F1 8 Tf 1 0 0 1 490 30 Tm (${escapePdfString(`Página ${index + 1} de ${pages.length}`)}) Tj ET`,
    );
  });

  const pageObjectIds = pages.map((_, index) => 3 + index * 2);
  const regularFontId = 3 + pages.length * 2;
  const boldFontId = regularFontId + 1;

  const objects: string[] = [
    "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n",
    `2 0 obj\n<< /Type /Pages /Kids [${pageObjectIds.map((id) => `${id} 0 R`).join(" ")}] /Count ${pages.length} >>\nendobj\n`,
  ];

  pages.forEach((pageCommands, index) => {
    const pageId = 3 + index * 2;
    const contentId = pageId + 1;
    const stream = pageCommands.join("\n");

    objects.push(
      `${pageId} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /Font << /F1 ${regularFontId} 0 R /F2 ${boldFontId} 0 R >> >> /Contents ${contentId} 0 R >>\nendobj\n`,
    );

    objects.push(
      `${contentId} 0 obj\n<< /Length ${stream.length} >>\nstream\n${stream}\nendstream\nendobj\n`,
    );
  });

  objects.push(
    `${regularFontId} 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj\n`,
  );
  objects.push(
    `${boldFontId} 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>\nendobj\n`,
  );

  let pdf = "%PDF-1.4\n";
  const offsets = [0];

  for (const object of objects) {
    offsets.push(pdf.length);
    pdf += object;
  }

  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;

  for (let index = 1; index <= objects.length; index++) {
    pdf += `${offsets[index].toString().padStart(10, "0")} 00000 n \n`;
  }

  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;

  const blob = new Blob([pdf], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  const slug = report.titulo
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

  link.href = url;
  link.download = `${slug || "relatorio-clinico"}.pdf`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}