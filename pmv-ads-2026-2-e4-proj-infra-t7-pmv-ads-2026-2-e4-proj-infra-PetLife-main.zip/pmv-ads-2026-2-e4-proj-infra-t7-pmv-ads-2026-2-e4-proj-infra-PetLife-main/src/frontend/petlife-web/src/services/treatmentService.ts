
import api from "../api/client";
import type { Treatment } from "../types";

export interface TreatmentView extends Treatment {
  observacoes?: string | null;
  subtituloFormatado?: string;
}

export interface CreateTreatmentPayload {
  pet_id: string;
  veterinario_id?: string | null;
  medicamento: string;
  dose: string;
  frequencia_horas?: number | null;
  duracao_uso?: string | null;
  recorrencia?: string | null;
  data_inicio: string;
  data_fim?: string | null;
  ativo: boolean;
  observacoes?: string | null;
}

const FALLBACK_STORAGE_KEY = "petlife_treatments_demo";

const DEFAULT_MOCK_TREATMENTS: TreatmentView[] = [
  {
    id: "treat-1",
    pet_id: "pet-1",
    medicamento: "Omeprazol",
    dose: "10 mg",
    frequencia_horas: 24,
    data_inicio: "2026-10-01",
    ativo: true,
    subtituloFormatado: "10 mg • a cada 24h • início 01/10/2026",
  },
  {
    id: "treat-2",
    pet_id: "pet-1",
    medicamento: "Vermífugo",
    dose: "1 comprimido",
    recorrencia: "dose única",
    data_inicio: "2026-09-15",
    data_fim: "2026-09-15",
    ativo: false,
    subtituloFormatado: "1 comprimido • dose única • 15/09/2026",
  },
  {
    id: "treat-3",
    pet_id: "pet-1",
    medicamento: "Antipulgas",
    dose: "Pipeta",
    recorrencia: "mensal",
    data_inicio: "2026-08-01",
    ativo: true,
    subtituloFormatado: "Pipeta • mensal • início 01/08/2026",
  },
];

function getFallbackTreatments(): TreatmentView[] {
  const saved = localStorage.getItem(FALLBACK_STORAGE_KEY);
  if (saved) {
    try {
      return JSON.parse(saved) as TreatmentView[];
    } catch {
      return DEFAULT_MOCK_TREATMENTS;
    }
  }
  return DEFAULT_MOCK_TREATMENTS;
}

export function formatTreatmentDetails(item: TreatmentView): string {
  if (item.subtituloFormatado) return item.subtituloFormatado;

  const parts: string[] = [item.dose];

  if (item.frequencia_horas) {
    parts.push(`a cada ${item.frequencia_horas}h`);
  } else if (item.recorrencia) {
    parts.push(item.recorrencia);
  }

  if (item.data_inicio) {
    const [yyyy, mm, dd] = item.data_inicio.split("T")[0].split("-");
    const formattedDate = dd && mm && yyyy ? `${dd}/${mm}/${yyyy}` : item.data_inicio;
    parts.push(item.ativo ? `início ${formattedDate}` : formattedDate);
  }

  return parts.filter(Boolean).join(" • ");
}

export async function fetchTreatmentsByPet(petId: string = "pet-1"): Promise<TreatmentView[]> {
  try {
    const response = await api.get<TreatmentView[]>(`/api/treatments/pet/${petId}`);
    if (Array.isArray(response.data) && response.data.length > 0) {
      return response.data;
    }
    return getFallbackTreatments();
  } catch (error) {
    console.warn("Não foi possível carregar tratamentos da API, usando dados de demonstração.", error);
    return getFallbackTreatments();
  }
}

export async function createTreatment(payload: CreateTreatmentPayload): Promise<TreatmentView> {
  try {
    const response = await api.post<TreatmentView>("/api/treatments", payload);
    return response.data;
  } catch (error) {
    console.warn("API offline: salvando tratamento localmente para demonstração.", error);
    const current = getFallbackTreatments();
    const created: TreatmentView = {
      ...payload,
      id: `treat-${Date.now()}`,
    };
    localStorage.setItem(FALLBACK_STORAGE_KEY, JSON.stringify([created, ...current]));
    return created;
  }
}

// Adicione esta função em src/services/treatmentService.ts
export async function updateTreatment(id: string, payload: CreateTreatmentPayload): Promise<TreatmentView> {
  try {
    const response = await api.put<TreatmentView>(`/api/treatments/${id}`, payload);
    return response.data;
  } catch (error) {
    console.warn("API offline: atualizando tratamento localmente para demonstração.", error);
    const current = getFallbackTreatments();
    const updated: TreatmentView = { ...payload, id };
    const newList = current.map((item) => (item.id === id ? updated : item));
    localStorage.setItem(FALLBACK_STORAGE_KEY, JSON.stringify(newList));
    return updated;
  }
}

export async function deleteTreatment(id: string): Promise<void> {
  try {
    await api.delete(`/api/treatments/${id}`);
  } catch (error) {
    console.warn("API offline: removendo tratamento localmente para demonstração.", error);
    const current = getFallbackTreatments().filter((item) => item.id !== id);
    localStorage.setItem(FALLBACK_STORAGE_KEY, JSON.stringify(current));
  }
}