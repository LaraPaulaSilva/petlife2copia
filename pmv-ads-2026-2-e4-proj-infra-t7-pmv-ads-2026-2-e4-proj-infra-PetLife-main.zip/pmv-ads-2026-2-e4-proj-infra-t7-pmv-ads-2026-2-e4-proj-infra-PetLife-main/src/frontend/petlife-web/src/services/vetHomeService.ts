import api from "../api/client";
import type { Notificacao, SharedPet } from "../types";
import { formatPetAge, formatWeightKg } from "../utils/homeFormat";

export interface VetPatient {
  id: string;
  name: string;
  species: string;
  breed: string;
  age: string;
  weight: string;
  tutor: string;
  photo?: string;
}

export interface VetHomeData {
  vetName: string;
  roleLabel: string;
  patientCount: number;
  unreadNotificationsCount: number;
  patients: VetPatient[];
}

function asArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

function isUnread(notificacao: Notificacao): boolean {
  const raw = notificacao as Notificacao & { Lida?: boolean };
  const lida = raw.lida ?? raw.Lida ?? false;
  return !lida;
}

export function mapSharedPetToPatient(pet: SharedPet): VetPatient {
  return {
    id: pet.id,
    name: pet.nome,
    species: pet.especie,
    breed: pet.raca?.trim() ? pet.raca : "Não informada",
    age: formatPetAge(pet.data_nascimento),
    weight: formatWeightKg(pet.peso_kg),
    tutor: pet.tutor_nome?.trim() ? pet.tutor_nome : "Tutor não informado",
    photo: pet.foto_url || undefined,
  };
}

export async function fetchVetHomeData(): Promise<VetHomeData> {
  const [petsRes, notificacoesRes] = await Promise.all([
    api.get<SharedPet[]>("/api/pets/shared"),
    api.get<Notificacao[]>("/api/Notificacoes").catch(() => ({ data: [] })),
  ]);

  const patients = asArray<SharedPet>(petsRes.data).map(mapSharedPetToPatient);

  return {
    vetName: "",
    roleLabel: "Veterinário",
    patientCount: patients.length,
    unreadNotificationsCount: asArray<Notificacao>(notificacoesRes.data).filter(isUnread).length,
    patients,
  };
}
