import api from "../api/client";
import type { Consulta, SharedPet } from "../types";
import { formatConsultaDate } from "./consultaService";

export interface VetPatientItem {
  id: string;
  name: string;
  species: string;
  breed: string;
  tutor: string;
  ultimaConsulta: string;
  photo?: string;
}

function asArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

/**
 * Encontra a data da consulta mais recente para um determinado pet.
 */
export function findLatestConsultaDate(consultas: Consulta[], petId: string): string {
  const petConsultas = consultas
    .filter((c) => {
      const cPetId = c.pet_id || (c as unknown as { petId?: string }).petId;
      return cPetId === petId;
    })
    .sort((a, b) => {
      const timeA = new Date(a.data).getTime();
      const timeB = new Date(b.data).getTime();
      return timeB - timeA;
    });

  if (petConsultas.length === 0 || !petConsultas[0]?.data) {
    return "-";
  }

  return formatConsultaDate(petConsultas[0].data);
}

/**
 * Busca a lista de pacientes compartilhados com o veterinário logado,
 * combinando com os registros de consultas para determinar a última consulta.
 */
export async function fetchVetPatients(): Promise<VetPatientItem[]> {
  const [petsRes, consultasRes] = await Promise.all([
    api.get<SharedPet[]>("/api/pets/shared"),
    api.get<Consulta[]>("/api/consultas").catch(() => ({ data: [] as Consulta[] })),
  ]);

  const sharedPets = asArray<SharedPet>(petsRes.data);
  const consultas = asArray<Consulta>(consultasRes.data);

  return sharedPets.map((pet) => ({
    id: pet.id,
    name: pet.nome,
    species: pet.especie,
    breed: pet.raca?.trim() ? pet.raca : "Não informada",
    tutor: pet.tutor_nome?.trim() ? pet.tutor_nome : "Tutor não informado",
    ultimaConsulta: findLatestConsultaDate(consultas, pet.id),
    photo: pet.foto_url || undefined,
  }));
}

/**
 * Resgata um código de compartilhamento para vincular um novo paciente ao veterinário.
 */
export async function redeemPatientShareCode(code: string): Promise<void> {
  const cleanCode = code.trim();
  await api.post("/api/shares/redeemsharecode", JSON.stringify(cleanCode), {
    headers: {
      "Content-Type": "application/json",
    },
  });
}
