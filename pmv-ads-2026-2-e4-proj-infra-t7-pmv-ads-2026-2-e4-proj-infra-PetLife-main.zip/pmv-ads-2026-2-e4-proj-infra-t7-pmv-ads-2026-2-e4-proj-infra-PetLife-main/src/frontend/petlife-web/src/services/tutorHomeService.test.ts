import { describe, it, expect, vi, beforeEach } from "vitest";
import api from "../api/client";
import { fetchTutorHomeData } from "./tutorHomeService";
import type { Consulta, Document, Pet, Treatment, Vaccine } from "../types";

vi.mock("../api/client", () => ({
  default: {
    get: vi.fn(),
  },
}));

const get = vi.mocked(api.get);

function daysFromNow(days: number): string {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString();
}

function yearsAgo(years: number): string {
  const date = new Date();
  date.setFullYear(date.getFullYear() - years);
  date.setMonth(date.getMonth() - 1);
  return date.toISOString();
}

const pet: Pet = {
  id: "pet-1",
  nome: "Mel",
  especie: "Gato",
  raca: "Persa",
  peso_kg: 3,
  data_nascimento: yearsAgo(2),
  foto_url: "https://cdn.example/mel.jpg",
  tutor_id: "tutor-1",
  criado_at: daysFromNow(-1),
};

const vaccine: Vaccine = {
  id: "vac-1",
  pet_id: "pet-1",
  tipo: "V4",
  data_aplicacao: daysFromNow(-30),
  data_proxima_dose: daysFromNow(7),
  origem_registro: "VETERINARIO",
  alerta_reforco: true,
};

const treatment: Treatment = {
  id: "treat-1",
  pet_id: "pet-1",
  medicamento: "Vermífugo",
  dose: "1 comprimido",
  data_inicio: daysFromNow(-10),
  ativo: true,
};

const consulta: Consulta = {
  id: "cons-1",
  pet_id: "pet-1",
  data: daysFromNow(1),
  tipo_atendimento: "retorno",
  motivo: "Revisão da vacina",
  status: "CONFIRMADA",
  origem_registro: "VETERINARIO",
  autor_id: "vet-1",
  criado_em: daysFromNow(-2),
};

const document: Document = {
  id: "doc-1",
  pet_id: "pet-1",
  usuario_id: "vet-1",
  perfil_autor: "Veterinário",
  titulo: "Laudo sanguíneo",
  arquivo_url: "https://cdn.example/laudo.pdf",
  data_upload: daysFromNow(-2),
};

function mockEndpoints(handlers: Record<string, unknown>) {
  get.mockImplementation(async (url) => {
    if (typeof url === "string" && url in handlers) {
      return { data: handlers[url] };
    }
    return { data: [] };
  });
}

describe("fetchTutorHomeData", () => {
  beforeEach(() => {
    get.mockReset();
  });

  it("chama GET /api/pets e devolve home vazia sem dados de demonstração", async () => {
    mockEndpoints({
      "/api/pets": [],
      "/api/Notificacoes": [],
      "/api/EventosRotina/usuario/tutor-1": [],
    });

    const data = await fetchTutorHomeData("tutor-1");

    expect(get).toHaveBeenCalledWith("/api/pets");
    expect(get).toHaveBeenCalledWith("/api/Notificacoes");
    expect(get).toHaveBeenCalledWith("/api/EventosRotina/usuario/tutor-1");
    expect(get.mock.calls.some(([url]) => String(url).includes("/api/vaccines"))).toBe(false);
    expect(data.featured).toBeNull();
    expect(data.alerts).toEqual([]);
    expect(data.vetUpdates).toEqual([]);
    expect(data.unreadNotificationsCount).toBe(0);
    expect(JSON.stringify(data)).not.toContain("Lulu");
  });

  it("monta o pet do dia, alertas, atualizações e o sino a partir das APIs", async () => {
    get.mockImplementation(async (url, config) => {
      const petId = (config?.params as { pet_id?: string } | undefined)?.pet_id;
      if (url === "/api/pets") return { data: [pet] };
      if (url === "/api/vaccines" && petId === "pet-1") return { data: [vaccine] };
      if (url === "/api/treatments/pet/pet-1") return { data: [treatment] };
      if (url === "/api/consultas" && petId === "pet-1") return { data: [consulta] };
      if (url === "/api/documents" && petId === "pet-1") return { data: [document] };
      if (url === "/api/EventosRotina/usuario/tutor-1") {
        return {
          data: [
            {
              id: "ev-1",
              petId: "pet-1",
              tipo: "tosa",
              status: "agendado",
              dataHora: daysFromNow(3),
            },
          ],
        };
      }
      if (url === "/api/Notificacoes") {
        return { data: [{ id: "n1", lida: false }, { id: "n2", lida: true }] };
      }
      return { data: [] };
    });

    const data = await fetchTutorHomeData("tutor-1");

    expect(data.featured).not.toBeNull();
    expect(data.featured?.name).toBe("Mel");
    expect(data.featured?.breedAge).toContain("Gato");
    expect(data.featured?.breedAge).toContain("Persa");
    expect(data.featured?.breedAge).toContain("2 anos");
    expect(data.featured?.weightLabel).toBe("Peso: 3,0 kg");
    expect(data.featured?.nextVaccineLine).toContain("V4");
    expect(data.featured?.medicationLine).toContain("Vermífugo");
    expect(data.unreadNotificationsCount).toBe(1);
    expect(data.alerts.some((alert) => alert.message.includes("V4"))).toBe(true);
    expect(data.alerts.some((alert) => alert.message.includes("Consulta"))).toBe(true);
    expect(data.alerts.some((alert) => alert.message.toLowerCase().includes("tosa"))).toBe(true);
    expect(data.vetUpdates.some((update) => update.type === "document")).toBe(true);
    expect(data.vetUpdates.some((update) => update.type === "vaccine")).toBe(true);
    expect(JSON.stringify(data)).not.toContain("Lulu");
  });

  it("propaga o erro quando a listagem de pets falha", async () => {
    get.mockImplementation(async (url) => {
      if (url === "/api/pets") {
        throw new Error("pets offline");
      }
      return { data: [] };
    });

    await expect(fetchTutorHomeData("tutor-1")).rejects.toThrow("pets offline");
  });
});
