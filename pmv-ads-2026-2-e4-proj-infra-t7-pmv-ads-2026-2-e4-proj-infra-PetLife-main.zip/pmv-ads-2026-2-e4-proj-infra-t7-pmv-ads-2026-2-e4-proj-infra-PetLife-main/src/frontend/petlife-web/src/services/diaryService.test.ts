import { describe, it, expect, vi, beforeEach } from "vitest";
import api from "../api/client";
import {
  createDiaryEntry,
  fetchDiaryByPet,
  formatDiaryDate,
  parseDiaryTags,
} from "./diaryService";
import type { PetDiaryEntry } from "../types";

vi.mock("../api/client", () => ({
  default: {
    get: vi.fn(),
    post: vi.fn(),
  },
}));

const get = vi.mocked(api.get);
const post = vi.mocked(api.post);

const entry: PetDiaryEntry = {
  id: "diary-1",
  pet_id: "pet-1",
  perfil_autor: "tutor",
  data_registro: "2026-09-27T00:00:00.000Z",
  tags: ["vacina", "febre"],
  Registro: "Lulu apresentou leve febre após a vacinação.",
};

describe("diaryService", () => {
  beforeEach(() => {
    get.mockReset();
    post.mockReset();
  });

  it("lista os registros do pet autenticado", async () => {
    get.mockResolvedValue({ data: [entry] });

    await expect(fetchDiaryByPet("pet-1")).resolves.toEqual([entry]);
    expect(get).toHaveBeenCalledWith("/api/pet-diary", {
      params: { pet_id: "pet-1" },
    });
  });

  it("devolve lista vazia quando a API não envia um array", async () => {
    get.mockResolvedValue({ data: { message: "ok" } });

    await expect(fetchDiaryByPet("pet-1")).resolves.toEqual([]);
  });

  it("cadastra um registro no diário", async () => {
    post.mockResolvedValue({ data: entry });

    const payload = {
      pet_id: "pet-1",
      data_registro: "2026-09-27",
      Registro: "Lulu apresentou leve febre após a vacinação.",
      tags: ["vacina", "febre"],
    };

    await expect(createDiaryEntry(payload)).resolves.toEqual(entry);
    expect(post).toHaveBeenCalledWith("/api/pet-diary", payload);
  });

  it("formata a data a partir da parte YYYY-MM-DD", () => {
    expect(formatDiaryDate("2026-09-27T00:00:00.000Z")).toBe("27/09/2026");
    expect(formatDiaryDate("2026-09-28")).toBe("28/09/2026");
    expect(formatDiaryDate("")).toBe("");
  });

  it("separa tags por vírgula e ignora vazias", () => {
    expect(parseDiaryTags("vacina, febre, ")).toEqual(["vacina", "febre"]);
    expect(parseDiaryTags(" recuperado ")).toEqual(["recuperado"]);
    expect(parseDiaryTags("")).toEqual([]);
  });
});
