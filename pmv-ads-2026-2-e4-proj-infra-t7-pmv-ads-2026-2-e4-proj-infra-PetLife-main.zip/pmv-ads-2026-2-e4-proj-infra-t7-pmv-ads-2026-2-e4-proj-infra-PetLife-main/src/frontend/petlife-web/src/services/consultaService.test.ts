import { describe, it, expect, vi, beforeEach } from "vitest";
import api from "../api/client";
import {
  createConsulta,
  deleteConsulta,
  fetchConsultasByPet,
  formatConsultaDate,
  formatConsultaValor,
} from "./consultaService";
import type { Consulta } from "../types";

vi.mock("../api/client", () => ({
  default: {
    get: vi.fn(),
    post: vi.fn(),
    delete: vi.fn(),
  },
}));

const get = vi.mocked(api.get);
const post = vi.mocked(api.post);
const del = vi.mocked(api.delete);

const consulta: Consulta = {
  id: "consulta-1",
  pet_id: "pet-1",
  data: "2026-10-05",
  hora: "14:30",
  tipo_atendimento: "Consulta de rotina",
  status: "SOLICITADA",
  origem_registro: "VETERINARIO",
  autor_id: "vet-1",
  valor: 150,
};

describe("consultaService", () => {
  beforeEach(() => {
    get.mockReset();
    post.mockReset();
    del.mockReset();
  });

  it("lista as consultas do pet", async () => {
    get.mockResolvedValue({ data: [consulta] });

    await expect(fetchConsultasByPet("pet-1")).resolves.toEqual([consulta]);
    expect(get).toHaveBeenCalledWith("/api/consultas", {
      params: { pet_id: "pet-1" },
    });
  });

  it("devolve lista vazia quando a API não envia um array", async () => {
    get.mockResolvedValue({ data: { message: "ok" } });
    await expect(fetchConsultasByPet("pet-1")).resolves.toEqual([]);
  });

  it("cadastra uma consulta", async () => {
    post.mockResolvedValue({ data: consulta });

    const payload = {
      pet_id: "pet-1",
      autor_id: "vet-1",
      data: "2026-10-05",
      tipo_atendimento: "Consulta de rotina",
    };

    await expect(createConsulta(payload)).resolves.toEqual(consulta);
    expect(post).toHaveBeenCalledWith("/api/consultas", payload);
  });

  it("exclui uma consulta enviando o solicitante", async () => {
    del.mockResolvedValue({ data: {} });

    await deleteConsulta("consulta-1", "vet-1");
    expect(del).toHaveBeenCalledWith("/api/consultas/consulta-1", {
      params: { solicitante_id: "vet-1" },
    });
  });

  it("formata data e valor", () => {
    expect(formatConsultaDate("2026-10-05T00:00:00Z")).toBe("05/10/2026");
    expect(formatConsultaDate("")).toBe("");
    expect(formatConsultaValor(150)).toContain("150");
    expect(formatConsultaValor(null)).toBe("");
  });
});
