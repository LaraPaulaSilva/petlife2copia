import api from "../api/client";
import type {
  Consulta,
  Document,
  EventoRotina,
  Notificacao,
  Pet,
  Treatment,
  Vaccine,
} from "../types";
import {
  daysFromToday,
  formatDatePt,
  formatPetAge,
  formatRelativeDate,
  formatScheduleLabel,
  formatWeightKg,
  isVeterinarioLabel,
  parseDate,
} from "../utils/homeFormat";

export interface FeaturedPetHome {
  id: string;
  name: string;
  breedAge: string;
  weightLabel: string;
  nextVaccineLine: string;
  medicationLine: string;
  image?: string;
}

export interface HomeAlert {
  id: string;
  pet: string;
  message: string;
  accent: "blue" | "pink";
  sortDate?: number;
}

export interface HomeVetUpdate {
  id: string;
  pet: string;
  description: string;
  date: string;
  type: "document" | "vaccine" | "consultation";
}

export interface TutorHomeData {
  featured: FeaturedPetHome | null;
  alerts: HomeAlert[];
  vetUpdates: HomeVetUpdate[];
  unreadNotificationsCount: number;
}

interface PetBundle {
  pet: Pet;
  vaccines: Vaccine[];
  treatments: Treatment[];
  consultas: Consulta[];
  documents: Document[];
}

const ALERT_WINDOW_DAYS = 30;
const ALERT_LIMIT = 6;
const UPDATE_LIMIT = 6;

function asArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

function fulfilledData<T>(result: PromiseSettledResult<{ data: T }>, fallback: T): T {
  return result.status === "fulfilled" ? result.value.data : fallback;
}

function pickString(...values: unknown[]): string | undefined {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value;
  }
  return undefined;
}

function pickBoolean(...values: unknown[]): boolean | undefined {
  for (const value of values) {
    if (typeof value === "boolean") return value;
  }
  return undefined;
}

function eventPetId(evento: EventoRotina): string | undefined {
  const raw = evento as EventoRotina & { PetId?: string; pet_id?: string };
  return pickString(raw.petId, raw.PetId, raw.pet_id);
}

function eventDate(evento: EventoRotina): string | undefined {
  const raw = evento as EventoRotina & { DataHora?: string; data_hora?: string };
  return pickString(raw.dataHora, raw.DataHora, raw.data_hora);
}

function eventStatus(evento: EventoRotina): string {
  const raw = evento as EventoRotina & { Status?: string };
  return (pickString(raw.status, raw.Status) ?? "").toLowerCase();
}

function eventTipo(evento: EventoRotina): string {
  const raw = evento as EventoRotina & { Tipo?: string };
  return pickString(raw.tipo, raw.Tipo) ?? "Evento";
}

function isPendingEvent(evento: EventoRotina): boolean {
  const status = eventStatus(evento);
  return status !== "concluido" && status !== "concluído" && status !== "cancelado";
}

function isUnread(notificacao: Notificacao): boolean {
  const raw = notificacao as Notificacao & { Lida?: boolean };
  return !(pickBoolean(raw.lida, raw.Lida) ?? false);
}

function capitalize(value: string): string {
  if (!value) return value;
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function petById(pets: Pet[]): Map<string, Pet> {
  return new Map(pets.map((pet) => [pet.id, pet]));
}

function chooseFeaturedPet(pets: Pet[]): Pet | null {
  if (pets.length === 0) return null;
  return [...pets].sort((a, b) => {
    const aTime = parseDate(a.criado_at)?.getTime() ?? 0;
    const bTime = parseDate(b.criado_at)?.getTime() ?? 0;
    return bTime - aTime;
  })[0];
}

function nextVaccine(vaccines: Vaccine[], now = new Date()): Vaccine | null {
  const upcoming = vaccines
    .filter((vaccine) => parseDate(vaccine.data_proxima_dose))
    .sort((a, b) => {
      const aTime = parseDate(a.data_proxima_dose)?.getTime() ?? 0;
      const bTime = parseDate(b.data_proxima_dose)?.getTime() ?? 0;
      return aTime - bTime;
    });

  const future = upcoming.find((vaccine) => {
    const diff = daysFromToday(vaccine.data_proxima_dose, now);
    return diff != null && diff >= 0;
  });

  return future ?? upcoming[0] ?? null;
}

function buildFeatured(
  pet: Pet,
  vaccines: Vaccine[],
  treatments: Treatment[],
  now = new Date(),
): FeaturedPetHome {
  const age = formatPetAge(pet.data_nascimento, now);
  const breedAge = [pet.especie, pet.raca, age].filter(Boolean).join(" • ");
  const upcoming = nextVaccine(vaccines, now);
  const activeTreatment = treatments.find((treatment) => treatment.ativo);

  let nextVaccineLine = "Próxima vacina: Em dia";
  if (upcoming?.data_proxima_dose) {
    const diff = daysFromToday(upcoming.data_proxima_dose, now);
    if (diff != null && diff < 0) {
      nextVaccineLine = `Próxima vacina: ${upcoming.tipo} vencida`;
    } else {
      nextVaccineLine = `Próxima vacina: ${upcoming.tipo} em ${formatDatePt(upcoming.data_proxima_dose)}`;
    }
  }

  return {
    id: pet.id,
    name: pet.nome,
    breedAge,
    weightLabel: pet.peso_kg != null ? `Peso: ${formatWeightKg(pet.peso_kg)}` : "Peso não informado",
    nextVaccineLine,
    medicationLine: activeTreatment
      ? `Medicação: ${activeTreatment.medicamento}`
      : "Medicação: Nenhuma em andamento",
    image: pet.foto_url || undefined,
  };
}

function buildAlerts(
  bundles: PetBundle[],
  eventos: EventoRotina[],
  pets: Pet[],
  now = new Date(),
): HomeAlert[] {
  const petsMap = petById(pets);
  const alerts: HomeAlert[] = [];

  for (const bundle of bundles) {
    for (const vaccine of bundle.vaccines) {
      const diff = daysFromToday(vaccine.data_proxima_dose, now);
      if (diff == null) continue;
      if (diff > ALERT_WINDOW_DAYS) continue;

      const when =
        diff < 0
          ? `venceu ${formatScheduleLabel(vaccine.data_proxima_dose, now)}`
          : `vence ${formatScheduleLabel(vaccine.data_proxima_dose, now)}`;

      alerts.push({
        id: `vaccine-${vaccine.id}`,
        pet: bundle.pet.nome,
        message: `Vacina ${vaccine.tipo} ${when}`,
        accent: "blue",
        sortDate: parseDate(vaccine.data_proxima_dose)?.getTime() ?? 0,
      });
    }

    for (const consulta of bundle.consultas) {
      if (consulta.status !== "SOLICITADA" && consulta.status !== "CONFIRMADA") continue;
      const diff = daysFromToday(consulta.data, now);
      if (diff == null || diff < 0) continue;

      alerts.push({
        id: `consulta-${consulta.id}`,
        pet: bundle.pet.nome,
        message: `Consulta agendada para ${formatScheduleLabel(consulta.data, now)}`,
        accent: "pink",
        sortDate: parseDate(consulta.data)?.getTime() ?? 0,
      });
    }
  }

  for (const evento of eventos) {
    if (!isPendingEvent(evento)) continue;
    const date = eventDate(evento);
    const pet = petsMap.get(eventPetId(evento) ?? "");
    const rawEvento = evento as EventoRotina & { Id?: string };
    alerts.push({
      id: `evento-${pickString(rawEvento.id, rawEvento.Id) ?? date ?? eventTipo(evento)}`,
      pet: pet?.nome ?? "Pet",
      message: `${capitalize(eventTipo(evento))} agendado para ${formatScheduleLabel(date, now)}`,
      accent: "blue",
      sortDate: parseDate(date)?.getTime() ?? 0,
    });
  }

  return alerts
    .sort((a, b) => (a.sortDate ?? 0) - (b.sortDate ?? 0))
    .slice(0, ALERT_LIMIT)
    .map((alert) => ({
      id: alert.id,
      pet: alert.pet,
      message: alert.message,
      accent: alert.accent,
    }));
}

function buildVetUpdates(bundles: PetBundle[], now = new Date()): HomeVetUpdate[] {
  const updates: Array<HomeVetUpdate & { sortDate: number }> = [];

  for (const bundle of bundles) {
    for (const document of bundle.documents) {
      if (!isVeterinarioLabel(document.perfil_autor)) continue;
      updates.push({
        id: `document-${document.id}`,
        pet: bundle.pet.nome,
        description: document.titulo
          ? `${document.titulo} adicionado ao prontuário`
          : "Novo documento adicionado ao prontuário",
        date: formatRelativeDate(document.data_upload, now),
        type: "document",
        sortDate: parseDate(document.data_upload)?.getTime() ?? 0,
      });
    }

    for (const vaccine of bundle.vaccines) {
      if (vaccine.origem_registro !== "VETERINARIO") continue;
      updates.push({
        id: `vaccine-${vaccine.id}`,
        pet: bundle.pet.nome,
        description: `Vacina ${vaccine.tipo} registrada`,
        date: formatRelativeDate(vaccine.data_aplicacao ?? vaccine.criado_at, now),
        type: "vaccine",
        sortDate: parseDate(vaccine.data_aplicacao ?? vaccine.criado_at)?.getTime() ?? 0,
      });
    }

    for (const consulta of bundle.consultas) {
      if (consulta.origem_registro !== "VETERINARIO") continue;
      updates.push({
        id: `consulta-${consulta.id}`,
        pet: bundle.pet.nome,
        description: consulta.motivo
          ? `Consulta registrada: ${consulta.motivo}`
          : "Consulta registrada pelo veterinário",
        date: formatRelativeDate(consulta.criado_em ?? consulta.data, now),
        type: "consultation",
        sortDate: parseDate(consulta.criado_em ?? consulta.data)?.getTime() ?? 0,
      });
    }
  }

  return updates
    .sort((a, b) => b.sortDate - a.sortDate)
    .slice(0, UPDATE_LIMIT)
    .map((update) => ({
      id: update.id,
      pet: update.pet,
      description: update.description,
      date: update.date,
      type: update.type,
    }));
}

async function fetchPetBundle(pet: Pet): Promise<PetBundle> {
  const [vaccinesRes, treatmentsRes, consultasRes, documentsRes] = await Promise.allSettled([
    api.get<Vaccine[]>("/api/vaccines", { params: { pet_id: pet.id } }),
    api.get<Treatment[]>(`/api/treatments/pet/${pet.id}`),
    api.get<Consulta[]>("/api/consultas", { params: { pet_id: pet.id } }),
    api.get<Document[]>("/api/documents", { params: { pet_id: pet.id } }),
  ]);

  return {
    pet,
    vaccines: asArray(fulfilledData(vaccinesRes, [])),
    treatments: asArray(fulfilledData(treatmentsRes, [])),
    consultas: asArray(fulfilledData(consultasRes, [])),
    documents: asArray(fulfilledData(documentsRes, [])),
  };
}

export async function fetchTutorHomeData(tutorId?: string): Promise<TutorHomeData> {
  const petsRes = await api.get<Pet[]>("/api/pets");
  const pets = asArray<Pet>(petsRes.data);

  const [eventosRes, notificacoesRes, bundles] = await Promise.all([
    tutorId
      ? api.get<EventoRotina[]>(`/api/EventosRotina/usuario/${tutorId}`).catch(() => ({ data: [] }))
      : Promise.resolve({ data: [] as EventoRotina[] }),
    api.get<Notificacao[]>("/api/Notificacoes").catch(() => ({ data: [] })),
    Promise.all(pets.map((pet) => fetchPetBundle(pet))),
  ]);

  const featuredPet = chooseFeaturedPet(pets);
  const featuredBundle = featuredPet
    ? bundles.find((bundle) => bundle.pet.id === featuredPet.id)
    : undefined;

  return {
    featured: featuredPet
      ? buildFeatured(featuredPet, featuredBundle?.vaccines ?? [], featuredBundle?.treatments ?? [])
      : null,
    alerts: buildAlerts(bundles, asArray<EventoRotina>(eventosRes.data), pets),
    vetUpdates: buildVetUpdates(bundles),
    unreadNotificationsCount: asArray<Notificacao>(notificacoesRes.data).filter(isUnread).length,
  };
}
