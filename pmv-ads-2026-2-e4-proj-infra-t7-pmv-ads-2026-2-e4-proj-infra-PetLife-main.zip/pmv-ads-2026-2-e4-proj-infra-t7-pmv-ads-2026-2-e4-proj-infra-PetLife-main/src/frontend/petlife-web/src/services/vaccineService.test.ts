import { describe, it, expect, vi, beforeEach } from "vitest";
import api from "../api/client";
import {
  createVaccine,
  deleteVaccine,
  fetchVaccinesByPet,
  formatVaccineDate,
  formatVaccineDetails,
} from "./vaccineService";
import type { Vaccine } from "../types";

vi.mock("../api/client", () => ({
  default: {
    get: vi.fn(),
    post: vi.fn(),
    delete: vi.fn(),
  },
}));

const get = vi.mocked(api.get);
const post = vi.mocked(api.post);
const del = vi.mocked(api.delete);

const vaccine: Vaccine = {
  id: "vaccine-1",
  pet_id: "pet-1",
  tipo: "V10 (Polivalente)",
  data_aplicacao: "2026-10-05",
  data_proxima_dose: "2027-10-05",
  lote: "LT-2026-0987",
  fabricante: "Zoetis",
  origem_registro: "TUTOR",
  alerta_reforco: true,
};

describe("vaccineService", () => {
  beforeEach(() => {
    get.mockReset();
    post.mockReset();
    del.mockReset();
  });

  it("lista as vacinas do pet", async () => {
    get.mockResolvedValue({ data: [vaccine] });

    await expect(fetchVaccinesByPet("pet-1")).resolves.toEqual([vaccine]);
    expect(get).toHaveBeenCalledWith("/api/vaccines", {
      params: { pet_id: "pet-1" },
    });
  });

  it("devolve lista vazia quando a API não envia um array", async () => {
    get.mockResolvedValue({ data: { message: "ok" } });

    await expect(fetchVaccinesByPet("pet-1")).resolves.toEqual([]);
  });

  it("cadastra uma vacina", async () => {
    post.mockResolvedValue({ data: vaccine });

    const payload = {
      pet_id: "pet-1",
      tipo: "V10 (Polivalente)",
      data_aplicacao: "2026-10-05",
      origem_registro: "TUTOR" as const,
      alerta_reforco: true,
    };

    await expect(createVaccine(payload)).resolves.toEqual(vaccine);
    expect(post).toHaveBeenCalledWith("/api/vaccines", payload);
  });

  it("exclui uma vacina pelo id", async () => {
    del.mockResolvedValue({ data: {} });

    await deleteVaccine("vaccine-1");
    expect(del).toHaveBeenCalledWith("/api/vaccines/vaccine-1");
  });

  it("formata a data a partir da parte YYYY-MM-DD", () => {
    expect(formatVaccineDate("2026-10-05T00:00:00.000Z")).toBe("05/10/2026");
    expect(formatVaccineDate("2026-10-05")).toBe("05/10/2026");
    expect(formatVaccineDate("")).toBe("");
    expect(formatVaccineDate(null)).toBe("");
  });

  it("monta os detalhes com fabricante e lote", () => {
    expect(formatVaccineDetails(vaccine)).toBe("Zoetis • Lote LT-2026-0987");
    expect(
      formatVaccineDetails({ ...vaccine, lote: null }),
    ).toBe("Zoetis");
    expect(
      formatVaccineDetails({ ...vaccine, fabricante: null, lote: null }),
    ).toBe("");
  });
});
