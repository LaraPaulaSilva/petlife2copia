import { describe, it, expect, vi, beforeEach } from "vitest";
import api from "../api/client";
import {
  createDocument,
  deleteDocument,
  fetchDocumentsByPet,
  formatDocumentDate,
  uploadDocumentFile,
} from "./documentService";
import type { Document } from "../types";

vi.mock("../api/client", () => ({
  default: {
    get: vi.fn(),
    post: vi.fn(),
    delete: vi.fn(),
  },
}));

const get = vi.mocked(api.get);
const post = vi.mocked(api.post);
const del = vi.mocked(api.delete);

const document: Document = {
  id: "doc-1",
  pet_id: "pet-1",
  usuario_id: "user-1",
  titulo: "Exame de sangue",
  tipo_doc: "Exame",
  arquivo_url: "https://cloudinary.com/exame.pdf",
};

describe("documentService", () => {
  beforeEach(() => {
    get.mockReset();
    post.mockReset();
    del.mockReset();
  });

  it("lista os documentos do pet", async () => {
    get.mockResolvedValue({ data: [document] });

    await expect(fetchDocumentsByPet("pet-1")).resolves.toEqual([document]);
    expect(get).toHaveBeenCalledWith("/api/documents", {
      params: { pet_id: "pet-1" },
    });
  });

  it("devolve lista vazia quando a API não envia um array", async () => {
    get.mockResolvedValue({ data: null });
    await expect(fetchDocumentsByPet("pet-1")).resolves.toEqual([]);
  });

  it("faz upload do arquivo e retorna a secure_url", async () => {
    post.mockResolvedValue({
      data: { secure_url: "https://cloudinary.com/novo.pdf" },
    });

    const file = new File(["conteudo"], "exame.pdf", {
      type: "application/pdf",
    });

    await expect(uploadDocumentFile(file)).resolves.toBe(
      "https://cloudinary.com/novo.pdf",
    );
    expect(post).toHaveBeenCalledWith(
      "/api/documents/upload",
      expect.any(FormData),
      { headers: { "Content-Type": "multipart/form-data" } },
    );
  });

  it("cadastra um documento", async () => {
    post.mockResolvedValue({ data: document });

    const payload = {
      pet_id: "pet-1",
      usuario_id: "user-1",
      titulo: "Exame de sangue",
      arquivo_url: "https://cloudinary.com/exame.pdf",
    };

    await expect(createDocument(payload)).resolves.toEqual(document);
    expect(post).toHaveBeenCalledWith("/api/documents", payload);
  });

  it("exclui um documento enviando o solicitante", async () => {
    del.mockResolvedValue({ data: {} });

    await deleteDocument("doc-1", "user-1");
    expect(del).toHaveBeenCalledWith("/api/documents/doc-1", {
      params: { solicitante_id: "user-1" },
    });
  });

  it("formata a data de upload", () => {
    expect(formatDocumentDate("2026-10-20T00:00:00Z")).toBe("20/10/2026");
    expect(formatDocumentDate("")).toBe("");
  });
});
