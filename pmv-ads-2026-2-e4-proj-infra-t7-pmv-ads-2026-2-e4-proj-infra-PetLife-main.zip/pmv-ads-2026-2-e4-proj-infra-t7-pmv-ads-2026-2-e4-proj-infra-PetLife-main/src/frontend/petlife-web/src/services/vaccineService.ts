import api from "../api/client";
import type { OrigemRegistro, Vaccine } from "../types";

export interface CreateVaccinePayload {
  pet_id: string;
  veterinario_id?: string | null;
  tipo: string;
  data_aplicacao: string;
  intervalo_reforco_dias?: number | null;
  data_proxima_dose?: string | null;
  comprovante_url?: string | null;
  lote?: string | null;
  fabricante?: string | null;
  laboratorio?: string | null;
  dose?: string | null;
  via_administracao?: string | null;
  local_aplicacao?: string | null;
  situacao?: string | null;
  origem_registro: OrigemRegistro;
  alerta_reforco: boolean;
  observacoes?: string | null;
}

function asArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

export function formatVaccineDate(value?: string | null): string {
  if (!value) return "";
  const datePart = value.split("T")[0];
  const [yyyy, mm, dd] = datePart.split("-");
  return dd && mm && yyyy ? `${dd}/${mm}/${yyyy}` : value;
}

export function formatVaccineDetails(vaccine: Vaccine): string {
  return [
    vaccine.fabricante,
    vaccine.laboratorio,
    vaccine.lote ? `Lote ${vaccine.lote}` : null,
    vaccine.dose,
  ]
    .filter((part): part is string => Boolean(part?.trim()))
    .join(" • ");
}

export function formatVaccineApplication(vaccine: Vaccine): string {
  return [vaccine.via_administracao, vaccine.local_aplicacao]
    .filter((part): part is string => Boolean(part?.trim()))
    .join(" • ");
}

export async function fetchVaccinesByPet(petId: string): Promise<Vaccine[]> {
  const response = await api.get<Vaccine[]>("/api/vaccines", {
    params: { pet_id: petId },
  });
  return asArray<Vaccine>(response.data);
}

export async function createVaccine(
  payload: CreateVaccinePayload,
): Promise<Vaccine> {
  const response = await api.post<Vaccine>("/api/vaccines", payload);
  return response.data;
}

export async function deleteVaccine(id: string): Promise<void> {
  await api.delete(`/api/vaccines/${id}`);
}
