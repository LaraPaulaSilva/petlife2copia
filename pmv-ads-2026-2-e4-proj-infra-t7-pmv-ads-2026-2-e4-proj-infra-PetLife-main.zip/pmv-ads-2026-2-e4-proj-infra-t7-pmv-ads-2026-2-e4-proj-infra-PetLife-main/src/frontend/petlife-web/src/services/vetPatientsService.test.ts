import { describe, it, expect, vi, beforeEach } from "vitest";
import api from "../api/client";
import {
  fetchVetPatients,
  findLatestConsultaDate,
  redeemPatientShareCode,
} from "./vetPatientsService";
import type { Consulta, SharedPet } from "../types";

vi.mock("../api/client", () => ({
  default: {
    get: vi.fn(),
    post: vi.fn(),
  },
}));

describe("vetPatientsService", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("findLatestConsultaDate", () => {
    it("retorna '-' quando não há consultas para o pet", () => {
      expect(findLatestConsultaDate([], "pet-1")).toBe("-");
    });

    it("retorna a data formatada da consulta mais recente", () => {
      const consultas: Partial<Consulta>[] = [
        { pet_id: "pet-1", data: "2026-08-10T10:00:00" },
        { pet_id: "pet-1", data: "2026-10-20T14:30:00" },
        { pet_id: "pet-2", data: "2026-11-01T09:00:00" },
      ];

      const result = findLatestConsultaDate(consultas as Consulta[], "pet-1");
      expect(result).toBe("20/10/2026");
    });
  });

  describe("fetchVetPatients", () => {
    it("busca e mapeia os pets compartilhados com a última consulta", async () => {
      const mockPets: Partial<SharedPet>[] = [
        {
          id: "pet-1",
          nome: "Lulu",
          especie: "Gato",
          raca: "Vira-lata",
          tutor_nome: "Ana Souza",
          foto_url: "https://example.com/lulu.jpg",
        },
        {
          id: "pet-2",
          nome: "Rex",
          especie: "Cão",
          raca: "Golden",
          tutor_nome: "Carlos Lima",
          foto_url: null,
        },
      ];

      const mockConsultas: Partial<Consulta>[] = [
        { pet_id: "pet-1", data: "2026-10-20" },
      ];

      vi.mocked(api.get).mockImplementation((url: string) => {
        if (url === "/api/pets/shared") {
          return Promise.resolve({ data: mockPets });
        }
        if (url === "/api/consultas") {
          return Promise.resolve({ data: mockConsultas });
        }
        return Promise.reject(new Error("Not found"));
      });

      const result = await fetchVetPatients();

      expect(result).toHaveLength(2);
      expect(result[0]).toEqual({
        id: "pet-1",
        name: "Lulu",
        species: "Gato",
        breed: "Vira-lata",
        tutor: "Ana Souza",
        ultimaConsulta: "20/10/2026",
        photo: "https://example.com/lulu.jpg",
      });
      expect(result[1]).toEqual({
        id: "pet-2",
        name: "Rex",
        species: "Cão",
        breed: "Golden",
        tutor: "Carlos Lima",
        ultimaConsulta: "-",
        photo: undefined,
      });
    });

    it("lida graciosamente com falha na listagem de consultas", async () => {
      const mockPets: Partial<SharedPet>[] = [
        {
          id: "pet-1",
          nome: "Lulu",
          especie: "Gato",
          raca: "Vira-lata",
          tutor_nome: "Ana Souza",
        },
      ];

      vi.mocked(api.get).mockImplementation((url: string) => {
        if (url === "/api/pets/shared") {
          return Promise.resolve({ data: mockPets });
        }
        if (url === "/api/consultas") {
          return Promise.reject(new Error("Erro de rede"));
        }
        return Promise.reject(new Error("Not found"));
      });

      const result = await fetchVetPatients();
      expect(result).toHaveLength(1);
      expect(result[0].ultimaConsulta).toBe("-");
    });
  });

  describe("redeemPatientShareCode", () => {
    it("chama endpoint /api/shares/redeemsharecode com o código enviado", async () => {
      vi.mocked(api.post).mockResolvedValue({ data: { success: true } });

      await redeemPatientShareCode("  abc12345  ");

      expect(api.post).toHaveBeenCalledWith(
        "/api/shares/redeemsharecode",
        JSON.stringify("abc12345"),
        {
          headers: {
            "Content-Type": "application/json",
          },
        },
      );
    });
  });
});
