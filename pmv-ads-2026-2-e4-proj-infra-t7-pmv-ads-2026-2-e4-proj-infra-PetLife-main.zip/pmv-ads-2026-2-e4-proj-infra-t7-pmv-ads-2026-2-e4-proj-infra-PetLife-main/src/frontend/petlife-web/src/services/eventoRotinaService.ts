import api from "../api/client";
import type { Pet } from "../types";

export type EventoRotina = {
  id: string;
  userId: string;
  petId: string;
  tipo: string;
  dataHora: string;
  recorrente?: boolean;
  intervaloDias?: number | null;
  observacoes?: string | null;
  status?: string;
};

export async function buscarEventosDoUsuario(userId: string) {
  const resposta = await api.get<EventoRotina[]>(
    "/api/EventosRotina/usuario/" + userId
  );
  return resposta.data;
}

export async function buscarPetsDoTutor() {
  const resposta = await api.get<Pet[]>("/api/pets");
  return resposta.data;
}
export type NovoEvento = {
  userId: string;
  petId: string;
  tipo: string;
  dataHora: string;
  recorrente: boolean;
  intervaloDias: number | null;
  observacoes: string;
  status: string;
};

export async function criarEvento(dados: NovoEvento) {
  const resposta = await api.post("/api/EventosRotina", dados);
  return resposta.data;
}
export async function atualizarEvento(id: string, dados: NovoEvento) {
  const resposta = await api.put("/api/EventosRotina/" + id, dados);
  return resposta.data;
}

export async function apagarEvento(id: string) {
  await api.delete("/api/EventosRotina/" + id);
}