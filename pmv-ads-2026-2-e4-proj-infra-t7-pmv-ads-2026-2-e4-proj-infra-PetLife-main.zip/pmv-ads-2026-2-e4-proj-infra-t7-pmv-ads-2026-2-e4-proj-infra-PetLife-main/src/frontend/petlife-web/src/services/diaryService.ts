import api from "../api/client";
import type { PetDiaryEntry } from "../types";

export interface CreateDiaryPayload {
  pet_id: string;
  data_registro: string;
  Registro: string;
  tags: string[];
  suspeita?: string | null;
}

function asArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

export function formatDiaryDate(value?: string | null): string {
  if (!value) return "";
  const datePart = value.split("T")[0];
  const [yyyy, mm, dd] = datePart.split("-");
  return dd && mm && yyyy ? `${dd}/${mm}/${yyyy}` : value;
}

export function parseDiaryTags(value: string): string[] {
  return value
    .split(",")
    .map((tag) => tag.trim())
    .filter(Boolean);
}

export async function fetchDiaryByPet(petId: string): Promise<PetDiaryEntry[]> {
  const response = await api.get<PetDiaryEntry[]>("/api/pet-diary", {
    params: { pet_id: petId },
  });
  return asArray<PetDiaryEntry>(response.data);
}

export async function createDiaryEntry(
  payload: CreateDiaryPayload,
): Promise<PetDiaryEntry> {
  const response = await api.post<PetDiaryEntry>("/api/pet-diary", payload);
  return response.data;
}
