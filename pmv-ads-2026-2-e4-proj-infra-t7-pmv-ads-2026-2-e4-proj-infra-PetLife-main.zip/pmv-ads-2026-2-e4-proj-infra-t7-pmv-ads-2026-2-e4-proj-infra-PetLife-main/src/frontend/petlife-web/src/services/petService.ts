import api from "../api/client";
import type { Pet } from "../types";
import { formatPetAge } from "../utils/homeFormat";

export interface CreatePetPayload {
  nome: string;
  especie: string;
  raca?: string | null;
  peso_kg?: number | null;
  data_nascimento?: string | null;
  microchip?: string | null;
}

function asArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

export function formatPetCardMeta(pet: Pet): string {
  const age = formatPetAge(pet.data_nascimento);
  const parts = [
    pet.especie,
    pet.raca,
    age === "Idade não informada" ? undefined : age,
  ].filter((part): part is string => Boolean(part?.trim()));

  return parts.join(" • ");
}

export async function listPets(): Promise<Pet[]> {
  const response = await api.get<Pet[]>("/api/pets");
  return asArray<Pet>(response.data);
}

export async function getPet(id: string): Promise<Pet> {
  const response = await api.get<Pet>(`/api/pets/${id}`);
  return response.data;
}

export async function createPet(payload: CreatePetPayload): Promise<Pet> {
  const response = await api.post<Pet>("/api/pets", payload);
  return response.data;
}

export async function updatePet(id: string, payload: CreatePetPayload): Promise<Pet> {
  const response = await api.put<Pet>(`/api/pets/${id}`, payload);
  return response.data;
}

export async function deletePet(id: string): Promise<void> {
  await api.delete(`/api/pets/${id}`);
}

export async function uploadPetPhoto(id: string, file: File): Promise<Pet> {
  const formData = new FormData();
  formData.append("file", file);

  const response = await api.post<Pet>(`/api/pets/${id}/photo`, formData, {
    headers: { "Content-Type": false },
  });

  return response.data;
}
