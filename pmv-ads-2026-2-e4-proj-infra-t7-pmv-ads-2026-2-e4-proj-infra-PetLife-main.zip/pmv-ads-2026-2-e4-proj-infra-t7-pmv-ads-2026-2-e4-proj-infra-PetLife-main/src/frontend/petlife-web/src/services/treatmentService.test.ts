import { describe, it, expect } from "vitest";
import { formatTreatmentDetails } from "./treatmentService";

describe("treatmentService - utilitários de exibição", () => {
  it("deve formatar os detalhes com dose, frequência e data de início", () => {
    const text = formatTreatmentDetails({
      id: "1",
      pet_id: "pet-1",
      medicamento: "Antibiótico",
      dose: "50mg",
      frequencia_horas: 8,
      data_inicio: "2026-11-01",
      ativo: true,
    });

    expect(text).toContain("50mg");
    expect(text).toContain("a cada 8h");
    expect(text).toContain("início");
  });

  it("deve formatar corretamente quando não houver frequência informada", () => {
    const text = formatTreatmentDetails({
      id: "2",
      pet_id: "pet-1",
      medicamento: "Pomada",
      dose: "1 aplicação",
      data_inicio: "2026-11-01",
      ativo: true,
    });

    expect(text).toContain("1 aplicação");
    expect(text).not.toContain("a cada");
  });
});