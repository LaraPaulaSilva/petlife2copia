import api from "../api/client";
import type { Consulta, OrigemRegistro, StatusConsulta } from "../types";

export interface CreateConsultaPayload {
  pet_id: string;
  tutor_id?: string | null;
  veterinario_id?: string | null;
  clinica?: string | null;
  data: string;
  hora?: string | null;
  tipo_atendimento: string;
  motivo?: string | null;
  status?: StatusConsulta;
  origem_registro?: OrigemRegistro;
  autor_id: string;
  descricao_clinica?: string | null;
  peso_kg?: number | null;
  temperatura_c?: number | null;
  diagnostico?: string | null;
  conduta?: string | null;
  retorno_previsto?: string | null;
  observacoes?: string | null;
  valor?: number | null;
}

export const STATUS_CONSULTA_LABEL: Record<StatusConsulta, string> = {
  SOLICITADA: "Solicitada",
  CONFIRMADA: "Confirmada",
  CANCELADA: "Cancelada",
  REALIZADA: "Realizada",
  NAO_COMPARECEU: "Não compareceu",
};

function asArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

export function formatConsultaDate(value?: string | null): string {
  if (!value) return "";
  const datePart = value.split("T")[0];
  const [yyyy, mm, dd] = datePart.split("-");
  return dd && mm && yyyy ? `${dd}/${mm}/${yyyy}` : value;
}

export function formatConsultaValor(valor?: number | null): string {
  if (valor === null || valor === undefined) return "";
  return valor.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

export async function fetchConsultasByPet(petId: string): Promise<Consulta[]> {
  const response = await api.get<Consulta[]>("/api/consultas", {
    params: { pet_id: petId },
  });
  return asArray<Consulta>(response.data);
}

export async function createConsulta(
  payload: CreateConsultaPayload,
): Promise<Consulta> {
  const response = await api.post<Consulta>("/api/consultas", payload);
  return response.data;
}

export async function deleteConsulta(
  id: string,
  solicitanteId?: string | null,
): Promise<void> {
  await api.delete(`/api/consultas/${id}`, {
    params: solicitanteId ? { solicitante_id: solicitanteId } : undefined,
  });
}
