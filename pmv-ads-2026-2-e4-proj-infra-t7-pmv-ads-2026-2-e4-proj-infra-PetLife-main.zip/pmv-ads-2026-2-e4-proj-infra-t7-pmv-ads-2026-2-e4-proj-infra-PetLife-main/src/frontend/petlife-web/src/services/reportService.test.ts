import { beforeEach, describe, expect, it, vi } from "vitest";

const { apiGet } = vi.hoisted(() => ({
  apiGet: vi.fn(),
}));

vi.mock("../api/client", () => ({
  default: {
    get: apiGet,
  },
}));

import {
  executeReport,
  getAvailablePets,
} from "./reportService";

const pet = {
  id: "pet-1",
  nome: "Lulu",
  especie: "Felino",
  tutor_nome: "Maria",
};

const consulta = {
  id: "consulta-1",
  pet_id: "pet-1",
  data: "2026-10-25",
  tipo_atendimento: "Rotina",
  motivo: "Check-up",
  status: "REALIZADA",
  observacoes: "Consulta de rotina",
};

const vacina = {
  id: "vacina-1",
  pet_id: "pet-1",
  tipo: "V10",
  data_aplicacao: "2026-10-25",
  origem_registro: "VETERINARIO",
};

function configureApiMock() {
  apiGet.mockImplementation(async (...args: unknown[]) => {
    const path = String(args[0]);

    if (path === "/api/pets/shared") {
      return { data: [pet] };
    }

    if (path.startsWith("/api/treatments/pet/")) {
      return { data: [] };
    }

    if (path === "/api/vaccines") {
      return { data: [vacina] };
    }

    if (path === "/api/consultas") {
      return { data: [consulta] };
    }

    if (path === "/api/documents" || path === "/api/pet-diary") {
      return { data: [] };
    }

    return { data: [] };
  });
}

describe("reportService", () => {
  beforeEach(() => {
    apiGet.mockReset();
    configureApiMock();
    localStorage.clear();
  });

  it("busca os pets compartilhados com o veterinário", async () => {
    await expect(getAvailablePets()).resolves.toEqual([
      expect.objectContaining({
        id: "pet-1",
        nome: "Lulu",
        especie: "Felino",
        tutorNome: "Maria",
      }),
    ]);

    expect(apiGet).toHaveBeenCalledWith("/api/pets/shared");
  });

  it("retorna somente consultas quando a área selecionada é Consulta", async () => {
    const result = await executeReport(
      "Consultas do mês",
      {
        tipoModulo: "Consulta",
        tipoPeriodo: "todos",
        ordenacao: "data_desc",
      },
      "Mariana Gressi",
    );

    expect(result.itens).toHaveLength(1);
    expect(result.itens[0].categoria).toBe("Consulta");
    expect(result.itens[0].itemDetalhe).toContain("Check-up");
  });

  it("aplica o período personalizado aos registros", async () => {
    const result = await executeReport(
      "Consultas de outubro",
      {
        tipoModulo: "Consulta",
        tipoPeriodo: "personalizado",
        dataInicio: "2026-10-25",
        dataFim: "2026-10-25",
      },
      "Mariana Gressi",
    );

    expect(result.itens).toHaveLength(1);
    expect(result.itens[0].data).toBe("2026-10-25");
  });

  it("não inclui vacinas no relatório de consultas", async () => {
    const result = await executeReport(
      "Consultas",
      {
        tipoModulo: "Consulta",
        tipoPeriodo: "todos",
      },
      "Mariana Gressi",
    );

    expect(result.itens.some((item) => item.categoria === "Vacina")).toBe(false);
  });
});