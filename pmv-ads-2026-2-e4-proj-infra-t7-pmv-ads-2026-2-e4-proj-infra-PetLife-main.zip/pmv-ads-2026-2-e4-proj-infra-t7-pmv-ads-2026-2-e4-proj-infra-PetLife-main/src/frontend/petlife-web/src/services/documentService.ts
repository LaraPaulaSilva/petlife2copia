import api from "../api/client";
import type { Document } from "../types";

export interface CreateDocumentPayload {
  pet_id: string;
  usuario_id: string;
  perfil_autor?: string | null;
  consulta_id?: string | null;
  titulo: string;
  tipo_doc?: string | null;
  arquivo_url: string;
}

interface UploadResult {
  secure_url: string;
  PublicId?: string;
}

function asArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

export function formatDocumentDate(value?: string | null): string {
  if (!value) return "";
  const datePart = value.split("T")[0];
  const [yyyy, mm, dd] = datePart.split("-");
  return dd && mm && yyyy ? `${dd}/${mm}/${yyyy}` : value;
}

export async function fetchDocumentsByPet(petId: string): Promise<Document[]> {
  const response = await api.get<Document[]>("/api/documents", {
    params: { pet_id: petId },
  });
  return asArray<Document>(response.data);
}

export async function uploadDocumentFile(file: File): Promise<string> {
  const formData = new FormData();
  formData.append("file", file);

  const response = await api.post<UploadResult>(
    "/api/documents/upload",
    formData,
    { headers: { "Content-Type": "multipart/form-data" } },
  );

  return response.data.secure_url;
}

export async function createDocument(
  payload: CreateDocumentPayload,
): Promise<Document> {
  const response = await api.post<Document>("/api/documents", payload);
  return response.data;
}

export async function deleteDocument(
  id: string,
  solicitanteId?: string | null,
): Promise<void> {
  await api.delete(`/api/documents/${id}`, {
    params: solicitanteId ? { solicitante_id: solicitanteId } : undefined,
  });
}
