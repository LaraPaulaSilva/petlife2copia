// Tipos que espelham os models do backend (PetLife 2.0 — MongoDB).
// Mantenha alinhado com src/backend/Models.

export type Role = "Tutor" | "Veterinário";
export type OrigemRegistro = "TUTOR" | "VETERINARIO";
export type StatusConsulta =
  | "SOLICITADA"
  | "CONFIRMADA"
  | "CANCELADA"
  | "REALIZADA"
  | "NAO_COMPARECEU";

export interface User {
  id: string;
  name: string;
  email: string;
  role?: Role;
  crmv?: string | null;
  cpf?: string | null;
  telefone?: string | null;
  endereço?: string | null;
  imagem?: string | null;
}

export interface AuthResponse {
  token: string;
  expires_at: string;
  user: User;
}

export interface Pet {
  id: string;
  nome: string;
  especie: string;
  raca?: string | null;
  peso_kg?: number | null;
  data_nascimento?: string | null;
  microchip?: string | null;
  foto_url?: string | null;
  tutor_id: string;
  criado_at?: string;
}

export interface SharedPet extends Pet {
  tutor_nome?: string | null;
}

export interface Share {
  pet_id: string;
  vet_id: string;
  id: string;
}
export interface Consulta {
  id: string;
  pet_id: string;
  tutor_id?: string | null;
  veterinario_id?: string | null;
  clinica?: string | null;
  data: string;
  hora?: string | null;
  tipo_atendimento: string;
  motivo?: string | null;
  status: StatusConsulta;
  origem_registro: OrigemRegistro;
  autor_id: string;
  descricao_clinica?: string | null;
  peso_kg?: number | null;
  temperatura_c?: number | null;
  diagnostico?: string | null;
  conduta?: string | null;
  retorno_previsto?: string | null;
  observacoes?: string | null;
  valor?: number | null;
  criado_em?: string;
}

export interface Vaccine {
  id: string;
  pet_id: string;
  veterinario_id?: string | null;
  tipo: string;
  data_aplicacao: string;
  data_proxima_dose?: string | null;
  comprovante_url?: string | null;
  lote?: string | null;
  fabricante?: string | null;
  laboratorio?: string | null;
  dose?: string | null;
  via_administracao?: string | null;
  local_aplicacao?: string | null;
  situacao?: string | null;
  origem_registro: OrigemRegistro;
  alerta_reforco: boolean;
  observacoes?: string | null;
  criado_at?: string;
}

export interface Document {
  id: string;
  pet_id: string;
  usuario_id: string;
  perfil_autor?: string | null;
  consulta_id?: string | null;
  titulo: string;
  tipo_doc?: string | null;
  arquivo_url: string;
  data_upload?: string;
}

export interface Treatment {
  id: string;
  pet_id: string;
  veterinario_id?: string | null;
  medicamento: string;
  dose: string;
  frequencia_horas?: number | null;
  duracao_uso?: string | null;
  recorrencia?: string | null;
  ciclos?: number | null;
  data_inicio: string;
  data_fim?: string | null;
  ativo: boolean;
}

export interface PetDiaryEntry {
  id: string;
  pet_id: string;
  usuario_id?: string | null;
  perfil_autor: string;
  data_registro: string;
  tags: string[];
  Registro: string;
  suspeita?: string | null;
  criado_at?: string;
}

export interface Report {
  id: string;
  user_id: string;
  name: string;
  type: string;
  created_at?: string;
  filters?: Record<string, string> | null;
}

export interface Notificacao {
  id?: string;
  userId?: string;
  titulo?: string;
  mensagem?: string;
  tipo?: string;
  dataHora?: string;
  lida?: boolean;
  canal?: string;
  referenciaId?: string | null;
}

export interface EventoRotina {
  id?: string;
  userId?: string;
  petId?: string;
  tipo?: string;
  dataHora?: string;
  recorrente?: boolean;
  intervaloDias?: number | null;
  observacoes?: string | null;
  status?: string;
}
