import axios from "axios";

// URL base da API do backend. Pode ser sobrescrita pela variável de ambiente
// VITE_API_URL (arquivo .env). Em desenvolvimento, aponta para a API local.
export const baseURL = import.meta.env.VITE_API_URL ?? "http://localhost:5210";
// const token = localStorage.getItem("petlife_token");
export const api = axios.create({
  baseURL,
  headers: {
    "Content-Type": "application/json",
    // ...(token && { Authorization: `Bearer ${token}` }),
  },
});

// Interceptor de requisição: anexa o token JWT (quando existir) em toda chamada.
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("petlife_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;
