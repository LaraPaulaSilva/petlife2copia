import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { listPets } from "../../services/petService";
import type { Pet, Share } from "../../types";
import styles from "./SharePetList.module.css";
import SharePetCard from "../../components/tutor/SharePetCard";
import api, { baseURL } from "../../api/client";

export default function SharePetList({ vetId }: { vetId: string }) {
  const { user } = useAuth();
  const location = useLocation();
  const [pets, setPets] = useState<Pet[]>([]);
  const [shares, setShares] = useState<Share[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const photoWarning = (location.state as { photoWarning?: string } | null)
    ?.photoWarning;

  useEffect(() => {
    if (!user?.id) {
      setLoading(true);
      return;
    }

    let isMounted = true;
    setLoading(true);
    setError(null);

    listPets()
      .then((data) => {
        if (isMounted) setPets(data);
      })
      .catch(() => {
        if (isMounted) {
          setPets([]);
          setError("Não foi possível carregar seus pets.");
        }
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [user?.id]);

  useEffect(() => {
    api
      .get(`${baseURL}/api/shares/getshares`)
      .then((data) => {
        setShares(data.data);
      })
      .catch((error) =>
        console.log("SharePetList >>>>> getshares >>>>>", error),
      );
  }, []);

  return (
    <div className={styles.pageContainer}>
      {photoWarning && <p className={styles.warningMessage}>{photoWarning}</p>}

      {loading && <p className={styles.statusMessage}>Carregando...</p>}

      {error && <p className={styles.errorMessage}>{error}</p>}

      {!loading && pets.length === 0 && !error && (
        <div className={styles.emptyState}>
          <p>Você ainda não cadastrou nenhum pet.</p>
          <Link to="/tutor/pets/novo" className={styles.addBtn}>
            + Adicionar pet
          </Link>
        </div>
      )}

      {!loading && pets.length > 0 && (
        <div className={styles.petsGrid}>
          {pets.map((pet) => {
            const petShares = shares.filter((s) => s.pet_id === pet.id);
            return (
              <SharePetCard
                key={pet.id}
                pet={pet}
                vetId={vetId}
                shares={petShares}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}
