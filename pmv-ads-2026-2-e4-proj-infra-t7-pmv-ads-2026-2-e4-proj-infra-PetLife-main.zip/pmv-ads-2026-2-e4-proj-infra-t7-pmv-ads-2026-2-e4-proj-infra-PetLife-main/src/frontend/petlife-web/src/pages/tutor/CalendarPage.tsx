import { useEffect, useState } from "react";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  PawPrint,
  Plus,
} from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";
import TutorLayout from "../../components/layout/TutorLayout";
import NewEventModal, {
  type EventoParaEditar,
} from "../../components/tutor/NewEventModal";
import {
  buscarEventosDoUsuario,
  buscarPetsDoTutor,
  type EventoRotina,
} from "../../services/eventoRotinaService";
import type { Pet } from "../../types";
import styles from "./CalendarPage.module.css";

const diasSemana = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

const nomesMeses = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
];

const nomesTipos: Record<string, string> = {
  vacina: "Vacina",
  vermifugo: "Vermífugo",
  antipulgas: "Antipulgas",
  consulta: "Consulta",
  tosa: "Tosa",
};

type Evento = {
  id: string;
  data: string;
  titulo: string;
  tipo: string;
  original: EventoRotina;
};

function formatarData(data: Date) {
  const ano = data.getFullYear();
  const mes = String(data.getMonth() + 1).padStart(2, "0");
  const dia = String(data.getDate()).padStart(2, "0");
  return ano + "-" + mes + "-" + dia;
}

function formatarHora(data: Date) {
  const h = String(data.getHours()).padStart(2, "0");
  const m = String(data.getMinutes()).padStart(2, "0");
  return h + ":" + m;
}

function lerDataHora(texto: string) {
  const temFuso = /(Z|[+-]\d{2}:\d{2})$/.test(texto);
  return new Date(temFuso ? texto : texto + "Z");
}

function corDoEvento(tipo: string) {
  const t = tipo.toLowerCase();
  if (t === "vacina") return styles.eventVacina;
  if (t === "vermifugo") return styles.eventVermifugo;
  if (t === "antipulgas") return styles.eventAntipulgas;
  return styles.eventConsulta;
}

export default function CalendarPage() {
  const { user } = useAuth();
  const hoje = new Date();
  const [mes, setMes] = useState(hoje.getMonth());
  const [ano, setAno] = useState(hoje.getFullYear());
  const [eventos, setEventos] = useState<Evento[]>([]);
  const [pets, setPets] = useState<Pet[]>([]);
  const [erro, setErro] = useState(false);
  const [modalAberto, setModalAberto] = useState(false);
  const [eventoEditando, setEventoEditando] = useState<EventoParaEditar | undefined>(undefined);
  const [versao, setVersao] = useState(0);

  useEffect(() => {
    if (!user?.id) return;

    Promise.allSettled([
      buscarEventosDoUsuario(user.id),
      buscarPetsDoTutor(),
    ]).then(([resEventos, resPets]) => {
      if (resEventos.status !== "fulfilled") {
        setErro(true);
        return;
      }

      const listaPets = resPets.status === "fulfilled" ? resPets.value : [];
      setPets(listaPets);

      const convertidos = resEventos.value.map((e: EventoRotina) => {
        const pet = listaPets.find((p) => p.id === e.petId);
        const nomeTipo = nomesTipos[e.tipo.toLowerCase()] ?? e.tipo;
        return {
          id: e.id,
          data: formatarData(lerDataHora(e.dataHora)),
          titulo: pet ? nomeTipo + " " + pet.nome : nomeTipo,
          tipo: e.tipo,
          original: e,
        };
      });

      setEventos(convertidos);
      setErro(false);
    });
  }, [user?.id, versao]);

  function abrirNovo() {
    setEventoEditando(undefined);
    setModalAberto(true);
  }

  function abrirEdicao(evento: Evento) {
    const o = evento.original;
    const quando = lerDataHora(o.dataHora);

    setEventoEditando({
      id: o.id,
      petId: o.petId,
      tipo: o.tipo,
      data: formatarData(quando),
      hora: formatarHora(quando),
      observacoes: o.observacoes ?? "",
      status: o.status ?? "agendado",
    });
    setModalAberto(true);
  }

  function fecharModal() {
    setModalAberto(false);
    setEventoEditando(undefined);
  }

  function depoisDeSalvar() {
    fecharModal();
    setVersao(versao + 1);
  }

  function mesAnterior() {
    if (mes === 0) {
      setMes(11);
      setAno(ano - 1);
    } else {
      setMes(mes - 1);
    }
  }

  function proximoMes() {
    if (mes === 11) {
      setMes(0);
      setAno(ano + 1);
    } else {
      setMes(mes + 1);
    }
  }

  const primeiroDiaDaSemana = new Date(ano, mes, 1).getDay();
  const diasNoMes = new Date(ano, mes + 1, 0).getDate();
  const totalQuadrados = Math.ceil((primeiroDiaDaSemana + diasNoMes) / 7) * 7;

  const dias: Date[] = [];
  for (let i = 0; i < totalQuadrados; i++) {
    dias.push(new Date(ano, mes, 1 - primeiroDiaDaSemana + i));
  }

  return (
    <TutorLayout>
      <div className={styles.pageContainer}>
        <header className={styles.topHeader}>
          <div className={styles.titleGroup}>
            <div className={styles.iconCircle}>
              <CalendarDays size={28} />
            </div>
            <div>
              <h1 className={styles.title}>Calendário</h1>
              <p className={styles.subtitle}>
                Acompanhe os eventos e compromissos dos seus pets.
              </p>
            </div>
          </div>

          <button
            type="button"
            className={styles.btnPrimary}
            onClick={abrirNovo}
          >
            <Plus size={20} />
            Novo evento
          </button>
        </header>

        {erro && (
          <p className={styles.erro}>
            Não foi possível carregar os eventos. Confira se o backend está rodando.
          </p>
        )}

<section className={styles.calendarCard}>
  <div className={styles.calendarToolbar}>
    <div className={styles.monthNav}>
      <button
        type="button"
        className={styles.navBtn}
        onClick={mesAnterior}
        aria-label="Mês anterior"
      >
        <ChevronLeft size={20} />
      </button>
      <h2 className={styles.monthTitle}>
        {nomesMeses[mes]} {ano}
      </h2>
      <button
        type="button"
        className={styles.navBtn}
        onClick={proximoMes}
        aria-label="Próximo mês"
      >
        <ChevronRight size={20} />
      </button>
    </div>

            <div className={styles.viewToggle}>
              <button type="button" className={`${styles.viewBtn} ${styles.viewBtnActive}`}>
                Mês
              </button>
              <button type="button" className={styles.viewBtn} disabled>
                Semana
              </button>
              <button type="button" className={styles.viewBtn} disabled>
                Dia
              </button>
            </div>
          </div>

          <div className={styles.weekdays}>
            {diasSemana.map((nome) => (
              <div key={nome} className={styles.weekday}>
                {nome}
              </div>
            ))}
          </div>

          <div className={styles.daysGrid}>
            {dias.map((dia) => {
              const data = formatarData(dia);
              const ehHoje = data === formatarData(hoje);
              const foraDoMes = dia.getMonth() !== mes;
              const eventosDoDia = eventos.filter((e) => e.data === data);

              let classe = styles.dayCell;
              if (foraDoMes) classe += " " + styles.outsideMonth;
              if (ehHoje) classe += " " + styles.today;

              return (
                <div key={data} className={classe}>
                  <span className={styles.dayNumber}>{dia.getDate()}</span>

                  {eventosDoDia.map((evento) => (
                    <div
                      key={evento.id}
                      className={`${styles.eventChip} ${corDoEvento(evento.tipo)}`}
                      onClick={() => abrirEdicao(evento)}
                    >
                      <PawPrint size={12} />
                      <span className={styles.eventText}>{evento.titulo}</span>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        </section>
      </div>

      {modalAberto && (
        <NewEventModal
          pets={pets}
          evento={eventoEditando}
          aoFechar={fecharModal}
          aoSalvar={depoisDeSalvar}
        />
      )}
    </TutorLayout>
  );
}