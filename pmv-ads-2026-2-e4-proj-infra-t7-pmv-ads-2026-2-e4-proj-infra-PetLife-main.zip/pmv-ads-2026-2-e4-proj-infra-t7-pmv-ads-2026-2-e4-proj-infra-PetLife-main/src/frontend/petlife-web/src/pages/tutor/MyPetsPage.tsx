import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import TutorLayout from "../../components/layout/TutorLayout";
import PetCard from "../../components/tutor/PetCard";
import { deletePet, listPets } from "../../services/petService";
import type { Pet } from "../../types";
import styles from "./MyPetsPage.module.css";

export default function MyPetsPage() {
  const { user } = useAuth();
  const location = useLocation();
  const [pets, setPets] = useState<Pet[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const photoWarning = (location.state as { photoWarning?: string } | null)?.photoWarning;

  useEffect(() => {
    if (!user?.id) {
      setLoading(true);
      return;
    }

    let isMounted = true;
    setLoading(true);
    setError(null);

    listPets()
      .then((data) => {
        if (isMounted) setPets(data);
      })
      .catch(() => {
        if (isMounted) {
          setPets([]);
          setError("Não foi possível carregar seus pets.");
        }
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [user?.id]);

  const handleDelete = async (id: string) => {
    try {
      await deletePet(id);
      setPets((current) => current.filter((pet) => pet.id !== id));
      setError(null);
    } catch {
      setError("Não foi possível excluir o pet.");
    }
  };

  return (
    <TutorLayout>
      <div className={styles.pageContainer}>
        <header className={styles.topHeader}>
          <h1 className={styles.pageTitle}>Meus Pets</h1>
          <Link to="/tutor/pets/novo" className={styles.addBtn}>
            + Adicionar pet
          </Link>
        </header>

        {photoWarning && <p className={styles.warningMessage}>{photoWarning}</p>}

        {loading && <p className={styles.statusMessage}>Carregando...</p>}

        {error && <p className={styles.errorMessage}>{error}</p>}

        {!loading && pets.length === 0 && !error && (
          <div className={styles.emptyState}>
            <p>Você ainda não cadastrou nenhum pet.</p>
            <Link to="/tutor/pets/novo" className={styles.addBtn}>
              + Adicionar pet
            </Link>
          </div>
        )}

        {!loading && pets.length > 0 && (
          <div className={styles.petsGrid}>
            {pets.map((pet) => (
              <PetCard key={pet.id} pet={pet} onDelete={handleDelete} />
            ))}
          </div>
        )}
      </div>
    </TutorLayout>
  );
}
