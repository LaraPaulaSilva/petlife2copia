import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, type InitialEntry } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import type { Pet, User } from "../../types";
import MyPetsPage from "./MyPetsPage";
import { deletePet, listPets } from "../../services/petService";

vi.mock("../../services/petService", async () => {
  const actual = await vi.importActual<typeof import("../../services/petService")>(
    "../../services/petService",
  );
  return {
    ...actual,
    listPets: vi.fn(),
    deletePet: vi.fn(),
  };
});

const mockedListPets = vi.mocked(listPets);
const mockedDeletePet = vi.mocked(deletePet);

const tutorUser: User = {
  id: "tutor-1",
  name: "Ana Souza",
  email: "ana@petlife.test",
  role: "Tutor",
};

function yearsAgo(years: number): string {
  const date = new Date();
  date.setFullYear(date.getFullYear() - years);
  date.setMonth(date.getMonth() - 1);
  return date.toISOString();
}

const pets: Pet[] = [
  {
    id: "pet-1",
    nome: "Lulu",
    especie: "Gato",
    raca: "Vira-lata",
    data_nascimento: yearsAgo(2),
    tutor_id: "tutor-1",
  },
  {
    id: "pet-2",
    nome: "Rex",
    especie: "Cão",
    raca: "Golden",
    data_nascimento: yearsAgo(4),
    tutor_id: "tutor-1",
  },
];

function renderMyPets(initialEntries: InitialEntry[] = ["/tutor/pets"]) {
  return render(
    <AuthContext.Provider
      value={{
        user: tutorUser,
        setUser: vi.fn(),
        login: vi.fn(),
        logout: vi.fn(),
      }}
    >
      <MemoryRouter initialEntries={initialEntries}>
        <MyPetsPage />
      </MemoryRouter>
    </AuthContext.Provider>,
  );
}

describe("MyPetsPage", () => {
  beforeEach(() => {
    mockedListPets.mockReset();
    mockedDeletePet.mockReset();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("exibe os cards com nome, meta e link para o prontuário", async () => {
    mockedListPets.mockResolvedValue(pets);
    renderMyPets();

    await waitFor(() => {
      expect(screen.getByRole("heading", { name: "Lulu" })).toBeInTheDocument();
      expect(screen.getByRole("heading", { name: "Rex" })).toBeInTheDocument();
    });

    expect(screen.getByText("Gato • Vira-lata • 2 anos")).toBeInTheDocument();
    expect(screen.getByText("Cão • Golden • 4 anos")).toBeInTheDocument();

    const prontuarioLinks = screen.getAllByRole("link", { name: "Ver prontuário" });
    expect(prontuarioLinks[0]).toHaveAttribute("href", "/tutor/pets/pet-1/tratamentos");
    expect(prontuarioLinks[1]).toHaveAttribute("href", "/tutor/pets/pet-2/tratamentos");

    const editLinks = screen.getAllByRole("link", { name: "Editar" });
    expect(editLinks[0]).toHaveAttribute("href", "/tutor/pets/pet-1/editar");
    expect(editLinks[1]).toHaveAttribute("href", "/tutor/pets/pet-2/editar");
  });

  it("mostra o botão de adicionar pet no cabeçalho", async () => {
    mockedListPets.mockResolvedValue(pets);
    renderMyPets();

    await waitFor(() => {
      expect(screen.getByRole("heading", { name: "Lulu" })).toBeInTheDocument();
    });

    const addLink = screen.getByRole("link", { name: "+ Adicionar pet" });
    expect(addLink).toHaveAttribute("href", "/tutor/pets/novo");
  });

  it("mostra estado vazio quando o tutor ainda não tem pets", async () => {
    mockedListPets.mockResolvedValue([]);
    renderMyPets();

    await waitFor(() => {
      expect(screen.getByText("Você ainda não cadastrou nenhum pet.")).toBeInTheDocument();
    });

    expect(screen.queryByText("Lulu")).not.toBeInTheDocument();
    expect(screen.getAllByRole("link", { name: "+ Adicionar pet" }).length).toBeGreaterThan(0);
  });

  it("mostra erro quando a lista de pets falha", async () => {
    mockedListPets.mockRejectedValue(new Error("falha na api"));
    renderMyPets();

    await waitFor(() => {
      expect(screen.getByText("Não foi possível carregar seus pets.")).toBeInTheDocument();
    });

    expect(screen.queryByText("Você ainda não cadastrou nenhum pet.")).not.toBeInTheDocument();
    expect(screen.queryByText("Lulu")).not.toBeInTheDocument();
  });

  it("mostra aviso quando a foto não foi enviada no cadastro", async () => {
    mockedListPets.mockResolvedValue([]);
    renderMyPets([
      {
        pathname: "/tutor/pets",
        state: { photoWarning: "O pet foi salvo, mas a foto não pôde ser enviada." },
      },
    ]);

    await waitFor(() => {
      expect(
        screen.getByText("O pet foi salvo, mas a foto não pôde ser enviada."),
      ).toBeInTheDocument();
    });
  });

  it("exclui o pet quando a exclusão é confirmada", async () => {
    const user = userEvent.setup();
    mockedListPets.mockResolvedValue(pets);
    mockedDeletePet.mockResolvedValue();
    vi.spyOn(window, "confirm").mockReturnValue(true);
    renderMyPets();

    await waitFor(() => {
      expect(screen.getByRole("heading", { name: "Lulu" })).toBeInTheDocument();
    });

    await user.click(screen.getAllByRole("button", { name: "Excluir" })[0]);

    await waitFor(() => {
      expect(mockedDeletePet).toHaveBeenCalledWith("pet-1");
      expect(screen.queryByRole("heading", { name: "Lulu" })).not.toBeInTheDocument();
    });

    expect(window.confirm).toHaveBeenCalledWith(
      "Excluir Lulu? Esta ação não pode ser desfeita.",
    );
    expect(screen.getByRole("heading", { name: "Rex" })).toBeInTheDocument();
  });

  it("não exclui o pet quando a exclusão é cancelada", async () => {
    const user = userEvent.setup();
    mockedListPets.mockResolvedValue(pets);
    vi.spyOn(window, "confirm").mockReturnValue(false);
    renderMyPets();

    await waitFor(() => {
      expect(screen.getByRole("heading", { name: "Lulu" })).toBeInTheDocument();
    });

    await user.click(screen.getAllByRole("button", { name: "Excluir" })[0]);

    expect(mockedDeletePet).not.toHaveBeenCalled();
    expect(screen.getByRole("heading", { name: "Lulu" })).toBeInTheDocument();
  });
});
