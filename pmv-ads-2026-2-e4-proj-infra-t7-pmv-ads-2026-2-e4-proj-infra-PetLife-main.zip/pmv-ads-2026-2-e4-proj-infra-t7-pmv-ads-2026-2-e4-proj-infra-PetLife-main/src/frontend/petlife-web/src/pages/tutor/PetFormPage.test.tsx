import { describe, it, expect, vi, beforeEach, beforeAll, afterEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import type { Pet, User } from "../../types";
import PetFormPage from "./PetFormPage";
import { createPet, deletePet, getPet, updatePet, uploadPetPhoto } from "../../services/petService";

vi.mock("../../services/petService", () => ({
  createPet: vi.fn(),
  deletePet: vi.fn(),
  getPet: vi.fn(),
  updatePet: vi.fn(),
  uploadPetPhoto: vi.fn(),
}));

const mockedCreate = vi.mocked(createPet);
const mockedDeletePet = vi.mocked(deletePet);
const mockedGetPet = vi.mocked(getPet);
const mockedUpdate = vi.mocked(updatePet);
const mockedUpload = vi.mocked(uploadPetPhoto);

const tutorUser: User = {
  id: "tutor-1",
  name: "Ana Souza",
  email: "ana@petlife.test",
  role: "Tutor",
};

const createdPet: Pet = {
  id: "pet-1",
  nome: "Lulu",
  especie: "Gato",
  raca: "Vira-lata",
  peso_kg: 4.2,
  data_nascimento: "2024-01-10",
  microchip: "123",
  tutor_id: "tutor-1",
};

function renderForm(path = "/tutor/pets/novo") {
  return render(
    <AuthContext.Provider
      value={{
        user: tutorUser,
        setUser: vi.fn(),
        login: vi.fn(),
        logout: vi.fn(),
      }}
    >
      <MemoryRouter initialEntries={[path]}>
        <Routes>
          <Route path="/tutor/pets/novo" element={<PetFormPage />} />
          <Route path="/tutor/pets/:petId/editar" element={<PetFormPage />} />
          <Route path="/tutor/pets" element={<div>Lista de pets</div>} />
        </Routes>
      </MemoryRouter>
    </AuthContext.Provider>,
  );
}

describe("PetFormPage", () => {
  beforeAll(() => {
    vi.stubGlobal(
      "URL",
      Object.assign(globalThis.URL, {
        createObjectURL: vi.fn(() => "blob:preview"),
        revokeObjectURL: vi.fn(),
      }),
    );
  });

  beforeEach(() => {
    mockedCreate.mockReset();
    mockedDeletePet.mockReset();
    mockedGetPet.mockReset();
    mockedUpdate.mockReset();
    mockedUpload.mockReset();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("bloqueia o envio sem nome ou espécie", async () => {
    const user = userEvent.setup();
    renderForm();

    await user.click(screen.getByRole("button", { name: "Salvar pet" }));

    expect(screen.getByText("Preencha o nome e a espécie do pet.")).toBeInTheDocument();
    expect(mockedCreate).not.toHaveBeenCalled();

    await user.type(screen.getByLabelText("Nome"), "Lulu");
    await user.click(screen.getByRole("button", { name: "Salvar pet" }));

    expect(mockedCreate).not.toHaveBeenCalled();
  });

  it("chama createPet com o payload e volta para a listagem", async () => {
    const user = userEvent.setup();
    mockedCreate.mockResolvedValue(createdPet);
    renderForm();

    await user.type(screen.getByLabelText("Nome"), "Lulu");
    await user.selectOptions(screen.getByLabelText("Espécie"), "Gato");
    await user.type(screen.getByLabelText("Raça"), "Vira-lata");
    await user.type(screen.getByLabelText("Peso (kg)"), "4.2");
    await user.type(screen.getByLabelText("Data de nascimento"), "2024-01-10");
    await user.type(screen.getByLabelText("Microchip"), "123");
    await user.click(screen.getByRole("button", { name: "Salvar pet" }));

    await waitFor(() => {
      expect(mockedCreate).toHaveBeenCalledWith({
        nome: "Lulu",
        especie: "Gato",
        raca: "Vira-lata",
        peso_kg: 4.2,
        data_nascimento: "2024-01-10",
        microchip: "123",
      });
    });

    expect(mockedUpload).not.toHaveBeenCalled();
    expect(screen.getByText("Lista de pets")).toBeInTheDocument();
  });

  it("faz upload da foto somente quando há arquivo", async () => {
    const user = userEvent.setup();
    mockedCreate.mockResolvedValue(createdPet);
    mockedUpload.mockResolvedValue(createdPet);
    renderForm();

    const file = new File(["foto"], "lulu.jpg", { type: "image/jpeg" });

    await user.type(screen.getByLabelText("Nome"), "Lulu");
    await user.selectOptions(screen.getByLabelText("Espécie"), "Gato");
    await user.upload(screen.getByLabelText("Selecionar foto do pet"), file);
    await user.click(screen.getByRole("button", { name: "Salvar pet" }));

    await waitFor(() => {
      expect(mockedCreate).toHaveBeenCalled();
      expect(mockedUpload).toHaveBeenCalledWith("pet-1", file);
    });
  });

  it("volta para a listagem ao cancelar sem gravar", async () => {
    const user = userEvent.setup();
    renderForm();

    await user.type(screen.getByLabelText("Nome"), "Lulu");
    await user.click(screen.getByRole("button", { name: "Cancelar" }));

    expect(screen.getByText("Lista de pets")).toBeInTheDocument();
    expect(mockedCreate).not.toHaveBeenCalled();
  });

  it("preenche o formulário e atualiza o pet existente", async () => {
    const user = userEvent.setup();
    mockedGetPet.mockResolvedValue(createdPet);
    mockedUpdate.mockResolvedValue({ ...createdPet, nome: "Mel" });
    renderForm("/tutor/pets/pet-1/editar");

    await waitFor(() => {
      expect(screen.getByRole("heading", { name: "Editar Pet" })).toBeInTheDocument();
      expect(screen.getByLabelText("Nome")).toHaveValue("Lulu");
    });

    expect(screen.getByLabelText("Espécie")).toHaveValue("Gato");
    expect(screen.getByLabelText("Raça")).toHaveValue("Vira-lata");
    expect(screen.getByLabelText("Peso (kg)")).toHaveValue(4.2);
    expect(screen.getByLabelText("Data de nascimento")).toHaveValue("2024-01-10");
    expect(screen.getByLabelText("Microchip")).toHaveValue("123");

    await user.clear(screen.getByLabelText("Nome"));
    await user.type(screen.getByLabelText("Nome"), "Mel");
    await user.click(screen.getByRole("button", { name: "Salvar pet" }));

    await waitFor(() => {
      expect(mockedUpdate).toHaveBeenCalledWith("pet-1", {
        nome: "Mel",
        especie: "Gato",
        raca: "Vira-lata",
        peso_kg: 4.2,
        data_nascimento: "2024-01-10",
        microchip: "123",
      });
    });

    expect(mockedCreate).not.toHaveBeenCalled();
    expect(screen.getByText("Lista de pets")).toBeInTheDocument();
  });

  it("mostra erro quando o pet não pode ser carregado", async () => {
    mockedGetPet.mockRejectedValue(new Error("falha na api"));
    renderForm("/tutor/pets/pet-1/editar");

    await waitFor(() => {
      expect(screen.getByText("Não foi possível carregar o pet.")).toBeInTheDocument();
    });

    expect(screen.queryByLabelText("Nome")).not.toBeInTheDocument();
  });

  it("exclui o pet no modo edição e volta para a listagem", async () => {
    const user = userEvent.setup();
    mockedGetPet.mockResolvedValue(createdPet);
    mockedDeletePet.mockResolvedValue();
    vi.spyOn(window, "confirm").mockReturnValue(true);
    renderForm("/tutor/pets/pet-1/editar");

    await waitFor(() => {
      expect(screen.getByRole("button", { name: "Excluir pet" })).toBeInTheDocument();
    });

    await user.click(screen.getByRole("button", { name: "Excluir pet" }));

    await waitFor(() => {
      expect(mockedDeletePet).toHaveBeenCalledWith("pet-1");
      expect(screen.getByText("Lista de pets")).toBeInTheDocument();
    });
  });

  it("não exclui o pet quando a exclusão é cancelada no formulário", async () => {
    const user = userEvent.setup();
    mockedGetPet.mockResolvedValue(createdPet);
    vi.spyOn(window, "confirm").mockReturnValue(false);
    renderForm("/tutor/pets/pet-1/editar");

    await waitFor(() => {
      expect(screen.getByRole("button", { name: "Excluir pet" })).toBeInTheDocument();
    });

    await user.click(screen.getByRole("button", { name: "Excluir pet" }));

    expect(mockedDeletePet).not.toHaveBeenCalled();
    expect(screen.getByRole("heading", { name: "Editar Pet" })).toBeInTheDocument();
  });
});
