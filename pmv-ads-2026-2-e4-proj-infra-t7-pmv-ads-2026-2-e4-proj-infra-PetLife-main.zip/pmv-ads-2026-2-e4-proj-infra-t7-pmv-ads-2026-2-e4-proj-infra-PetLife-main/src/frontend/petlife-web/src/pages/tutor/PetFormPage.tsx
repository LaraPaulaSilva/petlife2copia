import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Camera } from "lucide-react";
import TutorLayout from "../../components/layout/TutorLayout";
import {
  createPet,
  deletePet,
  getPet,
  updatePet,
  uploadPetPhoto,
  type CreatePetPayload,
} from "../../services/petService";
import type { Pet } from "../../types";
import styles from "./PetFormPage.module.css";

const PHOTO_WARNING =
  "O pet foi salvo, mas a foto não pôde ser enviada.";

const SPECIES_OPTIONS = ["Cão", "Gato"] as const;

function toDateInputValue(value?: string | null): string {
  if (!value) return "";
  const date = value.slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : "";
}

function fillFormFromPet(
  pet: Pet,
  setters: {
    setNome: (value: string) => void;
    setEspecie: (value: string) => void;
    setRaca: (value: string) => void;
    setPesoKg: (value: string) => void;
    setDataNascimento: (value: string) => void;
    setMicrochip: (value: string) => void;
    setPhotoPreview: (value: string | null) => void;
  },
) {
  setters.setNome(pet.nome);
  setters.setEspecie(pet.especie);
  setters.setRaca(pet.raca ?? "");
  setters.setPesoKg(pet.peso_kg != null ? String(pet.peso_kg) : "");
  setters.setDataNascimento(toDateInputValue(pet.data_nascimento));
  setters.setMicrochip(pet.microchip ?? "");
  setters.setPhotoPreview(pet.foto_url ?? null);
}

export default function PetFormPage() {
  const navigate = useNavigate();
  const { petId } = useParams<{ petId: string }>();
  const isEdit = Boolean(petId);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [nome, setNome] = useState("");
  const [especie, setEspecie] = useState("");
  const [raca, setRaca] = useState("");
  const [pesoKg, setPesoKg] = useState("");
  const [dataNascimento, setDataNascimento] = useState("");
  const [microchip, setMicrochip] = useState("");
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loading, setLoading] = useState(isEdit);

  useEffect(() => {
    return () => {
      if (photoPreview?.startsWith("blob:")) URL.revokeObjectURL(photoPreview);
    };
  }, [photoPreview]);

  useEffect(() => {
    if (!petId) return;

    let isMounted = true;
    setLoading(true);
    setError(null);

    getPet(petId)
      .then((pet) => {
        if (!isMounted) return;
        fillFormFromPet(pet, {
          setNome,
          setEspecie,
          setRaca,
          setPesoKg,
          setDataNascimento,
          setMicrochip,
          setPhotoPreview,
        });
      })
      .catch(() => {
        if (isMounted) setError("Não foi possível carregar o pet.");
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [petId]);

  const handlePhotoChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (photoPreview?.startsWith("blob:")) URL.revokeObjectURL(photoPreview);
    setPhotoFile(file);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const buildPayload = (): CreatePetPayload => ({
    nome: nome.trim(),
    especie,
    raca: raca.trim() || null,
    peso_kg: pesoKg ? Number(pesoKg) : null,
    data_nascimento: dataNascimento || null,
    microchip: microchip.trim() || null,
  });

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();

    if (!nome.trim() || !especie) {
      setError("Preencha o nome e a espécie do pet.");
      return;
    }

    setError(null);
    setIsSubmitting(true);

    try {
      const saved = isEdit && petId
        ? await updatePet(petId, buildPayload())
        : await createPet(buildPayload());

      if (photoFile) {
        try {
          await uploadPetPhoto(saved.id, photoFile);
        } catch {
          navigate("/tutor/pets", { state: { photoWarning: PHOTO_WARNING } });
          return;
        }
      }

      navigate("/tutor/pets");
    } catch {
      setError(
        isEdit
          ? "Não foi possível atualizar o pet. Tente novamente."
          : "Não foi possível cadastrar o pet. Tente novamente.",
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!petId) return;

    const confirmed = window.confirm(
      `Excluir ${nome}? Esta ação não pode ser desfeita.`,
    );
    if (!confirmed) return;

    setError(null);
    setIsSubmitting(true);

    try {
      await deletePet(petId);
      navigate("/tutor/pets");
    } catch {
      setError("Não foi possível excluir o pet. Tente novamente.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const speciesOptions = SPECIES_OPTIONS.includes(especie as (typeof SPECIES_OPTIONS)[number])
    ? SPECIES_OPTIONS
    : especie
      ? [especie, ...SPECIES_OPTIONS]
      : SPECIES_OPTIONS;

  return (
    <TutorLayout>
      <div className={styles.pageContainer}>
        <header className={styles.headerBlock}>
          <h1 className={styles.pageTitle}>{isEdit ? "Editar Pet" : "Adicionar Pet"}</h1>
        </header>

        {loading && <p className={styles.statusMessage}>Carregando...</p>}

        {!loading && error && !nome && isEdit && (
          <div>
            <p className={styles.errorMsg}>{error}</p>
            <button
              type="button"
              className={styles.cancelBtn}
              onClick={() => navigate("/tutor/pets")}
            >
              Voltar
            </button>
          </div>
        )}

        {!loading && !(isEdit && error && !nome) && (
          <div className={styles.formCard}>
            <form className={styles.form} onSubmit={handleSubmit}>
              <div className={styles.photoRow}>
                <div className={styles.avatar}>
                  {photoPreview ? (
                    <img src={photoPreview} alt="Prévia da foto" className={styles.avatarImg} />
                  ) : (
                    <Camera size={22} strokeWidth={2} aria-hidden="true" />
                  )}
                </div>
                <button
                  type="button"
                  className={styles.photoBtn}
                  onClick={() => fileInputRef.current?.click()}
                >
                  Enviar foto
                </button>
                <input
                  ref={fileInputRef}
                  id="pet-photo"
                  type="file"
                  accept="image/*"
                  className={styles.hiddenFile}
                  aria-label="Selecionar foto do pet"
                  onChange={handlePhotoChange}
                />
              </div>

              <div className={styles.fieldsGrid}>
                <div className={styles.fieldGroup}>
                  <label htmlFor="nome" className={styles.label}>
                    Nome
                  </label>
                  <input
                    id="nome"
                    type="text"
                    className={styles.input}
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                  />
                </div>

                <div className={styles.fieldGroup}>
                  <label htmlFor="especie" className={styles.label}>
                    Espécie
                  </label>
                  <select
                    id="especie"
                    className={styles.select}
                    value={especie}
                    onChange={(e) => setEspecie(e.target.value)}
                  >
                    <option value="">Selecione</option>
                    {speciesOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>

                <div className={styles.fieldGroup}>
                  <label htmlFor="raca" className={styles.label}>
                    Raça
                  </label>
                  <input
                    id="raca"
                    type="text"
                    className={styles.input}
                    value={raca}
                    onChange={(e) => setRaca(e.target.value)}
                  />
                </div>

                <div className={styles.fieldGroup}>
                  <label htmlFor="pesoKg" className={styles.label}>
                    Peso (kg)
                  </label>
                  <input
                    id="pesoKg"
                    type="number"
                    min={0}
                    step="0.1"
                    className={styles.input}
                    value={pesoKg}
                    onChange={(e) => setPesoKg(e.target.value)}
                  />
                </div>

                <div className={styles.fieldGroup}>
                  <label htmlFor="dataNascimento" className={styles.label}>
                    Data de nascimento
                  </label>
                  <input
                    id="dataNascimento"
                    type="date"
                    className={styles.input}
                    value={dataNascimento}
                    onChange={(e) => setDataNascimento(e.target.value)}
                  />
                </div>

                <div className={styles.fieldGroup}>
                  <label htmlFor="microchip" className={styles.label}>
                    Microchip
                  </label>
                  <input
                    id="microchip"
                    type="text"
                    className={styles.input}
                    value={microchip}
                    onChange={(e) => setMicrochip(e.target.value)}
                  />
                </div>
              </div>

              {error && <p className={styles.errorMsg}>{error}</p>}

              <div className={styles.actionsRow}>
                <button
                  type="submit"
                  className={styles.submitBtn}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Salvando..." : "Salvar pet"}
                </button>
                <button
                  type="button"
                  className={styles.cancelBtn}
                  onClick={() => navigate("/tutor/pets")}
                >
                  Cancelar
                </button>
                {isEdit && (
                  <button
                    type="button"
                    className={styles.deleteBtn}
                    onClick={handleDelete}
                    disabled={isSubmitting}
                  >
                    Excluir pet
                  </button>
                )}
              </div>
            </form>
          </div>
        )}
      </div>
    </TutorLayout>
  );
}
