import { useEffect, useState } from "react";
import { Bell, LogOut } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import TutorLayout from "../../components/layout/TutorLayout";
import FeaturedPetCard from "../../components/tutor/FeaturedPetCard";
import AlertsList from "../../components/tutor/AlertsList";
import VetUpdatesList from "../../components/tutor/VetUpdatesList";
import {
  fetchTutorHomeData,
  type TutorHomeData,
} from "../../services/tutorHomeService";
import styles from "./TutorHomePage.module.css";

export default function TutorHomePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<TutorHomeData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const firstName = user?.name ? user.name.split(" ")[0] : "Tutor";

  const handleLogout = () => {
    logout();
    localStorage.removeItem("hasPickedRole");
    navigate("/login", { replace: true });
  };

  useEffect(() => {
    if (!user?.id) {
      setLoading(true);
      return;
    }

    let isMounted = true;
    setLoading(true);
    setError(null);

    fetchTutorHomeData(user.id)
      .then((res) => {
        if (isMounted) setData(res);
      })
      .catch(() => {
        if (isMounted) {
          setData(null);
          setError("Não foi possível carregar os dados da home.");
        }
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [user?.id]);

  return (
    <TutorLayout>
      <div className={styles.pageContainer}>
        <header className={styles.topHeader}>
          <h1 className={styles.greetingTitle}>
            Olá, {firstName} <span className={styles.waveEmoji}>👋</span>
          </h1>

          <div className={styles.headerActions}>
            <Link
              to="/tutor/notificacoes"
              className={styles.notificationBtn}
              aria-label="Notificações"
              title="Notificações"
            >
              <Bell size={20} />
              {data && data.unreadNotificationsCount > 0 && (
                <span className={styles.badge}>
                  {data.unreadNotificationsCount}
                </span>
              )}
            </Link>

            <button
              type="button"
              className={styles.logoutBtn}
              onClick={handleLogout}
              aria-label="Sair"
              title="Sair"
            >
              <LogOut size={18} />
              <span>Sair</span>
            </button>
          </div>
        </header>

        {loading && <p className={styles.statusMessage}>Carregando...</p>}

        {error && <p className={styles.errorMessage}>{error}</p>}

        {!loading && !error && (
          <>
            <FeaturedPetCard featuredPet={data?.featured ?? null} />

            <div className={styles.dashboardGrid}>
              <AlertsList alerts={data?.alerts ?? []} />
              <VetUpdatesList updates={data?.vetUpdates ?? []} />
            </div>
          </>
        )}
      </div>
    </TutorLayout>
  );
}
