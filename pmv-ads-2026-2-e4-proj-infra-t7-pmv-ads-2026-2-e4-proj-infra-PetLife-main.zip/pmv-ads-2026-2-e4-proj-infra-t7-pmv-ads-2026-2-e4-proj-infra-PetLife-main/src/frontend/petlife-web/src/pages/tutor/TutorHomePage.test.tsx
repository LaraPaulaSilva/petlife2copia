import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import type { User } from "../../types";
import TutorHomePage from "./TutorHomePage";
import { fetchTutorHomeData } from "../../services/tutorHomeService";
import type { TutorHomeData } from "../../services/tutorHomeService";

vi.mock("../../services/tutorHomeService", () => ({
  fetchTutorHomeData: vi.fn(),
}));

const mockedFetch = vi.mocked(fetchTutorHomeData);

const tutorUser: User = {
  id: "tutor-1",
  name: "Ana Costa",
  email: "ana@petlife.test",
  role: "Tutor",
};

const filledData: TutorHomeData = {
  featured: {
    id: "pet-1",
    name: "Mel",
    breedAge: "Gato • Persa • 2 anos",
    weightLabel: "Peso: 3,0 kg",
    nextVaccineLine: "Próxima vacina: V4 em 15/11",
    medicationLine: "Medicação: Vermífugo",
  },
  alerts: [
    { id: "alert-1", pet: "Mel", message: "Vacina V4 vence em 7 dias", accent: "blue" },
    { id: "alert-2", pet: "Rex", message: "Consulta agendada para amanhã", accent: "pink" },
  ],
  vetUpdates: [
    {
      id: "vet-1",
      pet: "Mel",
      description: "Laudo sanguíneo adicionado ao prontuário",
      date: "há 2 dias",
      type: "document",
    },
    {
      id: "vet-2",
      pet: "Rex",
      description: "Vacina antirrábica registrada",
      date: "há 5 dias",
      type: "vaccine",
    },
  ],
  unreadNotificationsCount: 3,
};

const emptyData: TutorHomeData = {
  featured: null,
  alerts: [],
  vetUpdates: [],
  unreadNotificationsCount: 0,
};

function renderTutorHome() {
  return render(
    <AuthContext.Provider
      value={{
        user: tutorUser,
        setUser: vi.fn(),
        login: vi.fn(),
        logout: vi.fn(),
      }}
    >
      <MemoryRouter initialEntries={["/tutor"]}>
        <TutorHomePage />
      </MemoryRouter>
    </AuthContext.Provider>,
  );
}

describe("TutorHomePage", () => {
  beforeEach(() => {
    mockedFetch.mockReset();
  });

  it("exibe a sidebar com navegação e o nome do tutor autenticado", async () => {
    mockedFetch.mockResolvedValue(emptyData);
    renderTutorHome();

    expect(screen.getByText("Início")).toBeInTheDocument();
    expect(screen.getByText("Meus Pets")).toBeInTheDocument();
    expect(screen.getByText("Calendário")).toBeInTheDocument();
    expect(screen.getByText("Buscar")).toBeInTheDocument();
    expect(screen.getByText("Perfil")).toBeInTheDocument();
    expect(screen.getByText("Ana Costa")).toBeInTheDocument();
    await waitFor(() => {
      expect(mockedFetch).toHaveBeenCalledWith("tutor-1");
    });
  });

  it("exibe a saudação e o botão de notificação com contador", async () => {
    mockedFetch.mockResolvedValue(filledData);
    renderTutorHome();

    expect(screen.getByText(/Olá, Ana/i)).toBeInTheDocument();
    await waitFor(() => {
      expect(screen.getByText("3")).toBeInTheDocument();
    });
  });

  it("exibe o card de destaque com os dados reais do pet", async () => {
    mockedFetch.mockResolvedValue(filledData);
    renderTutorHome();

    await waitFor(() => {
      expect(screen.getByRole("heading", { name: "Mel" })).toBeInTheDocument();
      expect(screen.getByText("Pet do Dia")).toBeInTheDocument();
      expect(screen.getByText(/Gato • Persa • 2 anos/i)).toBeInTheDocument();
      expect(screen.getByText("Peso: 3,0 kg")).toBeInTheDocument();
      expect(screen.getByText("Próxima vacina: V4 em 15/11")).toBeInTheDocument();
      expect(screen.getByText("Medicação: Vermífugo")).toBeInTheDocument();
    });
  });

  it("exibe alertas e atualizações vindos do backend", async () => {
    mockedFetch.mockResolvedValue(filledData);
    renderTutorHome();

    await waitFor(() => {
      expect(screen.getByText("Vacina V4 vence em 7 dias")).toBeInTheDocument();
      expect(screen.getByText("Consulta agendada para amanhã")).toBeInTheDocument();
      expect(screen.getByText("Laudo sanguíneo adicionado ao prontuário")).toBeInTheDocument();
      expect(screen.getByText("Vacina antirrábica registrada")).toBeInTheDocument();
    });
  });

  it("mostra estado vazio quando o tutor ainda não tem pets", async () => {
    mockedFetch.mockResolvedValue(emptyData);
    renderTutorHome();

    await waitFor(() => {
      expect(screen.getByText("Adicionar primeiro pet")).toBeInTheDocument();
      expect(screen.getByText("Nenhum alerta ou lembrete pendente.")).toBeInTheDocument();
      expect(screen.getByText("Nenhuma atualização veterinária recente.")).toBeInTheDocument();
    });
    expect(screen.queryByText("Lulu")).not.toBeInTheDocument();
  });

  it("mostra erro quando a lista de pets falha", async () => {
    mockedFetch.mockRejectedValue(new Error("falha na api"));
    renderTutorHome();

    await waitFor(() => {
      expect(screen.getByText("Não foi possível carregar os dados da home.")).toBeInTheDocument();
    });
    expect(screen.queryByText("Adicionar primeiro pet")).not.toBeInTheDocument();
  });
});
