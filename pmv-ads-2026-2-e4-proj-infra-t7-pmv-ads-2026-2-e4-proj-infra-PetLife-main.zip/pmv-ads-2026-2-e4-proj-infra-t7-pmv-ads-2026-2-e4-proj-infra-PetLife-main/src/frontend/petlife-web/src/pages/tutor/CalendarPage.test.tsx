import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import CalendarPage from "./CalendarPage";
import {
  buscarEventosDoUsuario,
  buscarPetsDoTutor,
  apagarEvento,
  atualizarEvento,

} from "../../services/eventoRotinaService";

vi.mock("../../contexts/AuthContext", () => ({
  useAuth: () => ({ user: { id: "user-1", name: "Ana Souza" } }),
}));

vi.mock("../../components/layout/TutorLayout", () => ({
  default: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

vi.mock("../../services/eventoRotinaService", () => ({
  buscarEventosDoUsuario: vi.fn(),
  buscarPetsDoTutor: vi.fn(),
  criarEvento: vi.fn(),
  atualizarEvento: vi.fn(),
  apagarEvento: vi.fn(),
}));

const nomesMeses = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
];

const hoje = new Date();
const meioDiaDoDia15 = new Date(hoje.getFullYear(), hoje.getMonth(), 15, 12, 0).toISOString();

const pets = [{ id: "pet-1", nome: "Belinha" }];

const eventos = [
  {
    id: "evento-1",
    userId: "user-1",
    petId: "pet-1",
    tipo: "vacina",
    dataHora: meioDiaDoDia15,
    observacoes: "teste",
    status: "agendado",
  },
];

describe("CalendarPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(buscarEventosDoUsuario).mockResolvedValue(eventos as never);
    vi.mocked(buscarPetsDoTutor).mockResolvedValue(pets as never);
    vi.mocked(apagarEvento).mockResolvedValue(undefined);
    vi.mocked(atualizarEvento).mockResolvedValue(undefined);
  });

  it("mostra o título e o mês atual", async () => {
    render(<CalendarPage />);

    expect(screen.getByRole("heading", { name: "Calendário" })).toBeInTheDocument();
    expect(
      screen.getByText(`${nomesMeses[hoje.getMonth()]} ${hoje.getFullYear()}`)
    ).toBeInTheDocument();

    await screen.findByText("Vacina Belinha");
  });

  it("troca de mês ao clicar na seta", async () => {
    render(<CalendarPage />);
    await screen.findByText("Vacina Belinha");

    fireEvent.click(screen.getByLabelText("Próximo mês"));

    const proximo = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 1);
    expect(
      screen.getByText(`${nomesMeses[proximo.getMonth()]} ${proximo.getFullYear()}`)
    ).toBeInTheDocument();
  });

  it("mostra o evento no calendário com o nome do pet", async () => {
    render(<CalendarPage />);

    expect(await screen.findByText("Vacina Belinha")).toBeInTheDocument();
  });

  it("abre o formulário de novo evento", async () => {
    render(<CalendarPage />);
    await screen.findByText("Vacina Belinha");

    fireEvent.click(screen.getByRole("button", { name: /novo evento/i }));

    expect(screen.getByRole("heading", { name: "Novo evento" })).toBeInTheDocument();
  });

  it("abre a edição ao clicar em um evento", async () => {
    render(<CalendarPage />);

    fireEvent.click(await screen.findByText("Vacina Belinha"));

    expect(screen.getByRole("heading", { name: "Editar evento" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Apagar" })).toBeInTheDocument();
  });

  it("apaga o evento depois de confirmar", async () => {
    render(<CalendarPage />);

    fireEvent.click(await screen.findByText("Vacina Belinha"));
    fireEvent.click(screen.getByRole("button", { name: "Apagar" }));

    expect(screen.getByText("Apagar evento?")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Sim, apagar" }));

    await waitFor(() => {
      expect(apagarEvento).toHaveBeenCalledWith("evento-1");
    });
  });

  it("não apaga se cancelar a confirmação", async () => {
    render(<CalendarPage />);

    fireEvent.click(await screen.findByText("Vacina Belinha"));
    fireEvent.click(screen.getByRole("button", { name: "Apagar" }));

    const janela = screen.getByText("Apagar evento?").parentElement as HTMLElement;
    fireEvent.click(janela.querySelector("button") as HTMLElement);

    expect(apagarEvento).not.toHaveBeenCalled();
  });
    it("mostra os dados do evento preenchidos na edição", async () => {
    render(<CalendarPage />);

    fireEvent.click(await screen.findByText("Vacina Belinha"));

    expect(screen.getByLabelText("Tipo")).toHaveValue("vacina");
    expect(screen.getByLabelText("Pet")).toHaveValue("pet-1");
    expect(screen.getByLabelText("Observações")).toHaveValue("teste");
  });

  it("salva as alterações ao editar um evento", async () => {
    render(<CalendarPage />);

    fireEvent.click(await screen.findByText("Vacina Belinha"));

    fireEvent.change(screen.getByLabelText("Tipo"), { target: { value: "tosa" } });
    fireEvent.change(screen.getByLabelText("Observações"), {
      target: { value: "mudei a observação" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Salvar alterações" }));

    await waitFor(() => {
      expect(atualizarEvento).toHaveBeenCalledWith(
        "evento-1",
        expect.objectContaining({
          petId: "pet-1",
          tipo: "tosa",
          observacoes: "mudei a observação",
        })
      );
    });
  });
});