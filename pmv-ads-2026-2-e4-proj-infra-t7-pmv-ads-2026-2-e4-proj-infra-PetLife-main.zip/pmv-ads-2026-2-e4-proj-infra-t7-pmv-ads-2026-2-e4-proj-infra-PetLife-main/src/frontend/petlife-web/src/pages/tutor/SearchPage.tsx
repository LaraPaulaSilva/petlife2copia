import { Search, Loader } from "lucide-react";
import styles from "./SearchPage.module.css";
import TutorLayout from "../../components/layout/TutorLayout";
import { useEffect, useState } from "react";
import { User } from "../../types";
import api, { baseURL } from "../../api/client";
import VetCard from "../../components/tutor/VetCard";
import { useSearchParams } from "react-router-dom";

export default function SearchPage() {
  const [data, setData] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchParams, setSearchParams] = useSearchParams();
  const search = searchParams.get("search") ?? "";

  const getData = () => {
    const search = searchParams.get("search") ?? "";
    setLoading(true);
    api
      .get(`${baseURL}/api/users/vets?search=${search}`)
      .then((data) => {
        setData(data.data);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  useEffect(() => {
    getData();
  }, [searchParams]);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const inputValue = formData.get("busca") as string;
    setSearchParams({ search: inputValue });
  };

  return (
    <TutorLayout>
      <div className={styles.container}>
        <div className={styles.wrapper}>
          <div className={styles.headerRow}>
            <div>
              <h1 className={styles.title}>Buscar veterinários</h1>
              <p className={styles.subtitle}>
                Encontre veterinários próximos e compartilhe o perfil dos seus
                pets
              </p>
            </div>
          </div>
          <div className={styles.searchContainer}>
            <Search className={styles.searchIcon} />
            <form onSubmit={handleSubmit}>
              <input
                name="busca"
                defaultValue={search}
                disabled={loading}
                type="text"
                placeholder="Buscar por nome, endereço, ou CRMV..."
                className={styles.searchInput}
              />
            </form>
          </div>
          {loading ? (
            <div className={styles.loader}>
              <Loader />
            </div>
          ) : (
            <>
              <p className={styles.resultsCount}>
                {data.length} Veterinários cadastrados
              </p>
              <div className={styles.vetList}>
                {data.map((vet) => (
                  <VetCard key={vet.id} vet={vet} />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </TutorLayout>
  );
}
