import { useState } from "react";
import { PawPrint } from "lucide-react";
import api, { baseURL } from "../api/client";
import { useAuth } from "../contexts/AuthContext";
import { useNavigate, Link } from "react-router-dom";
import { getApiErrorMessage } from "../utils/apiError";
import styles from "./AuthPages.module.css";

const RegisterPage = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const data = Object.fromEntries(formData.entries());

    setError(null);
    setIsSubmitting(true);
    try {
      const response = await api.post(`${baseURL}/api/users/register`, data);
      login(response.data.user, response.data.token);
      localStorage.setItem("hasPickedRole", JSON.stringify(false));
      navigate("/register-role", { replace: true });
    } catch (err) {
      setError(
        getApiErrorMessage(err, "Não foi possível criar a conta. Tente novamente."),
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={styles.page}>
      <aside className={styles.brandSide}>
        <div className={styles.brandLogo}>
          <PawPrint className={styles.brandLogoIcon} />
          PetLife
        </div>
        <h1 className={styles.brandTitle}>Criar conta</h1>
        <p className={styles.brandSubtitle}>Comece a cuidar do seu pet hoje</p>
      </aside>

      <main className={styles.formSide}>
        <div className={styles.formCard}>
          <h2 className={styles.formTitle}>Criar conta</h2>
          <p className={styles.formSubtitle}>
            Preencha seus dados para começar a usar o PetLife.
          </p>

          <form className={styles.form} onSubmit={handleSubmit}>
            <div className={styles.field}>
              <label className={styles.label} htmlFor="Name">
                Nome completo
              </label>
              <input
                className={styles.input}
                name="Name"
                id="Name"
                type="text"
                placeholder="Seu nome"
              />
            </div>

            <div className={styles.field}>
              <label className={styles.label} htmlFor="Email">
                E-mail
              </label>
              <input
                className={styles.input}
                name="Email"
                id="Email"
                type="email"
                placeholder="seu@email"
              />
            </div>

            <div className={styles.field}>
              <label className={styles.label} htmlFor="Password">
                Senha
              </label>
              <input
                className={styles.input}
                name="Password"
                id="Password"
                type="password"
                placeholder="Crie uma senha"
              />
            </div>

            <div className={styles.field}>
              <label className={styles.label} htmlFor="ConfirmPassword">
                Confirmar senha
              </label>
              <input
                className={styles.input}
                name="ConfirmPassword"
                id="ConfirmPassword"
                type="password"
                placeholder="Repita a senha"
              />
            </div>

            {error && <p className={styles.errorMsg}>{error}</p>}

            <button
              className={styles.submitBtn}
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Cadastrando..." : "Cadastrar"}
            </button>
          </form>

          <p className={styles.footerText}>
            <Link className={styles.footerLink} to="/login">
              Já tem conta? Entrar
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
};

export default RegisterPage;
