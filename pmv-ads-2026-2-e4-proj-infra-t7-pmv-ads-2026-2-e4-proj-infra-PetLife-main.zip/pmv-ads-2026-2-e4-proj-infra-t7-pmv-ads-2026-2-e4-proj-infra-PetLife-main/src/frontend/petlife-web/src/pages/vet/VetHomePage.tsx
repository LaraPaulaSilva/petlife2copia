import { useEffect, useState, useMemo } from "react";
import { Bell, Search, LogOut } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import VetLayout from "../../components/layout/VetLayout";
import VetPatientCard from "../../components/vet/VetPatientCard";
import {
  fetchVetHomeData,
  type VetHomeData,
} from "../../services/vetHomeService";
import styles from "./VetHomePage.module.css";

export default function VetHomePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<VetHomeData | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const vetName = user?.name || "Veterinário";

  const handleLogout = () => {
    logout();
    localStorage.removeItem("hasPickedRole");
    navigate("/login", { replace: true });
  };

  useEffect(() => {
    if (!user?.id) {
      setLoading(true);
      return;
    }

    let isMounted = true;
    setLoading(true);
    setError(null);

    fetchVetHomeData()
      .then((res) => {
        if (isMounted) setData(res);
      })
      .catch(() => {
        if (isMounted) {
          setData(null);
          setError("Não foi possível carregar os dados da home.");
        }
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [user?.id]);

  const patients = data?.patients ?? [];

  const filteredPatients = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return patients;

    return patients.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.species.toLowerCase().includes(q) ||
        p.breed.toLowerCase().includes(q) ||
        p.tutor.toLowerCase().includes(q),
    );
  }, [patients, searchTerm]);

  const emptyMessage = searchTerm.trim()
    ? `Nenhum paciente encontrado com o termo "${searchTerm}".`
    : "Ainda não há pacientes compartilhados.";

  return (
    <VetLayout>
      <div className={styles.pageContainer}>
        <header className={styles.topHeader}>
          <h1 className={styles.greetingTitle}>Olá, {vetName}</h1>

          <div className={styles.headerActions}>
            <Link
              to="/vet/notificacoes"
              className={styles.notificationBtn}
              aria-label="Notificações"
              title="Notificações"
            >
              <Bell size={20} />
              {data && data.unreadNotificationsCount > 0 && (
                <span className={styles.badge}>
                  {data.unreadNotificationsCount}
                </span>
              )}
            </Link>

            <button
              type="button"
              className={styles.logoutBtn}
              onClick={handleLogout}
              aria-label="Sair"
              title="Sair"
            >
              <LogOut size={18} />
              <span>Sair</span>
            </button>
          </div>
        </header>

        {loading && <p className={styles.statusMessage}>Carregando...</p>}

        {error && <p className={styles.errorMessage}>{error}</p>}

        {!loading && !error && (
          <>
            <div className={styles.statsCard}>
              <span className={styles.statsValue}>
                {data?.patientCount ?? 0}
              </span>
              <span className={styles.statsLabel}>
                Pacientes sob meus cuidados
              </span>
            </div>

            <div className={styles.searchContainer}>
              <Search className={styles.searchIcon} size={20} />
              <input
                type="text"
                className={styles.searchInput}
                placeholder="Buscar pacientes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                aria-label="Buscar pacientes"
              />
            </div>

            <section aria-labelledby="patients-heading">
              <div className={styles.sectionHeader}>
                <h2 id="patients-heading" className={styles.sectionTitle}>
                  Meus Pacientes
                </h2>
              </div>

              <div className={styles.patientsGrid}>
                {filteredPatients.length === 0 ? (
                  <p className={styles.emptyState}>{emptyMessage}</p>
                ) : (
                  filteredPatients.map((patient) => (
                    <VetPatientCard key={patient.id} patient={patient} />
                  ))
                )}
              </div>
            </section>
          </>
        )}
      </div>
    </VetLayout>
  );
}
