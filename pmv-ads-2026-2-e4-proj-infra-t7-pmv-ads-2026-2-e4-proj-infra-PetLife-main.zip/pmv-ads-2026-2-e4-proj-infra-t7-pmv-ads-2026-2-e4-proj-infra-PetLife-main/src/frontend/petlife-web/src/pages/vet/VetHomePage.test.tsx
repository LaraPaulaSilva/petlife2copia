import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import type { User } from "../../types";
import VetHomePage from "./VetHomePage";
import { fetchVetHomeData } from "../../services/vetHomeService";
import type { VetHomeData } from "../../services/vetHomeService";

vi.mock("../../services/vetHomeService", () => ({
  fetchVetHomeData: vi.fn(),
}));

const mockedFetch = vi.mocked(fetchVetHomeData);

const vetUser: User = {
  id: "vet-1",
  name: "Paula Mendes",
  email: "paula@petlife.test",
  role: "Veterinário",
  crmv: "12345",
};

const filledData: VetHomeData = {
  vetName: "Paula Mendes",
  roleLabel: "Veterinário",
  patientCount: 4,
  unreadNotificationsCount: 2,
  patients: [
    {
      id: "patient-1",
      name: "Mel",
      species: "Gato",
      breed: "Persa",
      age: "2 anos",
      weight: "3,0 kg",
      tutor: "Ana Costa",
    },
    {
      id: "patient-2",
      name: "Rex",
      species: "Cão",
      breed: "Golden",
      age: "4 anos",
      weight: "28,5 kg",
      tutor: "Carlos Lima",
    },
    {
      id: "patient-3",
      name: "Mia",
      species: "Gata",
      breed: "Siamês",
      age: "1 ano",
      weight: "2,8 kg",
      tutor: "Júlia Reis",
    },
    {
      id: "patient-4",
      name: "Thor",
      species: "Cão",
      breed: "Pastor",
      age: "6 anos",
      weight: "32,0 kg",
      tutor: "Marcos Dias",
    },
  ],
};

const emptyData: VetHomeData = {
  vetName: "Paula Mendes",
  roleLabel: "Veterinário",
  patientCount: 0,
  unreadNotificationsCount: 0,
  patients: [],
};

function renderVetHome() {
  return render(
    <AuthContext.Provider
      value={{
        user: vetUser,
        setUser: vi.fn(),
        login: vi.fn(),
        logout: vi.fn(),
      }}
    >
      <MemoryRouter initialEntries={["/vet"]}>
        <VetHomePage />
      </MemoryRouter>
    </AuthContext.Provider>,
  );
}

describe("VetHomePage", () => {
  beforeEach(() => {
    mockedFetch.mockReset();
  });

  it("exibe a sidebar com itens específicos do veterinário", async () => {
    mockedFetch.mockResolvedValue(emptyData);
    renderVetHome();

    expect(screen.getByText("Início")).toBeInTheDocument();
    expect(screen.getByText("Pacientes")).toBeInTheDocument();
    expect(screen.getByText("Novo Paciente")).toBeInTheDocument();
    expect(screen.getByText("Calendário")).toBeInTheDocument();
    expect(screen.getByText("Perfil")).toBeInTheDocument();
    expect(screen.getAllByText("Paula Mendes").length).toBeGreaterThan(0);
    expect(screen.getByText("CRMV 12345")).toBeInTheDocument();
    await waitFor(() => {
      expect(mockedFetch).toHaveBeenCalled();
    });
  });

  it("exibe a saudação de boas-vindas e o badge de notificações", async () => {
    mockedFetch.mockResolvedValue(filledData);
    renderVetHome();

    expect(screen.getByText("Olá, Paula Mendes")).toBeInTheDocument();
    await waitFor(() => {
      expect(screen.getByText("2")).toBeInTheDocument();
    });
  });

  it("exibe o card de estatísticas com total de pacientes", async () => {
    mockedFetch.mockResolvedValue(filledData);
    renderVetHome();

    await waitFor(() => {
      expect(screen.getByText("4")).toBeInTheDocument();
      expect(screen.getByText("Pacientes sob meus cuidados")).toBeInTheDocument();
    });
  });

  it("exibe os cards de pacientes compartilhados", async () => {
    mockedFetch.mockResolvedValue(filledData);
    renderVetHome();

    await waitFor(() => {
      expect(screen.getByText("Mel")).toBeInTheDocument();
      expect(screen.getByText("Tutor: Ana Costa")).toBeInTheDocument();
      expect(screen.getByText("Rex")).toBeInTheDocument();
      expect(screen.getByText("Tutor: Carlos Lima")).toBeInTheDocument();
      expect(screen.getByText("Mia")).toBeInTheDocument();
      expect(screen.getByText("Thor")).toBeInTheDocument();
    });
  });

  it("permite filtrar pacientes através da barra de busca", async () => {
    mockedFetch.mockResolvedValue(filledData);
    renderVetHome();

    await waitFor(() => {
      expect(screen.getByText("Rex")).toBeInTheDocument();
    });

    const searchInput = screen.getByPlaceholderText("Buscar pacientes...");
    fireEvent.change(searchInput, { target: { value: "Rex" } });

    expect(screen.getByText("Rex")).toBeInTheDocument();
    expect(screen.queryByText("Thor")).not.toBeInTheDocument();
    expect(screen.queryByText("Mia")).not.toBeInTheDocument();
  });

  it("mostra estado vazio quando não há pacientes compartilhados", async () => {
    mockedFetch.mockResolvedValue(emptyData);
    renderVetHome();

    await waitFor(() => {
      expect(screen.getByText("Ainda não há pacientes compartilhados.")).toBeInTheDocument();
      expect(screen.getByText("0")).toBeInTheDocument();
    });
    expect(screen.queryByText("Lulu")).not.toBeInTheDocument();
    expect(screen.queryByText("Dra. Paula")).not.toBeInTheDocument();
  });

  it("mostra erro quando a listagem de pacientes falha", async () => {
    mockedFetch.mockRejectedValue(new Error("falha na api"));
    renderVetHome();

    await waitFor(() => {
      expect(screen.getByText("Não foi possível carregar os dados da home.")).toBeInTheDocument();
    });
  });
});
