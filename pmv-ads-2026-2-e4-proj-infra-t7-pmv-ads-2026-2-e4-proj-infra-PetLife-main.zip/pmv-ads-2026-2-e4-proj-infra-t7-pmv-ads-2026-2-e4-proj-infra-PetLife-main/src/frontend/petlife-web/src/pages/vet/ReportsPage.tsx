import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import VetSidebar from "../../components/layout/VetSidebar";
import {
  getTemplatesByVet,
  getAvailablePets,
  createReportTemplate,
  updateReportTemplate,
  deleteReportTemplate,
  executeReport,
  downloadReportPdf,
  type PetSummary,
  type ReportTemplate,
  type ReportFilters,
} from "../../services/reportService";
import ReportCard from "../../components/vet/ReportCard";
import ReportFormModal from "../../components/vet/ReportFormModal";
import styles from "./ReportsPage.module.css";

export default function ReportsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [templates, setTemplates] = useState<ReportTemplate[]>([]);
  const [pets, setPets] = useState<PetSummary[]>([]);
  const [loading, setLoading] = useState(true);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<
    "create_template" | "edit_template" | "ad_hoc" | "prontuario_pet"
  >("create_template");
  const [selectedTemplate, setSelectedTemplate] = useState<ReportTemplate | null>(null);

  const isVet = user?.role === "Veterinário";
  const vetId = user?.id ?? "vet-1";
  const vetNome = user?.name ?? "Veterinário";

  useEffect(() => {
    if (user && !isVet) {
      navigate("/tutor/pets");
      return;
    }

    async function load() {
      try {
        setLoading(true);
        const [templatesData, petsData] = await Promise.all([
          getTemplatesByVet(vetId),
          getAvailablePets(),
        ]);
        setTemplates(templatesData);
        setPets(petsData);
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [user, isVet, vetId, navigate]);

  const handleOpenCreateTemplate = () => {
    setSelectedTemplate(null);
    setModalMode("create_template");
    setIsModalOpen(true);
  };

  const handleOpenEditTemplate = (template: ReportTemplate) => {
    setSelectedTemplate(template);
    setModalMode("edit_template");
    setIsModalOpen(true);
  };

  const handleOpenAdHoc = () => {
    setSelectedTemplate(null);
    setModalMode("ad_hoc");
    setIsModalOpen(true);
  };

  const handleOpenProntuario = () => {
    setSelectedTemplate(null);
    setModalMode("prontuario_pet");
    setIsModalOpen(true);
  };

  const handleCreateTemplate = async (dados: {
    nome: string;
    descricao?: string;
    filtros: ReportFilters;
  }) => {
    const created = await createReportTemplate({
      veterinario_id: vetId,
      nome: dados.nome,
      descricao: dados.descricao,
      filtros: dados.filtros,
    });
    setTemplates((prev) => [created, ...prev]);
  };

  const handleUpdateTemplate = async (
    id: string,
    dados: { nome: string; descricao?: string; filtros: ReportFilters }
  ) => {
    const updated = await updateReportTemplate(id, dados);
    setTemplates((prev) => prev.map((item) => (item.id === id ? updated : item)));
  };

  const handleExecuteAndDownloadPdf = async (titulo: string, filtros: ReportFilters) => {
    const result = await executeReport(titulo, filtros, vetNome);
    downloadReportPdf(result);
  };

  const handleRunFromTemplate = async (template: ReportTemplate) => {
    await handleExecuteAndDownloadPdf(template.nome, template.filtros);
  };

  const handleDeleteTemplate = async (template: ReportTemplate) => {
    if (window.confirm(`Deseja excluir o modelo "${template.nome}"?`)) {
      await deleteReportTemplate(template.id);
      setTemplates((prev) => prev.filter((t) => t.id !== template.id));
    }
  };

  if (!isVet) return null;

  return (
    <div className={styles.pageLayout}>
      <VetSidebar activePath="/vet/relatorios" />

      <main className={styles.mainContent}>
        <div className={styles.contentWrapper}>
          <header className={styles.banner}>
            <div className={styles.bannerAvatar} aria-hidden="true" />
            <div className={styles.bannerInfo}>
              <h1 className={styles.bannerTitle}>📊 Relatórios</h1>
              <p className={styles.bannerSubtitle}>
                {vetNome} • Modelos personalizados, prontuários completos e emissão em PDF
              </p>
            </div>
          </header>

          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Modelos de Relatório</h2>
            <div className={styles.headerActions}>
              <button
                type="button"
                className={styles.secondaryActionBtn}
                onClick={handleOpenProntuario}
              >
                Gerar Prontuário de Pet
              </button>
              <button
                type="button"
                className={styles.secondaryActionBtn}
                onClick={handleOpenAdHoc}
              >
                Emitir sem modelo
              </button>
              <button
                type="button"
                className={styles.primaryActionBtn}
                onClick={handleOpenCreateTemplate}
              >
                + Novo modelo
              </button>
            </div>
          </div>

          {loading ? (
            <p className={styles.emptyText}>Carregando modelos...</p>
          ) : templates.length === 0 ? (
            <p className={styles.emptyText}>Nenhum modelo de relatório cadastrado.</p>
          ) : (
            <div className={styles.grid}>
              {templates.map((tmpl) => (
                <ReportCard
                  key={tmpl.id}
                  template={tmpl}
                  onRun={handleRunFromTemplate}
                  onEdit={handleOpenEditTemplate}
                  onDelete={handleDeleteTemplate}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      <ReportFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        mode={modalMode}
        initialTemplate={selectedTemplate}
        availablePets={pets}
        onSubmitTemplate={handleCreateTemplate}
        onUpdateTemplate={handleUpdateTemplate}
        onExecuteReport={handleExecuteAndDownloadPdf}
      />
    </div>
  );
}