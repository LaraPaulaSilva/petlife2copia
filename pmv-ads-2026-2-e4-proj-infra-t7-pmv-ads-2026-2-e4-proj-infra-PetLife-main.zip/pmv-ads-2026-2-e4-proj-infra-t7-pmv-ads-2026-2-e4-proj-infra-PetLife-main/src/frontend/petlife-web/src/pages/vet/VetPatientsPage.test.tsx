import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import type { User } from "../../types";
import VetPatientsPage from "./VetPatientsPage";
import {
  fetchVetPatients,
  redeemPatientShareCode,
  type VetPatientItem,
} from "../../services/vetPatientsService";

vi.mock("../../services/vetPatientsService", () => ({
  fetchVetPatients: vi.fn(),
  redeemPatientShareCode: vi.fn(),
}));

const mockedFetch = vi.mocked(fetchVetPatients);
const mockedRedeem = vi.mocked(redeemPatientShareCode);

const vetUser: User = {
  id: "vet-1",
  name: "Dra. Paula",
  email: "paula@petlife.test",
  role: "Veterinário",
  crmv: "12345",
};

const samplePatients: VetPatientItem[] = [
  {
    id: "pet-1",
    name: "Lulu",
    species: "Gato",
    breed: "Vira-lata",
    tutor: "Ana Souza",
    ultimaConsulta: "20/10/2026",
  },
  {
    id: "pet-2",
    name: "Rex",
    species: "Cão",
    breed: "Golden",
    tutor: "Carlos Lima",
    ultimaConsulta: "12/09/2026",
  },
  {
    id: "pet-3",
    name: "Mia",
    species: "Gata",
    breed: "Siamês",
    tutor: "Júlia Reis",
    ultimaConsulta: "03/10/2026",
  },
  {
    id: "pet-4",
    name: "Thor",
    species: "Cão",
    breed: "Pastor",
    tutor: "Marcos Dias",
    ultimaConsulta: "28/08/2026",
  },
];

function renderVetPatientsPage(defaultOpenNewModal = false) {
  return render(
    <AuthContext.Provider
      value={{
        user: vetUser,
        setUser: vi.fn(),
        login: vi.fn(),
        logout: vi.fn(),
      }}
    >
      <MemoryRouter initialEntries={["/vet/pacientes"]}>
        <VetPatientsPage defaultOpenNewModal={defaultOpenNewModal} />
      </MemoryRouter>
    </AuthContext.Provider>,
  );
}

describe("VetPatientsPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renderiza a estrutura da página, título, botão e cabeçalho da tabela", async () => {
    mockedFetch.mockResolvedValue(samplePatients);
    renderVetPatientsPage();

    expect(screen.getByRole("heading", { name: "Pacientes" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "+ Novo paciente" })).toBeInTheDocument();
    expect(
      screen.getByPlaceholderText("Buscar por nome, espécie ou tutor..."),
    ).toBeInTheDocument();

    await waitFor(() => {
      expect(screen.getByText("PACIENTE")).toBeInTheDocument();
      expect(screen.getByText("ESPÉCIE / RAÇA")).toBeInTheDocument();
      expect(screen.getByText("TUTOR")).toBeInTheDocument();
      expect(screen.getByText("ÚLTIMA CONSULTA")).toBeInTheDocument();
    });
  });

  it("exibe a lista de pacientes com espécie, raça, tutor, última consulta e link 'Abrir ›'", async () => {
    mockedFetch.mockResolvedValue(samplePatients);
    renderVetPatientsPage();

    await waitFor(() => {
      expect(screen.getByText("Lulu")).toBeInTheDocument();
      expect(screen.getByText("Gato • Vira-lata")).toBeInTheDocument();
      expect(screen.getByText("Ana Souza")).toBeInTheDocument();
      expect(screen.getByText("20/10/2026")).toBeInTheDocument();

      expect(screen.getByText("Rex")).toBeInTheDocument();
      expect(screen.getByText("Cão • Golden")).toBeInTheDocument();
      expect(screen.getByText("Carlos Lima")).toBeInTheDocument();
      expect(screen.getByText("12/09/2026")).toBeInTheDocument();

      expect(screen.getByText("Mia")).toBeInTheDocument();
      expect(screen.getByText("Gata • Siamês")).toBeInTheDocument();
      expect(screen.getByText("Júlia Reis")).toBeInTheDocument();
      expect(screen.getByText("03/10/2026")).toBeInTheDocument();

      expect(screen.getByText("Thor")).toBeInTheDocument();
      expect(screen.getByText("Cão • Pastor")).toBeInTheDocument();
      expect(screen.getByText("Marcos Dias")).toBeInTheDocument();
      expect(screen.getByText("28/08/2026")).toBeInTheDocument();
    });

    const openLinks = screen.getAllByRole("link", { name: /Abrir prontuário de/ });
    expect(openLinks).toHaveLength(4);
    expect(openLinks[0]).toHaveAttribute("href", "/vet/pacientes/pet-1/consultas");
  });

  it("permite filtrar pacientes pelo campo de busca", async () => {
    mockedFetch.mockResolvedValue(samplePatients);
    renderVetPatientsPage();

    await waitFor(() => {
      expect(screen.getByText("Lulu")).toBeInTheDocument();
    });

    const searchInput = screen.getByPlaceholderText("Buscar por nome, espécie ou tutor...");

    // Busca por tutor
    fireEvent.change(searchInput, { target: { value: "Carlos" } });
    expect(screen.getByText("Rex")).toBeInTheDocument();
    expect(screen.queryByText("Lulu")).not.toBeInTheDocument();
    expect(screen.queryByText("Mia")).not.toBeInTheDocument();

    // Busca por espécie
    fireEvent.change(searchInput, { target: { value: "Gat" } });
    expect(screen.getByText("Lulu")).toBeInTheDocument();
    expect(screen.getByText("Mia")).toBeInTheDocument();
    expect(screen.queryByText("Rex")).not.toBeInTheDocument();
  });

  it("mostra aviso quando a busca não retorna resultados", async () => {
    mockedFetch.mockResolvedValue(samplePatients);
    renderVetPatientsPage();

    await waitFor(() => {
      expect(screen.getByText("Lulu")).toBeInTheDocument();
    });

    const searchInput = screen.getByPlaceholderText("Buscar por nome, espécie ou tutor...");
    fireEvent.change(searchInput, { target: { value: "desconhecido" } });

    expect(
      screen.getByText(/Nenhum paciente encontrado para a busca "desconhecido"/),
    ).toBeInTheDocument();
  });

  it("mostra estado vazio quando não há pacientes cadastrados", async () => {
    mockedFetch.mockResolvedValue([]);
    renderVetPatientsPage();

    await waitFor(() => {
      expect(
        screen.getByText("Ainda não há pacientes compartilhados com você."),
      ).toBeInTheDocument();
      expect(
        screen.getByRole("button", { name: "+ Vincular primeiro paciente" }),
      ).toBeInTheDocument();
    });
  });

  it("mostra mensagem de erro ao falhar na requisição e permite tentar novamente", async () => {
    mockedFetch.mockRejectedValueOnce(new Error("Network Error"));
    renderVetPatientsPage();

    await waitFor(() => {
      expect(
        screen.getByText("Não foi possível carregar a lista de pacientes."),
      ).toBeInTheDocument();
    });

    mockedFetch.mockResolvedValueOnce(samplePatients);
    const retryBtn = screen.getByRole("button", { name: "Tentar novamente" });
    fireEvent.click(retryBtn);

    await waitFor(() => {
      expect(screen.getByText("Lulu")).toBeInTheDocument();
    });
  });

  it("abre modal para vincular novo paciente por código de compartilhamento", async () => {
    mockedFetch.mockResolvedValue(samplePatients);
    mockedRedeem.mockResolvedValue();

    renderVetPatientsPage();

    await waitFor(() => {
      expect(screen.getByText("Lulu")).toBeInTheDocument();
    });

    const addBtn = screen.getByRole("button", { name: "+ Novo paciente" });
    fireEvent.click(addBtn);

    expect(screen.getByRole("heading", { name: "Novo paciente" })).toBeInTheDocument();
    expect(
      screen.getByPlaceholderText("Ex: a1b2c3d4"),
    ).toBeInTheDocument();

    const input = screen.getByPlaceholderText("Ex: a1b2c3d4");
    fireEvent.change(input, { target: { value: "a1b2c3d4" } });

    const submitBtn = screen.getByRole("button", { name: "Vincular Paciente" });
    fireEvent.click(submitBtn);

    await waitFor(() => {
      expect(mockedRedeem).toHaveBeenCalledWith("a1b2c3d4");
      expect(screen.getByText("Paciente vinculado com sucesso!")).toBeInTheDocument();
    });
  });
});
