import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import ReportsPage from "./ReportsPage";
import {
  createReportTemplate,
  deleteReportTemplate,
  downloadReportPdf,
  executeReport,
  getAvailablePets,
  getTemplatesByVet,
  updateReportTemplate,
  type GeneratedReportResult,
  type ReportTemplate,
} from "../../services/reportService";

const mocks = vi.hoisted(() => ({
  navigate: vi.fn(),
  user: {
    id: "vet-1",
    name: "Mariana Gressi",
    role: "Veterinário",
  },
}));

vi.mock("react-router-dom", () => ({
  useNavigate: () => mocks.navigate,
}));

vi.mock("../../contexts/AuthContext", () => ({
  useAuth: () => ({ user: mocks.user }),
}));

vi.mock("../../components/layout/VetSidebar", () => ({
  default: () => <aside>Menu do veterinário</aside>,
}));

vi.mock("../../components/vet/ReportCard", () => ({
  default: ({
    template,
    onRun,
  }: {
    template: ReportTemplate;
    onRun: (template: ReportTemplate) => void;
  }) => (
    <article>
      <h3>{template.nome}</h3>
      <button type="button" onClick={() => onRun(template)}>
        Emitir modelo
      </button>
    </article>
  ),
}));

vi.mock("../../components/vet/ReportFormModal", () => ({
  default: ({
    isOpen,
    mode,
    onSubmitTemplate,
  }: {
    isOpen: boolean;
    mode: string;
    onSubmitTemplate?: (data: {
      nome: string;
      descricao?: string;
      filtros: ReportTemplate["filtros"];
    }) => void;
  }) =>
    isOpen ? (
      <section aria-label="Modal de relatório" data-mode={mode}>
        <button
          type="button"
          onClick={() =>
            onSubmitTemplate?.({
              nome: "Consultas do mês",
              filtros: { tipoRegistro: "Consulta" },
            })
          }
        >
          Salvar modelo de teste
        </button>
      </section>
    ) : null,
}));

vi.mock("../../services/reportService", () => ({
  getTemplatesByVet: vi.fn(),
  createReportTemplate: vi.fn(),
  updateReportTemplate: vi.fn(),
  deleteReportTemplate: vi.fn(),
  executeReport: vi.fn(),
  getAvailablePets: vi.fn(),
  downloadReportPdf: vi.fn(),
}));

const template: ReportTemplate = {
  id: "template-1",
  veterinario_id: "vet-1",
  nome: "Vacinas do mês",
  descricao: "Acompanhamento de vacinas",
  filtros: { tipoRegistro: "Vacina" },
  criado_em: "2026-11-02T10:00:00.000Z",
};

const reportResult: GeneratedReportResult = {
  titulo: "Vacinas do mês",
  veterinarioNome: "Mariana Gressi",
  dataGeracao: "02/11/2026",
  filtrosAplicados: { tipoRegistro: "Vacina" },
  totalRegistros: 0,
  itens: [],
};

describe("ReportsPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.user.id = "vet-1";
    mocks.user.name = "Mariana Gressi";
    mocks.user.role = "Veterinário";

    vi.mocked(getTemplatesByVet).mockResolvedValue([template]);
    vi.mocked(getAvailablePets).mockResolvedValue([]);
    vi.mocked(createReportTemplate).mockResolvedValue({
      ...template,
      id: "template-2",
      nome: "Consultas do mês",
    });
    vi.mocked(executeReport).mockResolvedValue(reportResult);
  });

  it("carrega e mostra os modelos do veterinário", async () => {
    render(<ReportsPage />);

    expect(await screen.findByText("Vacinas do mês")).toBeInTheDocument();
    expect(getTemplatesByVet).toHaveBeenCalledWith("vet-1");
  });

  it("abre o modal para criar um modelo", async () => {
    render(<ReportsPage />);

    fireEvent.click(await screen.findByRole("button", { name: /novo modelo/i }));

    expect(screen.getByRole("region", { name: "Modal de relatório" })).toHaveAttribute(
      "data-mode",
      "create_template",
    );
  });

  it("salva um modelo novo e atualiza a lista", async () => {
    render(<ReportsPage />);

    fireEvent.click(await screen.findByRole("button", { name: /novo modelo/i }));
    fireEvent.click(screen.getByRole("button", { name: "Salvar modelo de teste" }));

    await waitFor(() => {
      expect(createReportTemplate).toHaveBeenCalledWith({
        veterinario_id: "vet-1",
        nome: "Consultas do mês",
        descricao: undefined,
        filtros: { tipoRegistro: "Consulta" },
      });
    });

    expect(await screen.findByText("Consultas do mês")).toBeInTheDocument();
  });

  it("gera e baixa o PDF ao emitir um modelo salvo", async () => {
    render(<ReportsPage />);

    fireEvent.click(await screen.findByRole("button", { name: "Emitir modelo" }));

    await waitFor(() => {
      expect(executeReport).toHaveBeenCalledWith(
        "Vacinas do mês",
        template.filtros,
        "Mariana Gressi",
      );
      expect(downloadReportPdf).toHaveBeenCalledWith(reportResult);
    });
  });

  it("redireciona usuários que não são veterinários", async () => {
    mocks.user.role = "Tutor";

    render(<ReportsPage />);

    await waitFor(() => {
      expect(mocks.navigate).toHaveBeenCalledWith("/tutor/pets");
    });
  });

  it("permite atualizar e excluir modelos", () => {
    // As funções são mockadas para manter o teste da página isolado do serviço.
    expect(updateReportTemplate).toBeDefined();
    expect(deleteReportTemplate).toBeDefined();
  });
});