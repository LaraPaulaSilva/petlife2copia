import { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { Search, PawPrint, X } from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";
import VetLayout from "../../components/layout/VetLayout";
import {
  fetchVetPatients,
  redeemPatientShareCode,
  type VetPatientItem,
} from "../../services/vetPatientsService";
import styles from "./VetPatientsPage.module.css";

interface VetPatientsPageProps {
  defaultOpenNewModal?: boolean;
}

export default function VetPatientsPage({
  defaultOpenNewModal = false,
}: VetPatientsPageProps) {
  const { user } = useAuth();
  const [patients, setPatients] = useState<VetPatientItem[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Estado do modal "+ Novo paciente"
  const [isModalOpen, setIsModalOpen] = useState(defaultOpenNewModal);
  const [shareCode, setShareCode] = useState("");
  const [modalLoading, setModalLoading] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);
  const [modalSuccess, setModalSuccess] = useState<string | null>(null);

  const loadPatients = async () => {
    if (!user?.id) {
      setLoading(true);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const data = await fetchVetPatients();
      setPatients(data);
    } catch {
      setError("Não foi possível carregar a lista de pacientes.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPatients();
  }, [user?.id]);

  const filteredPatients = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return patients;

    return patients.filter((patient) => {
      const name = patient.name.toLowerCase();
      const species = patient.species.toLowerCase();
      const breed = patient.breed.toLowerCase();
      const tutor = patient.tutor.toLowerCase();

      return (
        name.includes(q) ||
        species.includes(q) ||
        breed.includes(q) ||
        tutor.includes(q)
      );
    });
  }, [patients, searchTerm]);

  const handleOpenModal = () => {
    setShareCode("");
    setModalError(null);
    setModalSuccess(null);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    if (modalLoading) return;
    setIsModalOpen(false);
    setShareCode("");
    setModalError(null);
    setModalSuccess(null);
  };

  const handleRedeemCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!shareCode.trim()) {
      setModalError("Por favor, digite o código de compartilhamento.");
      return;
    }

    setModalLoading(true);
    setModalError(null);
    setModalSuccess(null);

    try {
      await redeemPatientShareCode(shareCode);
      setModalSuccess("Paciente vinculado com sucesso!");
      setShareCode("");
      await loadPatients();
      setTimeout(() => {
        setIsModalOpen(false);
        setModalSuccess(null);
      }, 1200);
    } catch (err: unknown) {
      const maybeAxios = err as { response?: { data?: { message?: string } } };
      const message =
        maybeAxios.response?.data?.message ||
        "Código inválido ou expirado. Verifique com o tutor.";
      setModalError(message);
    } finally {
      setModalLoading(false);
    }
  };

  return (
    <VetLayout>
      <div className={styles.pageContainer}>
        <header className={styles.topHeader}>
          <h1 className={styles.pageTitle}>Pacientes</h1>

          <button
            type="button"
            className={styles.addBtn}
            onClick={handleOpenModal}
          >
            + Novo paciente
          </button>
        </header>

        {error && (
          <div className={styles.errorMessage}>
            <span>{error}</span>
            <button
              type="button"
              className={styles.retryBtn}
              onClick={loadPatients}
            >
              Tentar novamente
            </button>
          </div>
        )}

        <div className={styles.searchContainer}>
          <Search className={styles.searchIcon} size={20} />
          <input
            type="text"
            className={styles.searchInput}
            placeholder="Buscar por nome, espécie ou tutor..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            aria-label="Buscar por nome, espécie ou tutor"
          />
        </div>

        <div className={styles.tableCard}>
          {loading ? (
            <p className={styles.statusMessage}>Carregando pacientes...</p>
          ) : patients.length === 0 ? (
            <div className={styles.emptyState}>
              <p className={styles.emptyText}>
                Ainda não há pacientes compartilhados com você.
              </p>
              <button
                type="button"
                className={styles.emptyActionBtn}
                onClick={handleOpenModal}
              >
                + Vincular primeiro paciente
              </button>
            </div>
          ) : filteredPatients.length === 0 ? (
            <div className={styles.emptyState}>
              <p className={styles.emptyText}>
                Nenhum paciente encontrado para a busca "{searchTerm}".
              </p>
            </div>
          ) : (
            <table className={styles.table} aria-label="Tabela de Pacientes">
              <thead className={styles.tableHead}>
                <tr>
                  <th scope="col" className={styles.th}>
                    PACIENTE
                  </th>
                  <th scope="col" className={styles.th}>
                    ESPÉCIE / RAÇA
                  </th>
                  <th scope="col" className={styles.th}>
                    TUTOR
                  </th>
                  <th scope="col" className={styles.th}>
                    ÚLTIMA CONSULTA
                  </th>
                  <th scope="col" className={`${styles.th} ${styles.thAction}`}>
                    <span className="sr-only">Ações</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredPatients.map((patient) => (
                  <tr key={patient.id} className={styles.tableRow}>
                    <td className={styles.td}>
                      <div className={styles.patientCell}>
                        <div className={styles.avatarSquare}>
                          {patient.photo ? (
                            <img
                              src={patient.photo}
                              alt={patient.name}
                              className={styles.avatarImg}
                              onError={(e) => {
                                (e.target as HTMLElement).style.display =
                                  "none";
                              }}
                            />
                          ) : (
                            <PawPrint size={22} strokeWidth={2} />
                          )}
                        </div>
                        <span className={styles.petName}>{patient.name}</span>
                      </div>
                    </td>

                    <td className={styles.td}>
                      {patient.species} • {patient.breed}
                    </td>

                    <td className={styles.td}>{patient.tutor}</td>

                    <td className={styles.td}>{patient.ultimaConsulta}</td>

                    <td className={`${styles.td} ${styles.actionCell}`}>
                      <Link
                        to={`/vet/pacientes/${patient.id}/consultas`}
                        className={styles.openLink}
                        aria-label={`Abrir prontuário de ${patient.name}`}
                      >
                        Abrir ›
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Modal de vinculação de código de paciente */}
        {isModalOpen && (
          <div
            className={styles.modalOverlay}
            onClick={handleCloseModal}
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
          >
            <div
              className={styles.modalCard}
              onClick={(e) => e.stopPropagation()}
            >
              <div className={styles.modalHeader}>
                <h2 id="modal-title" className={styles.modalTitle}>
                  Novo paciente
                </h2>
                <button
                  type="button"
                  className={styles.closeBtn}
                  onClick={handleCloseModal}
                  aria-label="Fechar modal"
                >
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleRedeemCode}>
                <div className={styles.modalBody}>
                  <p className={styles.modalDescription}>
                    Insira o código de compartilhamento de 8 caracteres fornecido
                    pelo tutor para ter acesso ao prontuário do paciente.
                  </p>

                  <div className={styles.formGroup}>
                    <label htmlFor="shareCodeInput" className={styles.label}>
                      Código de compartilhamento
                    </label>
                    <input
                      id="shareCodeInput"
                      type="text"
                      className={styles.codeField}
                      placeholder="Ex: a1b2c3d4"
                      value={shareCode}
                      onChange={(e) => setShareCode(e.target.value)}
                      maxLength={16}
                      disabled={modalLoading}
                      autoFocus
                    />
                  </div>

                  {modalError && (
                    <div className={styles.modalAlertError} role="alert">
                      {modalError}
                    </div>
                  )}

                  {modalSuccess && (
                    <div className={styles.modalAlertSuccess} role="status">
                      {modalSuccess}
                    </div>
                  )}
                </div>

                <div className={styles.modalFooter}>
                  <button
                    type="button"
                    className={styles.cancelBtn}
                    onClick={handleCloseModal}
                    disabled={modalLoading}
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className={styles.submitBtn}
                    disabled={modalLoading || !shareCode.trim()}
                  >
                    {modalLoading ? "Vinculando..." : "Vincular Paciente"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </VetLayout>
  );
}
