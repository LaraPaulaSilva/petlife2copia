import { describe, it, expect, beforeEach } from "vitest";
import { render, screen, within } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import HomePage from "./HomePage";

describe("HomePage", () => {
  beforeEach(() => {
    render(
      <MemoryRouter>
        <HomePage />
      </MemoryRouter>,
    );
  });

  describe("Cabeçalho e marca", () => {
    it("exibe a marca PetLife", () => {
      expect(screen.getAllByText("Pet").length).toBeGreaterThan(0);
      expect(screen.getAllByText("Life").length).toBeGreaterThan(0);
    });

    it("exibe os links de navegação do topo", () => {
      const header = screen.getAllByRole("navigation")[0];
      expect(
        within(header).getByText("Funcionalidades"),
      ).toBeInTheDocument();
      expect(
        within(header).getByText("Para Veterinários"),
      ).toBeInTheDocument();
      expect(within(header).getByText("Sobre")).toBeInTheDocument();
    });

    it("exibe os links de entrar e criar conta no topo", () => {
      expect(
        screen.getByRole("link", { name: "Entrar" }),
      ).toBeInTheDocument();
      expect(
        screen.getAllByRole("link", { name: /Criar conta grátis/i }).length,
      ).toBeGreaterThanOrEqual(1);
    });
  });

  describe("Seção Hero", () => {
    it("exibe o título principal", () => {
      expect(
        screen.getByRole("heading", { name: /Toda a saúde do seu pet/i }),
      ).toBeInTheDocument();
    });

    it("exibe o selo e o subtítulo", () => {
      expect(
        screen.getByText("Prontuário eletrônico para pets"),
      ).toBeInTheDocument();
      expect(
        screen.getByText(/Organize o histórico, acompanhe a saúde/i),
      ).toBeInTheDocument();
    });

    it("exibe a imagem do hero com texto alternativo", () => {
      expect(
        screen.getByAltText(
          "Veterinária usando o PetLife ao lado de um golden retriever",
        ),
      ).toBeInTheDocument();
    });

    it("exibe os call-to-action do hero", () => {
      const hero = screen
        .getByRole("heading", { name: /Toda a saúde do seu pet/i })
        .closest("section");
      expect(hero).not.toBeNull();
      expect(
        within(hero!).getByRole("link", { name: /Criar conta grátis/i }),
      ).toBeInTheDocument();
    });
  });

  describe("Seção de Funcionalidades", () => {
    it("exibe o título da seção", () => {
      expect(
        screen.getByRole("heading", { name: "Tudo o que seu pet precisa" }),
      ).toBeInTheDocument();
    });

    it("exibe os 4 cards de funcionalidades", () => {
      expect(
        screen.getByRole("heading", { name: "Prontuário completo" }),
      ).toBeInTheDocument();
      expect(
        screen.getByRole("heading", {
          name: "Carteira de vacinação digital",
        }),
      ).toBeInTheDocument();
      expect(
        screen.getByRole("heading", { name: "Lembretes e alertas" }),
      ).toBeInTheDocument();
      expect(
        screen.getByRole("heading", { name: "Diário do pet" }),
      ).toBeInTheDocument();
    });
  });

  describe("Seção para Veterinários", () => {
    it("exibe o selo e o título da seção", () => {
      expect(
        screen.getAllByText("Para Veterinários").length,
      ).toBeGreaterThanOrEqual(1);
      expect(
        screen.getByRole("heading", {
          name: /Acompanhe seus pacientes e registre seus atendimentos/i,
        }),
      ).toBeInTheDocument();
    });

    it("exibe o botão Saiba mais", () => {
      expect(
        screen.getByRole("button", { name: "Saiba mais" }),
      ).toBeInTheDocument();
    });

    it("exibe a imagem da veterinária", () => {
      expect(
        screen.getByAltText("Veterinária segurando um gato"),
      ).toBeInTheDocument();
    });
  });

  describe("Seção de Depoimentos", () => {
    it("exibe o título da seção", () => {
      expect(
        screen.getByRole("heading", { name: "Quem já usa, aprova" }),
      ).toBeInTheDocument();
    });

    it("exibe os 3 depoimentos com nome e papel", () => {
      expect(screen.getByText("Juliana Martins")).toBeInTheDocument();
      expect(screen.getByText("Tutora da Luna")).toBeInTheDocument();
      expect(screen.getByText("Dr. Rafael Souza")).toBeInTheDocument();
      expect(screen.getByText("Médico Veterinário")).toBeInTheDocument();
      expect(screen.getByText("Camila Ribeiro")).toBeInTheDocument();
      expect(screen.getByText("Tutora da Mia")).toBeInTheDocument();
    });

    it("exibe os avatares dos depoimentos", () => {
      expect(screen.getByAltText("Juliana Martins")).toBeInTheDocument();
      expect(screen.getByAltText("Dr. Rafael Souza")).toBeInTheDocument();
      expect(screen.getByAltText("Camila Ribeiro")).toBeInTheDocument();
    });
  });

  describe("Banner de CTA final", () => {
    it("exibe o título e o link de criar conta", () => {
      expect(
        screen.getByRole("heading", {
          name: "Comece a cuidar melhor do seu pet hoje",
        }),
      ).toBeInTheDocument();
      expect(
        screen.getAllByRole("link", { name: /Criar conta grátis/i }),
      ).toHaveLength(3);
    });

    it("exibe os diferenciais do produto", () => {
      expect(
        screen.getByText(/100% seguro e confiável/i),
      ).toBeInTheDocument();
      expect(screen.getByText(/Gratuito para tutores/i)).toBeInTheDocument();
      expect(
        screen.getByText(/Disponível em todos os dispositivos/i),
      ).toBeInTheDocument();
    });
  });

  describe("Rodapé", () => {
    it("exibe o slogan da marca", () => {
      expect(
        screen.getByText("Tecnologia e carinho para uma vida melhor."),
      ).toBeInTheDocument();
    });

    it("exibe os links do rodapé", () => {
      expect(screen.getByText("Suporte")).toBeInTheDocument();
      expect(screen.getByText("Privacidade")).toBeInTheDocument();
    });
  });
});
