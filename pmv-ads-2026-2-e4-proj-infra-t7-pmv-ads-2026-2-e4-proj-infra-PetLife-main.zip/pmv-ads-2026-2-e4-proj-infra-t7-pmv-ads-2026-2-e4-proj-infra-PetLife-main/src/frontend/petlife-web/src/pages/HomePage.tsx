import { useNavigate } from "react-router-dom";
import {
  PawPrint,
  FileText,
  Syringe,
  Bell,
  BookOpen,
  Stethoscope,
  ShieldCheck,
  Heart,
  Smartphone,
  ArrowRight,
  Star,
} from "lucide-react";
import styles from "./HomePage.module.css";
import { Link } from "react-router-dom";
import SiteFooter from "../components/layout/SiteFooter";

const features = [
  {
    Icon: FileText,
    title: "Prontuário completo",
    description:
      "Histórico de consultas, exames, medicações e muito mais, sempre à mão.",
  },
  {
    Icon: Syringe,
    title: "Carteira de vacinação digital",
    description:
      "Mantenha as vacinas do seu pet em dia com lembretes automáticos.",
  },
  {
    Icon: Bell,
    title: "Lembretes e alertas",
    description:
      "Receba avisos de vacinas, retornos e cuidados importantes para o seu pet.",
  },
  {
    Icon: BookOpen,
    title: "Diário do pet",
    description:
      "Registre fotos, peso, alimentação e o que for importante na rotina dele.",
  },
];

const testimonials = [
  {
    name: "Juliana Martins",
    role: "Tutora da Luna",
    avatar: "/images/depoimento-1.jpeg",
    text: "O PetLife me dá tranquilidade para acompanhar a saúde da minha pet. É super fácil de usar e me sinto mais segura sabendo que nada passa despercebido.",
  },
  {
    name: "Dr. Rafael Souza",
    role: "Médico Veterinário",
    avatar: "/images/depoimento-3.jpeg",
    text: "O sistema é intuitivo e completo. Conseguimos oferecer um atendimento mais organizado e próximo dos tutores.",
  },
  {
    name: "Camila Ribeiro",
    role: "Tutora da Mia",
    avatar: "/images/depoimento-2.jpeg",
    text: "Desde que comecei a usar o PetLife, consigo manter todo o histórico da minha gata em um só lugar. Os lembretes de vacina são incríveis.",
  },
];

export default function HomePage() {
  const navigate = useNavigate();

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <div className={styles.logo}>
          <PawPrint className={styles.logoIcon} />
          <span className={styles.logoText}>
            <span className={styles.logoPet}>Pet</span>
            <span className={styles.logoLife}>Life</span>
          </span>
        </div>
        <nav className={styles.nav}>
          <a href="#funcionalidades">Funcionalidades</a>
          <a href="#veterinarios">Para Veterinários</a>
          <a href="#sobre">Sobre</a>
        </nav>
        <div className={styles.headerActions}>
          <Link className={styles.btnOutline} to={"/login"}>
            Entrar
          </Link>
          <Link className={styles.btnPrimary} to={"/register"}>
            Criar conta grátis
          </Link>
        </div>
      </header>

      <section className={styles.hero}>
        <img
          className={styles.heroBg}
          src="/images/hero-banner.png"
          alt="Veterinária usando o PetLife ao lado de um golden retriever"
        />
        <div className={styles.heroOverlay}>
          <div className={styles.heroContent}>
            <span className={styles.badge}>
              Prontuário eletrônico para pets
            </span>
            <h1 className={styles.heroTitle}>
              Toda a saúde do seu pet{" "}
              <span className={styles.highlightPink}>em um</span>{" "}
              <span className={styles.highlightOrange}>só lugar</span>
            </h1>
            <p className={styles.heroSubtitle}>
              Organize o histórico, acompanhe a saúde e mantenha seu pet sempre
              protegido. PetLife é praticidade, segurança e muito amor em cada
              detalhe.
            </p>
            <div className={styles.heroActions}>
              <Link className={styles.btnPrimary} to={"/register"}>
                Criar conta grátis <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section id="funcionalidades" className={styles.features}>
        <h2 className={styles.sectionTitle}>Tudo o que seu pet precisa</h2>
        <p className={styles.sectionSubtitle}>
          Funcionalidades que facilitam o dia a dia e garantem mais saúde e
          bem-estar.
        </p>
        <div className={styles.featureGrid}>
          {features.map((f) => (
            <div key={f.title} className={styles.featureCard}>
              <div className={styles.featureIcon}>
                <f.Icon size={24} />
              </div>
              <h3>{f.title}</h3>
              <p>{f.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="veterinarios" className={styles.vetSection}>
        <div className={styles.vetContent}>
          <span className={styles.vetBadge}>
            <Stethoscope size={14} /> Para Veterinários
          </span>
          <h2>
            Acompanhe seus pacientes e registre seus atendimentos com mais
            praticidade.
          </h2>
          <p>
            O PetLife facilita a rotina do veterinário, centralizando
            informações, agilizando o atendimento e melhorando a comunicação com
            os tutores.
          </p>
          <button className={styles.btnWhite} onClick={() => navigate("/vet")}>
            Saiba mais
          </button>
        </div>
        <img
          className={styles.vetImage}
          src="/images/vet.jpeg"
          alt="Veterinária segurando um gato"
        />
      </section>

      <section id="sobre" className={styles.testimonials}>
        <h2 className={styles.sectionTitle}>Quem já usa, aprova</h2>
        <p className={styles.sectionSubtitle}>
          Tutores e veterinários que confiam no PetLife.
        </p>
        <div className={styles.testimonialGrid}>
          {testimonials.map((t) => (
            <div key={t.name} className={styles.testimonialCard}>
              <p className={styles.testimonialText}>"{t.text}"</p>
              <div className={styles.testimonialAuthor}>
                <img
                  className={styles.testimonialAvatar}
                  src={t.avatar}
                  alt={t.name}
                />
                <div>
                  <strong>{t.name}</strong>
                  <span>{t.role}</span>
                </div>
              </div>
              <div className={styles.stars}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={16} fill="currentColor" />
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.ctaBanner}>
        <div className={styles.ctaText}>
          <h2>Comece a cuidar melhor do seu pet hoje</h2>
          <p>É rápido, seguro e gratuito. Seu pet merece o melhor.</p>

          <Link className={styles.btnWhite} to={"/register"}>
            Criar conta grátis <ArrowRight size={18} />
          </Link>
        </div>
        <ul className={styles.ctaPerks}>
          <li>
            <ShieldCheck size={18} /> 100% seguro e confiável
          </li>
          <li>
            <Heart size={18} /> Gratuito para tutores
          </li>
          <li>
            <Smartphone size={18} /> Disponível em todos os dispositivos
          </li>
        </ul>
      </section>

      <SiteFooter />
    </div>
  );
}
