import { useState } from "react";
import { PawPrint } from "lucide-react";
import { useNavigate, Link } from "react-router-dom";
import api, { baseURL } from "../api/client";
import { useAuth } from "../contexts/AuthContext";
import { getApiErrorMessage } from "../utils/apiError";
import styles from "./AuthPages.module.css";

const LoginPage = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const data = Object.fromEntries(formData.entries());

    setError(null);
    setIsSubmitting(true);
    try {
      const response = await api.post(`${baseURL}/api/users/login`, data);
      login(response.data.user, response.data.token);

      const hasPickedRole = localStorage.getItem("hasPickedRole");
      const parsedHasPickedRole: boolean = hasPickedRole === "true";
      if (!parsedHasPickedRole) {
        navigate("/register-role", { replace: true });
        return;
      }
      const url = response.data.user.role === "Tutor" ? "/tutor" : "/vet";
      navigate(url, { replace: true });
    } catch (err) {
      setError(
        getApiErrorMessage(err, "E-mail ou senha inválidos. Tente novamente."),
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={styles.page}>
      <aside className={styles.brandSide}>
        <div className={styles.brandLogo}>
          <PawPrint className={styles.brandLogoIcon} />
          PetLife
        </div>
        <h1 className={styles.brandTitle}>Bem-vindo de volta</h1>
        <p className={styles.brandSubtitle}>
          Acesse sua conta e cuide do seu pet
        </p>
      </aside>

      <main className={styles.formSide}>
        <div className={styles.formCard}>
          <h2 className={styles.formTitle}>Entrar</h2>
          <p className={styles.formSubtitle}>
            Informe seus dados para acessar o PetLife.
          </p>

          <form className={styles.form} onSubmit={handleSubmit}>
            <div className={styles.field}>
              <label className={styles.label} htmlFor="Email">
                E-mail
              </label>
              <input
                className={styles.input}
                name="Email"
                id="Email"
                type="email"
                placeholder="seu@email"
              />
            </div>

            <div className={styles.field}>
              <label className={styles.label} htmlFor="Password">
                Senha
              </label>
              <input
                className={styles.input}
                name="Password"
                id="Password"
                type="password"
                placeholder="Sua senha"
              />
            </div>

            {error && <p className={styles.errorMsg}>{error}</p>}

            <button
              className={styles.submitBtn}
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Entrando..." : "Entrar"}
            </button>
          </form>

          <p className={styles.footerText}>
            <Link className={styles.footerLink} to="/register">
              Não tem conta? Criar conta
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
};

export default LoginPage;
