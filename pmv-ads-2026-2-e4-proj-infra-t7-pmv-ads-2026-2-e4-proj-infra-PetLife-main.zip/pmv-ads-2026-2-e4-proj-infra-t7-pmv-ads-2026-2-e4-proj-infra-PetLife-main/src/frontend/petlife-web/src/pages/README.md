# pages/

Cada integrante cria aqui a sua página (um arquivo/pasta por tela).

Convenção:
- Um componente por página, ex: `Login.tsx`, `HomeTutor.tsx`, `Prontuario.tsx`.
- Estilos da página em CSS Module ao lado: `Login.module.css`.
- Depois de criar a página, registre a rota em `src/routes/AppRouter.tsx`.

Exemplo mínimo de página:

```tsx
// src/pages/Login.tsx
import styles from "./Login.module.css";

export default function Login() {
  return <div className={styles.container}>Login</div>;
}
```

Para consumir a API, importe o cliente Axios e os tipos:

```tsx
import api from "../api/client";
import type { Pet } from "../types";

const { data } = await api.get<Pet[]>("/api/pets");
```
