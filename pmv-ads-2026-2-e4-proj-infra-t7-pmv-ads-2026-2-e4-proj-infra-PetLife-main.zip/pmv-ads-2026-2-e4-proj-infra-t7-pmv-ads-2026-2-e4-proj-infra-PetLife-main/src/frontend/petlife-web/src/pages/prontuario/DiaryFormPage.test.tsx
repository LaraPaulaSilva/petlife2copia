import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import type { Pet, PetDiaryEntry, User } from "../../types";
import DiaryFormPage from "./DiaryFormPage";
import { createDiaryEntry } from "../../services/diaryService";
import { getPet } from "../../services/petService";

vi.mock("../../services/diaryService", async () => {
  const actual = await vi.importActual<typeof import("../../services/diaryService")>(
    "../../services/diaryService",
  );
  return {
    ...actual,
    createDiaryEntry: vi.fn(),
  };
});

vi.mock("../../services/petService", () => ({
  getPet: vi.fn(),
}));

const mockedCreate = vi.mocked(createDiaryEntry);
const mockedGetPet = vi.mocked(getPet);

const tutorUser: User = {
  id: "tutor-1",
  name: "Ana Souza",
  email: "ana@petlife.test",
  role: "Tutor",
};

const pet: Pet = {
  id: "pet-1",
  nome: "Lulu",
  especie: "Gato",
  raca: "Vira-lata",
  tutor_id: "tutor-1",
};

const createdEntry: PetDiaryEntry = {
  id: "diary-1",
  pet_id: "pet-1",
  perfil_autor: "tutor",
  data_registro: "2026-09-27",
  tags: ["vacina", "febre"],
  Registro: "Lulu apresentou leve febre após a vacinação.",
};

function renderForm(path = "/tutor/pets/pet-1/diario/novo") {
  return render(
    <AuthContext.Provider
      value={{
        user: tutorUser,
        setUser: vi.fn(),
        login: vi.fn(),
        logout: vi.fn(),
      }}
    >
      <MemoryRouter initialEntries={[path]}>
        <Routes>
          <Route path="/tutor/pets/:petId/diario/novo" element={<DiaryFormPage />} />
          <Route path="/tutor/pets/:petId/diario" element={<div>Lista do diário</div>} />
        </Routes>
      </MemoryRouter>
    </AuthContext.Provider>,
  );
}

describe("DiaryFormPage", () => {
  beforeEach(() => {
    mockedCreate.mockReset();
    mockedGetPet.mockReset();
    mockedGetPet.mockResolvedValue(pet);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("bloqueia o envio sem o texto do registro", async () => {
    const user = userEvent.setup();
    renderForm();

    await waitFor(() => {
      expect(screen.getByText("Pet: Lulu")).toBeInTheDocument();
    });

    await user.click(screen.getByRole("button", { name: "Salvar registro" }));

    expect(screen.getByText("Preencha a data e o texto do registro.")).toBeInTheDocument();
    expect(mockedCreate).not.toHaveBeenCalled();
  });

  it("chama createDiaryEntry com o payload e volta para a listagem", async () => {
    const user = userEvent.setup();
    mockedCreate.mockResolvedValue(createdEntry);
    renderForm();

    await waitFor(() => {
      expect(screen.getByText("Pet: Lulu")).toBeInTheDocument();
    });

    await user.clear(screen.getByLabelText("Data"));
    await user.type(screen.getByLabelText("Data"), "2026-09-27");
    await user.type(
      screen.getByLabelText("Registro"),
      "Lulu apresentou leve febre após a vacinação.",
    );
    await user.type(screen.getByLabelText("Tags"), "vacina, febre");
    await user.click(screen.getByRole("button", { name: "Salvar registro" }));

    await waitFor(() => {
      expect(mockedCreate).toHaveBeenCalledWith({
        pet_id: "pet-1",
        data_registro: "2026-09-27",
        Registro: "Lulu apresentou leve febre após a vacinação.",
        tags: ["vacina", "febre"],
      });
    });

    expect(screen.getByText("Lista do diário")).toBeInTheDocument();
  });

  it("volta para a listagem ao cancelar sem gravar", async () => {
    const user = userEvent.setup();
    renderForm();

    await waitFor(() => {
      expect(screen.getByText("Pet: Lulu")).toBeInTheDocument();
    });

    await user.type(screen.getByLabelText("Registro"), "Texto que não deve ser salvo");
    await user.click(screen.getByRole("button", { name: "Cancelar" }));

    expect(screen.getByText("Lista do diário")).toBeInTheDocument();
    expect(mockedCreate).not.toHaveBeenCalled();
  });
});
