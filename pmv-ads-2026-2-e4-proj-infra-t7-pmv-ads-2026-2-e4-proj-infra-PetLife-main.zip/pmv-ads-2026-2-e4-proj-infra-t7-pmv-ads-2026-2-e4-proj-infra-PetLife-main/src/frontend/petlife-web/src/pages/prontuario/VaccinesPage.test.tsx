import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import type { Pet, User, Vaccine } from "../../types";
import VaccinesPage from "./VaccinesPage";
import {
  fetchVaccinesByPet,
  deleteVaccine,
  createVaccine,
} from "../../services/vaccineService";
import { getPet } from "../../services/petService";

vi.mock("../../services/vaccineService", async () => {
  const actual = await vi.importActual<typeof import("../../services/vaccineService")>(
    "../../services/vaccineService",
  );
  return {
    ...actual,
    fetchVaccinesByPet: vi.fn(),
    deleteVaccine: vi.fn(),
    createVaccine: vi.fn(),
  };
});

vi.mock("../../services/petService", () => ({
  getPet: vi.fn(),
}));

const mockedFetch = vi.mocked(fetchVaccinesByPet);
const mockedDelete = vi.mocked(deleteVaccine);
const mockedCreate = vi.mocked(createVaccine);
const mockedGetPet = vi.mocked(getPet);

const tutorUser: User = {
  id: "tutor-1",
  name: "Ana Souza",
  email: "ana@petlife.test",
  role: "Tutor",
};

const vetUser: User = {
  id: "vet-1",
  name: "Dra. Paula",
  email: "paula@petlife.test",
  role: "Veterinário",
};

const pet: Pet = {
  id: "pet-1",
  nome: "Lulu",
  especie: "Gato",
  raca: "Vira-lata",
  tutor_id: "tutor-1",
};

const vaccines: Vaccine[] = [
  {
    id: "vaccine-1",
    pet_id: "pet-1",
    tipo: "V10 (Polivalente)",
    data_aplicacao: "2026-10-05",
    data_proxima_dose: "2027-10-05",
    lote: "LT-2026-0987",
    fabricante: "Zoetis",
    origem_registro: "TUTOR",
    alerta_reforco: true,
  },
  {
    id: "vaccine-2",
    pet_id: "pet-1",
    tipo: "Antirrábica",
    data_aplicacao: "2026-08-10",
    data_proxima_dose: "2027-08-10",
    lote: "AR-5521",
    fabricante: "MSD",
    origem_registro: "VETERINARIO",
    alerta_reforco: false,
  },
];

function renderPage(
  path = "/tutor/pets/pet-1/vacinas",
  user: User = tutorUser,
) {
  return render(
    <AuthContext.Provider
      value={{
        user,
        setUser: vi.fn(),
        login: vi.fn(),
        logout: vi.fn(),
      }}
    >
      <MemoryRouter initialEntries={[path]}>
        <Routes>
          <Route path="/tutor/pets/:petId/vacinas" element={<VaccinesPage />} />
          <Route path="/vet/pacientes/:petId/vacinas" element={<VaccinesPage />} />
        </Routes>
      </MemoryRouter>
    </AuthContext.Provider>,
  );
}

describe("VaccinesPage", () => {
  beforeEach(() => {
    mockedFetch.mockReset();
    mockedDelete.mockReset();
    mockedCreate.mockReset();
    mockedGetPet.mockReset();
    mockedGetPet.mockResolvedValue(pet);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("exibe as vacinas do pet com tipo e detalhes", async () => {
    mockedFetch.mockResolvedValue(vaccines);
    renderPage();

    await waitFor(() => {
      expect(screen.getByText("V10 (Polivalente)")).toBeInTheDocument();
    });

    expect(screen.getByText("Antirrábica")).toBeInTheDocument();
    expect(screen.getByText("Zoetis • Lote LT-2026-0987")).toBeInTheDocument();
    expect(screen.getByText("MSD • Lote AR-5521")).toBeInTheDocument();
    expect(screen.getByText("Lulu • Gato • Vira-lata")).toBeInTheDocument();
    expect(mockedFetch).toHaveBeenCalledWith("pet-1");
  });

  it("abre o modal de nova vacina ao clicar no botão", async () => {
    mockedFetch.mockResolvedValue(vaccines);
    const user = userEvent.setup();
    renderPage();

    await waitFor(() => {
      expect(screen.getByText("V10 (Polivalente)")).toBeInTheDocument();
    });

    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();

    await user.click(screen.getByRole("button", { name: "+ Nova vacina" }));

    expect(screen.getByRole("dialog")).toBeInTheDocument();
    expect(screen.getByLabelText("Vacina")).toBeInTheDocument();
  });

  it("mostra estado vazio quando não há vacinas", async () => {
    mockedFetch.mockResolvedValue([]);
    renderPage();

    await waitFor(() => {
      expect(screen.getByText("Nenhuma vacina cadastrada.")).toBeInTheDocument();
    });
  });

  it("mostra erro quando a listagem falha", async () => {
    mockedFetch.mockRejectedValue(new Error("falha na api"));
    renderPage();

    await waitFor(() => {
      expect(
        screen.getByText("Não foi possível carregar as vacinas do pet."),
      ).toBeInTheDocument();
    });
  });

  it("cria a vacina pelo modal e adiciona na lista", async () => {
    mockedFetch.mockResolvedValue([]);
    const createdVaccine: Vaccine = {
      id: "vaccine-nova",
      pet_id: "pet-1",
      tipo: "Gripe canina",
      data_aplicacao: "2026-10-05",
      origem_registro: "TUTOR",
      alerta_reforco: true,
    };
    mockedCreate.mockResolvedValue(createdVaccine);
    const user = userEvent.setup();
    renderPage();

    await waitFor(() => {
      expect(screen.getByText("Nenhuma vacina cadastrada.")).toBeInTheDocument();
    });

    await user.click(screen.getByRole("button", { name: "+ Nova vacina" }));
    await user.type(screen.getByLabelText("Vacina"), "Gripe canina");
    await user.click(screen.getByRole("button", { name: "Salvar vacina" }));

    await waitFor(() => {
      expect(mockedCreate).toHaveBeenCalledWith(
        expect.objectContaining({
          pet_id: "pet-1",
          tipo: "Gripe canina",
          origem_registro: "TUTOR",
        }),
      );
    });

    expect(screen.getByText("Gripe canina")).toBeInTheDocument();
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("usa origem veterinário ao cadastrar na visão do vet", async () => {
    mockedFetch.mockResolvedValue([]);
    mockedCreate.mockResolvedValue({
      id: "vaccine-vet",
      pet_id: "pet-1",
      tipo: "Antirrábica",
      data_aplicacao: "2026-10-05",
      origem_registro: "VETERINARIO",
      alerta_reforco: true,
    });
    const user = userEvent.setup();
    renderPage("/vet/pacientes/pet-1/vacinas", vetUser);

    await waitFor(() => {
      expect(screen.getByText("Nenhuma vacina cadastrada.")).toBeInTheDocument();
    });

    await user.click(screen.getByRole("button", { name: "+ Nova vacina" }));
    await user.type(screen.getByLabelText("Vacina"), "Antirrábica");
    await user.click(screen.getByRole("button", { name: "Salvar vacina" }));

    await waitFor(() => {
      expect(mockedCreate).toHaveBeenCalledWith(
        expect.objectContaining({
          veterinario_id: "vet-1",
          origem_registro: "VETERINARIO",
        }),
      );
    });
  });

  it("remove a vacina da lista ao excluir", async () => {
    mockedFetch.mockResolvedValue(vaccines);
    mockedDelete.mockResolvedValue();
    const user = userEvent.setup();
    renderPage();

    await waitFor(() => {
      expect(screen.getByText("V10 (Polivalente)")).toBeInTheDocument();
    });

    const deleteButtons = screen.getAllByRole("button", { name: "Excluir" });
    await user.click(deleteButtons[0]);

    await waitFor(() => {
      expect(screen.queryByText("V10 (Polivalente)")).not.toBeInTheDocument();
    });
    expect(mockedDelete).toHaveBeenCalledWith("vaccine-1");
    expect(screen.getByText("Antirrábica")).toBeInTheDocument();
  });
});
