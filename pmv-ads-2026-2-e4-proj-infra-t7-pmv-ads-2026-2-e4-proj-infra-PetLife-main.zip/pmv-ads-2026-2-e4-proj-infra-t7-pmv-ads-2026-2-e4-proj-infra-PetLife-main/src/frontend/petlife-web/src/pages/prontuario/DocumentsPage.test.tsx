import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import type { Document, Pet, User } from "../../types";
import DocumentsPage from "./DocumentsPage";
import {
  fetchDocumentsByPet,
  deleteDocument,
} from "../../services/documentService";
import { fetchConsultasByPet } from "../../services/consultaService";
import { getPet } from "../../services/petService";

vi.mock("../../services/documentService", async () => {
  const actual = await vi.importActual<typeof import("../../services/documentService")>(
    "../../services/documentService",
  );
  return {
    ...actual,
    fetchDocumentsByPet: vi.fn(),
    deleteDocument: vi.fn(),
    createDocument: vi.fn(),
  };
});

vi.mock("../../services/consultaService", () => ({
  fetchConsultasByPet: vi.fn(),
  formatConsultaDate: (v: string) => v,
}));

vi.mock("../../services/petService", () => ({
  getPet: vi.fn(),
}));

const mockedFetch = vi.mocked(fetchDocumentsByPet);
const mockedDelete = vi.mocked(deleteDocument);
const mockedFetchConsultas = vi.mocked(fetchConsultasByPet);
const mockedGetPet = vi.mocked(getPet);

const tutorUser: User = {
  id: "tutor-1",
  name: "Ana Souza",
  email: "ana@petlife.test",
  role: "Tutor",
};

const pet: Pet = {
  id: "pet-1",
  nome: "Lulu",
  especie: "Gato",
  raca: "Vira-lata",
  tutor_id: "tutor-1",
};

const documents: Document[] = [
  {
    id: "doc-1",
    pet_id: "pet-1",
    usuario_id: "user-1",
    perfil_autor: "Dra. Paula",
    consulta_id: "consulta-1",
    titulo: "Exame de sangue",
    tipo_doc: "Exame",
    arquivo_url: "https://cloudinary.com/exame.pdf",
    data_upload: "2026-10-20",
  },
];

function renderPage(path = "/tutor/pets/pet-1/documentos", user: User = tutorUser) {
  return render(
    <AuthContext.Provider
      value={{ user, setUser: vi.fn(), login: vi.fn(), logout: vi.fn() }}
    >
      <MemoryRouter initialEntries={[path]}>
        <Routes>
          <Route path="/tutor/pets/:petId/documentos" element={<DocumentsPage />} />
          <Route path="/vet/pacientes/:petId/documentos" element={<DocumentsPage />} />
        </Routes>
      </MemoryRouter>
    </AuthContext.Provider>,
  );
}

describe("DocumentsPage", () => {
  beforeEach(() => {
    mockedFetch.mockReset();
    mockedDelete.mockReset();
    mockedFetchConsultas.mockReset();
    mockedFetchConsultas.mockResolvedValue([]);
    mockedGetPet.mockReset();
    mockedGetPet.mockResolvedValue(pet);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("exibe os documentos do pet", async () => {
    mockedFetch.mockResolvedValue(documents);
    renderPage();

    await waitFor(() => {
      expect(screen.getByText("Exame de sangue")).toBeInTheDocument();
    });

    expect(screen.getByText("Lulu • Gato • Vira-lata")).toBeInTheDocument();
    expect(mockedFetch).toHaveBeenCalledWith("pet-1");
  });

  it("mostra estado vazio quando não há documentos", async () => {
    mockedFetch.mockResolvedValue([]);
    renderPage();

    await waitFor(() => {
      expect(
        screen.getByText("Nenhum documento cadastrado."),
      ).toBeInTheDocument();
    });
  });

  it("abre o modal de novo documento ao clicar no botão", async () => {
    mockedFetch.mockResolvedValue([]);
    const user = userEvent.setup();
    renderPage();

    await waitFor(() => {
      expect(screen.getByText("Nenhum documento cadastrado.")).toBeInTheDocument();
    });

    await user.click(screen.getByRole("button", { name: "+ Novo documento" }));

    expect(screen.getByRole("dialog")).toBeInTheDocument();
    expect(screen.getByLabelText("Título")).toBeInTheDocument();
    expect(screen.getByLabelText("URL do arquivo")).toBeInTheDocument();
  });

  it("remove o documento da lista ao excluir", async () => {
    mockedFetch.mockResolvedValue(documents);
    mockedDelete.mockResolvedValue();
    const user = userEvent.setup();
    renderPage();

    await waitFor(() => {
      expect(screen.getByText("Exame de sangue")).toBeInTheDocument();
    });

    await user.click(screen.getByRole("button", { name: "Excluir" }));

    await waitFor(() => {
      expect(screen.queryByText("Exame de sangue")).not.toBeInTheDocument();
    });
    expect(mockedDelete).toHaveBeenCalledWith("doc-1", "tutor-1");
  });
});
