import { useEffect, useState } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import ProntuarioLayout from "../../components/layout/ProntuarioLayout";
import { getPet } from "../../services/petService";
import { fetchDiaryByPet, formatDiaryDate } from "../../services/diaryService";
import type { Pet, PetDiaryEntry } from "../../types";
import styles from "./DiaryPage.module.css";

function formatPetSummary(pet: Pet): string {
  return [pet.nome, pet.especie, pet.raca]
    .filter((part): part is string => Boolean(part?.trim()))
    .join(" • ");
}

export default function DiaryPage() {
  const { petId = "" } = useParams<{ petId: string }>();
  const location = useLocation();
  const { user } = useAuth();
  const [entries, setEntries] = useState<PetDiaryEntry[]>([]);
  const [petSummary, setPetSummary] = useState("");
  const [petPhoto, setPetPhoto] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const isVet =
    location.pathname.startsWith("/vet") || user?.role === "Veterinário";
  const basePath = isVet ? `/vet/pacientes/${petId}` : `/tutor/pets/${petId}`;

  useEffect(() => {
    if (!petId) return;

    let isMounted = true;
    setLoading(true);
    setError(null);

    Promise.all([fetchDiaryByPet(petId), getPet(petId).catch(() => null)])
      .then(([data, pet]) => {
        if (!isMounted) return;
        setEntries(data);
        if (pet) {
          setPetSummary(formatPetSummary(pet));
          setPetPhoto(pet.foto_url ?? null);
        }
      })
      .catch(() => {
        if (isMounted) {
          setEntries([]);
          setError("Não foi possível carregar o diário do pet.");
        }
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [petId]);

  return (
    <ProntuarioLayout
      title="Diário"
      icon="📖"
      activeTab="diario"
      petSummary={petSummary}
      petPhoto={petPhoto}
    >
      <div className={styles.sectionHeader}>
        <h2 className={styles.sectionTitle}>Diário do Pet</h2>
        {!isVet && (
          <Link to={`${basePath}/diario/novo`} className={styles.newEntryBtn}>
            + Novo registro
          </Link>
        )}
      </div>

      {loading && <p className={styles.statusMessage}>Carregando...</p>}

      {error && <p className={styles.errorMessage}>{error}</p>}

      {!loading && !error && entries.length === 0 && (
        <p className={styles.emptyState}>Nenhum registro no diário.</p>
      )}

      {!loading && !error && entries.length > 0 && (
        <div className={styles.entriesList}>
          {entries.map((entry) => (
            <article key={entry.id} className={styles.entryCard}>
              <time className={styles.entryDate} dateTime={entry.data_registro}>
                {formatDiaryDate(entry.data_registro)}
              </time>
              <p className={styles.entryText}>{entry.Registro}</p>
              {entry.tags?.length > 0 && (
                <ul className={styles.tagsRow}>
                  {entry.tags.map((tag, index) => (
                    <li key={`${entry.id}-${tag}-${index}`} className={styles.tagPill}>
                      {tag}
                    </li>
                  ))}
                </ul>
              )}
            </article>
          ))}
        </div>
      )}
    </ProntuarioLayout>
  );
}
