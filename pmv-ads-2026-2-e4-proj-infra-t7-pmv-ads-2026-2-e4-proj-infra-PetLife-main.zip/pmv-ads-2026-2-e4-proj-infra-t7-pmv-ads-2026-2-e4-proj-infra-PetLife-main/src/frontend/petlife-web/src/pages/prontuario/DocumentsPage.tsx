import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import ProntuarioLayout from "../../components/layout/ProntuarioLayout";
import DocumentCard from "../../components/prontuario/DocumentCard";
import DocumentFormModal from "../../components/prontuario/DocumentFormModal";
import SiteFooter from "../../components/layout/SiteFooter";
import { getPet } from "../../services/petService";
import {
  deleteDocument,
  fetchDocumentsByPet,
} from "../../services/documentService";
import {
  fetchConsultasByPet,
  formatConsultaDate,
} from "../../services/consultaService";
import type { Document, Pet } from "../../types";
import styles from "./DocumentsPage.module.css";

function formatPetSummary(pet: Pet): string {
  return [pet.nome, pet.especie, pet.raca]
    .filter((part): part is string => Boolean(part?.trim()))
    .join(" • ");
}

export default function DocumentsPage() {
  const { petId = "" } = useParams<{ petId: string }>();
  const location = useLocation();
  const { user } = useAuth();
  const [documents, setDocuments] = useState<Document[]>([]);
  const [consultaDates, setConsultaDates] = useState<Record<string, string>>({});
  const [petSummary, setPetSummary] = useState("");
  const [petName, setPetName] = useState("");
  const [petPhoto, setPetPhoto] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const isVet =
    location.pathname.startsWith("/vet") || user?.role === "Veterinário";

  useEffect(() => {
    if (!petId) return;

    let isMounted = true;
    setLoading(true);
    setError(null);

    Promise.all([
      fetchDocumentsByPet(petId),
      getPet(petId).catch(() => null),
      fetchConsultasByPet(petId).catch(() => []),
    ])
      .then(([data, pet, consultas]) => {
        if (!isMounted) return;
        setDocuments(data);
        setConsultaDates(
          Object.fromEntries(
            consultas.map((c) => [c.id, formatConsultaDate(c.data)]),
          ),
        );
        if (pet) {
          setPetSummary(formatPetSummary(pet));
          setPetName(pet.nome);
          setPetPhoto(pet.foto_url ?? null);
        }
      })
      .catch(() => {
        if (isMounted) {
          setDocuments([]);
          setError("Não foi possível carregar os documentos do pet.");
        }
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [petId]);

  const handleCreated = (document: Document) => {
    setDocuments((current) => [document, ...current]);
  };

  const handleDelete = async (document: Document) => {
    try {
      await deleteDocument(document.id, user?.id);
      setDocuments((current) =>
        current.filter((item) => item.id !== document.id),
      );
    } catch {
      setError("Não foi possível excluir o documento. Tente novamente.");
    }
  };

  return (
    <ProntuarioLayout
      title="Documentos"
      icon="📄"
      activeTab="documentos"
      petSummary={petSummary}
      petPhoto={petPhoto}
      fullWidth
    >
      <div className={styles.sectionHeader}>
        <h2 className={styles.sectionTitle}>Documentos</h2>
        <button
          type="button"
          className={styles.newDocumentBtn}
          onClick={() => setIsModalOpen(true)}
        >
          + Novo documento
        </button>
      </div>

      {loading && <p className={styles.statusMessage}>Carregando...</p>}

      {error && <p className={styles.errorMessage}>{error}</p>}

      {!loading && !error && documents.length === 0 && (
        <p className={styles.emptyState}>Nenhum documento cadastrado.</p>
      )}

      {!loading && !error && documents.length > 0 && (
        <div className={styles.documentsGrid}>
          {documents.map((document) => (
            <DocumentCard
              key={document.id}
              document={document}
              consultaLabel={
                document.consulta_id
                  ? consultaDates[document.consulta_id] ?? null
                  : null
              }
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      <div className={styles.footerWrapper}>
        <SiteFooter showBrand={false} />
      </div>

      <DocumentFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onCreated={handleCreated}
        petId={petId}
        petName={petName}
        isVet={isVet}
        userId={user?.id}
      />
    </ProntuarioLayout>
  );
}
