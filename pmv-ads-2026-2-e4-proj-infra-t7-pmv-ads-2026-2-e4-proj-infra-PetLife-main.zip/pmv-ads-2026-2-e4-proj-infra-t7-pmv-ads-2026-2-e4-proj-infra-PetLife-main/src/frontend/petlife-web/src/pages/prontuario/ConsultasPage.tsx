import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import ProntuarioLayout from "../../components/layout/ProntuarioLayout";
import ConsultaCard from "../../components/prontuario/ConsultaCard";
import ConsultaFormModal from "../../components/prontuario/ConsultaFormModal";
import ConsultaDetailsModal from "../../components/prontuario/ConsultaDetailsModal";
import TreatmentFormModal from "../../components/prontuario/TreatmentFormModal";
import SiteFooter from "../../components/layout/SiteFooter";
import { getPet } from "../../services/petService";
import {
  deleteConsulta,
  fetchConsultasByPet,
} from "../../services/consultaService";
import { fetchDocumentsByPet } from "../../services/documentService";
import type { Consulta, Document, Pet } from "../../types";
import styles from "./ConsultasPage.module.css";

function formatPetSummary(pet: Pet): string {
  return [pet.nome, pet.especie, pet.raca]
    .filter((part): part is string => Boolean(part?.trim()))
    .join(" • ");
}

export default function ConsultasPage() {
  const { petId = "" } = useParams<{ petId: string }>();
  const location = useLocation();
  const { user } = useAuth();
  const [consultas, setConsultas] = useState<Consulta[]>([]);
  const [documentos, setDocumentos] = useState<Document[]>([]);
  const [petSummary, setPetSummary] = useState("");
  const [petName, setPetName] = useState("");
  const [petPhoto, setPetPhoto] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isTreatmentModalOpen, setIsTreatmentModalOpen] = useState(false);
  const [selectedConsulta, setSelectedConsulta] = useState<Consulta | null>(
    null,
  );

  const isVet =
    location.pathname.startsWith("/vet") || user?.role === "Veterinário";

  useEffect(() => {
    if (!petId) return;

    let isMounted = true;
    setLoading(true);
    setError(null);

    Promise.all([
      fetchConsultasByPet(petId),
      getPet(petId).catch(() => null),
      fetchDocumentsByPet(petId).catch(() => []),
    ])
      .then(([data, pet, docs]) => {
        if (!isMounted) return;
        setConsultas(data);
        setDocumentos(docs);
        if (pet) {
          setPetSummary(formatPetSummary(pet));
          setPetName(pet.nome);
          setPetPhoto(pet.foto_url ?? null);
        }
      })
      .catch(() => {
        if (isMounted) {
          setConsultas([]);
          setError("Não foi possível carregar as consultas do pet.");
        }
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [petId]);

  const handleCreated = (consulta: Consulta, abrirTratamento?: boolean) => {
    setConsultas((current) => [consulta, ...current]);
    // A consulta já foi salva. Se o vet pediu tratamento, abrimos o modal em seguida.
    if (abrirTratamento) {
      setIsTreatmentModalOpen(true);
    }
  };

  const handleDelete = async (consulta: Consulta) => {
    try {
      await deleteConsulta(consulta.id, user?.id);
      setConsultas((current) =>
        current.filter((item) => item.id !== consulta.id),
      );
    } catch {
      setError("Não foi possível excluir a consulta. Tente novamente.");
    }
  };

  return (
    <ProntuarioLayout
      title="Consultas"
      icon="🩺"
      activeTab="consultas"
      petSummary={petSummary}
      petPhoto={petPhoto}
      fullWidth
    >
      <div className={styles.sectionHeader}>
        <h2 className={styles.sectionTitle}>Consultas</h2>
        <button
          type="button"
          className={styles.newConsultaBtn}
          onClick={() => setIsModalOpen(true)}
        >
          + Nova consulta
        </button>
      </div>

      {loading && <p className={styles.statusMessage}>Carregando...</p>}

      {error && <p className={styles.errorMessage}>{error}</p>}

      {!loading && !error && consultas.length === 0 && (
        <p className={styles.emptyState}>Nenhuma consulta cadastrada.</p>
      )}

      {!loading && !error && consultas.length > 0 && (
        <div className={styles.consultasGrid}>
          {consultas.map((consulta) => (
            <ConsultaCard
              key={consulta.id}
              consulta={consulta}
              onView={setSelectedConsulta}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      <div className={styles.footerWrapper}>
        <SiteFooter showBrand={false} />
      </div>

      <ConsultaFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onCreated={handleCreated}
        petId={petId}
        petName={petName}
        isVet={isVet}
        userId={user?.id}
      />

      <ConsultaDetailsModal
        isOpen={selectedConsulta !== null}
        onClose={() => setSelectedConsulta(null)}
        consulta={selectedConsulta}
        documentos={documentos.filter(
          (doc) => doc.consulta_id === selectedConsulta?.id,
        )}
      />

      <TreatmentFormModal
        isOpen={isTreatmentModalOpen}
        onClose={() => setIsTreatmentModalOpen(false)}
        onSaved={() => setIsTreatmentModalOpen(false)}
        petId={petId}
        petName={petName}
        isVet={isVet}
        vetId={user?.id}
      />
    </ProntuarioLayout>
  );
}
