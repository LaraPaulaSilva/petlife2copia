import { useEffect, useState, type FormEvent } from "react";
import { useNavigate, useParams } from "react-router-dom";
import ProntuarioLayout from "../../components/layout/ProntuarioLayout";
import { createDiaryEntry, parseDiaryTags } from "../../services/diaryService";
import { getPet } from "../../services/petService";
import styles from "./DiaryFormPage.module.css";

function todayInputValue(): string {
  const now = new Date();
  const yyyy = String(now.getFullYear());
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const dd = String(now.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

export default function DiaryFormPage() {
  const { petId = "" } = useParams<{ petId: string }>();
  const navigate = useNavigate();
  const returnPath = `/tutor/pets/${petId}/diario`;

  const [petName, setPetName] = useState("");
  const [dataRegistro, setDataRegistro] = useState(todayInputValue);
  const [registro, setRegistro] = useState("");
  const [tags, setTags] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!petId) return;

    let isMounted = true;
    getPet(petId)
      .then((pet) => {
        if (isMounted) setPetName(pet.nome);
      })
      .catch(() => {
        if (isMounted) setPetName("");
      });

    return () => {
      isMounted = false;
    };
  }, [petId]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    if (!dataRegistro || !registro.trim()) {
      setError("Preencha a data e o texto do registro.");
      return;
    }

    setError(null);
    setIsSubmitting(true);

    try {
      await createDiaryEntry({
        pet_id: petId,
        data_registro: dataRegistro,
        Registro: registro.trim(),
        tags: parseDiaryTags(tags),
      });
      navigate(returnPath);
    } catch (err) {
      console.error("Erro ao salvar registro do diário:", err);
      setError("Não foi possível salvar o registro. Tente novamente.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <ProntuarioLayout showHeaderAndTabs={false}>
      <div className={styles.pageContainer}>
        <header className={styles.headerBlock}>
          <h1 className={styles.pageTitle}>Novo registro</h1>
          <p className={styles.petSubtitle}>
            {petName ? `Pet: ${petName}` : "Pet"}
          </p>
        </header>

        <div className={styles.formCard}>
          <form className={styles.form} onSubmit={handleSubmit}>
            <div className={styles.fieldGroup}>
              <label htmlFor="dataRegistro" className={styles.label}>
                Data
              </label>
              <input
                id="dataRegistro"
                type="date"
                className={styles.input}
                value={dataRegistro}
                onChange={(e) => setDataRegistro(e.target.value)}
              />
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="registro" className={styles.label}>
                Registro
              </label>
              <textarea
                id="registro"
                className={styles.textarea}
                placeholder="Descreva o que aconteceu com o pet..."
                value={registro}
                onChange={(e) => setRegistro(e.target.value)}
              />
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="tags" className={styles.label}>
                Tags
              </label>
              <input
                id="tags"
                type="text"
                className={styles.input}
                placeholder="Ex: vacina, febre"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
              />
              <p className={styles.hint}>Separe as tags por vírgula.</p>
            </div>

            {error && <p className={styles.errorMsg}>{error}</p>}

            <div className={styles.actionsRow}>
              <button
                type="submit"
                className={styles.submitBtn}
                disabled={isSubmitting}
              >
                {isSubmitting ? "Salvando..." : "Salvar registro"}
              </button>
              <button
                type="button"
                className={styles.cancelBtn}
                onClick={() => navigate(returnPath)}
              >
                Cancelar
              </button>
            </div>
          </form>
        </div>
      </div>
    </ProntuarioLayout>
  );
}
