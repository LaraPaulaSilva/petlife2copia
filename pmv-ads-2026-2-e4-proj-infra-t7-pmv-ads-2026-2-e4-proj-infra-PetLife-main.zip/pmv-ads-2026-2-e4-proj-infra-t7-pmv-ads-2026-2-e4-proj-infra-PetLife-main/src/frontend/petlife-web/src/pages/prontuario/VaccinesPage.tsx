import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import ProntuarioLayout from "../../components/layout/ProntuarioLayout";
import VaccineCard from "../../components/prontuario/VaccineCard";
import VaccineFormModal from "../../components/prontuario/VaccineFormModal";
import SiteFooter from "../../components/layout/SiteFooter";
import { getPet } from "../../services/petService";
import { deleteVaccine, fetchVaccinesByPet } from "../../services/vaccineService";
import type { Pet, Vaccine } from "../../types";
import styles from "./VaccinesPage.module.css";

function formatPetSummary(pet: Pet): string {
  return [pet.nome, pet.especie, pet.raca]
    .filter((part): part is string => Boolean(part?.trim()))
    .join(" • ");
}

export default function VaccinesPage() {
  const { petId = "" } = useParams<{ petId: string }>();
  const location = useLocation();
  const { user } = useAuth();
  const [vaccines, setVaccines] = useState<Vaccine[]>([]);
  const [petSummary, setPetSummary] = useState("");
  const [petName, setPetName] = useState("");
  const [petPhoto, setPetPhoto] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const isVet =
    location.pathname.startsWith("/vet") || user?.role === "Veterinário";

  useEffect(() => {
    if (!petId) return;

    let isMounted = true;
    setLoading(true);
    setError(null);

    Promise.all([fetchVaccinesByPet(petId), getPet(petId).catch(() => null)])
      .then(([data, pet]) => {
        if (!isMounted) return;
        setVaccines(data);
        if (pet) {
          setPetSummary(formatPetSummary(pet));
          setPetName(pet.nome);
          setPetPhoto(pet.foto_url ?? null);
        }
      })
      .catch(() => {
        if (isMounted) {
          setVaccines([]);
          setError("Não foi possível carregar as vacinas do pet.");
        }
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [petId]);

  const handleCreated = (vaccine: Vaccine) => {
    setVaccines((current) => [vaccine, ...current]);
  };

  const handleDelete = async (vaccine: Vaccine) => {
    try {
      await deleteVaccine(vaccine.id);
      setVaccines((current) => current.filter((item) => item.id !== vaccine.id));
    } catch {
      setError("Não foi possível excluir a vacina. Tente novamente.");
    }
  };

  return (
    <ProntuarioLayout
      title="Vacinas"
      icon="💉"
      activeTab="vacinas"
      petSummary={petSummary}
      petPhoto={petPhoto}
      fullWidth
    >
      <div className={styles.sectionHeader}>
        <h2 className={styles.sectionTitle}>Vacinas</h2>
        <button
          type="button"
          className={styles.newVaccineBtn}
          onClick={() => setIsModalOpen(true)}
        >
          + Nova vacina
        </button>
      </div>

      {loading && <p className={styles.statusMessage}>Carregando...</p>}

      {error && <p className={styles.errorMessage}>{error}</p>}

      {!loading && !error && vaccines.length === 0 && (
        <p className={styles.emptyState}>Nenhuma vacina cadastrada.</p>
      )}

      {!loading && !error && vaccines.length > 0 && (
        <div className={styles.vaccinesGrid}>
          {vaccines.map((vaccine) => (
            <VaccineCard
              key={vaccine.id}
              vaccine={vaccine}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      <div className={styles.footerWrapper}>
        <SiteFooter showBrand={false} />
      </div>

      <VaccineFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onCreated={handleCreated}
        petId={petId}
        petName={petName}
        isVet={isVet}
        vetId={user?.id}
      />
    </ProntuarioLayout>
  );
}
