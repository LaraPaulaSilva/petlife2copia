import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import type { Consulta, Pet, User } from "../../types";
import ConsultasPage from "./ConsultasPage";
import {
  fetchConsultasByPet,
  deleteConsulta,
  createConsulta,
} from "../../services/consultaService";
import { fetchDocumentsByPet } from "../../services/documentService";
import { getPet } from "../../services/petService";

vi.mock("../../services/consultaService", async () => {
  const actual = await vi.importActual<typeof import("../../services/consultaService")>(
    "../../services/consultaService",
  );
  return {
    ...actual,
    fetchConsultasByPet: vi.fn(),
    deleteConsulta: vi.fn(),
    createConsulta: vi.fn(),
  };
});

vi.mock("../../services/documentService", () => ({
  fetchDocumentsByPet: vi.fn(),
}));

vi.mock("../../services/petService", () => ({
  getPet: vi.fn(),
}));

const mockedFetch = vi.mocked(fetchConsultasByPet);
const mockedDelete = vi.mocked(deleteConsulta);
const mockedCreate = vi.mocked(createConsulta);
const mockedGetPet = vi.mocked(getPet);
const mockedFetchDocs = vi.mocked(fetchDocumentsByPet);

const tutorUser: User = {
  id: "tutor-1",
  name: "Ana Souza",
  email: "ana@petlife.test",
  role: "Tutor",
};

const vetUser: User = {
  id: "vet-1",
  name: "Dra. Paula",
  email: "paula@petlife.test",
  role: "Veterinário",
};

const pet: Pet = {
  id: "pet-1",
  nome: "Lulu",
  especie: "Gato",
  raca: "Vira-lata",
  tutor_id: "tutor-1",
};

const consultas: Consulta[] = [
  {
    id: "consulta-1",
    pet_id: "pet-1",
    clinica: "Clínica PetLife Centro",
    data: "2026-10-05",
    hora: "14:30",
    tipo_atendimento: "Consulta de rotina",
    status: "REALIZADA",
    origem_registro: "VETERINARIO",
    autor_id: "vet-1",
    valor: 150,
  },
];

function renderPage(path = "/tutor/pets/pet-1/consultas", user: User = tutorUser) {
  return render(
    <AuthContext.Provider
      value={{ user, setUser: vi.fn(), login: vi.fn(), logout: vi.fn() }}
    >
      <MemoryRouter initialEntries={[path]}>
        <Routes>
          <Route path="/tutor/pets/:petId/consultas" element={<ConsultasPage />} />
          <Route path="/vet/pacientes/:petId/consultas" element={<ConsultasPage />} />
        </Routes>
      </MemoryRouter>
    </AuthContext.Provider>,
  );
}

describe("ConsultasPage", () => {
  beforeEach(() => {
    mockedFetch.mockReset();
    mockedDelete.mockReset();
    mockedCreate.mockReset();
    mockedGetPet.mockReset();
    mockedGetPet.mockResolvedValue(pet);
    mockedFetchDocs.mockReset();
    mockedFetchDocs.mockResolvedValue([]);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("exibe as consultas do pet", async () => {
    mockedFetch.mockResolvedValue(consultas);
    renderPage();

    await waitFor(() => {
      expect(screen.getByText("Consulta de rotina")).toBeInTheDocument();
    });

    expect(screen.getByText("Clínica PetLife Centro")).toBeInTheDocument();
    expect(screen.getByText("Lulu • Gato • Vira-lata")).toBeInTheDocument();
    expect(mockedFetch).toHaveBeenCalledWith("pet-1");
  });

  it("mostra estado vazio quando não há consultas", async () => {
    mockedFetch.mockResolvedValue([]);
    renderPage();

    await waitFor(() => {
      expect(
        screen.getByText("Nenhuma consulta cadastrada."),
      ).toBeInTheDocument();
    });
  });

  it("mostra erro quando a listagem falha", async () => {
    mockedFetch.mockRejectedValue(new Error("falha"));
    renderPage();

    await waitFor(() => {
      expect(
        screen.getByText("Não foi possível carregar as consultas do pet."),
      ).toBeInTheDocument();
    });
  });

  it("abre o modal de nova consulta e cadastra", async () => {
    mockedFetch.mockResolvedValue([]);
    mockedCreate.mockResolvedValue({
      ...consultas[0],
      id: "consulta-nova",
      tipo_atendimento: "Retorno",
    });
    const user = userEvent.setup();
    renderPage("/vet/pacientes/pet-1/consultas", vetUser);

    await waitFor(() => {
      expect(screen.getByText("Nenhuma consulta cadastrada.")).toBeInTheDocument();
    });

    await user.click(screen.getByRole("button", { name: "+ Nova consulta" }));
    expect(screen.getByRole("dialog")).toBeInTheDocument();

    // Na visão do vet, o tipo é escolhido por rádio e a queixa principal é obrigatória
    await user.click(screen.getByRole("radio", { name: "Retorno" }));
    await user.type(
      screen.getByLabelText("Queixa principal"),
      "Acompanhamento pós-cirúrgico",
    );
    await user.click(screen.getByRole("button", { name: "Salvar consulta" }));

    await waitFor(() => {
      expect(mockedCreate).toHaveBeenCalledWith(
        expect.objectContaining({
          pet_id: "pet-1",
          tipo_atendimento: "Retorno",
          motivo: "Acompanhamento pós-cirúrgico",
          origem_registro: "VETERINARIO",
          veterinario_id: "vet-1",
        }),
      );
    });

    expect(screen.getByText("Retorno")).toBeInTheDocument();
  });
});
