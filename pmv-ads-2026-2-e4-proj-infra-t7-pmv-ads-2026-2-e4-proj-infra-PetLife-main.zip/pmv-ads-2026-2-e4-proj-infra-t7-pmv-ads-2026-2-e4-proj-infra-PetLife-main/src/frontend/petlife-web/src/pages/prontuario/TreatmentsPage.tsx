import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import ProntuarioLayout from "../../components/layout/ProntuarioLayout";
import TreatmentCard from "../../components/prontuario/TreatmentCard";
import TreatmentFormModal from "../../components/prontuario/TreatmentFormModal";
import SiteFooter from "../../components/layout/SiteFooter";
import { getPet } from "../../services/petService";
import {
  deleteTreatment,
  fetchTreatmentsByPet,
  type TreatmentView,
} from "../../services/treatmentService";
import type { Pet } from "../../types";
import styles from "./TreatmentsPage.module.css";

function formatPetSummary(pet: Pet): string {
  return [pet.nome, pet.especie, pet.raca]
    .filter((part): part is string => Boolean(part?.trim()))
    .join(" • ");
}

export default function TreatmentsPage() {
  const { petId = "pet-1" } = useParams<{ petId: string }>();
  const location = useLocation();
  const { user } = useAuth();
  const [treatments, setTreatments] = useState<TreatmentView[]>([]);
  const [petSummary, setPetSummary] = useState("Lulu • Gato • Vira-lata");
  const [petName, setPetName] = useState("Lulu");
  const [petPhoto, setPetPhoto] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTreatment, setEditingTreatment] = useState<TreatmentView | null>(null);


  const isVet =
    location.pathname.startsWith("/vet") || user?.role === "Veterinário";

  useEffect(() => {
    if (!petId) return;

    let isMounted = true;
    setLoading(true);
    setError(null);

    Promise.all([fetchTreatmentsByPet(petId), getPet(petId).catch(() => null)])
      .then(([data, pet]) => {
        if (!isMounted) return;
        setTreatments(data);
        if (pet) {
          setPetSummary(formatPetSummary(pet));
          setPetName(pet.nome);
          setPetPhoto(pet.foto_url ?? null);
        }
      })
      .catch(() => {
        if (isMounted) {
          setTreatments([]);
          setError("Não foi possível carregar os tratamentos do pet.");
        }
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [petId]);

  
  const handleSaved = (savedTreatment: TreatmentView) => {
   setTreatments((current) => {
     const exists = current.some((item) => item.id === savedTreatment.id);
     if (exists) {
       return current.map((item) => (item.id === savedTreatment.id ? savedTreatment : item));
     }
     return [savedTreatment, ...current];
   });
 };

  const handleDelete = async (treatment: TreatmentView) => {
    try {
      await deleteTreatment(treatment.id);
      setTreatments((current) =>
        current.filter((item) => item.id !== treatment.id),
      );
    } catch {
      setError("Não foi possível excluir o tratamento. Tente novamente.");
    }
  };

  return (
    <ProntuarioLayout
      title="Tratamentos"
      icon="💊"
      activeTab="tratamentos"
      petSummary={petSummary}
      petPhoto={petPhoto}
      fullWidth
    >
      <div className={styles.sectionHeader}>
        <h2 className={styles.sectionTitle}>Tratamentos</h2>
        <button
          type="button"
          className={styles.newTreatmentBtn}
          onClick={() => setIsModalOpen(true)}
        >
          + Novo tratamento
        </button>
      </div>

      {loading && <p className={styles.statusMessage}>Carregando...</p>}

      {error && <p className={styles.errorMessage}>{error}</p>}

      {!loading && !error && treatments.length === 0 && (
        <p className={styles.emptyState}>Nenhum tratamento cadastrado.</p>
      )}

      {!loading && !error && treatments.length > 0 && (
        <div className={styles.treatmentsList}>
          {treatments.map((item) => (
            <TreatmentCard
              key={item.id}
              treatment={item}
              onEdit={(treatment) => {
                setEditingTreatment(treatment);
                setIsModalOpen(true);
              }}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      <div className={styles.footerWrapper}>
        <SiteFooter showBrand={false} />
      </div>

      <TreatmentFormModal
        isOpen={isModalOpen}
        onClose={() => {
         setIsModalOpen(false);
         setEditingTreatment(null);
        }}
        onSaved={handleSaved}
        petId={petId}
        petName={petName}
        isVet={isVet}
        vetId={user?.id}
        treatmentToEdit={editingTreatment}
      />
      
    </ProntuarioLayout>
  );
}