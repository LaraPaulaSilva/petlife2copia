import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { AuthContext } from "../../contexts/AuthContext";
import type { Pet, PetDiaryEntry, User } from "../../types";
import DiaryPage from "./DiaryPage";
import { fetchDiaryByPet } from "../../services/diaryService";
import { getPet } from "../../services/petService";

vi.mock("../../services/diaryService", async () => {
  const actual = await vi.importActual<typeof import("../../services/diaryService")>(
    "../../services/diaryService",
  );
  return {
    ...actual,
    fetchDiaryByPet: vi.fn(),
  };
});

vi.mock("../../services/petService", () => ({
  getPet: vi.fn(),
}));

const mockedFetchDiary = vi.mocked(fetchDiaryByPet);
const mockedGetPet = vi.mocked(getPet);

const tutorUser: User = {
  id: "tutor-1",
  name: "Ana Souza",
  email: "ana@petlife.test",
  role: "Tutor",
};

const vetUser: User = {
  id: "vet-1",
  name: "Dr. Carlos",
  email: "carlos@petlife.test",
  role: "Veterinário",
};

const pet: Pet = {
  id: "pet-1",
  nome: "Lulu",
  especie: "Gato",
  raca: "Vira-lata",
  tutor_id: "tutor-1",
};

const entries: PetDiaryEntry[] = [
  {
    id: "diary-1",
    pet_id: "pet-1",
    perfil_autor: "tutor",
    data_registro: "2026-09-28T00:00:00.000Z",
    tags: ["recuperado"],
    Registro: "Já está bem e sem febre hoje. Comendo normalmente.",
  },
  {
    id: "diary-2",
    pet_id: "pet-1",
    perfil_autor: "tutor",
    data_registro: "2026-09-27T00:00:00.000Z",
    tags: ["vacina", "febre"],
    Registro: "Lulu apresentou leve febre após a vacinação. Observando ao longo do dia.",
  },
];

function renderDiary(
  path = "/tutor/pets/pet-1/diario",
  user: User = tutorUser,
) {
  return render(
    <AuthContext.Provider
      value={{
        user,
        setUser: vi.fn(),
        login: vi.fn(),
        logout: vi.fn(),
      }}
    >
      <MemoryRouter initialEntries={[path]}>
        <Routes>
          <Route path="/tutor/pets/:petId/diario" element={<DiaryPage />} />
          <Route path="/vet/pacientes/:petId/diario" element={<DiaryPage />} />
        </Routes>
      </MemoryRouter>
    </AuthContext.Provider>,
  );
}

describe("DiaryPage", () => {
  beforeEach(() => {
    mockedFetchDiary.mockReset();
    mockedGetPet.mockReset();
    mockedGetPet.mockResolvedValue(pet);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("exibe os registros com data, texto e tags", async () => {
    mockedFetchDiary.mockResolvedValue(entries);
    renderDiary();

    await waitFor(() => {
      expect(
        screen.getByText("Já está bem e sem febre hoje. Comendo normalmente."),
      ).toBeInTheDocument();
    });

    expect(screen.getByText("28/09/2026")).toBeInTheDocument();
    expect(screen.getByText("27/09/2026")).toBeInTheDocument();
    expect(
      screen.getByText(
        "Lulu apresentou leve febre após a vacinação. Observando ao longo do dia.",
      ),
    ).toBeInTheDocument();
    expect(screen.getByText("recuperado")).toBeInTheDocument();
    expect(screen.getByText("vacina")).toBeInTheDocument();
    expect(screen.getByText("febre")).toBeInTheDocument();
    expect(screen.getByText("Lulu • Gato • Vira-lata")).toBeInTheDocument();
    expect(mockedFetchDiary).toHaveBeenCalledWith("pet-1");
  });

  it("mostra o link para criar um novo registro", async () => {
    mockedFetchDiary.mockResolvedValue(entries);
    renderDiary();

    await waitFor(() => {
      expect(screen.getByText("recuperado")).toBeInTheDocument();
    });

    const newLink = screen.getByRole("link", { name: "+ Novo registro" });
    expect(newLink).toHaveAttribute("href", "/tutor/pets/pet-1/diario/novo");
  });

  it("mostra estado vazio quando o pet ainda não tem registros", async () => {
    mockedFetchDiary.mockResolvedValue([]);
    renderDiary();

    await waitFor(() => {
      expect(screen.getByText("Nenhum registro no diário.")).toBeInTheDocument();
    });

    expect(screen.queryByText("recuperado")).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "+ Novo registro" })).toBeInTheDocument();
  });

  it("mostra erro quando a listagem falha", async () => {
    mockedFetchDiary.mockRejectedValue(new Error("falha na api"));
    renderDiary();

    await waitFor(() => {
      expect(
        screen.getByText("Não foi possível carregar o diário do pet."),
      ).toBeInTheDocument();
    });

    expect(screen.queryByText("Nenhum registro no diário.")).not.toBeInTheDocument();
    expect(screen.queryByText("recuperado")).not.toBeInTheDocument();
  });

  it("esconde o botão de novo registro na visão do veterinário", async () => {
    mockedFetchDiary.mockResolvedValue(entries);
    renderDiary("/vet/pacientes/pet-1/diario", vetUser);

    await waitFor(() => {
      expect(screen.getByText("recuperado")).toBeInTheDocument();
    });

    expect(screen.queryByRole("link", { name: "+ Novo registro" })).not.toBeInTheDocument();
  });
});
