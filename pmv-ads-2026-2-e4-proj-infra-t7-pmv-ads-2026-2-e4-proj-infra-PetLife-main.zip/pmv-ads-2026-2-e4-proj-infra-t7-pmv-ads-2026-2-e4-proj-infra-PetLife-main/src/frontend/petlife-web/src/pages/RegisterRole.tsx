import { useState } from "react";
import { Heart, Stethoscope } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import api, { baseURL } from "../api/client";
import { Navigate, useNavigate } from "react-router-dom";
import { getApiErrorMessage } from "../utils/apiError";
import styles from "./RegisterRole.module.css";

const RegisterRole = () => {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const hasPickedRole = localStorage.getItem("hasPickedRole");
  const parsedHasPickedRole: boolean = hasPickedRole === "true";

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const submitter = (event.nativeEvent as SubmitEvent)
      .submitter as HTMLButtonElement | null;
    const role = submitter?.value;

    setError(null);
    try {
      const response = await api.post(
        `${baseURL}/api/users/registerrole`,
        role,
      );
      localStorage.setItem("hasPickedRole", JSON.stringify(true));
      if (role === "Veterinário") {
        login(response.data.user, response.data.token);
      }
      const url = role === "Veterinário" ? "/vet" : "/tutor";
      navigate(url, { replace: true });
    } catch (err) {
      setError(
        getApiErrorMessage(err, "Não foi possível salvar o perfil. Tente novamente."),
      );
    }
  };

  if (parsedHasPickedRole) {
    const url = user?.role === "Veterinário" ? "/vet" : "/tutor";
    return <Navigate to={url} />;
  }

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        {user?.name && (
          <p className={styles.greeting}>Olá, {user.name}</p>
        )}
        <h1 className={styles.title}>Qual é o seu perfil?</h1>
        <p className={styles.subtitle}>
          Selecione como você vai usar o PetLife
        </p>

        <form onSubmit={handleSubmit}>
          <div className={styles.options}>
            <button
              className={styles.optionCard}
              name="action"
              type="submit"
              value="Tutor"
            >
              <span className={`${styles.optionIcon} ${styles.optionIconTutor}`}>
                <Heart size={28} />
              </span>
              <span className={styles.optionTitle}>Sou tutor</span>
              <span className={styles.optionDesc}>
                Gerencie a saúde e rotina dos seus pets
              </span>
            </button>

            <button
              className={styles.optionCard}
              name="action"
              type="submit"
              value="Veterinário"
            >
              <span className={`${styles.optionIcon} ${styles.optionIconVet}`}>
                <Stethoscope size={28} />
              </span>
              <span className={styles.optionTitle}>Sou veterinário</span>
              <span className={styles.optionDesc}>
                Acompanhe e cuide dos seus pacientes
              </span>
            </button>
          </div>

          {error && <p className={styles.errorMsg}>{error}</p>}
        </form>
      </div>
    </div>
  );
};

export default RegisterRole;
