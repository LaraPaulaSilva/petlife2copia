import type { Page } from "@playwright/test";

export const TUTOR = {
  id: "tutor-1",
  name: "Ana Souza",
  email: "ana@petlife.test",
  role: "Tutor",
};

const JSON_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
};

export async function mockTutorSession(page: Page) {
  await page.addInitScript(() => {
    localStorage.setItem("petlife_token", "e2e-token");
    localStorage.setItem("hasPickedRole", "true");
  });

  await page.route("**/api/users/me", async (route) => {
    if (route.request().method() === "OPTIONS") {
      await route.fulfill({
        status: 204,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET,OPTIONS",
          "Access-Control-Allow-Headers": "*",
        },
      });
      return;
    }

    await route.fulfill({
      status: 200,
      headers: JSON_HEADERS,
      body: JSON.stringify(TUTOR),
    });
  });
}
