import type { Page } from "@playwright/test";

export interface MockDiaryEntry {
  id: string;
  pet_id: string;
  usuario_id?: string | null;
  perfil_autor: string;
  data_registro: string;
  tags: string[];
  Registro: string;
  suspeita?: string | null;
  criado_at?: string;
}

const JSON_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
};

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "*",
};

export function sampleDiaryEntry(
  overrides: Partial<MockDiaryEntry> = {},
): MockDiaryEntry {
  return {
    id: "diary-1",
    pet_id: "pet-1",
    usuario_id: "tutor-1",
    perfil_autor: "tutor",
    data_registro: "2026-09-27T00:00:00.000Z",
    tags: ["vacina", "febre"],
    Registro:
      "Lulu apresentou leve febre após a vacinação. Observando ao longo do dia.",
    ...overrides,
  };
}

export async function mockDiaryApi(
  page: Page,
  initialEntries: MockDiaryEntry[] = [],
  options: { listError?: boolean } = {},
) {
  const entries: MockDiaryEntry[] = [...initialEntries];
  let seq = entries.length + 1;

  await page.route("**/api/pet-diary**", async (route) => {
    const request = route.request();
    const method = request.method();

    if (method === "OPTIONS") {
      await route.fulfill({ status: 204, headers: CORS_HEADERS });
      return;
    }

    const url = new URL(request.url());
    const petId = url.searchParams.get("pet_id") ?? url.searchParams.get("petId");

    if (method === "GET") {
      if (options.listError) {
        await route.fulfill({
          status: 500,
          headers: JSON_HEADERS,
          body: JSON.stringify({ Message: "erro" }),
        });
        return;
      }

      const filtered = petId
        ? entries.filter((entry) => entry.pet_id === petId)
        : entries;
      const ordered = [...filtered].sort((a, b) =>
        b.data_registro.localeCompare(a.data_registro),
      );

      await route.fulfill({
        status: 200,
        headers: JSON_HEADERS,
        body: JSON.stringify(ordered),
      });
      return;
    }

    if (method === "POST") {
      const body = request.postDataJSON() as Partial<MockDiaryEntry>;
      const created: MockDiaryEntry = {
        id: `diary-${seq++}`,
        pet_id: body.pet_id ?? "pet-1",
        usuario_id: "tutor-1",
        perfil_autor: "tutor",
        data_registro: body.data_registro ?? "",
        tags: body.tags ?? [],
        Registro: body.Registro ?? "",
        suspeita: body.suspeita ?? null,
        criado_at: new Date().toISOString(),
      };
      entries.unshift(created);
      await route.fulfill({
        status: 201,
        headers: JSON_HEADERS,
        body: JSON.stringify(created),
      });
      return;
    }

    await route.fulfill({
      status: 404,
      headers: JSON_HEADERS,
      body: JSON.stringify({ Message: "Não encontrado." }),
    });
  });
}
