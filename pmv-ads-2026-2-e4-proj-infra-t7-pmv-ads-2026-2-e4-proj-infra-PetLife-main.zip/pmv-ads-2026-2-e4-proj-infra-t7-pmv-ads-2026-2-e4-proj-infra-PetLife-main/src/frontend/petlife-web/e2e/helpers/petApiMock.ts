import type { Page } from "@playwright/test";

export interface MockPet {
  id: string;
  nome: string;
  especie: string;
  raca?: string | null;
  peso_kg?: number | null;
  data_nascimento?: string | null;
  microchip?: string | null;
  foto_url?: string | null;
  tutor_id: string;
  criado_at?: string;
}

const JSON_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
};

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "*",
};

export function samplePet(overrides: Partial<MockPet> = {}): MockPet {
  return {
    id: "pet-1",
    nome: "Lulu",
    especie: "Gato",
    raca: "Vira-lata",
    peso_kg: 4.2,
    data_nascimento: "2024-01-10",
    microchip: "123",
    tutor_id: "tutor-1",
    ...overrides,
  };
}

export async function mockPetApi(
  page: Page,
  initialPets: MockPet[] = [],
  options: { listError?: boolean } = {},
) {
  const pets: MockPet[] = [...initialPets];
  let seq = pets.length + 1;

  await page.route("**/api/pets**", async (route) => {
    const request = route.request();
    const method = request.method();

    if (method === "OPTIONS") {
      await route.fulfill({ status: 204, headers: CORS_HEADERS });
      return;
    }

    const url = new URL(request.url());
    const parts = url.pathname.split("/").filter(Boolean);
    const id = parts[2];

    if (method === "GET" && !id) {
      if (options.listError) {
        await route.fulfill({
          status: 500,
          headers: JSON_HEADERS,
          body: JSON.stringify({ Message: "erro" }),
        });
        return;
      }

      await route.fulfill({
        status: 200,
        headers: JSON_HEADERS,
        body: JSON.stringify(pets),
      });
      return;
    }

    if (method === "GET" && id) {
      const pet = pets.find((item) => item.id === id);
      if (!pet) {
        await route.fulfill({
          status: 404,
          headers: JSON_HEADERS,
          body: JSON.stringify({ Message: "Pet não encontrado." }),
        });
        return;
      }

      await route.fulfill({
        status: 200,
        headers: JSON_HEADERS,
        body: JSON.stringify(pet),
      });
      return;
    }

    if (method === "POST" && !id) {
      const body = request.postDataJSON() as Partial<MockPet>;
      const created: MockPet = {
        id: `pet-${seq++}`,
        tutor_id: "tutor-1",
        nome: body.nome ?? "",
        especie: body.especie ?? "",
        raca: body.raca ?? null,
        peso_kg: body.peso_kg ?? null,
        data_nascimento: body.data_nascimento ?? null,
        microchip: body.microchip ?? null,
        foto_url: body.foto_url ?? null,
      };
      pets.push(created);
      await route.fulfill({
        status: 201,
        headers: JSON_HEADERS,
        body: JSON.stringify(created),
      });
      return;
    }

    if (method === "PUT" && id) {
      const index = pets.findIndex((item) => item.id === id);
      if (index < 0) {
        await route.fulfill({
          status: 404,
          headers: JSON_HEADERS,
          body: JSON.stringify({ Message: "Pet não encontrado." }),
        });
        return;
      }

      const body = request.postDataJSON() as Partial<MockPet>;
      pets[index] = { ...pets[index], ...body };
      await route.fulfill({
        status: 200,
        headers: JSON_HEADERS,
        body: JSON.stringify(pets[index]),
      });
      return;
    }

    if (method === "DELETE" && id) {
      const index = pets.findIndex((item) => item.id === id);
      if (index < 0) {
        await route.fulfill({
          status: 404,
          headers: JSON_HEADERS,
          body: JSON.stringify({ Message: "Pet não encontrado." }),
        });
        return;
      }

      pets.splice(index, 1);
      await route.fulfill({ status: 204, headers: CORS_HEADERS });
      return;
    }

    await route.fulfill({
      status: 404,
      headers: JSON_HEADERS,
      body: JSON.stringify({ Message: "Não encontrado." }),
    });
  });
}
