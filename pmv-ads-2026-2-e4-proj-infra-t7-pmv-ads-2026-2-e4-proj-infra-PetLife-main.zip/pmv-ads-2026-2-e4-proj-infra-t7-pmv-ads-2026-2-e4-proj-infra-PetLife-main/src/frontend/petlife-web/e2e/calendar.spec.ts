import { test, expect, type Page } from "@playwright/test";

const hoje = new Date();
const dia15 = new Date(hoje.getFullYear(), hoje.getMonth(), 15, 12, 0).toISOString();

const nomesMeses = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
];

const pets = [{ id: "pet-1", nome: "Belinha", especie: "Cachorro" }];

const usuario = {
  id: "user-1",
  name: "Ana Souza",
  email: "ana@petlife.com",
  role: "Tutor",
};

async function prepararPagina(page: Page) {
  let eventos = [
    {
      id: "evento-1",
      userId: "user-1",
      petId: "pet-1",
      tipo: "vacina",
      dataHora: dia15,
      observacoes: "teste",
      status: "agendado",
    },
  ];

  await page.addInitScript((u) => {
    localStorage.setItem("petlife_token", "token-de-teste");
    localStorage.setItem("petlife_user", JSON.stringify(u));
  }, usuario);

  await page.route("**/api/users/me", (route) =>
    route.fulfill({ json: usuario })
  );

  await page.route("**/api/pets", (route) =>
    route.fulfill({ json: pets })
  );

  await page.route("**/api/EventosRotina/usuario/**", (route) =>
    route.fulfill({ json: eventos })
  );

  await page.route("**/api/EventosRotina/evento-1", (route) => {
    const metodo = route.request().method();

    if (metodo === "DELETE") {
      eventos = [];
      return route.fulfill({ json: { Message: "Evento apagado." } });
    }

    if (metodo === "PUT") {
      const dados = route.request().postDataJSON();
      eventos = eventos.map((e) =>
        e.id === "evento-1" ? { ...e, ...dados, id: "evento-1" } : e
      );
      return route.fulfill({ json: eventos[0] });
    }

    return route.continue();
  });

  await page.route("**/api/EventosRotina", (route) => {
    if (route.request().method() === "POST") {
      const dados = route.request().postDataJSON();
      const novo = { ...dados, id: "evento-" + (eventos.length + 1) };
      eventos = [...eventos, novo];
      return route.fulfill({ json: novo });
    }
    return route.continue();
  });
}

test.describe("Calendário", () => {
  test("mostra o título, o mês atual e o evento", async ({ page }) => {
    await prepararPagina(page);
    await page.goto("/tutor/calendario");

    await expect(page.getByRole("heading", { name: "Calendário" })).toBeVisible();
    await expect(
      page.getByText(`${nomesMeses[hoje.getMonth()]} ${hoje.getFullYear()}`)
    ).toBeVisible();
    await expect(page.getByText("Vacina Belinha")).toBeVisible();
  });

  test("troca de mês com a seta", async ({ page }) => {
    await prepararPagina(page);
    await page.goto("/tutor/calendario");

    await page.getByLabel("Próximo mês").click();

    const proximo = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 1);
    await expect(
      page.getByText(`${nomesMeses[proximo.getMonth()]} ${proximo.getFullYear()}`)
    ).toBeVisible();
  });

  test("cria um novo evento", async ({ page }) => {
    await prepararPagina(page);
    await page.goto("/tutor/calendario");
    await expect(page.getByText("Vacina Belinha")).toBeVisible();

    await page.getByRole("button", { name: /novo evento/i }).click();
    await expect(page.getByRole("heading", { name: "Novo evento" })).toBeVisible();

    await page.getByLabel("Tipo").selectOption("tosa");

    const dia20 = new Date(hoje.getFullYear(), hoje.getMonth(), 20);
    const p = (n: number) => String(n).padStart(2, "0");
    await page
      .getByLabel("Data do evento")
      .fill(`${dia20.getFullYear()}-${p(dia20.getMonth() + 1)}-${p(dia20.getDate())}`);
    await page.getByLabel("Horário do evento").fill("10:00");

    await page.getByRole("button", { name: "Salvar", exact: true }).click();

    await expect(page.getByText("Tosa Belinha")).toBeVisible();
  });

  test("edita um evento", async ({ page }) => {
    await prepararPagina(page);
    await page.goto("/tutor/calendario");

    await page.getByText("Vacina Belinha").click();
    await expect(page.getByRole("heading", { name: "Editar evento" })).toBeVisible();

    await page.getByLabel("Tipo").selectOption("tosa");
    await page.getByRole("button", { name: "Salvar alterações" }).click();

    await expect(page.getByText("Tosa Belinha")).toBeVisible();
    await expect(page.getByText("Vacina Belinha")).toHaveCount(0);
  });

  test("apaga um evento depois de confirmar", async ({ page }) => {
    await prepararPagina(page);
    await page.goto("/tutor/calendario");

    await page.getByText("Vacina Belinha").click();
    await expect(page.getByRole("heading", { name: "Editar evento" })).toBeVisible();

    await page.getByRole("button", { name: "Apagar", exact: true }).click();
    await expect(page.getByText("Apagar evento?")).toBeVisible();

    await page.getByRole("button", { name: "Sim, apagar" }).click();

    await expect(page.getByText("Vacina Belinha")).toHaveCount(0);
  });
});