import { test, expect } from "@playwright/test";
import { mockTutorSession } from "./helpers/tutorSession";
import { mockPetApi, samplePet } from "./helpers/petApiMock";

async function openMyPets(page: Parameters<typeof mockTutorSession>[0]) {
  await mockTutorSession(page);
}

test.describe("Gestão de pets (E2E)", () => {
  test("fluxo completo: vazio, cadastrar, editar e excluir", async ({ page }) => {
    await openMyPets(page);
    await mockPetApi(page, []);
    await page.goto("/tutor/pets");

    await expect(page.getByRole("heading", { name: "Meus Pets" })).toBeVisible();
    await expect(page.getByText("Você ainda não cadastrou nenhum pet.")).toBeVisible();
    await expect(page.getByRole("link", { name: "+ Adicionar pet" }).first()).toBeVisible();

    await page.getByRole("link", { name: "+ Adicionar pet" }).first().click();
    await expect(page).toHaveURL(/\/tutor\/pets\/novo/);
    await expect(page.getByRole("heading", { name: "Adicionar Pet" })).toBeVisible();

    await page.getByLabel("Nome").fill("Lulu");
    await page.getByLabel("Espécie").selectOption("Gato");
    await page.getByLabel("Raça").fill("Vira-lata");
    await page.getByRole("button", { name: "Salvar pet" }).click();

    await expect(page).toHaveURL(/\/tutor\/pets$/);
    await expect(page.getByRole("heading", { name: "Lulu" })).toBeVisible();
    await expect(page.getByText("Gato • Vira-lata")).toBeVisible();

    await page.getByRole("link", { name: "Editar" }).click();
    await expect(page).toHaveURL(/\/tutor\/pets\/.+\/editar/);
    await expect(page.getByRole("heading", { name: "Editar Pet" })).toBeVisible();
    await expect(page.getByLabel("Nome")).toHaveValue("Lulu");

    await page.getByLabel("Nome").fill("Mel");
    await page.getByRole("button", { name: "Salvar pet" }).click();

    await expect(page).toHaveURL(/\/tutor\/pets$/);
    await expect(page.getByRole("heading", { name: "Mel" })).toBeVisible();
    await expect(page.getByRole("heading", { name: "Lulu" })).toHaveCount(0);

    page.once("dialog", (dialog) => dialog.accept());
    await page.getByRole("button", { name: "Excluir" }).click();

    await expect(page.getByRole("heading", { name: "Mel" })).toHaveCount(0);
    await expect(page.getByText("Você ainda não cadastrou nenhum pet.")).toBeVisible();
  });

  test("lista pets já cadastrados com ações de prontuário, editar e excluir", async ({ page }) => {
    await openMyPets(page);
    await mockPetApi(page, [
      samplePet(),
      samplePet({
        id: "pet-2",
        nome: "Rex",
        especie: "Cão",
        raca: "Golden",
        data_nascimento: "2022-03-01",
      }),
    ]);
    await page.goto("/tutor/pets");

    await expect(page.getByRole("heading", { name: "Lulu" })).toBeVisible();
    await expect(page.getByText("Gato • Vira-lata • 2 anos")).toBeVisible();
    await expect(page.getByRole("heading", { name: "Rex" })).toBeVisible();
    await expect(page.getByText("Cão • Golden • 4 anos")).toBeVisible();

    await expect(page.getByRole("link", { name: "Ver prontuário" })).toHaveCount(2);
    await expect(page.getByRole("link", { name: "Editar" })).toHaveCount(2);
    await expect(page.getByRole("button", { name: "Excluir" })).toHaveCount(2);
  });

  test("abre o prontuário a partir do card", async ({ page }) => {
    await openMyPets(page);
    await mockPetApi(page, [samplePet()]);
    await page.route("**/api/treatments**", async (route) => {
      await route.fulfill({
        status: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: "[]",
      });
    });
    await page.goto("/tutor/pets");

    await page.getByRole("link", { name: "Ver prontuário" }).click();
    await expect(page).toHaveURL(/\/tutor\/pets\/pet-1\/tratamentos/);
    await expect(page.getByRole("heading", { name: "Tratamentos" }).first()).toBeVisible();
  });

  test("bloqueia o cadastro sem nome ou espécie", async ({ page }) => {
    await openMyPets(page);
    await mockPetApi(page, []);
    await page.goto("/tutor/pets/novo");

    await page.getByRole("button", { name: "Salvar pet" }).click();
    await expect(page.getByText("Preencha o nome e a espécie do pet.")).toBeVisible();
    await expect(page).toHaveURL(/\/tutor\/pets\/novo/);
  });

  test("volta para a listagem ao cancelar o cadastro", async ({ page }) => {
    await openMyPets(page);
    await mockPetApi(page, []);
    await page.goto("/tutor/pets/novo");

    await page.getByLabel("Nome").fill("Lulu");
    await page.getByRole("button", { name: "Cancelar" }).click();

    await expect(page).toHaveURL(/\/tutor\/pets$/);
    await expect(page.getByText("Você ainda não cadastrou nenhum pet.")).toBeVisible();
  });

  test("mantém o pet quando a exclusão é cancelada", async ({ page }) => {
    await openMyPets(page);
    await mockPetApi(page, [samplePet()]);
    await page.goto("/tutor/pets");

    await expect(page.getByRole("heading", { name: "Lulu" })).toBeVisible();

    page.once("dialog", (dialog) => dialog.dismiss());
    await page.getByRole("button", { name: "Excluir" }).click();

    await expect(page.getByRole("heading", { name: "Lulu" })).toBeVisible();
  });

  test("mostra erro quando a listagem falha", async ({ page }) => {
    await openMyPets(page);
    await mockPetApi(page, [], { listError: true });
    await page.goto("/tutor/pets");

    await expect(page.getByText("Não foi possível carregar seus pets.")).toBeVisible();
    await expect(page.getByText("Você ainda não cadastrou nenhum pet.")).toHaveCount(0);
  });

  test("destaca Meus Pets no menu da listagem", async ({ page }) => {
    await openMyPets(page);
    await mockPetApi(page, []);
    await page.goto("/tutor/pets");

    const meusPets = page
      .getByRole("navigation", { name: "Menu principal" })
      .getByRole("link", { name: "Meus Pets" });

    await expect(meusPets).toBeVisible();
    await expect(meusPets).toHaveClass(/active/);
  });
});
