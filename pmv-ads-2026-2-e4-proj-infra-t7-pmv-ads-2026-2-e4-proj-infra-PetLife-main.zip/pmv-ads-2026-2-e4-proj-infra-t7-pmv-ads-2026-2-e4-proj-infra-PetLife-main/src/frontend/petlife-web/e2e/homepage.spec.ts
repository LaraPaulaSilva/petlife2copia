import { test, expect } from "@playwright/test";

test.beforeEach(async ({ page }) => {
  await page.goto("/");
});

test.describe("HomePage (E2E)", () => {
  test("carrega a página com o título PetLife", async ({ page }) => {
    await expect(page).toHaveTitle(/PetLife/);
  });

  test("exibe o título principal do hero", async ({ page }) => {
    await expect(
      page.getByRole("heading", { name: /Toda a saúde do seu pet/i }),
    ).toBeVisible();
  });

  test("exibe os links de ação principais", async ({ page }) => {
    await expect(
      page.getByRole("link", { name: "Entrar" }),
    ).toBeVisible();
    await expect(
      page.getByRole("link", { name: /Criar conta grátis/i }).first(),
    ).toBeVisible();
  });

  test("exibe as seções principais da landing", async ({ page }) => {
    await expect(
      page.getByRole("heading", { name: "Tudo o que seu pet precisa" }),
    ).toBeVisible();
    await expect(
      page.getByRole("heading", { name: "Quem já usa, aprova" }),
    ).toBeVisible();
    await expect(
      page.getByRole("heading", {
        name: "Comece a cuidar melhor do seu pet hoje",
      }),
    ).toBeVisible();
  });

  test("exibe os 4 cards de funcionalidades", async ({ page }) => {
    await expect(
      page.getByRole("heading", { name: "Prontuário completo" }),
    ).toBeVisible();
    await expect(
      page.getByRole("heading", { name: "Carteira de vacinação digital" }),
    ).toBeVisible();
    await expect(
      page.getByRole("heading", { name: "Lembretes e alertas" }),
    ).toBeVisible();
    await expect(
      page.getByRole("heading", { name: "Diário do pet" }),
    ).toBeVisible();
  });

  test("exibe os depoimentos dos usuários", async ({ page }) => {
    await expect(page.getByText("Juliana Martins")).toBeVisible();
    await expect(page.getByText("Dr. Rafael Souza")).toBeVisible();
    await expect(page.getByText("Camila Ribeiro")).toBeVisible();
  });

  test("carrega a imagem do hero", async ({ page }) => {
    const heroImg = page.getByAltText(
      "Veterinária usando o PetLife ao lado de um golden retriever",
    );
    await expect(heroImg).toBeVisible();
  });

  test("navega para a seção de funcionalidades pelo menu", async ({
    page,
  }) => {
    await page.getByRole("link", { name: "Funcionalidades" }).first().click();
    await expect(page).toHaveURL(/#funcionalidades/);
  });
});
