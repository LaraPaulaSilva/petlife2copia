import { test, expect } from "@playwright/test";
import { mockTutorSession } from "./helpers/tutorSession";
import { mockPetApi, samplePet } from "./helpers/petApiMock";
import { mockDiaryApi, sampleDiaryEntry } from "./helpers/diaryApiMock";

const DIARY_PATH = "/tutor/pets/pet-1/diario";

async function openDiary(
  page: Parameters<typeof mockTutorSession>[0],
  entries: Parameters<typeof mockDiaryApi>[1] = [],
  options: Parameters<typeof mockDiaryApi>[2] = {},
) {
  await mockTutorSession(page);
  await mockPetApi(page, [samplePet()]);
  await mockDiaryApi(page, entries, options);
}

test.describe("Diário do pet (E2E)", () => {
  test("fluxo completo: vazio, cadastrar e ver na lista", async ({ page }) => {
    await openDiary(page, []);
    await page.goto(DIARY_PATH);

    await expect(page.getByRole("heading", { name: "Diário", exact: true })).toBeVisible();
    await expect(page.getByText("Lulu • Gato • Vira-lata")).toBeVisible();
    await expect(page.getByRole("heading", { name: "Diário do Pet" })).toBeVisible();
    await expect(page.getByText("Nenhum registro no diário.")).toBeVisible();

    await page.getByRole("link", { name: "+ Novo registro" }).click();
    await expect(page).toHaveURL(/\/tutor\/pets\/pet-1\/diario\/novo/);
    await expect(page.getByRole("heading", { name: "Novo registro" })).toBeVisible();
    await expect(page.getByText("Pet: Lulu")).toBeVisible();

    await page.getByLabel("Data").fill("2026-09-27");
    await page
      .getByLabel("Registro")
      .fill("Lulu apresentou leve febre após a vacinação. Observando ao longo do dia.");
    await page.getByLabel("Tags").fill("vacina, febre");
    await page.getByRole("button", { name: "Salvar registro" }).click();

    await expect(page).toHaveURL(/\/tutor\/pets\/pet-1\/diario$/);
    await expect(page.getByText("Nenhum registro no diário.")).toHaveCount(0);
    await expect(page.getByText("27/09/2026")).toBeVisible();
    await expect(
      page.getByText(
        "Lulu apresentou leve febre após a vacinação. Observando ao longo do dia.",
      ),
    ).toBeVisible();
    await expect(page.getByRole("article").getByText("vacina", { exact: true })).toBeVisible();
    await expect(page.getByRole("article").getByText("febre", { exact: true })).toBeVisible();
  });

  test("lista registros já cadastrados com data, texto e tags", async ({ page }) => {
    await openDiary(page, [
      sampleDiaryEntry({
        id: "diary-2",
        data_registro: "2026-09-28T00:00:00.000Z",
        tags: ["recuperado"],
        Registro: "Já está bem e sem febre hoje. Comendo normalmente.",
      }),
      sampleDiaryEntry(),
    ]);
    await page.goto(DIARY_PATH);

    await expect(page.getByText("28/09/2026")).toBeVisible();
    await expect(page.getByText("27/09/2026")).toBeVisible();
    await expect(
      page.getByText("Já está bem e sem febre hoje. Comendo normalmente."),
    ).toBeVisible();
    await expect(
      page.getByText(
        "Lulu apresentou leve febre após a vacinação. Observando ao longo do dia.",
      ),
    ).toBeVisible();
    await expect(page.getByRole("article").getByText("recuperado", { exact: true })).toBeVisible();
    await expect(page.getByRole("article").getByText("vacina", { exact: true })).toBeVisible();
    await expect(page.getByRole("article").getByText("febre", { exact: true })).toBeVisible();
    await expect(page.getByRole("link", { name: "+ Novo registro" })).toBeVisible();
  });

  test("bloqueia o cadastro sem o texto do registro", async ({ page }) => {
    await openDiary(page, []);
    await page.goto(`${DIARY_PATH}/novo`);

    await expect(page.getByRole("heading", { name: "Novo registro" })).toBeVisible();
    await page.getByRole("button", { name: "Salvar registro" }).click();

    await expect(page.getByText("Preencha a data e o texto do registro.")).toBeVisible();
    await expect(page).toHaveURL(/\/tutor\/pets\/pet-1\/diario\/novo/);
  });

  test("volta para a listagem ao cancelar o cadastro", async ({ page }) => {
    await openDiary(page, []);
    await page.goto(`${DIARY_PATH}/novo`);

    await page.getByLabel("Registro").fill("Texto que não deve ser salvo");
    await page.getByRole("button", { name: "Cancelar" }).click();

    await expect(page).toHaveURL(/\/tutor\/pets\/pet-1\/diario$/);
    await expect(page.getByText("Nenhum registro no diário.")).toBeVisible();
  });

  test("mostra erro quando a listagem falha", async ({ page }) => {
    await openDiary(page, [], { listError: true });
    await page.goto(DIARY_PATH);

    await expect(
      page.getByText("Não foi possível carregar o diário do pet."),
    ).toBeVisible();
    await expect(page.getByText("Nenhum registro no diário.")).toHaveCount(0);
  });

  test("destaca Meus Pets e a aba Diário", async ({ page }) => {
    await openDiary(page, []);
    await page.goto(DIARY_PATH);

    const meusPets = page
      .getByRole("navigation", { name: "Menu principal" })
      .getByRole("link", { name: "Meus Pets" });
    const diarioTab = page
      .getByRole("navigation", { name: "Abas do prontuário" })
      .getByRole("link", { name: "Diário" });

    await expect(meusPets).toHaveClass(/active/);
    await expect(diarioTab).toHaveClass(/tabPillActive/);
  });
});
