# e2e/

Testes end-to-end (E2E) com **Playwright**. Cada arquivo testa um fluxo da aplicação
rodando num navegador real.

Convenção: `nome-do-fluxo.spec.ts` (ex: `homepage.spec.ts`, `login.spec.ts`).

Para rodar:

```bash
npm run test:e2e        # roda os testes (sobe o dev server automaticamente)
npm run test:e2e:ui     # interface visual
```

Exemplo mínimo:

```ts
import { test, expect } from "@playwright/test";

test("abre a home", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveTitle(/PetLife/);
});
```
