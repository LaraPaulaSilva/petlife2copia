# 💻 Módulo Frontend (Aplicação Web)

Aplicação web do PetLife, construída em **React + Vite + TypeScript**, que consome a
API do [backend](../../src/backend). O código do projeto fica em [`petlife-web/`](petlife-web).

---

## 🛠️ Stack

- **React 18** + **TypeScript** — interface por componentes, com tipagem.
- **Vite** — servidor de desenvolvimento e build.
- **React Router** — navegação entre páginas.
- **Axios** — consumo da API (com token JWT automático).
- **CSS Modules** — estilos por componente, usando os tokens de design em `src/index.css`.
- **lucide-react** — biblioteca de ícones (a mesma do app mobile, Lucide), para manter
  a identidade visual entre web e mobile.

## 🚀 Como executar

Pré-requisito: **Node.js 18+** (testado com Node 24).

```bash
cd src/frontend/petlife-web
npm install            # instala as dependências (primeira vez)
npm run dev            # sobe o servidor em http://localhost:5173
```

Outros comandos:

```bash
npm run build          # build de produção (gera dist/)
npm run preview        # pré-visualiza o build
npm run lint           # checagem de estilo/qualidade (ESLint)
```

### Configuração da API

A URL da API é lida da variável `VITE_API_URL`. Copie o `.env.example` para `.env`:

```bash
# .env
VITE_API_URL=http://localhost:5210
```

Se não definir, o padrão é `http://localhost:5210` (API local).

## 📁 Estrutura de pastas (`petlife-web/src`)

```
src/
├─ api/          → cliente Axios (client.ts) com baseURL e token JWT
├─ types/        → tipos TypeScript espelhando os models do backend
├─ contexts/     → estado global (AuthContext: usuário logado + token)
├─ routes/       → AppRouter (registre aqui a rota de cada página)
├─ components/   → componentes reutilizáveis (cada um cria os seus)
├─ pages/        → telas da aplicação (cada integrante cria a sua)
├─ index.css     → tokens de design (cores, fonte Nunito, espaçamentos)
├─ test/         → setup dos testes unitários (Vitest)
├─ App.tsx       → raiz (AuthProvider + AppRouter)
└─ main.tsx      → ponto de entrada
```

Os testes **E2E** (Playwright) ficam na pasta `petlife-web/e2e/`.

## 👥 Fluxo de trabalho em equipe

1. Crie sua página em `src/pages/` (ex: `Login.tsx` + `Login.module.css`).
2. Registre a rota em `src/routes/AppRouter.tsx`.
3. Para dados, use o cliente Axios e os tipos:

```tsx
import api from "../api/client";
import type { Pet } from "../types";

const { data } = await api.get<Pet[]>("/api/pets");
```

4. Siga os tokens de cor/estilo de `src/index.css` para manter a identidade visual.

## 🧪 Testes

A estratégia de testes usa duas ferramentas complementares:

- **Vitest + React Testing Library** — testes **unitários/de componente**, rápidos e
  isolados (não precisam da aplicação rodando). Os arquivos ficam ao lado do componente,
  com a extensão `.test.tsx` (ex: `src/pages/HomePage.test.tsx`).
- **Playwright** — testes **E2E (ponta a ponta)**, que abrem um navegador real e navegam
  pela aplicação como um usuário. Ficam na pasta `e2e/` (ex: `e2e/homepage.spec.ts`).

### Comandos

```bash
# Testes unitários (Vitest)
npm run test            # modo watch (re-roda ao salvar)
npm run test:run        # roda uma vez e encerra
npm run test:coverage   # roda com relatório de cobertura

# Testes E2E (Playwright) — sobe o dev server automaticamente
npm run test:e2e        # roda os testes E2E
npm run test:e2e:ui     # abre a interface visual do Playwright
```

Na primeira vez, instale os navegadores do Playwright:

```bash
npx playwright install chromium
```

### Convenção para o time

- Teste de componente/página → crie `NomeDaPagina.test.tsx` ao lado do componente.
- Teste de fluxo E2E → crie `nome-do-fluxo.spec.ts` na pasta `e2e/`.
