using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface IReportService {
        Task<IEnumerable<Report>> GetByUserIdAsync(string userId);
        Task<Report> CreateAsync(Report report);
        Task<Report?> UpdateAsync(string id, Report report);
        Task<bool> DeleteAsync(string id);
    }
}