using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface ITokenService
    {
        string GenerateToken(User user, string role);
        DateTime GetExpirationDate();
    }
}
