using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface INotificacaoService
    {
        Task CriarAsync(string userId, string titulo, string mensagem, string tipo, string? referenciaId);
        Task<IEnumerable<Notificacao>> GetByUserAsync(string userId);
        Task<bool> MarcarComoLidaAsync(string id);
        Task<bool> DeleteAsync(string id);
        Task<ConfiguracaoNotificacao> ObterPreferenciasAsync(string userId);
        Task<ConfiguracaoNotificacao> SalvarPreferenciasAsync(ConfiguracaoNotificacao config);
    }
}