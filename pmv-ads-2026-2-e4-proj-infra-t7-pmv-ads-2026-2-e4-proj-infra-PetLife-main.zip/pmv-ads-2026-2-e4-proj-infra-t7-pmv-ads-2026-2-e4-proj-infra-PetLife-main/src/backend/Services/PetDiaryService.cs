using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class PetDiaryService(ApplicationDbContext context) : IPetDiaryService
    {
        private readonly ApplicationDbContext _context = context;

        public async Task<IEnumerable<PetDiaryEntry>> GetAllAsync(string userId, bool isVeterinario, string? petId = null)
        {
            if (!isVeterinario)
            {
                if (!string.IsNullOrWhiteSpace(petId))
                {
                    await GarantirPetDoTutorAsync(petId, userId);
                }
                else
                {
                    var petIdsDoTutor = await _context.Pets
                        .Where(p => p.TutorId == userId)
                        .Select(p => p.Id)
                        .ToListAsync();

                    var entriesDoTutor = await _context.PetDiaries
                        .Where(d => petIdsDoTutor.Contains(d.PetId))
                        .ToListAsync();

                    return Ordenar(entriesDoTutor);
                }
            }

            var query = _context.PetDiaries.AsQueryable();

            if (!string.IsNullOrWhiteSpace(petId))
            {
                query = query.Where(d => d.PetId == petId);
            }

            var entries = await query.ToListAsync();
            return Ordenar(entries);
        }

        public async Task<PetDiaryEntry?> GetByIdAsync(string id, string userId, bool isVeterinario)
        {
            var entry = await _context.PetDiaries.FirstOrDefaultAsync(d => d.Id == id);
            if (entry == null)
            {
                return null;
            }

            if (!isVeterinario)
            {
                await GarantirPetDoTutorAsync(entry.PetId, userId);
            }

            return entry;
        }

        public async Task<PetDiaryEntry> CreateAsync(CreatePetDiaryDto dto, string userId)
        {
            if (string.IsNullOrWhiteSpace(dto.PetId))
            {
                throw new ArgumentException("O pet_id é obrigatório.", nameof(dto.PetId));
            }

            if (string.IsNullOrWhiteSpace(dto.DataRegistro))
            {
                throw new ArgumentException("A data de registro é obrigatória.", nameof(dto.DataRegistro));
            }

            if (string.IsNullOrWhiteSpace(dto.Registro))
            {
                throw new ArgumentException("O registro/descrição é obrigatório.", nameof(dto.Registro));
            }

            await GarantirPetDoTutorAsync(dto.PetId, userId);

            var tags = dto.Tags?
                .Where(t => !string.IsNullOrWhiteSpace(t))
                .Select(t => t.Trim())
                .Distinct()
                .ToList() ?? new List<string>();

            var entry = new PetDiaryEntry
            {
                Id = Guid.NewGuid().ToString(),
                PetId = dto.PetId.Trim(),
                UsuarioId = userId,
                PerfilAutor = "tutor",
                DataRegistro = dto.DataRegistro.Trim(),
                Tags = tags,
                Registro = dto.Registro.Trim(),
                Suspeita = string.IsNullOrWhiteSpace(dto.Suspeita) ? null : dto.Suspeita.Trim(),
                CriadoAt = dto.CriadoAt ?? DateTime.UtcNow
            };

            _context.PetDiaries.Add(entry);
            await _context.SaveChangesAsync();

            return entry;
        }

        public async Task<PetDiaryEntry?> UpdateAsync(string id, UpdatePetDiaryDto dto, string userId)
        {
            var entry = await _context.PetDiaries.FirstOrDefaultAsync(d => d.Id == id);
            if (entry == null)
            {
                return null;
            }

            await GarantirPetDoTutorAsync(entry.PetId, userId);

            if (dto.DataRegistro != null)
            {
                if (string.IsNullOrWhiteSpace(dto.DataRegistro))
                {
                    throw new ArgumentException("A data de registro não pode ser vazia.", nameof(dto.DataRegistro));
                }
                entry.DataRegistro = dto.DataRegistro.Trim();
            }

            if (dto.Registro != null)
            {
                if (string.IsNullOrWhiteSpace(dto.Registro))
                {
                    throw new ArgumentException("O registro não pode ser vazio.", nameof(dto.Registro));
                }
                entry.Registro = dto.Registro.Trim();
            }

            if (dto.Tags != null)
            {
                entry.Tags = dto.Tags
                    .Where(t => !string.IsNullOrWhiteSpace(t))
                    .Select(t => t.Trim())
                    .Distinct()
                    .ToList();
            }

            if (dto.Suspeita != null)
            {
                entry.Suspeita = string.IsNullOrWhiteSpace(dto.Suspeita) ? null : dto.Suspeita.Trim();
            }

            if (dto.PerfilAutor != null)
            {
                entry.PerfilAutor = string.IsNullOrWhiteSpace(dto.PerfilAutor) ? "tutor" : dto.PerfilAutor.Trim().ToLowerInvariant();
            }

            if (dto.UsuarioId != null)
            {
                entry.UsuarioId = string.IsNullOrWhiteSpace(dto.UsuarioId) ? null : dto.UsuarioId.Trim();
            }

            await _context.SaveChangesAsync();

            return entry;
        }

        public async Task<bool> DeleteAsync(string id, string userId)
        {
            var entry = await _context.PetDiaries.FirstOrDefaultAsync(d => d.Id == id);
            if (entry == null)
            {
                return false;
            }

            await GarantirPetDoTutorAsync(entry.PetId, userId);

            _context.PetDiaries.Remove(entry);
            await _context.SaveChangesAsync();

            return true;
        }

        private async Task GarantirPetDoTutorAsync(string petId, string userId)
        {
            var pet = await _context.Pets.FirstOrDefaultAsync(p => p.Id == petId);
            if (pet == null)
            {
                throw new KeyNotFoundException("Pet não encontrado.");
            }

            if (!string.Equals(pet.TutorId, userId, StringComparison.Ordinal))
            {
                throw new UnauthorizedAccessException("Este pet não pertence ao tutor autenticado.");
            }
        }

        private static IEnumerable<PetDiaryEntry> Ordenar(IEnumerable<PetDiaryEntry> entries)
        {
            return entries
                .OrderByDescending(d => d.DataRegistro)
                .ThenByDescending(d => d.CriadoAt);
        }
    }
}
