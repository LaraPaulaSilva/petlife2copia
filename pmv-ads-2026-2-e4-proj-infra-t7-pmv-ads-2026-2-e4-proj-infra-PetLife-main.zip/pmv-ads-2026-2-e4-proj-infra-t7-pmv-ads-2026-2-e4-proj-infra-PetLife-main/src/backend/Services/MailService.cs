﻿using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Options;
using MimeKit;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class MailService(IOptions<MailSettings> mailSettings) : IMailService
    {
        private readonly MailSettings _mailSettings = mailSettings.Value;
        public async Task SendEmailAsync(string toEmail, string subject, string body, bool isHtml = true)
        {
            var email = new MimeMessage();
            email.From.Add(new MailboxAddress(_mailSettings.SenderName, _mailSettings.SenderEmail));
            email.To.Add(MailboxAddress.Parse(toEmail));
            email.Subject = subject;

            var bodyBuilder = new BodyBuilder();
            if (isHtml)
            {
                bodyBuilder.HtmlBody = body;
            }
            else
            {
                bodyBuilder.TextBody = body;
            }
            email.Body = bodyBuilder.ToMessageBody();

            using var smtp = new SmtpClient();
            try
            {
                await smtp.ConnectAsync(_mailSettings.Server.Trim(), _mailSettings.Port, SecureSocketOptions.StartTls);

                if (!string.IsNullOrEmpty(_mailSettings.Username))
                {
                    await smtp.AuthenticateAsync(_mailSettings.Username, _mailSettings.Password);
                }
                await smtp.SendAsync(email);
            }
            finally
            {
                await smtp.DisconnectAsync(true);
            }
        }
    }
}
