using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class VaccineService(ApplicationDbContext context) : IVaccineService
    {
        private readonly ApplicationDbContext _context = context;

        public async Task<IEnumerable<Vaccine>> GetAllAsync(string? petId = null)
        {
            var query = _context.Vaccines.AsQueryable();

            if (!string.IsNullOrWhiteSpace(petId))
            {
                query = query.Where(v => v.PetId == petId);
            }

            return await query.ToListAsync();
        }

        public async Task<Vaccine?> GetByIdAsync(string id)
        {
            return await _context.Vaccines.FirstOrDefaultAsync(v => v.Id == id);
        }

        public async Task<Vaccine> CreateAsync(CreateVaccineDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.PetId))
            {
                throw new ArgumentException("O pet_id é obrigatório.", nameof(dto.PetId));
            }

            if (string.IsNullOrWhiteSpace(dto.Tipo))
            {
                throw new ArgumentException("O tipo da vacina é obrigatório.", nameof(dto.Tipo));
            }

            if (string.IsNullOrWhiteSpace(dto.DataAplicacao))
            {
                throw new ArgumentException("A data de aplicação é obrigatória.", nameof(dto.DataAplicacao));
            }

            // O pet referenciado precisa existir.
            var petExiste = await _context.Pets.AnyAsync(p => p.Id == dto.PetId);
            if (!petExiste)
            {
                throw new ArgumentException($"Pet com id '{dto.PetId}' não encontrado.", nameof(dto.PetId));
            }

            // Se um veterinário foi informado, ele precisa existir como usuário.
            if (!string.IsNullOrWhiteSpace(dto.VeterinarioId)
                && !await _context.Users.AnyAsync(u => u.Id == dto.VeterinarioId))
            {
                throw new ArgumentException($"Veterinário com id '{dto.VeterinarioId}' não encontrado.", nameof(dto.VeterinarioId));
            }

            var origem = dto.OrigemRegistro ?? OrigemRegistro.VETERINARIO;
            var dataAplicacao = ParseDate(dto.DataAplicacao);

            // O tutor só cadastra vacinas históricas; aplicações a partir de hoje são do veterinário.
            if (origem == OrigemRegistro.TUTOR && dataAplicacao.HasValue
                && dataAplicacao.Value.Date >= DateTime.UtcNow.Date)
            {
                throw new ArgumentException(
                    "O tutor só pode cadastrar registros históricos de vacinação. " +
                    "Aplicações realizadas após a entrada do pet no sistema devem ser registradas pelo veterinário.",
                    nameof(dto.OrigemRegistro));
            }

            // Próxima dose calculada a partir do intervalo de reforço, quando não informada.
            var proximaDose = dto.DataProximaDose;
            if (string.IsNullOrWhiteSpace(proximaDose)
                && dto.IntervaloReforcoDias.HasValue
                && dto.IntervaloReforcoDias.Value > 0
                && dataAplicacao.HasValue)
            {
                proximaDose = dataAplicacao.Value.Date
                    .AddDays(dto.IntervaloReforcoDias.Value)
                    .ToString("yyyy-MM-dd");
            }

            var vaccine = new Vaccine
            {
                Id = Guid.NewGuid().ToString(),
                PetId = dto.PetId,
                VeterinarioId = origem == OrigemRegistro.TUTOR || string.IsNullOrWhiteSpace(dto.VeterinarioId) ? null : dto.VeterinarioId,
                Tipo = dto.Tipo.Trim(),
                DataAplicacao = dto.DataAplicacao,
                DataProximaDose = proximaDose,
                ComprovanteUrl = dto.ComprovanteUrl,
                Lote = string.IsNullOrWhiteSpace(dto.Lote) ? null : dto.Lote.Trim(),
                Fabricante = string.IsNullOrWhiteSpace(dto.Fabricante) ? null : dto.Fabricante.Trim(),
                Laboratorio = string.IsNullOrWhiteSpace(dto.Laboratorio) ? null : dto.Laboratorio.Trim(),
                Dose = string.IsNullOrWhiteSpace(dto.Dose) ? null : dto.Dose.Trim(),
                ViaAdministracao = string.IsNullOrWhiteSpace(dto.ViaAdministracao) ? null : dto.ViaAdministracao.Trim(),
                LocalAplicacao = string.IsNullOrWhiteSpace(dto.LocalAplicacao) ? null : dto.LocalAplicacao.Trim(),
                Situacao = string.IsNullOrWhiteSpace(dto.Situacao) ? null : dto.Situacao.Trim(),
                OrigemRegistro = origem,
                AlertaReforco = dto.AlertaReforco ?? true,
                Observacoes = string.IsNullOrWhiteSpace(dto.Observacoes) ? null : dto.Observacoes.Trim(),
                CriadoAt = DateTime.UtcNow
            };

            _context.Vaccines.Add(vaccine);
            await _context.SaveChangesAsync();

            return vaccine;
        }

        private static DateTime? ParseDate(string? value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            if (DateTime.TryParse(value, System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out var parsed))
            {
                return parsed;
            }

            return null;
        }

        public async Task<Vaccine?> UpdateAsync(string id, UpdateVaccineDto dto)
        {
            var vaccine = await _context.Vaccines.FirstOrDefaultAsync(v => v.Id == id);
            if (vaccine == null)
            {
                return null;
            }

            if (dto.Tipo != null)
            {
                if (string.IsNullOrWhiteSpace(dto.Tipo))
                {
                    throw new ArgumentException("O tipo não pode ser vazio.", nameof(dto.Tipo));
                }
                vaccine.Tipo = dto.Tipo.Trim();
            }

            if (dto.DataAplicacao != null)
            {
                if (string.IsNullOrWhiteSpace(dto.DataAplicacao))
                {
                    throw new ArgumentException("A data de aplicação não pode ser vazia.", nameof(dto.DataAplicacao));
                }
                vaccine.DataAplicacao = dto.DataAplicacao;
            }

            if (dto.VeterinarioId != null)
            {
                if (!string.IsNullOrWhiteSpace(dto.VeterinarioId)
                    && !await _context.Users.AnyAsync(u => u.Id == dto.VeterinarioId))
                {
                    throw new ArgumentException($"Veterinário com id '{dto.VeterinarioId}' não encontrado.", nameof(dto.VeterinarioId));
                }
                vaccine.VeterinarioId = string.IsNullOrWhiteSpace(dto.VeterinarioId) ? null : dto.VeterinarioId;
            }

            if (dto.DataProximaDose != null)
            {
                vaccine.DataProximaDose = dto.DataProximaDose;
            }

            if (dto.ComprovanteUrl != null)
            {
                vaccine.ComprovanteUrl = dto.ComprovanteUrl;
            }

            if (dto.Lote != null)
            {
                vaccine.Lote = string.IsNullOrWhiteSpace(dto.Lote) ? null : dto.Lote.Trim();
            }

            if (dto.Fabricante != null)
            {
                vaccine.Fabricante = string.IsNullOrWhiteSpace(dto.Fabricante) ? null : dto.Fabricante.Trim();
            }

            if (dto.Laboratorio != null)
            {
                vaccine.Laboratorio = string.IsNullOrWhiteSpace(dto.Laboratorio) ? null : dto.Laboratorio.Trim();
            }

            if (dto.Dose != null)
            {
                vaccine.Dose = string.IsNullOrWhiteSpace(dto.Dose) ? null : dto.Dose.Trim();
            }

            if (dto.ViaAdministracao != null)
            {
                vaccine.ViaAdministracao = string.IsNullOrWhiteSpace(dto.ViaAdministracao) ? null : dto.ViaAdministracao.Trim();
            }

            if (dto.LocalAplicacao != null)
            {
                vaccine.LocalAplicacao = string.IsNullOrWhiteSpace(dto.LocalAplicacao) ? null : dto.LocalAplicacao.Trim();
            }

            if (dto.Situacao != null)
            {
                vaccine.Situacao = string.IsNullOrWhiteSpace(dto.Situacao) ? null : dto.Situacao.Trim();
            }

            if (dto.AlertaReforco.HasValue)
            {
                vaccine.AlertaReforco = dto.AlertaReforco.Value;
            }

            if (dto.Observacoes != null)
            {
                vaccine.Observacoes = string.IsNullOrWhiteSpace(dto.Observacoes) ? null : dto.Observacoes.Trim();
            }

            await _context.SaveChangesAsync();

            return vaccine;
        }

        public async Task<bool> DeleteAsync(string id)
        {
            var vaccine = await _context.Vaccines.FirstOrDefaultAsync(v => v.Id == id);
            if (vaccine == null)
            {
                return false;
            }

            _context.Vaccines.Remove(vaccine);
            await _context.SaveChangesAsync();

            return true;
        }
    }
}
