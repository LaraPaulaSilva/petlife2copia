using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface ITreatmentService
    {
        // Apenas o tipo de retorno, o nome do método e os parâmetros esperados
        Task<IEnumerable<Treatment>> GetByPetAsync(string petId);
        Task<Treatment?> GetByIdAsync(string id);
        Task<Treatment> CreateAsync(Treatment treatment);
        Task<Treatment?> UpdateAsync(string id, Treatment treatment);
        Task<bool> DeleteAsync(string id);
    }
}