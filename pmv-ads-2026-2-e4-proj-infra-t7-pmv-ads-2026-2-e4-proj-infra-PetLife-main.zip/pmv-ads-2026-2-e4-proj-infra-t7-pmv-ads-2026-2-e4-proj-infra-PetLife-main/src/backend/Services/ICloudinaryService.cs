using Microsoft.AspNetCore.Http;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface ICloudinaryService
    {
        Task<CloudinaryUploadResult> UploadImageAsync(IFormFile file, string? folder = "petlife/pets");
        Task<CloudinaryUploadResult> UploadImageAsync(Stream stream, string fileName, string? folder = "petlife/pets");
        Task<CloudinaryUploadResult> UploadFileAsync(IFormFile file, string? folder = "petlife/documents");
        Task<bool> DeleteImageAsync(string publicId);
    }
}
