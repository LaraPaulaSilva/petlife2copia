using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface IDocumentService
    {
        Task<IEnumerable<Document>> GetAllAsync(string? petId = null);
        Task<Document?> GetByIdAsync(string id);
        Task<Document> CreateAsync(CreateDocumentDto dto);
        Task<Document?> UpdateAsync(string id, UpdateDocumentDto dto);
        Task<bool> DeleteAsync(string id, string? solicitanteId = null);
    }
}
