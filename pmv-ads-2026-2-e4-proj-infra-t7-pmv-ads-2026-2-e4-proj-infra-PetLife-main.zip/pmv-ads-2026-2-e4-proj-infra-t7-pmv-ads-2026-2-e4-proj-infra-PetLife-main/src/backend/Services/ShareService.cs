using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class ShareService(ApplicationDbContext context) : IShareService
    {
        private readonly ApplicationDbContext _context = context;


        public async Task<List<Share>> GetSharesAsync(string userId)
        {
            return await _context.Shares
                .Where(s => s.TutorId == userId)
                .ToListAsync();
        }

        public async Task<List<VetProfile>> GetProfilesAsync(string userId)
        {
            var vetIds = await _context.Shares
                .Where(s => s.TutorId == userId)
                .Select(s => s.VetId)
                .ToArrayAsync();

            return await _context.Users
                .Where(u => vetIds.Contains(u.Id))
                .Select(vet => new VetProfile
                {
                    Id = vet.Id,
                    Image = vet.Image,
                    Name = vet.Name
                })
                .ToListAsync();
        }

        public async Task<Share?> ValidateShareCode(string code, string vetId)
        {
            var dbCode = await _context.ShareCodes.FirstOrDefaultAsync(s => s.Code == code);
            if (dbCode == null) return null;
            if (dbCode.ExpiresAt < DateTime.UtcNow)
            {
                _context.ShareCodes.Remove(dbCode);
                return null;
            }
            var share = new Share
            {
                PetId = dbCode.PetId,
                TutorId = dbCode.TutorId,
                VetId = vetId
            };
            _context.Shares.Add(share);
            _context.ShareCodes.Remove(dbCode);
            await _context.SaveChangesAsync();
            return share;
        }

        public async Task<Share> CreateShareAsync(Share model, string userId)
        {
            var share = new Share
            {
                PetId = model.PetId,
                VetId = model.VetId,
                TutorId = userId,
            };

            _context.Shares.Add(share);
            await _context.SaveChangesAsync();
            return share;
        }

        public async Task<bool> DeleteShareAsync(string id)
        {
            var share = await _context.Shares.FirstOrDefaultAsync(s => s.Id == id);
            if(share == null)
            {
                return false;
            }
            _context.Shares.Remove(share);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<ShareCode> CreateShareCodeAsync(ShareCode model, string userId)
        {
            var shareCode = new ShareCode
            {
                PetId = model.PetId,
                TutorId = userId,
            };

            _context.ShareCodes.Add(shareCode);
            await _context.SaveChangesAsync();
            return shareCode;
        }
    }
}
