using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface IEventoRotinaService
    {
        Task<IEnumerable<EventoRotina>> GetByPetAsync(string petId);
        Task<IEnumerable<EventoRotina>> GetByUserAsync(string userId);
        Task<EventoRotina?> GetByIdAsync(string id);
        Task<EventoRotina> CreateAsync(EventoRotina evento);
        Task<EventoRotina?> UpdateAsync(string id, EventoRotina updated);
        Task<bool> DeleteAsync(string id);
    }
}