using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface IVaccineService
    {
        Task<IEnumerable<Vaccine>> GetAllAsync(string? petId = null);
        Task<Vaccine?> GetByIdAsync(string id);
        Task<Vaccine> CreateAsync(CreateVaccineDto dto);
        Task<Vaccine?> UpdateAsync(string id, UpdateVaccineDto dto);
        Task<bool> DeleteAsync(string id);
    }
}
