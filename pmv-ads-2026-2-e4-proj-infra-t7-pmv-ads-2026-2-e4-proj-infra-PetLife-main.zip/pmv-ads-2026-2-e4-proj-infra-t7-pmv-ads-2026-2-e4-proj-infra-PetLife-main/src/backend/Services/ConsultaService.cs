using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class ConsultaService(ApplicationDbContext context) : IConsultaService
    {
        private readonly ApplicationDbContext _context = context;

        public async Task<IEnumerable<Consulta>> GetAllAsync(string? petId = null)
        {
            var query = _context.Consultas.AsQueryable();

            if (!string.IsNullOrWhiteSpace(petId))
            {
                query = query.Where(c => c.PetId == petId);
            }

            return await query.ToListAsync();
        }

        public async Task<Consulta?> GetByIdAsync(string id)
        {
            return await _context.Consultas.FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task<Consulta> CreateAsync(CreateConsultaDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.PetId))
            {
                throw new ArgumentException("O pet_id é obrigatório.", nameof(dto.PetId));
            }

            if (string.IsNullOrWhiteSpace(dto.AutorId))
            {
                throw new ArgumentException("O autor_id é obrigatório.", nameof(dto.AutorId));
            }

            if (string.IsNullOrWhiteSpace(dto.TipoAtendimento))
            {
                throw new ArgumentException("O tipo de atendimento é obrigatório.", nameof(dto.TipoAtendimento));
            }

            if (string.IsNullOrWhiteSpace(dto.Data))
            {
                throw new ArgumentException("A data é obrigatória.", nameof(dto.Data));
            }

            // O pet referenciado precisa existir.
            if (!await _context.Pets.AnyAsync(p => p.Id == dto.PetId))
            {
                throw new ArgumentException($"Pet com id '{dto.PetId}' não encontrado.", nameof(dto.PetId));
            }

            // O autor do registro precisa existir como usuário.
            if (!await _context.Users.AnyAsync(u => u.Id == dto.AutorId))
            {
                throw new ArgumentException($"Autor com id '{dto.AutorId}' não encontrado.", nameof(dto.AutorId));
            }

            // Tutor e veterinário, quando informados, precisam existir.
            if (!string.IsNullOrWhiteSpace(dto.TutorId)
                && !await _context.Users.AnyAsync(u => u.Id == dto.TutorId))
            {
                throw new ArgumentException($"Tutor com id '{dto.TutorId}' não encontrado.", nameof(dto.TutorId));
            }

            if (!string.IsNullOrWhiteSpace(dto.VeterinarioId)
                && !await _context.Users.AnyAsync(u => u.Id == dto.VeterinarioId))
            {
                throw new ArgumentException($"Veterinário com id '{dto.VeterinarioId}' não encontrado.", nameof(dto.VeterinarioId));
            }

            var origem = dto.OrigemRegistro ?? OrigemRegistro.VETERINARIO;

            // Somente o veterinário registra os campos clínicos (diagnóstico/registro profissional).
            var descricaoClinica = dto.DescricaoClinica;
            var temCamposClinicos =
                !string.IsNullOrWhiteSpace(descricaoClinica)
                || !string.IsNullOrWhiteSpace(dto.Diagnostico)
                || !string.IsNullOrWhiteSpace(dto.Conduta)
                || dto.PesoKg.HasValue
                || dto.TemperaturaC.HasValue;

            if (origem == OrigemRegistro.TUTOR && temCamposClinicos)
            {
                throw new UnauthorizedAccessException(
                    "O tutor não pode registrar dados clínicos (descrição, diagnóstico, conduta, peso ou temperatura); esses campos são exclusivos do veterinário.");
            }

            var consulta = new Consulta
            {
                Id = Guid.NewGuid().ToString(),
                PetId = dto.PetId,
                TutorId = string.IsNullOrWhiteSpace(dto.TutorId) ? null : dto.TutorId,
                VeterinarioId = string.IsNullOrWhiteSpace(dto.VeterinarioId) ? null : dto.VeterinarioId,
                Clinica = string.IsNullOrWhiteSpace(dto.Clinica) ? null : dto.Clinica.Trim(),
                Data = dto.Data,
                Hora = string.IsNullOrWhiteSpace(dto.Hora) ? null : dto.Hora.Trim(),
                TipoAtendimento = dto.TipoAtendimento.Trim(),
                Motivo = string.IsNullOrWhiteSpace(dto.Motivo) ? null : dto.Motivo.Trim(),
                Status = dto.Status ?? StatusConsulta.SOLICITADA,
                OrigemRegistro = origem,
                AutorId = dto.AutorId,
                DescricaoClinica = string.IsNullOrWhiteSpace(descricaoClinica) ? null : descricaoClinica.Trim(),
                PesoKg = dto.PesoKg,
                TemperaturaC = dto.TemperaturaC,
                Diagnostico = string.IsNullOrWhiteSpace(dto.Diagnostico) ? null : dto.Diagnostico.Trim(),
                Conduta = string.IsNullOrWhiteSpace(dto.Conduta) ? null : dto.Conduta.Trim(),
                RetornoPrevisto = string.IsNullOrWhiteSpace(dto.RetornoPrevisto) ? null : dto.RetornoPrevisto.Trim(),
                Observacoes = string.IsNullOrWhiteSpace(dto.Observacoes) ? null : dto.Observacoes.Trim(),
                Valor = dto.Valor,
                CriadoEm = DateTime.UtcNow
            };

            _context.Consultas.Add(consulta);
            await _context.SaveChangesAsync();

            return consulta;
        }

        public async Task<Consulta?> UpdateAsync(string id, UpdateConsultaDto dto)
        {
            var consulta = await _context.Consultas.FirstOrDefaultAsync(c => c.Id == id);
            if (consulta == null)
            {
                return null;
            }

            // Cada usuário só edita registros de sua autoria.
            if (!string.IsNullOrWhiteSpace(dto.SolicitanteId)
                && !string.Equals(dto.SolicitanteId, consulta.AutorId, StringComparison.Ordinal))
            {
                throw new UnauthorizedAccessException(
                    "Você só pode editar consultas de sua própria autoria.");
            }

            // O tutor não edita a descrição clínica; só consultas de origem veterinária a aceitam.
            if (dto.DescricaoClinica != null && consulta.OrigemRegistro == OrigemRegistro.TUTOR)
            {
                throw new UnauthorizedAccessException(
                    "A descrição clínica é exclusiva do veterinário e não pode ser alterada nesta consulta.");
            }

            if (dto.TipoAtendimento != null)
            {
                if (string.IsNullOrWhiteSpace(dto.TipoAtendimento))
                {
                    throw new ArgumentException("O tipo de atendimento não pode ser vazio.", nameof(dto.TipoAtendimento));
                }
                consulta.TipoAtendimento = dto.TipoAtendimento.Trim();
            }

            if (dto.Data != null)
            {
                if (string.IsNullOrWhiteSpace(dto.Data))
                {
                    throw new ArgumentException("A data não pode ser vazia.", nameof(dto.Data));
                }
                consulta.Data = dto.Data;
            }

            if (dto.VeterinarioId != null)
            {
                if (!string.IsNullOrWhiteSpace(dto.VeterinarioId)
                    && !await _context.Users.AnyAsync(u => u.Id == dto.VeterinarioId))
                {
                    throw new ArgumentException($"Veterinário com id '{dto.VeterinarioId}' não encontrado.", nameof(dto.VeterinarioId));
                }
                consulta.VeterinarioId = string.IsNullOrWhiteSpace(dto.VeterinarioId) ? null : dto.VeterinarioId;
            }

            if (dto.Clinica != null)
            {
                consulta.Clinica = string.IsNullOrWhiteSpace(dto.Clinica) ? null : dto.Clinica.Trim();
            }

            if (dto.Hora != null)
            {
                consulta.Hora = string.IsNullOrWhiteSpace(dto.Hora) ? null : dto.Hora.Trim();
            }

            if (dto.Motivo != null)
            {
                consulta.Motivo = string.IsNullOrWhiteSpace(dto.Motivo) ? null : dto.Motivo.Trim();
            }

            if (dto.Status.HasValue)
            {
                consulta.Status = dto.Status.Value;
            }

            if (dto.DescricaoClinica != null)
            {
                consulta.DescricaoClinica = string.IsNullOrWhiteSpace(dto.DescricaoClinica) ? null : dto.DescricaoClinica.Trim();
            }

            if (dto.PesoKg.HasValue)
            {
                consulta.PesoKg = dto.PesoKg;
            }

            if (dto.TemperaturaC.HasValue)
            {
                consulta.TemperaturaC = dto.TemperaturaC;
            }

            if (dto.Diagnostico != null)
            {
                consulta.Diagnostico = string.IsNullOrWhiteSpace(dto.Diagnostico) ? null : dto.Diagnostico.Trim();
            }

            if (dto.Conduta != null)
            {
                consulta.Conduta = string.IsNullOrWhiteSpace(dto.Conduta) ? null : dto.Conduta.Trim();
            }

            if (dto.RetornoPrevisto != null)
            {
                consulta.RetornoPrevisto = string.IsNullOrWhiteSpace(dto.RetornoPrevisto) ? null : dto.RetornoPrevisto.Trim();
            }

            if (dto.Observacoes != null)
            {
                consulta.Observacoes = string.IsNullOrWhiteSpace(dto.Observacoes) ? null : dto.Observacoes.Trim();
            }

            if (dto.Valor.HasValue)
            {
                consulta.Valor = dto.Valor;
            }

            await _context.SaveChangesAsync();

            return consulta;
        }

        public async Task<bool> DeleteAsync(string id, string? solicitanteId = null)
        {
            var consulta = await _context.Consultas.FirstOrDefaultAsync(c => c.Id == id);
            if (consulta == null)
            {
                return false;
            }

            // Cada usuário só exclui registros de sua autoria.
            if (!string.IsNullOrWhiteSpace(solicitanteId)
                && !string.Equals(solicitanteId, consulta.AutorId, StringComparison.Ordinal))
            {
                throw new UnauthorizedAccessException(
                    "Você só pode excluir consultas de sua própria autoria.");
            }

            // Consulta REALIZADA é mantida como registro clínico e não pode ser excluída.
            if (consulta.Status == StatusConsulta.REALIZADA)
            {
                throw new InvalidOperationException(
                    "Uma consulta REALIZADA não pode ser excluída; ela é mantida no histórico clínico.");
            }

            _context.Consultas.Remove(consulta);
            await _context.SaveChangesAsync();

            return true;
        }
    }
}
