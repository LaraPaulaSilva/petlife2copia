using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface IConsultaService
    {
        Task<IEnumerable<Consulta>> GetAllAsync(string? petId = null);
        Task<Consulta?> GetByIdAsync(string id);
        Task<Consulta> CreateAsync(CreateConsultaDto dto);
        Task<Consulta?> UpdateAsync(string id, UpdateConsultaDto dto);
        Task<bool> DeleteAsync(string id, string? solicitanteId = null);
    }
}
