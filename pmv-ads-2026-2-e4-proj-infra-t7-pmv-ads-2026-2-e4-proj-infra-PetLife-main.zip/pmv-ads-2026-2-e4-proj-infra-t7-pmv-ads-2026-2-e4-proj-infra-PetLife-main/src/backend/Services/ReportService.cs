using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class ReportService(ApplicationDbContext context) : IReportService {
        private readonly ApplicationDbContext _context = context;

        public async Task<IEnumerable<Report>> GetByUserIdAsync(string userId) => 
            await _context.Reports.Where(r => r.UserId == userId).ToListAsync();

        public async Task<Report> CreateAsync(Report report) {
            _context.Reports.Add(report);
            await _context.SaveChangesAsync();
            return report;
        }

        public async Task<Report?> UpdateAsync(string id, Report updated) {
            var existing = await _context.Reports.FirstOrDefaultAsync(r => r.Id == id);
            if (existing == null) return null;

            existing.Name = updated.Name;
            existing.Type = updated.Type;
            existing.Filters = updated.Filters;

            await _context.SaveChangesAsync();
            return existing;
        }

        public async Task<bool> DeleteAsync(string id) {
            var report = await _context.Reports.FirstOrDefaultAsync(r => r.Id == id);
            if (report == null) return false;

            _context.Reports.Remove(report);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}