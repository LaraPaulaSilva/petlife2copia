using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class TokenService(IConfiguration configuration) : ITokenService
    {
        private readonly IConfiguration _configuration = configuration;

        public string GenerateToken(User user, string role)
        {
            var secret = _configuration["Jwt:Secret"] ?? "PetLife_Super_Secret_Key_Distributed_Apps_2026_PUC_Minas!";
            var issuer = _configuration["Jwt:Issuer"] ?? "PetLifeApi";
            var audience = _configuration["Jwt:Audience"] ?? "PetLifeClients";

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, user.Id),
                new(ClaimTypes.Name, user.Name),
                new(ClaimTypes.Email, user.Email ?? string.Empty),
                new(ClaimTypes.Role, role),
                new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            if (!string.IsNullOrWhiteSpace(user.Crmv))
            {
                claims.Add(new Claim("crmv", user.Crmv));
            }

            var expires = GetExpirationDate();

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = expires,
                Issuer = issuer,
                Audience = audience,
                SigningCredentials = credentials
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);

            return tokenHandler.WriteToken(token);
        }

        public DateTime GetExpirationDate()
        {
            var hoursStr = _configuration["Jwt:ExpirationInHours"] ?? "24";
            if (!double.TryParse(hoursStr, out var hours))
            {
                hours = 24;
            }

            return DateTime.UtcNow.AddHours(hours);
        }
    }
}
