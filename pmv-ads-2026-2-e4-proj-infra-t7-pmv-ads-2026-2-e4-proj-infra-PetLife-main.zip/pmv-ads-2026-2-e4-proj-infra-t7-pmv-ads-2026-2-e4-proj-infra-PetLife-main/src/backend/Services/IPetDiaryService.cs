using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface IPetDiaryService
    {
        Task<IEnumerable<PetDiaryEntry>> GetAllAsync(string userId, bool isVeterinario, string? petId = null);
        Task<PetDiaryEntry?> GetByIdAsync(string id, string userId, bool isVeterinario);
        Task<PetDiaryEntry> CreateAsync(CreatePetDiaryDto dto, string userId);
        Task<PetDiaryEntry?> UpdateAsync(string id, UpdatePetDiaryDto dto, string userId);
        Task<bool> DeleteAsync(string id, string userId);
    }
}
