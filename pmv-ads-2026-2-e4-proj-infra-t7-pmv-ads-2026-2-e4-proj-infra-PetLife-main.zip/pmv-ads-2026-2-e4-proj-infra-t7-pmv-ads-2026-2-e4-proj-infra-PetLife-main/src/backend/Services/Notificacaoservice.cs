using Microsoft.EntityFrameworkCore;
using MongoDB.Bson;
using PetLife.Api.Data;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class NotificacaoService(ApplicationDbContext context, IMailService mailService) : INotificacaoService
    {
        private readonly ApplicationDbContext _context = context;

        public async Task CriarAsync(string userId, string titulo, string mensagem, string tipo, string? referenciaId)
        {
            var config = await _context.ConfiguracoesNotificacao.FirstOrDefaultAsync(c => c.UserId == userId);

            if (config == null)
                config = new ConfiguracaoNotificacao { UserId = userId };

            if (config.EmailAtivo)
            {
                var notificacaoEmail = new Notificacao
                {
                    Id = ObjectId.GenerateNewId().ToString(),
                    UserId = userId,
                    Titulo = titulo,
                    Mensagem = mensagem,
                    Tipo = tipo,
                    Canal = "email",
                    ReferenciaId = referenciaId
                };

                _context.Notificacoes.Add(notificacaoEmail);
                await _context.SaveChangesAsync();

                var usuario = await _context.Users.FirstOrDefaultAsync(u => u.Id == userId);

                if (usuario != null && !string.IsNullOrEmpty(usuario.Email))
                {
                    try
                    {
                        await mailService.SendEmailAsync(usuario.Email, titulo, mensagem, false);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Erro ao enviar email: " + ex.Message);
                    }
                }
            }

            if (config.PushAtivo)
            {
                var notificacaoPush = new Notificacao
                {
                    // CORREÇÃO: faltava gerar o Id da notificação de push
                    Id = ObjectId.GenerateNewId().ToString(),
                    UserId = userId,
                    Titulo = titulo,
                    Mensagem = mensagem,
                    Tipo = tipo,
                    Canal = "push",
                    ReferenciaId = referenciaId
                };

                _context.Notificacoes.Add(notificacaoPush);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<Notificacao>> GetByUserAsync(string userId)
        {
            return await _context.Notificacoes
                .Where(n => n.UserId == userId)
                .OrderByDescending(n => n.DataHora)
                .ToListAsync();
        }

        public async Task<bool> MarcarComoLidaAsync(string id)
        {
            var notificacao = await _context.Notificacoes.FirstOrDefaultAsync(n => n.Id == id);
            if (notificacao == null) return false;

            notificacao.Lida = true;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAsync(string id)
        {
            var notificacao = await _context.Notificacoes.FirstOrDefaultAsync(n => n.Id == id);
            if (notificacao == null) return false;

            _context.Notificacoes.Remove(notificacao);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<ConfiguracaoNotificacao> ObterPreferenciasAsync(string userId)
        {
            var config = await _context.ConfiguracoesNotificacao.FirstOrDefaultAsync(c => c.UserId == userId);

            if (config == null)
                config = new ConfiguracaoNotificacao { UserId = userId };

            return config;
        }

        public async Task<ConfiguracaoNotificacao> SalvarPreferenciasAsync(ConfiguracaoNotificacao novaConfig)
        {
            var existente = await _context.ConfiguracoesNotificacao.FirstOrDefaultAsync(c => c.UserId == novaConfig.UserId);

            if (existente == null)
            {
                if (string.IsNullOrEmpty(novaConfig.Id))
                    novaConfig.Id = ObjectId.GenerateNewId().ToString();

                _context.ConfiguracoesNotificacao.Add(novaConfig);
                await _context.SaveChangesAsync();
                return novaConfig;
            }

            existente.EmailAtivo = novaConfig.EmailAtivo;
            existente.PushAtivo = novaConfig.PushAtivo;
            existente.FcmToken = novaConfig.FcmToken;
            await _context.SaveChangesAsync();

            return existente;
        }
    }
}