using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class TreatmentService(ApplicationDbContext context) : ITreatmentService
    {
        // Injeção do banco de dados
        private readonly ApplicationDbContext _context = context;

        // Implementação real: COMO buscar no banco
        public async Task<IEnumerable<Treatment>> GetByPetAsync(string petId)
        {
            return await _context.Treatments
                .Where(t => t.PetId == petId)
                .ToListAsync();
        }

        // Implementação real: COMO salvar no banco
        public async Task<Treatment> CreateAsync(Treatment treatment)
        {
            _context.Treatments.Add(treatment);
            await _context.SaveChangesAsync();
            return treatment;
        }

        // Implementação real: COMO atualizar e salvar
        public async Task<Treatment?> UpdateAsync(string id, Treatment updated)
        {
            var existing = await _context.Treatments.FirstOrDefaultAsync(t => t.Id == id);
            if (existing == null) return null;

            existing.Medicamento = updated.Medicamento;
            existing.Dose = updated.Dose;
            existing.Ativo = updated.Ativo;
            existing.HistoricoDoses = updated.HistoricoDoses;
            
            await _context.SaveChangesAsync();
            return existing;
        }

        // Implementação real: COMO deletar
        public async Task<bool> DeleteAsync(string id)
        {
            var treatment = await _context.Treatments.FirstOrDefaultAsync(t => t.Id == id);
            if (treatment == null) return false;

            _context.Treatments.Remove(treatment);
            await _context.SaveChangesAsync();
            return true;
        }
        
        public async Task<Treatment?> GetByIdAsync(string id)
        {
            return await _context.Treatments.FirstOrDefaultAsync(t => t.Id == id);
        }
    }
}