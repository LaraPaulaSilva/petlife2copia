using Microsoft.EntityFrameworkCore;
using MongoDB.Bson;
using PetLife.Api.Data;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class EventoRotinaService(ApplicationDbContext context, INotificacaoService notificacaoService) : IEventoRotinaService
    {
        private readonly ApplicationDbContext _context = context;

        public async Task<IEnumerable<EventoRotina>> GetByPetAsync(string petId)
        {
            return await _context.EventosRotina
                .Where(e => e.PetId == petId)
                .ToListAsync();
        }

        public async Task<IEnumerable<EventoRotina>> GetByUserAsync(string userId)
        {
            return await _context.EventosRotina
                .Where(e => e.UserId == userId)
                .ToListAsync();
        }

        public async Task<EventoRotina?> GetByIdAsync(string id)
        {
            return await _context.EventosRotina.FirstOrDefaultAsync(e => e.Id == id);
        }

        public async Task<EventoRotina> CreateAsync(EventoRotina evento)
        {
            // Garantia extra: o modelo já gera um Id, mas aqui sempre geramos um novo,
            // ignorando qualquer valor enviado no JSON (inclusive null ou vazio).
            evento.Id = ObjectId.GenerateNewId().ToString();

            var fusoBrasil = TimeZoneInfo.FindSystemTimeZoneById("America/Sao_Paulo");
            var dataSemFuso = DateTime.SpecifyKind(evento.DataHora, DateTimeKind.Unspecified);
            evento.DataHora = TimeZoneInfo.ConvertTimeToUtc(dataSemFuso, fusoBrasil);

            _context.EventosRotina.Add(evento);
            await _context.SaveChangesAsync();

            var dataParaMensagem = TimeZoneInfo.ConvertTimeFromUtc(evento.DataHora, fusoBrasil);
            var titulo = "Novo agendamento: " + evento.Tipo;
            var mensagem = evento.Tipo + " agendado para " + dataParaMensagem.ToString("dd/MM/yyyy HH:mm");

            var tipoNotificacao = evento.Tipo;
            if (evento.Tipo == "vermifugo") tipoNotificacao = "vermifugo";
            if (evento.Tipo == "antipulgas") tipoNotificacao = "antipulgas";
            if (evento.Tipo == "vacina") tipoNotificacao = "proxima_vacina";

            await notificacaoService.CriarAsync(evento.UserId, titulo, mensagem, tipoNotificacao, evento.Id);

            return evento;
        }

        public async Task<EventoRotina?> UpdateAsync(string id, EventoRotina updated)
        {
            var existing = await _context.EventosRotina.FirstOrDefaultAsync(e => e.Id == id);
            if (existing == null) return null;

            var fusoBrasil = TimeZoneInfo.FindSystemTimeZoneById("America/Sao_Paulo");
            var dataSemFuso = DateTime.SpecifyKind(updated.DataHora, DateTimeKind.Unspecified);

            existing.PetId = updated.PetId;
            existing.Tipo = updated.Tipo;
            existing.DataHora = TimeZoneInfo.ConvertTimeToUtc(dataSemFuso, fusoBrasil);
            existing.Recorrente = updated.Recorrente;
            existing.IntervaloDias = updated.IntervaloDias;
            existing.Observacoes = updated.Observacoes;
            existing.Status = updated.Status;

            await _context.SaveChangesAsync();
            return existing;
        }

        public async Task<bool> DeleteAsync(string id)
        {
            var evento = await _context.EventosRotina.FirstOrDefaultAsync(e => e.Id == id);
            if (evento == null) return false;

            _context.EventosRotina.Remove(evento);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}