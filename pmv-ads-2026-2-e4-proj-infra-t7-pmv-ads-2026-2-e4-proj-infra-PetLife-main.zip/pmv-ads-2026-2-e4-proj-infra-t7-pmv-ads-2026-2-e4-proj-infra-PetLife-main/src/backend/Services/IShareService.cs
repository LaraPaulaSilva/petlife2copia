﻿using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface IShareService
    {
        Task<List<VetProfile>> GetProfilesAsync(string userId);
        Task<List<Share>> GetSharesAsync(string userId);
        Task<Share?> ValidateShareCode(string code, string vetId);
        Task<Share> CreateShareAsync(Share model, string userId);
        Task<bool> DeleteShareAsync(string id);
        Task<ShareCode> CreateShareCodeAsync(ShareCode model, string userId);
    }
}
