using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class DocumentService(ApplicationDbContext context) : IDocumentService
    {
        private readonly ApplicationDbContext _context = context;

        public async Task<IEnumerable<Document>> GetAllAsync(string? petId = null)
        {
            var query = _context.Documents.AsQueryable();

            if (!string.IsNullOrWhiteSpace(petId))
            {
                query = query.Where(d => d.PetId == petId);
            }

            return await query.ToListAsync();
        }

        public async Task<Document?> GetByIdAsync(string id)
        {
            return await _context.Documents.FirstOrDefaultAsync(d => d.Id == id);
        }

        public async Task<Document> CreateAsync(CreateDocumentDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.PetId))
            {
                throw new ArgumentException("O pet_id é obrigatório.", nameof(dto.PetId));
            }

            if (string.IsNullOrWhiteSpace(dto.UsuarioId))
            {
                throw new ArgumentException("O usuario_id é obrigatório.", nameof(dto.UsuarioId));
            }

            if (string.IsNullOrWhiteSpace(dto.Titulo))
            {
                throw new ArgumentException("O título é obrigatório.", nameof(dto.Titulo));
            }

            if (string.IsNullOrWhiteSpace(dto.ArquivoUrl))
            {
                throw new ArgumentException("A URL do arquivo é obrigatória.", nameof(dto.ArquivoUrl));
            }

            // O pet referenciado precisa existir.
            if (!await _context.Pets.AnyAsync(p => p.Id == dto.PetId))
            {
                throw new ArgumentException($"Pet com id '{dto.PetId}' não encontrado.", nameof(dto.PetId));
            }

            // O usuário que envia o documento precisa existir.
            if (!await _context.Users.AnyAsync(u => u.Id == dto.UsuarioId))
            {
                throw new ArgumentException($"Usuário com id '{dto.UsuarioId}' não encontrado.", nameof(dto.UsuarioId));
            }

            // Se o documento é vinculado a uma consulta, ela precisa existir.
            if (!string.IsNullOrWhiteSpace(dto.ConsultaId)
                && !await _context.Consultas.AnyAsync(c => c.Id == dto.ConsultaId))
            {
                throw new ArgumentException($"Consulta com id '{dto.ConsultaId}' não encontrada.", nameof(dto.ConsultaId));
            }

            var document = new Document
            {
                Id = Guid.NewGuid().ToString(),
                PetId = dto.PetId,
                UsuarioId = dto.UsuarioId,
                PerfilAutor = string.IsNullOrWhiteSpace(dto.PerfilAutor) ? null : dto.PerfilAutor.Trim(),
                ConsultaId = string.IsNullOrWhiteSpace(dto.ConsultaId) ? null : dto.ConsultaId,
                Titulo = dto.Titulo.Trim(),
                TipoDoc = string.IsNullOrWhiteSpace(dto.TipoDoc) ? null : dto.TipoDoc.Trim(),
                ArquivoUrl = dto.ArquivoUrl.Trim(),
                DataUpload = DateTime.UtcNow
            };

            _context.Documents.Add(document);
            await _context.SaveChangesAsync();

            return document;
        }

        public async Task<Document?> UpdateAsync(string id, UpdateDocumentDto dto)
        {
            var document = await _context.Documents.FirstOrDefaultAsync(d => d.Id == id);
            if (document == null)
            {
                return null;
            }

            // Cada usuário só edita documentos de sua autoria.
            if (!string.IsNullOrWhiteSpace(dto.SolicitanteId)
                && !string.Equals(dto.SolicitanteId, document.UsuarioId, StringComparison.Ordinal))
            {
                throw new UnauthorizedAccessException(
                    "Você só pode editar documentos de sua própria autoria.");
            }

            if (dto.Titulo != null)
            {
                if (string.IsNullOrWhiteSpace(dto.Titulo))
                {
                    throw new ArgumentException("O título não pode ser vazio.", nameof(dto.Titulo));
                }
                document.Titulo = dto.Titulo.Trim();
            }

            if (dto.ArquivoUrl != null)
            {
                if (string.IsNullOrWhiteSpace(dto.ArquivoUrl))
                {
                    throw new ArgumentException("A URL do arquivo não pode ser vazia.", nameof(dto.ArquivoUrl));
                }
                document.ArquivoUrl = dto.ArquivoUrl.Trim();
            }

            if (dto.TipoDoc != null)
            {
                document.TipoDoc = string.IsNullOrWhiteSpace(dto.TipoDoc) ? null : dto.TipoDoc.Trim();
            }

            if (dto.ConsultaId != null)
            {
                if (!string.IsNullOrWhiteSpace(dto.ConsultaId)
                    && !await _context.Consultas.AnyAsync(c => c.Id == dto.ConsultaId))
                {
                    throw new ArgumentException($"Consulta com id '{dto.ConsultaId}' não encontrada.", nameof(dto.ConsultaId));
                }
                document.ConsultaId = string.IsNullOrWhiteSpace(dto.ConsultaId) ? null : dto.ConsultaId;
            }

            await _context.SaveChangesAsync();

            return document;
        }

        public async Task<bool> DeleteAsync(string id, string? solicitanteId = null)
        {
            var document = await _context.Documents.FirstOrDefaultAsync(d => d.Id == id);
            if (document == null)
            {
                return false;
            }

            // Cada usuário só exclui documentos de sua autoria.
            if (!string.IsNullOrWhiteSpace(solicitanteId)
                && !string.Equals(solicitanteId, document.UsuarioId, StringComparison.Ordinal))
            {
                throw new UnauthorizedAccessException(
                    "Você só pode excluir documentos de sua própria autoria.");
            }

            _context.Documents.Remove(document);
            await _context.SaveChangesAsync();

            return true;
        }
    }
}
