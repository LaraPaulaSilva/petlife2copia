using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class PetService(ApplicationDbContext context, ICloudinaryService cloudinaryService) : IPetService
    {
        private readonly ApplicationDbContext _context = context;
        private readonly ICloudinaryService _cloudinaryService = cloudinaryService;

        public async Task<IEnumerable<Pet>> GetAllAsync(string? tutorId = null)
        {
            var query = _context.Pets.AsQueryable();

            if (!string.IsNullOrWhiteSpace(tutorId))
            {
                query = query.Where(p => p.TutorId == tutorId);
            }

            return await query.ToListAsync();
        }

        public async Task<IEnumerable<Pet>> GetSharedAsync(string? vetId = null)
        {
            var shares = _context.Shares.Where(s => s.VetId == vetId);
            var ids = shares.Select(s => s.PetId).ToArray();
            var pets = _context.Pets.Where(p => ids.Contains(p.Id));
            return await pets.ToListAsync();
        }
        public async Task<Pet?> GetByIdAsync(string id)
        {
            return await _context.Pets.FirstOrDefaultAsync(p => p.Id == id);
        }

        public async Task<Pet> CreateAsync(CreatePetDto dto, string tutorId)
        {
            if (string.IsNullOrWhiteSpace(tutorId))
            {
                throw new ArgumentException("O tutor_id é obrigatório.", nameof(tutorId));
            }

            if (string.IsNullOrWhiteSpace(dto.Nome))
            {
                throw new ArgumentException("O nome do pet é obrigatório.", nameof(dto.Nome));
            }

            if (string.IsNullOrWhiteSpace(dto.Especie))
            {
                throw new ArgumentException("A espécie do pet é obrigatória.", nameof(dto.Especie));
            }

            var pet = new Pet
            {
                Id = Guid.NewGuid().ToString(),
                Nome = dto.Nome.Trim(),
                Especie = dto.Especie.Trim(),
                Raca = string.IsNullOrWhiteSpace(dto.Raca) ? null : dto.Raca.Trim(),
                PesoKg = dto.PesoKg,
                DataNascimento = dto.DataNascimento,
                Microchip = string.IsNullOrWhiteSpace(dto.Microchip) ? null : dto.Microchip.Trim(),
                FotoUrl = dto.FotoUrl,
                TutorId = tutorId,
                CriadoAt = dto.CriadoAt ?? DateTime.UtcNow
            };

            _context.Pets.Add(pet);
            await _context.SaveChangesAsync();

            return pet;
        }

        public async Task<Pet?> UpdateAsync(string id, UpdatePetDto dto)
        {
            var pet = await _context.Pets.FirstOrDefaultAsync(p => p.Id == id);
            if (pet == null)
            {
                return null;
            }

            if (dto.Nome != null)
            {
                if (string.IsNullOrWhiteSpace(dto.Nome))
                {
                    throw new ArgumentException("O nome não pode ser vazio.", nameof(dto.Nome));
                }
                pet.Nome = dto.Nome.Trim();
            }

            if (dto.Especie != null)
            {
                if (string.IsNullOrWhiteSpace(dto.Especie))
                {
                    throw new ArgumentException("A espécie não pode ser vazia.", nameof(dto.Especie));
                }
                pet.Especie = dto.Especie.Trim();
            }

            if (dto.Raca != null)
            {
                pet.Raca = string.IsNullOrWhiteSpace(dto.Raca) ? null : dto.Raca.Trim();
            }

            if (dto.PesoKg.HasValue)
            {
                pet.PesoKg = dto.PesoKg.Value;
            }

            if (dto.DataNascimento != null)
            {
                pet.DataNascimento = dto.DataNascimento;
            }

            if (dto.Microchip != null)
            {
                pet.Microchip = string.IsNullOrWhiteSpace(dto.Microchip) ? null : dto.Microchip.Trim();
            }

            if (dto.FotoUrl != null)
            {
                pet.FotoUrl = dto.FotoUrl;
            }

            if (!string.IsNullOrWhiteSpace(dto.TutorId))
            {
                pet.TutorId = dto.TutorId;
            }

            await _context.SaveChangesAsync();

            return pet;
        }

        public async Task<bool> DeleteAsync(string id)
        {
            var pet = await _context.Pets.FirstOrDefaultAsync(p => p.Id == id);
            if (pet == null)
            {
                return false;
            }

            _context.Pets.Remove(pet);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<Pet?> UploadPhotoAsync(string petId, IFormFile file)
        {
            if (string.IsNullOrWhiteSpace(petId))
            {
                throw new ArgumentException("O ID do pet é obrigatório.", nameof(petId));
            }

            if (file == null || file.Length == 0)
            {
                throw new ArgumentException("O arquivo de foto é obrigatório e não pode estar vazio.", nameof(file));
            }

            var pet = await _context.Pets.FirstOrDefaultAsync(p => p.Id == petId);
            if (pet == null)
            {
                return null;
            }

            var uploadResult = await _cloudinaryService.UploadImageAsync(file, "petlife/pets");
            pet.FotoUrl = uploadResult.SecureUrl;

            await _context.SaveChangesAsync();

            return pet;
        }
    }
}
