using CloudinaryDotNet;
using CloudinaryDotNet.Actions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public class CloudinaryService : ICloudinaryService
    {
        private readonly Cloudinary _cloudinary;

        public CloudinaryService(IOptions<CloudinarySettings> config, IConfiguration? configuration = null)
        {
            var settings = config.Value;

            var cloudName = !string.IsNullOrWhiteSpace(settings.CloudName)
                ? settings.CloudName
                : configuration?["Cloudinary:CloudName"]
                  ?? configuration?["CLOUDINARY_CLOUD_NAME"]
                  ?? Environment.GetEnvironmentVariable("CLOUDINARY_CLOUD_NAME");

            var apiKey = !string.IsNullOrWhiteSpace(settings.ApiKey)
                ? settings.ApiKey
                : configuration?["Cloudinary:ApiKey"]
                  ?? configuration?["CLOUDINARY_API_KEY"]
                  ?? Environment.GetEnvironmentVariable("CLOUDINARY_API_KEY");

            var apiSecret = !string.IsNullOrWhiteSpace(settings.ApiSecret)
                ? settings.ApiSecret
                : configuration?["Cloudinary:ApiSecret"]
                  ?? configuration?["CLOUDINARY_API_SECRET"]
                  ?? Environment.GetEnvironmentVariable("CLOUDINARY_API_SECRET");

            if (string.IsNullOrWhiteSpace(cloudName) ||
                string.IsNullOrWhiteSpace(apiKey) ||
                string.IsNullOrWhiteSpace(apiSecret))
            {
                throw new InvalidOperationException(
                    "Cloudinary não configurado. Verifique as configurações de CloudName, ApiKey e ApiSecret no appsettings ou variáveis de ambiente.");
            }

            var account = new Account(cloudName.Trim(), apiKey.Trim(), apiSecret.Trim());
            _cloudinary = new Cloudinary(account);
            _cloudinary.Api.Secure = true;
        }

        public async Task<CloudinaryUploadResult> UploadImageAsync(IFormFile file, string? folder = "petlife/pets")
        {
            if (file == null || file.Length == 0)
            {
                throw new ArgumentException("O arquivo de imagem é obrigatório e não pode estar vazio.", nameof(file));
            }

            await using var stream = file.OpenReadStream();
            return await UploadImageAsync(stream, file.FileName, folder);
        }

        public async Task<CloudinaryUploadResult> UploadImageAsync(Stream stream, string fileName, string? folder = "petlife/pets")
        {
            if (stream == null || stream.Length == 0 && !stream.CanRead)
            {
                throw new ArgumentException("O stream de imagem é inválido.", nameof(stream));
            }

            var uploadParams = new ImageUploadParams
            {
                File = new FileDescription(string.IsNullOrWhiteSpace(fileName) ? "upload.jpg" : fileName, stream),
                Folder = string.IsNullOrWhiteSpace(folder) ? null : folder.Trim()
            };

            var uploadResult = await _cloudinary.UploadAsync(uploadParams);

            if (uploadResult.Error != null)
            {
                throw new InvalidOperationException($"Cloudinary upload falhou: {uploadResult.Error.Message}");
            }

            var secureUrl = uploadResult.SecureUrl?.AbsoluteUri ?? uploadResult.Url?.AbsoluteUri ?? string.Empty;
            return new CloudinaryUploadResult(secureUrl, uploadResult.PublicId);
        }

        public async Task<CloudinaryUploadResult> UploadFileAsync(IFormFile file, string? folder = "petlife/documents")
        {
            if (file == null || file.Length == 0)
            {
                throw new ArgumentException("O arquivo é obrigatório e não pode estar vazio.", nameof(file));
            }

            await using var stream = file.OpenReadStream();

            var fileName = string.IsNullOrWhiteSpace(file.FileName)
                ? "documento"
                : file.FileName;

            // resource_type "auto" faz o Cloudinary detectar o tipo (PDF, imagem, etc.)
            // e servir o arquivo de forma visualizável no navegador.
            var uploadParams = new AutoUploadParams
            {
                File = new FileDescription(fileName, stream),
                Folder = string.IsNullOrWhiteSpace(folder) ? null : folder.Trim(),
                UseFilename = true,
                UniqueFilename = true,
            };

            var uploadResult = await _cloudinary.UploadAsync(uploadParams);

            if (uploadResult.Error != null)
            {
                throw new InvalidOperationException($"Cloudinary upload falhou: {uploadResult.Error.Message}");
            }

            var secureUrl = uploadResult.SecureUrl?.AbsoluteUri ?? uploadResult.Url?.AbsoluteUri ?? string.Empty;
            return new CloudinaryUploadResult(secureUrl, uploadResult.PublicId);
        }

        public async Task<bool> DeleteImageAsync(string publicId)
        {
            if (string.IsNullOrWhiteSpace(publicId))
            {
                return false;
            }

            var deleteParams = new DeletionParams(publicId.Trim());
            var result = await _cloudinary.DestroyAsync(deleteParams);

            return result.Result?.ToLowerInvariant() == "ok";
        }
    }
}
