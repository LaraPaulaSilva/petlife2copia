using Microsoft.AspNetCore.Http;
using PetLife.Api.Models;

namespace PetLife.Api.Services
{
    public interface IPetService
    {
        Task<IEnumerable<Pet>> GetAllAsync(string? tutorId = null);
        Task<IEnumerable<Pet>> GetSharedAsync(string? vetId = null);
        Task<Pet?> GetByIdAsync(string id);
        Task<Pet> CreateAsync(CreatePetDto dto, string tutorId);
        Task<Pet?> UpdateAsync(string id, UpdatePetDto dto);
        Task<bool> DeleteAsync(string id);
        Task<Pet?> UploadPhotoAsync(string petId, IFormFile file);
    }
}
