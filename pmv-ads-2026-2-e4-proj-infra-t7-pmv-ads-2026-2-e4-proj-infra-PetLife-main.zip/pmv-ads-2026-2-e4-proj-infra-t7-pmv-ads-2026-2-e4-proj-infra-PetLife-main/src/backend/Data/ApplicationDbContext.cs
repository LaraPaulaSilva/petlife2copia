using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MongoDB.EntityFrameworkCore.Extensions;
using PetLife.Api.Models;

namespace PetLife.Api.Data

{
    public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : IdentityDbContext<User>(options)
    {
        public DbSet<Pet> Pets { get; set; } = null!;
        public DbSet<Treatment> Treatments { get; set; } = null!;
        public DbSet<Vaccine> Vaccines { get; set; } = null!;
        public DbSet<Document> Documents { get; set; } = null!;
        public DbSet<Consulta> Consultas { get; set; } = null!;
        public DbSet<Report> Reports { get; set; } = null!;
        public DbSet<PetDiaryEntry> PetDiaries { get; set; } = null!;
        public DbSet<EventoRotina> EventosRotina { get; set; } = null!;
        public DbSet<Notificacao> Notificacoes { get; set; } = null!;
        public DbSet<ConfiguracaoNotificacao> ConfiguracoesNotificacao { get; set; } = null!;
        public DbSet<Share> Shares { get; set; } = null!;
        public DbSet<ShareCode> ShareCodes { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<Pet>().ToCollection("pets");
            builder.Entity<Treatment>().ToCollection("tratamentos");
            builder.Entity<Vaccine>().ToCollection("vacinas");
            builder.Entity<Document>().ToCollection("documentos");
            builder.Entity<Consulta>().ToCollection("consultas");
            builder.Entity<Report>().ToCollection("reports");
            builder.Entity<PetDiaryEntry>().ToCollection("diario_pet");
            builder.Entity<EventoRotina>().ToCollection("eventos_rotina");
            builder.Entity<Notificacao>().ToCollection("notificacoes");
            builder.Entity<Share>().ToCollection("Shares");
            builder.Entity<ShareCode>().ToCollection("ShareCodes");

            // Persiste os enums como texto no MongoDB (ex: "SOLICITADA") em vez de número.
            builder.Entity<Consulta>().Property(c => c.Status).HasConversion<string>();
            builder.Entity<Consulta>().Property(c => c.OrigemRegistro).HasConversion<string>();
            builder.Entity<Vaccine>().Property(v => v.OrigemRegistro).HasConversion<string>();
        }
    }
}
