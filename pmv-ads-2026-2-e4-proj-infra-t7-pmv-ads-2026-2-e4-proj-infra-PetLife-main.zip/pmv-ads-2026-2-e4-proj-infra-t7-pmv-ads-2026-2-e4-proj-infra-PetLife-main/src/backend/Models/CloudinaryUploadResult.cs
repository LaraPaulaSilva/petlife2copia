using System.Text.Json.Serialization;

namespace PetLife.Api.Models
{
    public class CloudinaryUploadResult
    {
        [JsonPropertyName("secure_url")]
        public string SecureUrl { get; set; } = string.Empty;

        [JsonPropertyName("public_id")]
        public string PublicId { get; set; } = string.Empty;

        public CloudinaryUploadResult()
        {
        }

        public CloudinaryUploadResult(string secureUrl, string publicId)
        {
            SecureUrl = secureUrl;
            PublicId = publicId;
        }
    }
}
