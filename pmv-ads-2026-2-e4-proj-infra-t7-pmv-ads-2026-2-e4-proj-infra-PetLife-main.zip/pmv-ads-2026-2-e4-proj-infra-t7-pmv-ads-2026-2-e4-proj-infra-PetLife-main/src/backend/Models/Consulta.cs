using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace PetLife.Api.Models
{
    public enum StatusConsulta
    {
        SOLICITADA,
        CONFIRMADA,
        CANCELADA,
        REALIZADA,
        NAO_COMPARECEU
    }

    public class Consulta
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [JsonPropertyName("pet_id")]
        public string PetId { get; set; } = string.Empty;

        [JsonPropertyName("tutor_id")]
        public string? TutorId { get; set; }

        [JsonPropertyName("veterinario_id")]
        public string? VeterinarioId { get; set; }

        [JsonPropertyName("clinica")]
        public string? Clinica { get; set; }

        [Required]
        [JsonPropertyName("data")]
        public string Data { get; set; } = string.Empty;

        [JsonPropertyName("hora")]
        public string? Hora { get; set; }

        [Required]
        [JsonPropertyName("tipo_atendimento")]
        public string TipoAtendimento { get; set; } = string.Empty;

        [JsonPropertyName("motivo")]
        public string? Motivo { get; set; }

        [JsonPropertyName("status")]
        public StatusConsulta Status { get; set; } = StatusConsulta.SOLICITADA;

        [JsonPropertyName("origem_registro")]
        public OrigemRegistro OrigemRegistro { get; set; } = OrigemRegistro.VETERINARIO;

        [Required]
        [JsonPropertyName("autor_id")]
        public string AutorId { get; set; } = string.Empty;

        [JsonPropertyName("descricao_clinica")]
        public string? DescricaoClinica { get; set; }

        [JsonPropertyName("peso_kg")]
        public decimal? PesoKg { get; set; }

        [JsonPropertyName("temperatura_c")]
        public decimal? TemperaturaC { get; set; }

        [JsonPropertyName("diagnostico")]
        public string? Diagnostico { get; set; }

        [JsonPropertyName("conduta")]
        public string? Conduta { get; set; }

        [JsonPropertyName("retorno_previsto")]
        public string? RetornoPrevisto { get; set; }

        [JsonPropertyName("observacoes")]
        public string? Observacoes { get; set; }

        [JsonPropertyName("valor")]
        public decimal? Valor { get; set; }

        [JsonPropertyName("criado_em")]
        public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    }

    public class CreateConsultaDto
    {
        [Required(ErrorMessage = "O pet_id é obrigatório.")]
        [JsonPropertyName("pet_id")]
        public string PetId { get; set; } = string.Empty;

        [JsonPropertyName("tutor_id")]
        public string? TutorId { get; set; }

        [JsonPropertyName("veterinario_id")]
        public string? VeterinarioId { get; set; }

        [JsonPropertyName("clinica")]
        public string? Clinica { get; set; }

        [Required(ErrorMessage = "A data é obrigatória.")]
        [JsonPropertyName("data")]
        public string Data { get; set; } = string.Empty;

        [JsonPropertyName("hora")]
        public string? Hora { get; set; }

        [Required(ErrorMessage = "O tipo de atendimento é obrigatório.")]
        [JsonPropertyName("tipo_atendimento")]
        public string TipoAtendimento { get; set; } = string.Empty;

        [JsonPropertyName("motivo")]
        public string? Motivo { get; set; }

        [JsonPropertyName("status")]
        public StatusConsulta? Status { get; set; }

        [JsonPropertyName("origem_registro")]
        public OrigemRegistro? OrigemRegistro { get; set; }

        [Required(ErrorMessage = "O autor_id é obrigatório.")]
        [JsonPropertyName("autor_id")]
        public string AutorId { get; set; } = string.Empty;

        [JsonPropertyName("descricao_clinica")]
        public string? DescricaoClinica { get; set; }

        [JsonPropertyName("peso_kg")]
        public decimal? PesoKg { get; set; }

        [JsonPropertyName("temperatura_c")]
        public decimal? TemperaturaC { get; set; }

        [JsonPropertyName("diagnostico")]
        public string? Diagnostico { get; set; }

        [JsonPropertyName("conduta")]
        public string? Conduta { get; set; }

        [JsonPropertyName("retorno_previsto")]
        public string? RetornoPrevisto { get; set; }

        [JsonPropertyName("observacoes")]
        public string? Observacoes { get; set; }

        [JsonPropertyName("valor")]
        public decimal? Valor { get; set; }
    }

    public class UpdateConsultaDto
    {
        [JsonPropertyName("solicitante_id")]
        public string? SolicitanteId { get; set; }

        [JsonPropertyName("veterinario_id")]
        public string? VeterinarioId { get; set; }

        [JsonPropertyName("clinica")]
        public string? Clinica { get; set; }

        [JsonPropertyName("data")]
        public string? Data { get; set; }

        [JsonPropertyName("hora")]
        public string? Hora { get; set; }

        [JsonPropertyName("tipo_atendimento")]
        public string? TipoAtendimento { get; set; }

        [JsonPropertyName("motivo")]
        public string? Motivo { get; set; }

        [JsonPropertyName("status")]
        public StatusConsulta? Status { get; set; }

        [JsonPropertyName("descricao_clinica")]
        public string? DescricaoClinica { get; set; }

        [JsonPropertyName("peso_kg")]
        public decimal? PesoKg { get; set; }

        [JsonPropertyName("temperatura_c")]
        public decimal? TemperaturaC { get; set; }

        [JsonPropertyName("diagnostico")]
        public string? Diagnostico { get; set; }

        [JsonPropertyName("conduta")]
        public string? Conduta { get; set; }

        [JsonPropertyName("retorno_previsto")]
        public string? RetornoPrevisto { get; set; }

        [JsonPropertyName("observacoes")]
        public string? Observacoes { get; set; }

        [JsonPropertyName("valor")]
        public decimal? Valor { get; set; }
    }
}
