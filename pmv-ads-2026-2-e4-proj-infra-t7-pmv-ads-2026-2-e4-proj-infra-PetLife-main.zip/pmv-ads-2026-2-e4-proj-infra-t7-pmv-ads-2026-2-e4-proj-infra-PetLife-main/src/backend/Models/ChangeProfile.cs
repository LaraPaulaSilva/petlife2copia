﻿namespace PetLife.Api.Models
{
    public class ChangeProfile
    {
        public required string Name { get; set; } 
        public string? Crmv { get; set; }
        public required string Telefone { get; set; }
        public string? Cpf { get; set; }
        public required string Endereço { get; set; }
        public required string Image { get; set; }
    }
}
