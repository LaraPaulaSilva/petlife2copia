﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace PetLife.Api.Models
{
    public class ShareCode
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime ExpiresAt { get; set; } = DateTime.UtcNow.AddHours(24);
        [Required]
        [JsonPropertyName("pet_id")]
        public required string PetId { get; set; } = string.Empty;
        public string TutorId { get; set; } = string.Empty;
        public string Code {  get; set; } = Guid.NewGuid().ToString()[..8];
    }
}
