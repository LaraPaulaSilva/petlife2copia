﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace PetLife.Api.Models
{
    public class Share
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = Guid.NewGuid().ToString();
        [JsonPropertyName("criado_at")]
        public DateTime CriadoAt { get; set; } = DateTime.UtcNow;
        [Required]
        [JsonPropertyName("vet_id")]
        public string VetId { get; set; } = string.Empty;
        [Required]
        [JsonPropertyName("pet_id")]
        public string PetId { get; set; } = string.Empty;
        public string TutorId { get; set; } = string.Empty;
    }
}
