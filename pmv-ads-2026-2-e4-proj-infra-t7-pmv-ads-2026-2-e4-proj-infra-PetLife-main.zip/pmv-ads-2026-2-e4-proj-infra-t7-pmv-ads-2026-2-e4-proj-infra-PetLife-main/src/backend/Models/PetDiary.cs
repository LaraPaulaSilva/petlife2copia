using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace PetLife.Api.Models
{
    public class PetDiaryEntry
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [JsonPropertyName("pet_id")]
        public string PetId { get; set; } = string.Empty;

        [JsonPropertyName("usuario_id")]
        public string? UsuarioId { get; set; }

        [JsonPropertyName("perfil_autor")]
        public string PerfilAutor { get; set; } = "tutor";

        [Required]
        [JsonPropertyName("data_registro")]
        public string DataRegistro { get; set; } = string.Empty;

        [JsonPropertyName("tags")]
        public List<string> Tags { get; set; } = new();

        [Required]
        [JsonPropertyName("Registro")]
        public string Registro { get; set; } = string.Empty;

        [JsonPropertyName("suspeita")]
        public string? Suspeita { get; set; }

        [JsonPropertyName("criado_at")]
        public DateTime CriadoAt { get; set; } = DateTime.UtcNow;
    }

    public class CreatePetDiaryDto
    {
        [Required(ErrorMessage = "O pet_id é obrigatório.")]
        [JsonPropertyName("pet_id")]
        public string PetId { get; set; } = string.Empty;

        [JsonPropertyName("usuario_id")]
        public string? UsuarioId { get; set; }

        [JsonPropertyName("perfil_autor")]
        public string? PerfilAutor { get; set; }

        [Required(ErrorMessage = "A data de registro é obrigatória.")]
        [JsonPropertyName("data_registro")]
        public string DataRegistro { get; set; } = string.Empty;

        [JsonPropertyName("tags")]
        public List<string>? Tags { get; set; }

        [Required(ErrorMessage = "O registro/descrição é obrigatório.")]
        [JsonPropertyName("Registro")]
        public string Registro { get; set; } = string.Empty;

        [JsonPropertyName("suspeita")]
        public string? Suspeita { get; set; }

        [JsonPropertyName("criado_at")]
        public DateTime? CriadoAt { get; set; }
    }

    public class UpdatePetDiaryDto
    {
        [JsonPropertyName("data_registro")]
        public string? DataRegistro { get; set; }

        [JsonPropertyName("tags")]
        public List<string>? Tags { get; set; }

        [JsonPropertyName("Registro")]
        public string? Registro { get; set; }

        [JsonPropertyName("suspeita")]
        public string? Suspeita { get; set; }

        [JsonPropertyName("perfil_autor")]
        public string? PerfilAutor { get; set; }

        [JsonPropertyName("usuario_id")]
        public string? UsuarioId { get; set; }
    }
}
