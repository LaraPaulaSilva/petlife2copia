﻿namespace PetLife.Api.Models
{
    public class VetProfile
    {
        public required string Name { get; set; }
        public required string Image{ get; set; }
        public required string Id { get; set; }
    }
}
