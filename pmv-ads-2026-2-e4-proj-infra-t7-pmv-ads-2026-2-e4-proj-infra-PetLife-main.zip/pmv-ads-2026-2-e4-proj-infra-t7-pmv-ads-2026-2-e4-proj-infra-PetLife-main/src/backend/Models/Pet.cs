using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace PetLife.Api.Models
{
    public class Pet
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [JsonPropertyName("nome")]
        public string Nome { get; set; } = string.Empty;

        [Required]
        [JsonPropertyName("especie")]
        public string Especie { get; set; } = string.Empty;

        [JsonPropertyName("raca")]
        public string? Raca { get; set; }

        [JsonPropertyName("peso_kg")]
        public double? PesoKg { get; set; }

        [JsonPropertyName("data_nascimento")]
        public string? DataNascimento { get; set; }

        [JsonPropertyName("microchip")]
        public string? Microchip { get; set; }

        [JsonPropertyName("foto_url")]
        public string? FotoUrl { get; set; }

        [Required]
        [JsonPropertyName("tutor_id")]
        public string TutorId { get; set; } = string.Empty;

        [JsonPropertyName("criado_at")]
        public DateTime CriadoAt { get; set; } = DateTime.UtcNow;
    }

    public class SharedPetDto : Pet
    {
        [JsonPropertyName("tutor_nome")]
        public string TutorNome { get; set; } = string.Empty;
    }

    public class CreatePetDto
    {
        [Required(ErrorMessage = "O nome é obrigatório.")]
        [JsonPropertyName("nome")]
        public string Nome { get; set; } = string.Empty;

        [Required(ErrorMessage = "A espécie é obrigatória.")]
        [JsonPropertyName("especie")]
        public string Especie { get; set; } = string.Empty;

        [JsonPropertyName("raca")]
        public string? Raca { get; set; }

        [JsonPropertyName("peso_kg")]
        public double? PesoKg { get; set; }

        [JsonPropertyName("data_nascimento")]
        public string? DataNascimento { get; set; }

        [JsonPropertyName("microchip")]
        public string? Microchip { get; set; }

        [JsonPropertyName("foto_url")]
        public string? FotoUrl { get; set; }

        [JsonPropertyName("tutor_id")]
        public string? TutorId { get; set; }

        [JsonPropertyName("criado_at")]
        public DateTime? CriadoAt { get; set; }
    }

    public class UpdatePetDto
    {
        [JsonPropertyName("nome")]
        public string? Nome { get; set; }

        [JsonPropertyName("especie")]
        public string? Especie { get; set; }

        [JsonPropertyName("raca")]
        public string? Raca { get; set; }

        [JsonPropertyName("peso_kg")]
        public double? PesoKg { get; set; }

        [JsonPropertyName("data_nascimento")]
        public string? DataNascimento { get; set; }

        [JsonPropertyName("microchip")]
        public string? Microchip { get; set; }

        [JsonPropertyName("foto_url")]
        public string? FotoUrl { get; set; }

        [JsonPropertyName("tutor_id")]
        public string? TutorId { get; set; }
    }
}
