namespace PetLife.Api.Models;

public class EventoRotina
{
    public string Id { get; set; } = string.Empty;

    public string UserId { get; set; } = string.Empty;

    public string PetId { get; set; } = string.Empty;

    public string Tipo { get; set; } = string.Empty;

    public DateTime DataHora { get; set; }

    public bool Recorrente { get; set; }

    public int? IntervaloDias { get; set; }

    public string? Observacoes { get; set; }

    public string Status { get; set; } = "agendado";
}