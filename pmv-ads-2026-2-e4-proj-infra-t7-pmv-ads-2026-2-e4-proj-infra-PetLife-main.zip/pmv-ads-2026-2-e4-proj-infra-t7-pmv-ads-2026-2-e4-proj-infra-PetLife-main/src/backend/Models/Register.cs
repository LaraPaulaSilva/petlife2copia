using System.ComponentModel.DataAnnotations;

namespace PetLife.Api.Models
{
 
    public class Register
    {
        [Required(ErrorMessage = "O Email é obrigatório.")]
        [EmailAddress(ErrorMessage = "Formato de e-mail inválido.")]
        public string Email { get; set; } = string.Empty;
        [Required(ErrorMessage = "Obrigatório informar o nome!")]
        [StringLength(50)]
        public string Name { get; set; } = string.Empty;
        [Required(ErrorMessage = "A Senha é obrigatória.")]
        [StringLength(100, ErrorMessage = "A Senha deve conter entre {2} e {1} caracteres", MinimumLength = 4)]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "A Senha e a confirmação de senha não combinam.")]
        public string ConfirmPassword { get; set; } = string.Empty;
        public string Role { get; set; } = "Tutor";
        public string? Crmv { get; set; }
        public string? Telefone { get; set; }
        public string? Cpf { get; set; }
        public string? Endereço { get; set; }
        public string? Image { get; set; }


    }
}
