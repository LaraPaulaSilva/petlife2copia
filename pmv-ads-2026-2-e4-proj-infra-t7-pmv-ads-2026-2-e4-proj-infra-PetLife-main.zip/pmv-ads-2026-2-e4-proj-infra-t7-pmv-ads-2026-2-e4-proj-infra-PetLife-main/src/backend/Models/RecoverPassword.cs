﻿using System.ComponentModel.DataAnnotations;

namespace PetLife.Api.Models
{
    public class ForgotPassword
    {
        [Required(ErrorMessage = "O email é obrigatório")]
        public required string Email { get; set; }
    }

    public class ResetPassword
    {
        [Required(ErrorMessage = "O email é obrigatório")]
        public required string Email { get; set; }
        [Required(ErrorMessage = "O token é obrigatório")]
        public required string Token { get; set; }
        [Required(ErrorMessage = "A senha é obrigatória")]
        public required string Password { get; set; }
        [Compare("Password", ErrorMessage = "A Senha e a confirmação de senha não combinam.")]
        public required string ConfirmPassword { get; set; }
    }
}
