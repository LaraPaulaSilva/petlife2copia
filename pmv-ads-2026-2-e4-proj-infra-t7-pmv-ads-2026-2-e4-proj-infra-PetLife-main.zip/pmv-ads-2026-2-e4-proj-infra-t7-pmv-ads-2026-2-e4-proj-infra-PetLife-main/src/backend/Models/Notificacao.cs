using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace PetLife.Api.Models;

public class Notificacao
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    public string UserId { get; set; } = string.Empty;

    public string Titulo { get; set; } = string.Empty;

    public string Mensagem { get; set; } = string.Empty;

    public string Tipo { get; set; } = string.Empty;

    public DateTime DataHora { get; set; } = DateTime.UtcNow;

    public bool Lida { get; set; }

    public string Canal { get; set; } = string.Empty;

    public string? ReferenciaId { get; set; }
}