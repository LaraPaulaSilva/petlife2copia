namespace PetLife.Api.Models;

public class ConfiguracaoNotificacao
{
    public string Id { get; set; } = string.Empty;

    public string UserId { get; set; } = string.Empty;

    public bool EmailAtivo { get; set; } = true;

    public bool PushAtivo { get; set; } = true;

    public string? FcmToken { get; set; }
}