using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace PetLife.Api.Models
{
    public class Document
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [JsonPropertyName("pet_id")]
        public string PetId { get; set; } = string.Empty;

        [Required]
        [JsonPropertyName("usuario_id")]
        public string UsuarioId { get; set; } = string.Empty;

        [JsonPropertyName("perfil_autor")]
        public string? PerfilAutor { get; set; }

        [JsonPropertyName("consulta_id")]
        public string? ConsultaId { get; set; }

        [Required]
        [JsonPropertyName("titulo")]
        public string Titulo { get; set; } = string.Empty;

        [JsonPropertyName("tipo_doc")]
        public string? TipoDoc { get; set; }

        [Required]
        [JsonPropertyName("arquivo_url")]
        public string ArquivoUrl { get; set; } = string.Empty;

        [JsonPropertyName("data_upload")]
        public DateTime DataUpload { get; set; } = DateTime.UtcNow;
    }

    public class CreateDocumentDto
    {
        [Required(ErrorMessage = "O pet_id é obrigatório.")]
        [JsonPropertyName("pet_id")]
        public string PetId { get; set; } = string.Empty;

        [Required(ErrorMessage = "O usuario_id é obrigatório.")]
        [JsonPropertyName("usuario_id")]
        public string UsuarioId { get; set; } = string.Empty;

        [JsonPropertyName("perfil_autor")]
        public string? PerfilAutor { get; set; }

        [JsonPropertyName("consulta_id")]
        public string? ConsultaId { get; set; }

        [Required(ErrorMessage = "O título é obrigatório.")]
        [JsonPropertyName("titulo")]
        public string Titulo { get; set; } = string.Empty;

        [JsonPropertyName("tipo_doc")]
        public string? TipoDoc { get; set; }

        [Required(ErrorMessage = "A URL do arquivo é obrigatória.")]
        [JsonPropertyName("arquivo_url")]
        public string ArquivoUrl { get; set; } = string.Empty;
    }

    public class UpdateDocumentDto
    {
        [JsonPropertyName("solicitante_id")]
        public string? SolicitanteId { get; set; }

        [JsonPropertyName("consulta_id")]
        public string? ConsultaId { get; set; }

        [JsonPropertyName("titulo")]
        public string? Titulo { get; set; }

        [JsonPropertyName("tipo_doc")]
        public string? TipoDoc { get; set; }

        [JsonPropertyName("arquivo_url")]
        public string? ArquivoUrl { get; set; }
    }
}
