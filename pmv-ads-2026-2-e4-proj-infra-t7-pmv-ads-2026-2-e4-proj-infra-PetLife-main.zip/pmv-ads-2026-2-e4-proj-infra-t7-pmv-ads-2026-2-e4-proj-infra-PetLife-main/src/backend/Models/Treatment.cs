using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace PetLife.Api.Models
{
    public class DoseHistory {
        [JsonPropertyName("taken")] public bool Taken { get; set; }
        [JsonPropertyName("time")] public string? Time { get; set; }
    }

    public class Treatment {
        [JsonPropertyName("id")] public string Id { get; set; } = Guid.NewGuid().ToString();
        
        [Required]
        [JsonPropertyName("pet_id")] 
        public string PetId { get; set; } = string.Empty;
        
        [JsonPropertyName("veterinario_id")] 
        public string? VeterinarioId { get; set; }
        
        [Required]
        [JsonPropertyName("medicamento")] 
        public string Medicamento { get; set; } = string.Empty;

        [JsonPropertyName("dose")] 
        public string Dose { get; set; } = string.Empty;

        [JsonPropertyName("frequencia_horas")] 
        public int? FrequenciaHoras { get; set; }
        [JsonPropertyName("duracao_uso")] 
        public string? DuracaoUso { get; set; }
        [JsonPropertyName("recorrencia")] 
        public string? Recorrencia { get; set; }
        [JsonPropertyName("ciclos")] 
        public int? Ciclos { get; set; }
        [JsonPropertyName("data_inicio")] 
        public string DataInicio { get; set; } = string.Empty;
        [JsonPropertyName("data_fim")] 
        public string? DataFim { get; set; }
        [JsonPropertyName("ativo")] 
        public bool Ativo { get; set; } = true;
        [NotMapped]
        [JsonPropertyName("historico_doses")] 
        public Dictionary<string, List<DoseHistory>>? HistoricoDoses { get; set; }
    }
}