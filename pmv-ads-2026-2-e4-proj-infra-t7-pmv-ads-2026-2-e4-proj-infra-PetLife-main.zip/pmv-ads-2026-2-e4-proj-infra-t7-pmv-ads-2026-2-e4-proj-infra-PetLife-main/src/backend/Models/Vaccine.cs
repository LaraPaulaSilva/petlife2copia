using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace PetLife.Api.Models
{
    public enum OrigemRegistro
    {
        TUTOR,
        VETERINARIO
    }

    public class Vaccine
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [JsonPropertyName("pet_id")]
        public string PetId { get; set; } = string.Empty;

        [JsonPropertyName("veterinario_id")]
        public string? VeterinarioId { get; set; }

        [Required]
        [JsonPropertyName("tipo")]
        public string Tipo { get; set; } = string.Empty;

        [Required]
        [JsonPropertyName("data_aplicacao")]
        public string DataAplicacao { get; set; } = string.Empty;

        [JsonPropertyName("data_proxima_dose")]
        public string? DataProximaDose { get; set; }

        [JsonPropertyName("comprovante_url")]
        public string? ComprovanteUrl { get; set; }

        [JsonPropertyName("lote")]
        public string? Lote { get; set; }

        [JsonPropertyName("fabricante")]
        public string? Fabricante { get; set; }

        [JsonPropertyName("laboratorio")]
        public string? Laboratorio { get; set; }

        [JsonPropertyName("dose")]
        public string? Dose { get; set; }

        [JsonPropertyName("via_administracao")]
        public string? ViaAdministracao { get; set; }

        [JsonPropertyName("local_aplicacao")]
        public string? LocalAplicacao { get; set; }

        [JsonPropertyName("situacao")]
        public string? Situacao { get; set; }

        [JsonPropertyName("origem_registro")]
        public OrigemRegistro OrigemRegistro { get; set; } = OrigemRegistro.VETERINARIO;

        [JsonPropertyName("alerta_reforco")]
        public bool AlertaReforco { get; set; } = true;

        [JsonPropertyName("observacoes")]
        public string? Observacoes { get; set; }

        [JsonPropertyName("criado_at")]
        public DateTime CriadoAt { get; set; } = DateTime.UtcNow;
    }

    public class CreateVaccineDto
    {
        [Required(ErrorMessage = "O pet_id é obrigatório.")]
        [JsonPropertyName("pet_id")]
        public string PetId { get; set; } = string.Empty;

        [JsonPropertyName("veterinario_id")]
        public string? VeterinarioId { get; set; }

        [Required(ErrorMessage = "O tipo da vacina é obrigatório.")]
        [JsonPropertyName("tipo")]
        public string Tipo { get; set; } = string.Empty;

        [Required(ErrorMessage = "A data de aplicação é obrigatória.")]
        [JsonPropertyName("data_aplicacao")]
        public string DataAplicacao { get; set; } = string.Empty;

        [JsonPropertyName("intervalo_reforco_dias")]
        public int? IntervaloReforcoDias { get; set; }

        [JsonPropertyName("data_proxima_dose")]
        public string? DataProximaDose { get; set; }

        [JsonPropertyName("comprovante_url")]
        public string? ComprovanteUrl { get; set; }

        [JsonPropertyName("lote")]
        public string? Lote { get; set; }

        [JsonPropertyName("fabricante")]
        public string? Fabricante { get; set; }

        [JsonPropertyName("laboratorio")]
        public string? Laboratorio { get; set; }

        [JsonPropertyName("dose")]
        public string? Dose { get; set; }

        [JsonPropertyName("via_administracao")]
        public string? ViaAdministracao { get; set; }

        [JsonPropertyName("local_aplicacao")]
        public string? LocalAplicacao { get; set; }

        [JsonPropertyName("situacao")]
        public string? Situacao { get; set; }

        [JsonPropertyName("origem_registro")]
        public OrigemRegistro? OrigemRegistro { get; set; }

        [JsonPropertyName("alerta_reforco")]
        public bool? AlertaReforco { get; set; }

        [JsonPropertyName("observacoes")]
        public string? Observacoes { get; set; }
    }

    public class UpdateVaccineDto
    {
        [JsonPropertyName("veterinario_id")]
        public string? VeterinarioId { get; set; }

        [JsonPropertyName("tipo")]
        public string? Tipo { get; set; }

        [JsonPropertyName("data_aplicacao")]
        public string? DataAplicacao { get; set; }

        [JsonPropertyName("data_proxima_dose")]
        public string? DataProximaDose { get; set; }

        [JsonPropertyName("comprovante_url")]
        public string? ComprovanteUrl { get; set; }

        [JsonPropertyName("lote")]
        public string? Lote { get; set; }

        [JsonPropertyName("fabricante")]
        public string? Fabricante { get; set; }

        [JsonPropertyName("laboratorio")]
        public string? Laboratorio { get; set; }

        [JsonPropertyName("dose")]
        public string? Dose { get; set; }

        [JsonPropertyName("via_administracao")]
        public string? ViaAdministracao { get; set; }

        [JsonPropertyName("local_aplicacao")]
        public string? LocalAplicacao { get; set; }

        [JsonPropertyName("situacao")]
        public string? Situacao { get; set; }

        [JsonPropertyName("alerta_reforco")]
        public bool? AlertaReforco { get; set; }

        [JsonPropertyName("observacoes")]
        public string? Observacoes { get; set; }
    }
}
