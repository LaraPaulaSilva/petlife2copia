﻿using System.ComponentModel.DataAnnotations;

namespace PetLife.Api.Models
{
    public class ChangePassword
    {
        [Required(ErrorMessage = "A Senha atual é obrigatória.")]
        [DataType(DataType.Password)]
        public string CurrentPassword { get; set; } = string.Empty;
        [Required(ErrorMessage = "A Senha nova é obrigatória.")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; } = string.Empty;
        [DataType(DataType.Password)]
        [Compare("NewPassword", ErrorMessage = "A Senha nova e a confirmação de senha não combinam.")]
        public string ConfirmPassword { get; set; } = string.Empty;

    }
}
