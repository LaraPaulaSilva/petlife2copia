using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace PetLife.Api.Models
{
    public class Report {
        [JsonPropertyName("id")] 
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [JsonPropertyName("user_id")] 
        public string UserId { get; set; } = string.Empty;

        [Required]
        [JsonPropertyName("name")] 
        public string Name { get; set; } = string.Empty; // Ex: "Consultas deste Mês", "Tratamentos Pendentes"

        [Required]
        [JsonPropertyName("type")] 
        public string Type { get; set; } = string.Empty; // Ex: "consultas", "tratamentos", "vacinas"

        [JsonPropertyName("created_at")] 
        public string CreatedAt { get; set; } = DateTime.UtcNow.ToString("o");

        [NotMapped]
        [JsonPropertyName("filters")] 
        public Dictionary<string, string>? Filters { get; set; }
    }
}