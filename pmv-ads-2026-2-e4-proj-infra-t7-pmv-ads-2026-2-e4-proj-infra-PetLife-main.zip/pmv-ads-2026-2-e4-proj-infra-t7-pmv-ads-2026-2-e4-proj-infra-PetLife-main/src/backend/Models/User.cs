using Microsoft.AspNetCore.Identity;

namespace PetLife.Api.Models
{
    public class User : IdentityUser
    {
        public required string Name { get; set; }
        public string? Crmv { get; set; }
        public string? Cpf { get; set; }
        public string? Endereço { get; set; }
        public string? Image { get; set; }
    }

    public class EditUser
    {
        public required string Name { get; set; }
        public string? Crmv { get; set; }
        public string? Cpf { get; set; }
        public string? Endereço { get; set; }
        public string? Email { get; set; }
        public string? Image { get; set; }
    }
}

