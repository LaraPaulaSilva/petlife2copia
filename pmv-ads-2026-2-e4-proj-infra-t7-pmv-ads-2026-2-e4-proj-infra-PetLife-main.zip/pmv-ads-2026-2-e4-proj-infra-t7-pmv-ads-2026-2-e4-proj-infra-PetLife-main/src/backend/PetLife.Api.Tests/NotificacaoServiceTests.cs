using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Moq;
using PetLife.Api.Data;
using PetLife.Api.Models;
using PetLife.Api.Services;
using Xunit;

namespace PetLife.Api.Tests
{
    public class NotificacaoServiceTests
    {
        // Cria um ApplicationDbContext novo e isolado (InMemory) para cada teste
        private static ApplicationDbContext CriarContexto()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            return new ApplicationDbContext(options);
        }

        // Mock padrão do IMailService (não envia e-mail de verdade)
        private static Mock<IMailService> CriarMailServiceMock()
        {
            var mock = new Mock<IMailService>();
            mock.Setup(m => m.SendEmailAsync(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<bool>()))
                .Returns(Task.CompletedTask);
            return mock;
        }

        // Cria uma notificação válida
        private static Notificacao CriarNotificacao(string id, string userId, bool lida = false, string canal = "push")
        {
            return new Notificacao
            {
                Id = id,
                UserId = userId,
                Titulo = "Novo agendamento: Tosa",
                Mensagem = "Tosa agendado para 10/10/2026 00:30",
                Tipo = "Tosa",
                DataHora = DateTime.UtcNow,
                Lida = lida,
                Canal = canal,
                ReferenciaId = "ref-123"
            };
        }

        // ======================================================
        // CriarAsync
        // ======================================================

        [Fact]
        public async Task CriarAsync_ComEmailEPushAtivos_DeveCriarDuasNotificacoes()
        {
            using var ctx = CriarContexto();
            var mailMock = CriarMailServiceMock();

            // config com e-mail e push ativos (padrao do model e true/true)
            ctx.ConfiguracoesNotificacao.Add(new ConfiguracaoNotificacao
            {
                Id = "cfg-1",
                UserId = "user-1",
                EmailAtivo = true,
                PushAtivo = true
            });
            await ctx.SaveChangesAsync();

            var service = new NotificacaoService(ctx, mailMock.Object);

            await service.CriarAsync("user-1", "Titulo", "Mensagem", "Tosa", "ref-1");

            var notificacoes = await ctx.Notificacoes.ToListAsync();
            Assert.Equal(2, notificacoes.Count);
            Assert.Contains(notificacoes, n => n.Canal == "email");
            Assert.Contains(notificacoes, n => n.Canal == "push");
        }

        [Fact]
        public async Task CriarAsync_SemConfiguracao_DeveUsarPadraoEcriarDuasNotificacoes()
        {
            // Sem config no banco -> o service cria uma com os defaults (EmailAtivo=true, PushAtivo=true)
            using var ctx = CriarContexto();
            var mailMock = CriarMailServiceMock();
            var service = new NotificacaoService(ctx, mailMock.Object);

            await service.CriarAsync("user-sem-config", "Titulo", "Mensagem", "Tosa", null);

            var notificacoes = await ctx.Notificacoes.ToListAsync();
            Assert.Equal(2, notificacoes.Count);
        }

        [Fact]
        public async Task CriarAsync_ApenasEmailAtivo_DeveCriarSomenteNotificacaoEmail()
        {
            using var ctx = CriarContexto();
            var mailMock = CriarMailServiceMock();

            ctx.ConfiguracoesNotificacao.Add(new ConfiguracaoNotificacao
            {
                Id = "cfg-2",
                UserId = "user-2",
                EmailAtivo = true,
                PushAtivo = false
            });
            await ctx.SaveChangesAsync();

            var service = new NotificacaoService(ctx, mailMock.Object);

            await service.CriarAsync("user-2", "Titulo", "Mensagem", "Tosa", null);

            var notificacoes = await ctx.Notificacoes.ToListAsync();
            Assert.Single(notificacoes);
            Assert.Equal("email", notificacoes[0].Canal);
        }

        [Fact]
        public async Task CriarAsync_ApenasPushAtivo_DeveCriarSomenteNotificacaoPush()
        {
            using var ctx = CriarContexto();
            var mailMock = CriarMailServiceMock();

            ctx.ConfiguracoesNotificacao.Add(new ConfiguracaoNotificacao
            {
                Id = "cfg-3",
                UserId = "user-3",
                EmailAtivo = false,
                PushAtivo = true
            });
            await ctx.SaveChangesAsync();

            var service = new NotificacaoService(ctx, mailMock.Object);

            await service.CriarAsync("user-3", "Titulo", "Mensagem", "Tosa", null);

            var notificacoes = await ctx.Notificacoes.ToListAsync();
            Assert.Single(notificacoes);
            Assert.Equal("push", notificacoes[0].Canal);
        }

        [Fact]
        public async Task CriarAsync_ComEmailAtivoEUsuarioComEmail_DeveEnviarEmail()
        {
            using var ctx = CriarContexto();
            var mailMock = CriarMailServiceMock();

            ctx.ConfiguracoesNotificacao.Add(new ConfiguracaoNotificacao
            {
                Id = "cfg-4",
                UserId = "user-4",
                EmailAtivo = true,
                PushAtivo = false
            });
            ctx.Users.Add(new User
            {
                Id = "user-4",
                Name = "Lara Maria",
                Email = "lara@petlife.com",
                UserName = "lara@petlife.com"
            });
            await ctx.SaveChangesAsync();

            var service = new NotificacaoService(ctx, mailMock.Object);

            await service.CriarAsync("user-4", "Titulo", "Mensagem", "Tosa", null);

            // Verifica que o e-mail foi disparado uma vez
            mailMock.Verify(m => m.SendEmailAsync(
                "lara@petlife.com", "Titulo", "Mensagem", false), Times.Once);
        }

        // ======================================================
        // GetByUserAsync
        // ======================================================

        [Fact]
        public async Task GetByUserAsync_DeveRetornarApenasNotificacoesDoUsuario()
        {
            using var ctx = CriarContexto();
            ctx.Notificacoes.AddRange(
                CriarNotificacao("n1", "user-1"),
                CriarNotificacao("n2", "user-1"),
                CriarNotificacao("n3", "user-2")
            );
            await ctx.SaveChangesAsync();

            var service = new NotificacaoService(ctx, CriarMailServiceMock().Object);

            var resultado = (await service.GetByUserAsync("user-1")).ToList();

            Assert.Equal(2, resultado.Count);
            Assert.All(resultado, n => Assert.Equal("user-1", n.UserId));
        }

        [Fact]
        public async Task GetByUserAsync_DeveOrdenarPorDataHoraDecrescente()
        {
            using var ctx = CriarContexto();

            var antiga = CriarNotificacao("n1", "user-1");
            antiga.DataHora = new DateTime(2026, 1, 1, 10, 0, 0, DateTimeKind.Utc);

            var recente = CriarNotificacao("n2", "user-1");
            recente.DataHora = new DateTime(2026, 10, 11, 10, 0, 0, DateTimeKind.Utc);

            ctx.Notificacoes.AddRange(antiga, recente);
            await ctx.SaveChangesAsync();

            var service = new NotificacaoService(ctx, CriarMailServiceMock().Object);

            var resultado = (await service.GetByUserAsync("user-1")).ToList();

            Assert.Equal("n2", resultado[0].Id); // mais recente primeiro
            Assert.Equal("n1", resultado[1].Id);
        }

        [Fact]
        public async Task GetByUserAsync_SemNotificacoes_DeveRetornarListaVazia()
        {
            using var ctx = CriarContexto();
            var service = new NotificacaoService(ctx, CriarMailServiceMock().Object);

            var resultado = await service.GetByUserAsync("user-inexistente");

            Assert.Empty(resultado);
        }

        // ======================================================
        // MarcarComoLidaAsync
        // ======================================================

        [Fact]
        public async Task MarcarComoLidaAsync_NotificacaoExistente_DeveMarcarComoLidaERetornarTrue()
        {
            using var ctx = CriarContexto();
            ctx.Notificacoes.Add(CriarNotificacao("n1", "user-1", lida: false));
            await ctx.SaveChangesAsync();

            var service = new NotificacaoService(ctx, CriarMailServiceMock().Object);

            var resultado = await service.MarcarComoLidaAsync("n1");

            Assert.True(resultado);
            var persistida = await ctx.Notificacoes.FirstAsync(n => n.Id == "n1");
            Assert.True(persistida.Lida);
        }

        [Fact]
        public async Task MarcarComoLidaAsync_NotificacaoInexistente_DeveRetornarFalse()
        {
            using var ctx = CriarContexto();
            var service = new NotificacaoService(ctx, CriarMailServiceMock().Object);

            var resultado = await service.MarcarComoLidaAsync("id-inexistente");

            Assert.False(resultado);
        }

        // ======================================================
        // DeleteAsync
        // ======================================================

        [Fact]
        public async Task DeleteAsync_NotificacaoExistente_DeveRemoverERetornarTrue()
        {
            using var ctx = CriarContexto();
            ctx.Notificacoes.Add(CriarNotificacao("n1", "user-1"));
            await ctx.SaveChangesAsync();

            var service = new NotificacaoService(ctx, CriarMailServiceMock().Object);

            var resultado = await service.DeleteAsync("n1");

            Assert.True(resultado);
            Assert.Empty(await ctx.Notificacoes.ToListAsync());
        }

        [Fact]
        public async Task DeleteAsync_NotificacaoInexistente_DeveRetornarFalse()
        {
            using var ctx = CriarContexto();
            var service = new NotificacaoService(ctx, CriarMailServiceMock().Object);

            var resultado = await service.DeleteAsync("id-inexistente");

            Assert.False(resultado);
        }

        // ======================================================
        // ObterPreferenciasAsync
        // ======================================================

        [Fact]
        public async Task ObterPreferenciasAsync_ComConfiguracaoExistente_DeveRetornarConfiguracao()
        {
            using var ctx = CriarContexto();
            ctx.ConfiguracoesNotificacao.Add(new ConfiguracaoNotificacao
            {
                Id = "cfg-1",
                UserId = "user-1",
                EmailAtivo = false,
                PushAtivo = true,
                FcmToken = "token-abc"
            });
            await ctx.SaveChangesAsync();

            var service = new NotificacaoService(ctx, CriarMailServiceMock().Object);

            var config = await service.ObterPreferenciasAsync("user-1");

            Assert.Equal("user-1", config.UserId);
            Assert.False(config.EmailAtivo);
            Assert.True(config.PushAtivo);
            Assert.Equal("token-abc", config.FcmToken);
        }

        [Fact]
        public async Task ObterPreferenciasAsync_SemConfiguracao_DeveRetornarPadraoComUserId()
        {
            using var ctx = CriarContexto();
            var service = new NotificacaoService(ctx, CriarMailServiceMock().Object);

            var config = await service.ObterPreferenciasAsync("user-novo");

            Assert.Equal("user-novo", config.UserId);
            Assert.True(config.EmailAtivo); // defaults do model
            Assert.True(config.PushAtivo);
        }

        // ======================================================
        // SalvarPreferenciasAsync
        // ======================================================

        [Fact]
        public async Task SalvarPreferenciasAsync_SemConfiguracaoExistente_DeveCriarNovaComId()
        {
            using var ctx = CriarContexto();
            var service = new NotificacaoService(ctx, CriarMailServiceMock().Object);

            var nova = new ConfiguracaoNotificacao
            {
                UserId = "user-1",
                EmailAtivo = false,
                PushAtivo = true,
                FcmToken = "token-xyz"
            };

            var salvo = await service.SalvarPreferenciasAsync(nova);

            Assert.False(string.IsNullOrEmpty(salvo.Id)); // Id foi gerado
            Assert.Single(await ctx.ConfiguracoesNotificacao.ToListAsync());
            Assert.Equal("token-xyz", salvo.FcmToken);
        }

        [Fact]
        public async Task SalvarPreferenciasAsync_ComConfiguracaoExistente_DeveAtualizarCampos()
        {
            using var ctx = CriarContexto();
            ctx.ConfiguracoesNotificacao.Add(new ConfiguracaoNotificacao
            {
                Id = "cfg-1",
                UserId = "user-1",
                EmailAtivo = true,
                PushAtivo = true,
                FcmToken = "token-antigo"
            });
            await ctx.SaveChangesAsync();

            var service = new NotificacaoService(ctx, CriarMailServiceMock().Object);

            var atualizacao = new ConfiguracaoNotificacao
            {
                UserId = "user-1",
                EmailAtivo = false,
                PushAtivo = false,
                FcmToken = "token-novo"
            };

            var salvo = await service.SalvarPreferenciasAsync(atualizacao);

            Assert.Equal("cfg-1", salvo.Id); // manteve o mesmo registro
            Assert.False(salvo.EmailAtivo);
            Assert.False(salvo.PushAtivo);
            Assert.Equal("token-novo", salvo.FcmToken);
            Assert.Single(await ctx.ConfiguracoesNotificacao.ToListAsync()); // nao duplicou
        }
    }
}
