using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;
using PetLife.Api.Services;
using Xunit;

namespace PetLife.Api.Tests
{
    public class ConsultaServiceTests : IDisposable
    {
        private readonly ApplicationDbContext _context;
        private readonly ConsultaService _service;

        public ConsultaServiceTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationDbContext(options);
            _service = new ConsultaService(_context);

            // Pet e usuários referenciados pelos testes precisam existir (validação de referência).
            _context.Pets.Add(new Pet { Id = "pet-1", Nome = "Rex", Especie = "Cão", TutorId = "tutor-1" });
            _context.Users.AddRange(
                new User { Id = "vet-1", Name = "Vet Teste", UserName = "vet1@test.com", Email = "vet1@test.com" },
                new User { Id = "tutor-1", Name = "Tutor Teste", UserName = "tutor1@test.com", Email = "tutor1@test.com" }
            );
            _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
            GC.SuppressFinalize(this);
        }

        [Fact]
        public async Task GetAllAsync_ComPetId_DeveFiltrarPorPet()
        {
            _context.Consultas.AddRange(
                new Consulta { PetId = "pet-1", AutorId = "u1", TipoAtendimento = "consulta", Data = "2024-01-10" },
                new Consulta { PetId = "pet-2", AutorId = "u1", TipoAtendimento = "cirurgia", Data = "2024-02-10" }
            );
            await _context.SaveChangesAsync();

            var consultas = await _service.GetAllAsync("pet-1");

            Assert.Single(consultas);
        }

        [Fact]
        public async Task CreateAsync_DadosValidos_DeveSalvar()
        {
            var dto = new CreateConsultaDto
            {
                PetId = "pet-1",
                AutorId = "vet-1",
                OrigemRegistro = OrigemRegistro.VETERINARIO,
                TipoAtendimento = "  consulta  ",
                Data = "2024-05-01",
                DescricaoClinica = "  Diagnostico X  "
            };

            var consulta = await _service.CreateAsync(dto);

            Assert.Equal("consulta", consulta.TipoAtendimento);
            Assert.Equal("Diagnostico X", consulta.DescricaoClinica);
            Assert.Equal(StatusConsulta.SOLICITADA, consulta.Status);
        }

        [Fact]
        public async Task CreateAsync_SemTipoAtendimento_DeveLancarArgumentException()
        {
            var dto = new CreateConsultaDto { PetId = "pet-1", AutorId = "u1", TipoAtendimento = "", Data = "2024-05-01" };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.CreateAsync(dto));
        }

        [Fact]
        public async Task CreateAsync_TutorComDescricaoClinica_DeveLancarUnauthorized()
        {
            var dto = new CreateConsultaDto
            {
                PetId = "pet-1",
                AutorId = "tutor-1",
                OrigemRegistro = OrigemRegistro.TUTOR,
                TipoAtendimento = "consulta",
                Data = "2024-05-01",
                DescricaoClinica = "diagnostico indevido"
            };

            await Assert.ThrowsAsync<UnauthorizedAccessException>(() => _service.CreateAsync(dto));
        }

        [Fact]
        public async Task UpdateAsync_AutorDiferente_DeveLancarUnauthorized()
        {
            var consulta = new Consulta { PetId = "pet-1", AutorId = "u1", TipoAtendimento = "consulta", Data = "2024-01-01" };
            _context.Consultas.Add(consulta);
            await _context.SaveChangesAsync();

            var dto = new UpdateConsultaDto { SolicitanteId = "outro", Motivo = "hack" };

            await Assert.ThrowsAsync<UnauthorizedAccessException>(() => _service.UpdateAsync(consulta.Id, dto));
        }

        [Fact]
        public async Task UpdateAsync_MesmoAutor_DeveAtualizar()
        {
            var consulta = new Consulta { PetId = "pet-1", AutorId = "u1", TipoAtendimento = "consulta", Data = "2024-01-01" };
            _context.Consultas.Add(consulta);
            await _context.SaveChangesAsync();

            var dto = new UpdateConsultaDto { SolicitanteId = "u1", TipoAtendimento = "cirurgia", Status = StatusConsulta.CONFIRMADA };
            var result = await _service.UpdateAsync(consulta.Id, dto);

            Assert.NotNull(result);
            Assert.Equal("cirurgia", result.TipoAtendimento);
            Assert.Equal(StatusConsulta.CONFIRMADA, result.Status);
        }

        [Fact]
        public async Task UpdateAsync_TutorTentaEditarDescricaoClinica_DeveLancarUnauthorized()
        {
            var consulta = new Consulta
            {
                PetId = "pet-1",
                AutorId = "tutor-1",
                TipoAtendimento = "consulta",
                Data = "2024-01-01",
                OrigemRegistro = OrigemRegistro.TUTOR
            };
            _context.Consultas.Add(consulta);
            await _context.SaveChangesAsync();

            var dto = new UpdateConsultaDto { SolicitanteId = "tutor-1", DescricaoClinica = "tentativa" };

            await Assert.ThrowsAsync<UnauthorizedAccessException>(() => _service.UpdateAsync(consulta.Id, dto));
        }

        [Fact]
        public async Task DeleteAsync_ConsultaRealizada_DeveLancarInvalidOperation()
        {
            var consulta = new Consulta
            {
                PetId = "pet-1",
                AutorId = "u1",
                TipoAtendimento = "consulta",
                Data = "2024-01-01",
                Status = StatusConsulta.REALIZADA
            };
            _context.Consultas.Add(consulta);
            await _context.SaveChangesAsync();

            await Assert.ThrowsAsync<InvalidOperationException>(() => _service.DeleteAsync(consulta.Id, "u1"));
        }

        [Fact]
        public async Task DeleteAsync_AutorDiferente_DeveLancarUnauthorized()
        {
            var consulta = new Consulta { PetId = "pet-1", AutorId = "u1", TipoAtendimento = "consulta", Data = "2024-01-01" };
            _context.Consultas.Add(consulta);
            await _context.SaveChangesAsync();

            await Assert.ThrowsAsync<UnauthorizedAccessException>(() => _service.DeleteAsync(consulta.Id, "outro"));
        }

        [Fact]
        public async Task DeleteAsync_MesmoAutorNaoRealizada_DeveRemover()
        {
            var consulta = new Consulta { PetId = "pet-1", AutorId = "u1", TipoAtendimento = "consulta", Data = "2024-01-01" };
            _context.Consultas.Add(consulta);
            await _context.SaveChangesAsync();

            var result = await _service.DeleteAsync(consulta.Id, "u1");

            Assert.True(result);
            Assert.Null(await _context.Consultas.FindAsync(consulta.Id));
        }
    }
}
