using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Moq;
using PetLife.Api.Models;
using PetLife.Api.Services;
using Xunit;

namespace PetLife.Api.Tests
{
    public class CloudinaryServiceTests
    {
        [Fact]
        public void Construtor_ConfiguracaoAusente_DeveLancarInvalidOperationException()
        {
            var options = Options.Create(new CloudinarySettings());

            var ex = Assert.Throws<InvalidOperationException>(() => new CloudinaryService(options));
            Assert.Contains("Cloudinary não configurado", ex.Message);
        }

        [Fact]
        public void Construtor_ConfiguracaoValida_DeveInstanciarComSucesso()
        {
            var options = Options.Create(new CloudinarySettings
            {
                CloudName = "test_cloud",
                ApiKey = "123456789",
                ApiSecret = "secret_key"
            });

            var service = new CloudinaryService(options);
            Assert.NotNull(service);
        }

        [Fact]
        public async Task UploadImageAsync_ArquivoNulo_DeveLancarArgumentException()
        {
            var options = Options.Create(new CloudinarySettings
            {
                CloudName = "test_cloud",
                ApiKey = "123456789",
                ApiSecret = "secret_key"
            });
            var service = new CloudinaryService(options);

            await Assert.ThrowsAsync<ArgumentException>(() => service.UploadImageAsync((IFormFile)null!));
        }

        [Fact]
        public async Task UploadImageAsync_ArquivoVazio_DeveLancarArgumentException()
        {
            var options = Options.Create(new CloudinarySettings
            {
                CloudName = "test_cloud",
                ApiKey = "123456789",
                ApiSecret = "secret_key"
            });
            var service = new CloudinaryService(options);

            var fileMock = new Mock<IFormFile>();
            fileMock.Setup(f => f.Length).Returns(0);

            await Assert.ThrowsAsync<ArgumentException>(() => service.UploadImageAsync(fileMock.Object));
        }

        [Fact]
        public async Task DeleteImageAsync_PublicIdVazio_DeveRetornarFalse()
        {
            var options = Options.Create(new CloudinarySettings
            {
                CloudName = "test_cloud",
                ApiKey = "123456789",
                ApiSecret = "secret_key"
            });
            var service = new CloudinaryService(options);

            var result = await service.DeleteImageAsync("   ");
            Assert.False(result);
        }
    }
}
