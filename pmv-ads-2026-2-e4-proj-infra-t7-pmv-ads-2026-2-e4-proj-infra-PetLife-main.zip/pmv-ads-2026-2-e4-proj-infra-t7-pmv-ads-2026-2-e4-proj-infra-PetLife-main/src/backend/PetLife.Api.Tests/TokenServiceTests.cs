using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.Extensions.Configuration;
using PetLife.Api.Models;
using PetLife.Api.Services;
using Xunit;

namespace PetLife.Api.Tests
{
    public class TokenServiceTests
    {
        private readonly IConfiguration _configuration;
        private readonly TokenService _tokenService;

        public TokenServiceTests()
        {
            var inMemorySettings = new Dictionary<string, string?>
            {
                { "Jwt:Secret", "ChaveSuperSecretaComMaisDeTrintaEDoisCaracteres12345!" },
                { "Jwt:Issuer", "PetLifeApiTest" },
                { "Jwt:Audience", "PetLifeClientsTest" },
                { "Jwt:ExpirationInHours", "12" }
            };

            _configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            _tokenService = new TokenService(_configuration);
        }

        [Fact]
        public void GenerateToken_ComUsuarioTutor_DeveGerarJwtValidoComClaimsCorretas()
        {
            var user = new User
            {
                Id = "tutor-guid-123",
                Name = "Lucas Costa",
                Email = "lucas@petlife.com"
            };

            var token = _tokenService.GenerateToken(user, "Tutor");

            Assert.False(string.IsNullOrWhiteSpace(token));

            var handler = new JwtSecurityTokenHandler();
            Assert.True(handler.CanReadToken(token));

            var jwtToken = handler.ReadJwtToken(token);
            Assert.Equal("PetLifeApiTest", jwtToken.Issuer);
            Assert.Contains("PetLifeClientsTest", jwtToken.Audiences);

            var nameIdentifierClaim = jwtToken.Claims.FirstOrDefault(c =>
                c.Type == ClaimTypes.NameIdentifier || c.Type == "nameid" || c.Type == "sub");
            Assert.NotNull(nameIdentifierClaim);
            Assert.Equal("tutor-guid-123", nameIdentifierClaim.Value);

            var nameClaim = jwtToken.Claims.FirstOrDefault(c =>
                c.Type == ClaimTypes.Name || c.Type == "unique_name");
            Assert.NotNull(nameClaim);
            Assert.Equal("Lucas Costa", nameClaim.Value);

            var emailClaim = jwtToken.Claims.FirstOrDefault(c =>
                c.Type == ClaimTypes.Email || c.Type == "email");
            Assert.NotNull(emailClaim);
            Assert.Equal("lucas@petlife.com", emailClaim.Value);

            var roleClaim = jwtToken.Claims.FirstOrDefault(c =>
                c.Type == ClaimTypes.Role || c.Type == "role");
            Assert.NotNull(roleClaim);
            Assert.Equal("Tutor", roleClaim.Value);
        }

        [Fact]
        public void GenerateToken_ComUsuarioVeterinarioECrmv_DeveIncluirClaimCrmvERoleVeterinario()
        {
            var user = new User
            {
                Id = "vet-guid-456",
                Name = "Dra. Paula",
                Email = "paula.vet@petlife.com",
                Crmv = "MG-98765"
            };

            var token = _tokenService.GenerateToken(user, "Veterinário");

            var handler = new JwtSecurityTokenHandler();
            var jwtToken = handler.ReadJwtToken(token);

            var roleClaim = jwtToken.Claims.FirstOrDefault(c =>
                c.Type == ClaimTypes.Role || c.Type == "role");
            Assert.NotNull(roleClaim);
            Assert.Equal("Veterinário", roleClaim.Value);

            var crmvClaim = jwtToken.Claims.FirstOrDefault(c => c.Type == "crmv");
            Assert.NotNull(crmvClaim);
            Assert.Equal("MG-98765", crmvClaim.Value);
        }

        [Fact]
        public void GetExpirationDate_DeveRetornarDataFuturaConformeConfiguracao()
        {
            var agora = DateTime.UtcNow;
            var expiracao = _tokenService.GetExpirationDate();

            Assert.True(expiracao > agora);
            var diferencaHoras = (expiracao - agora).TotalHours;
            Assert.InRange(diferencaHoras, 11.9, 12.1);
        }
    }
}
