using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;
using PetLife.Api.Services;
using Xunit;

namespace PetLife.Api.Tests
{
    public class VaccineServiceTests : IDisposable
    {
        private readonly ApplicationDbContext _context;
        private readonly VaccineService _service;

        public VaccineServiceTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationDbContext(options);
            _service = new VaccineService(_context);

            // Pet referenciado pelos testes precisa existir (validação de referência).
            _context.Pets.Add(new Pet { Id = "pet-1", Nome = "Rex", Especie = "Cão", TutorId = "tutor-1" });
            _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
            GC.SuppressFinalize(this);
        }

        [Fact]
        public async Task GetAllAsync_ComPetId_DeveFiltrarPorPet()
        {
            _context.Vaccines.AddRange(
                new Vaccine { PetId = "pet-1", Tipo = "V8", DataAplicacao = "2024-01-10" },
                new Vaccine { PetId = "pet-1", Tipo = "Antirrábica", DataAplicacao = "2024-02-10" },
                new Vaccine { PetId = "pet-2", Tipo = "V8", DataAplicacao = "2024-03-10" }
            );
            await _context.SaveChangesAsync();

            var vaccines = await _service.GetAllAsync("pet-1");

            Assert.Equal(2, vaccines.Count());
            Assert.All(vaccines, v => Assert.Equal("pet-1", v.PetId));
        }

        [Fact]
        public async Task CreateAsync_DadosValidos_DeveSalvarVacina()
        {
            var dto = new CreateVaccineDto
            {
                PetId = "pet-1",
                Tipo = "  V10  ",
                DataAplicacao = "2024-05-01",
                Lote = "  L123  ",
                Fabricante = "  Zoetis  ",
                OrigemRegistro = OrigemRegistro.VETERINARIO
            };

            var vaccine = await _service.CreateAsync(dto);

            Assert.NotNull(vaccine);
            Assert.Equal("V10", vaccine.Tipo);
            Assert.Equal("L123", vaccine.Lote);
            Assert.Equal("Zoetis", vaccine.Fabricante);
            Assert.Equal(OrigemRegistro.VETERINARIO, vaccine.OrigemRegistro);
        }

        [Fact]
        public async Task CreateAsync_SemTipo_DeveLancarArgumentException()
        {
            var dto = new CreateVaccineDto { PetId = "pet-1", Tipo = "", DataAplicacao = "2024-05-01" };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.CreateAsync(dto));
        }

        [Fact]
        public async Task CreateAsync_ComIntervaloReforco_DeveCalcularProximaDose()
        {
            var dto = new CreateVaccineDto
            {
                PetId = "pet-1",
                Tipo = "Antirrábica",
                DataAplicacao = "2024-01-01",
                IntervaloReforcoDias = 365
            };

            var vaccine = await _service.CreateAsync(dto);

            Assert.Equal("2024-12-31", vaccine.DataProximaDose);
        }

        [Fact]
        public async Task CreateAsync_TutorComDataFutura_DeveLancarArgumentException()
        {
            // Regra: tutor só cadastra registros históricos.
            var dataFutura = DateTime.UtcNow.Date.AddDays(10).ToString("yyyy-MM-dd");
            var dto = new CreateVaccineDto
            {
                PetId = "pet-1",
                Tipo = "V8",
                DataAplicacao = dataFutura,
                OrigemRegistro = OrigemRegistro.TUTOR
            };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.CreateAsync(dto));
        }

        [Fact]
        public async Task CreateAsync_TutorComDataPassada_DevePermitir()
        {
            var dataPassada = DateTime.UtcNow.Date.AddDays(-30).ToString("yyyy-MM-dd");
            var dto = new CreateVaccineDto
            {
                PetId = "pet-1",
                Tipo = "V8",
                DataAplicacao = dataPassada,
                OrigemRegistro = OrigemRegistro.TUTOR
            };

            var vaccine = await _service.CreateAsync(dto);

            Assert.NotNull(vaccine);
            Assert.Equal(OrigemRegistro.TUTOR, vaccine.OrigemRegistro);
        }

        [Fact]
        public async Task UpdateAsync_VacinaExistente_DeveAtualizarCampos()
        {
            var vaccine = new Vaccine { PetId = "pet-1", Tipo = "V8", DataAplicacao = "2024-01-01" };
            _context.Vaccines.Add(vaccine);
            await _context.SaveChangesAsync();

            var dto = new UpdateVaccineDto { Tipo = "V10", Lote = "NOVO-LOTE" };

            var result = await _service.UpdateAsync(vaccine.Id, dto);

            Assert.NotNull(result);
            Assert.Equal("V10", result.Tipo);
            Assert.Equal("NOVO-LOTE", result.Lote);
        }

        [Fact]
        public async Task UpdateAsync_VacinaInexistente_DeveRetornarNull()
        {
            var result = await _service.UpdateAsync("id-inexistente", new UpdateVaccineDto { Tipo = "X" });

            Assert.Null(result);
        }

        [Fact]
        public async Task DeleteAsync_VacinaExistente_DeveRemover()
        {
            var vaccine = new Vaccine { PetId = "pet-1", Tipo = "V8", DataAplicacao = "2024-01-01" };
            _context.Vaccines.Add(vaccine);
            await _context.SaveChangesAsync();

            var result = await _service.DeleteAsync(vaccine.Id);

            Assert.True(result);
            Assert.Null(await _context.Vaccines.FindAsync(vaccine.Id));
        }

        [Fact]
        public async Task DeleteAsync_VacinaInexistente_DeveRetornarFalse()
        {
            var result = await _service.DeleteAsync("id-inexistente");

            Assert.False(result);
        }
    }
}
