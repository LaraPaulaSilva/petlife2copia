using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;
using PetLife.Api.Services;
using Xunit;

namespace PetLife.Api.Tests
{
    public class EventoRotinaServiceTests
    {
        [Fact]
        public async Task CreateAsync_SalvaEventoNoBanco()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var service = new EventoRotinaService(context, new NotificacaoServiceFake());

            var evento = new EventoRotina
            {
                UserId = "user-1",
                PetId = "pet-1",
                Tipo = "vacina",
                DataHora = DateTime.UtcNow.AddDays(3),
                Recorrente = true,
                IntervaloDias = 365
            };

            var result = await service.CreateAsync(evento);

            Assert.Equal("vacina", result.Tipo);
            Assert.Equal(1, await context.EventosRotina.CountAsync());
        }

        [Fact]
        public async Task DeleteAsync_RemoveEventoExistente()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var service = new EventoRotinaService(context, new NotificacaoServiceFake());

            var evento = await service.CreateAsync(new EventoRotina { UserId = "user-1", PetId = "pet-1", Tipo = "banho", DataHora = DateTime.UtcNow });

            var apagado = await service.DeleteAsync(evento.Id);

            Assert.True(apagado);
            Assert.Equal(0, await context.EventosRotina.CountAsync());
        }

        [Fact]
        public async Task CreateAsync_GeraNovoId_IgnorandoOIdEnviado()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var service = new EventoRotinaService(context, new NotificacaoServiceFake());

            var evento = new EventoRotina { Id = "id-falso-enviado-pelo-cliente", UserId = "user-1", PetId = "pet-1", Tipo = "banho", DataHora = DateTime.UtcNow };

            var result = await service.CreateAsync(evento);

            Assert.NotEqual("id-falso-enviado-pelo-cliente", result.Id);
            Assert.False(string.IsNullOrEmpty(result.Id));
        }

        [Fact]
        public async Task CreateAsync_DisparaNotificacao()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var fake = new NotificacaoServiceFake();
            var service = new EventoRotinaService(context, fake);

            await service.CreateAsync(new EventoRotina { UserId = "user-1", PetId = "pet-1", Tipo = "consulta", DataHora = DateTime.UtcNow });

            Assert.Equal(1, fake.ChamadasCriarAsync);
        }

        [Fact]
        public async Task CreateAsync_MapeiaTipoVacina_ParaProximaVacina()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var fake = new NotificacaoServiceFake();
            var service = new EventoRotinaService(context, fake);

            await service.CreateAsync(new EventoRotina { UserId = "user-1", PetId = "pet-1", Tipo = "vacina", DataHora = DateTime.UtcNow });

            Assert.Equal("proxima_vacina", fake.UltimoTipo);
        }

        [Fact]
        public async Task GetByPetAsync_RetornaApenasEventosDoPet()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var service = new EventoRotinaService(context, new NotificacaoServiceFake());

            await service.CreateAsync(new EventoRotina { UserId = "user-1", PetId = "pet-1", Tipo = "banho", DataHora = DateTime.UtcNow });
            await service.CreateAsync(new EventoRotina { UserId = "user-1", PetId = "pet-2", Tipo = "banho", DataHora = DateTime.UtcNow });

            var resultado = await service.GetByPetAsync("pet-1");

            Assert.Single(resultado);
            Assert.All(resultado, e => Assert.Equal("pet-1", e.PetId));
        }

        [Fact]
        public async Task GetByUserAsync_RetornaApenasEventosDoUsuario()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var service = new EventoRotinaService(context, new NotificacaoServiceFake());

            await service.CreateAsync(new EventoRotina { UserId = "user-1", PetId = "pet-1", Tipo = "banho", DataHora = DateTime.UtcNow });
            await service.CreateAsync(new EventoRotina { UserId = "user-2", PetId = "pet-1", Tipo = "banho", DataHora = DateTime.UtcNow });

            var resultado = await service.GetByUserAsync("user-1");

            Assert.Single(resultado);
            Assert.All(resultado, e => Assert.Equal("user-1", e.UserId));
        }

        [Fact]
        public async Task GetByIdAsync_RetornaEvento_QuandoExiste()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var service = new EventoRotinaService(context, new NotificacaoServiceFake());

            var criado = await service.CreateAsync(new EventoRotina { UserId = "user-1", PetId = "pet-1", Tipo = "banho", DataHora = DateTime.UtcNow });

            var encontrado = await service.GetByIdAsync(criado.Id);

            Assert.NotNull(encontrado);
            Assert.Equal(criado.Id, encontrado!.Id);
        }

        [Fact]
        public async Task GetByIdAsync_RetornaNull_QuandoNaoExiste()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var service = new EventoRotinaService(context, new NotificacaoServiceFake());

            var encontrado = await service.GetByIdAsync("id-que-nao-existe");

            Assert.Null(encontrado);
        }

        [Fact]
        public async Task UpdateAsync_AtualizaCampos_QuandoEventoExiste()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var service = new EventoRotinaService(context, new NotificacaoServiceFake());

            var criado = await service.CreateAsync(new EventoRotina { UserId = "user-1", PetId = "pet-1", Tipo = "banho", DataHora = DateTime.UtcNow });

            var dadosAtualizados = new EventoRotina { UserId = "user-1", PetId = "pet-1", Tipo = "tosa", DataHora = DateTime.UtcNow, Status = "concluido", Observacoes = "Pet tranquilo" };

            var atualizado = await service.UpdateAsync(criado.Id, dadosAtualizados);

            Assert.NotNull(atualizado);
            Assert.Equal("tosa", atualizado!.Tipo);
            Assert.Equal("concluido", atualizado.Status);
            Assert.Equal("Pet tranquilo", atualizado.Observacoes);
        }

        [Fact]
        public async Task UpdateAsync_RetornaNull_QuandoEventoNaoExiste()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var service = new EventoRotinaService(context, new NotificacaoServiceFake());

            var atualizado = await service.UpdateAsync("id-inexistente", new EventoRotina { UserId = "user-1", PetId = "pet-1", Tipo = "banho", DataHora = DateTime.UtcNow });

            Assert.Null(atualizado);
        }

        [Fact]
        public async Task DeleteAsync_RetornaFalse_QuandoEventoNaoExiste()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var service = new EventoRotinaService(context, new NotificacaoServiceFake());

            var apagado = await service.DeleteAsync("id-inexistente");

            Assert.False(apagado);
        }
    }

    public class NotificacaoServiceFake : INotificacaoService
    {
        public int ChamadasCriarAsync { get; private set; }
        public string? UltimoTipo { get; private set; }

        public Task CriarAsync(string userId, string titulo, string mensagem, string tipo, string? referenciaId)
        {
            ChamadasCriarAsync++;
            UltimoTipo = tipo;
            return Task.CompletedTask;
        }

        public Task<IEnumerable<Notificacao>> GetByUserAsync(string userId) => Task.FromResult<IEnumerable<Notificacao>>(new List<Notificacao>());
        public Task<bool> MarcarComoLidaAsync(string id) => Task.FromResult(true);
        public Task<bool> DeleteAsync(string id) => Task.FromResult(true);
        public Task<ConfiguracaoNotificacao> ObterPreferenciasAsync(string userId) => Task.FromResult(new ConfiguracaoNotificacao { UserId = userId });
        public Task<ConfiguracaoNotificacao> SalvarPreferenciasAsync(ConfiguracaoNotificacao config) => Task.FromResult(config);
    }
}