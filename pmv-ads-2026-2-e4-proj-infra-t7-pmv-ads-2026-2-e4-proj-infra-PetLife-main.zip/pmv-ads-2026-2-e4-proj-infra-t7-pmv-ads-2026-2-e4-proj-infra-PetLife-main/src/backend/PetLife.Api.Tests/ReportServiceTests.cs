using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;
using PetLife.Api.Services;
using Xunit;

namespace PetLife.Api.Tests
{
    public class ReportServiceTests {
        [Fact]
        public async Task CreateAsync_ShouldSaveReportModelToDatabase() {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            
            using var context = new ApplicationDbContext(options);
            var service = new ReportService(context);
            
            var report = new Report { 
                UserId = "user-123", 
                Name = "Monthly Consultations", 
                Type = "consultations",
                Filters = new Dictionary<string, string> { { "status", "completed" } }
            };

            var result = await service.CreateAsync(report);
            
            Assert.Equal("Monthly Consultations", result.Name);
            Assert.Equal(1, await context.Reports.CountAsync());
        }
    }
}