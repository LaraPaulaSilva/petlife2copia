using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;
using PetLife.Api.Services;
using Xunit;

namespace PetLife.Api.Tests
{
    public class DocumentServiceTests : IDisposable
    {
        private readonly ApplicationDbContext _context;
        private readonly DocumentService _service;

        public DocumentServiceTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationDbContext(options);
            _service = new DocumentService(_context);

            // Pet, usuário e consulta referenciados pelos testes precisam existir (validação de referência).
            _context.Pets.Add(new Pet { Id = "pet-1", Nome = "Rex", Especie = "Cão", TutorId = "tutor-1" });
            _context.Users.Add(new User { Id = "vet-1", Name = "Vet Teste", UserName = "vet1@test.com", Email = "vet1@test.com" });
            _context.Consultas.Add(new Consulta { Id = "consulta-123", PetId = "pet-1", AutorId = "vet-1", TipoAtendimento = "consulta", Data = "2024-01-01" });
            _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
            GC.SuppressFinalize(this);
        }

        [Fact]
        public async Task GetAllAsync_ComPetId_DeveFiltrarPorPet()
        {
            _context.Documents.AddRange(
                new Document { PetId = "pet-1", UsuarioId = "u1", Titulo = "Exame A", ArquivoUrl = "url-a" },
                new Document { PetId = "pet-2", UsuarioId = "u1", Titulo = "Exame B", ArquivoUrl = "url-b" }
            );
            await _context.SaveChangesAsync();

            var docs = await _service.GetAllAsync("pet-1");

            Assert.Single(docs);
            Assert.All(docs, d => Assert.Equal("pet-1", d.PetId));
        }

        [Fact]
        public async Task CreateAsync_DadosValidos_DeveSalvarComTrimEPerfil()
        {
            var dto = new CreateDocumentDto
            {
                PetId = "pet-1",
                UsuarioId = "vet-1",
                PerfilAutor = "Veterinário",
                Titulo = "  Laudo  ",
                TipoDoc = "  laudo  ",
                ArquivoUrl = "  https://cloud/laudo.pdf  "
            };

            var doc = await _service.CreateAsync(dto);

            Assert.Equal("Laudo", doc.Titulo);
            Assert.Equal("laudo", doc.TipoDoc);
            Assert.Equal("https://cloud/laudo.pdf", doc.ArquivoUrl);
            Assert.Equal("Veterinário", doc.PerfilAutor);
        }

        [Fact]
        public async Task CreateAsync_ComConsultaId_DeveVincularConsulta()
        {
            var dto = new CreateDocumentDto
            {
                PetId = "pet-1",
                UsuarioId = "vet-1",
                ConsultaId = "consulta-123",
                Titulo = "Exame vinculado",
                ArquivoUrl = "https://cloud/exame.pdf"
            };

            var doc = await _service.CreateAsync(dto);

            Assert.Equal("consulta-123", doc.ConsultaId);
        }

        [Fact]
        public async Task CreateAsync_SemArquivoUrl_DeveLancarArgumentException()
        {
            var dto = new CreateDocumentDto { PetId = "pet-1", UsuarioId = "u1", Titulo = "X", ArquivoUrl = "" };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.CreateAsync(dto));
        }

        [Fact]
        public async Task UpdateAsync_MesmoAutor_DeveAtualizar()
        {
            var doc = new Document { PetId = "pet-1", UsuarioId = "u1", Titulo = "Antigo", ArquivoUrl = "url" };
            _context.Documents.Add(doc);
            await _context.SaveChangesAsync();

            var dto = new UpdateDocumentDto { SolicitanteId = "u1", Titulo = "Atualizado" };
            var result = await _service.UpdateAsync(doc.Id, dto);

            Assert.NotNull(result);
            Assert.Equal("Atualizado", result.Titulo);
        }

        [Fact]
        public async Task UpdateAsync_AutorDiferente_DeveLancarUnauthorized()
        {
            var doc = new Document { PetId = "pet-1", UsuarioId = "u1", Titulo = "Antigo", ArquivoUrl = "url" };
            _context.Documents.Add(doc);
            await _context.SaveChangesAsync();

            var dto = new UpdateDocumentDto { SolicitanteId = "outro-usuario", Titulo = "Hack" };

            await Assert.ThrowsAsync<UnauthorizedAccessException>(() => _service.UpdateAsync(doc.Id, dto));
        }

        [Fact]
        public async Task DeleteAsync_AutorDiferente_DeveLancarUnauthorized()
        {
            var doc = new Document { PetId = "pet-1", UsuarioId = "u1", Titulo = "Doc", ArquivoUrl = "url" };
            _context.Documents.Add(doc);
            await _context.SaveChangesAsync();

            await Assert.ThrowsAsync<UnauthorizedAccessException>(() => _service.DeleteAsync(doc.Id, "outro-usuario"));
        }

        [Fact]
        public async Task DeleteAsync_MesmoAutor_DeveRemover()
        {
            var doc = new Document { PetId = "pet-1", UsuarioId = "u1", Titulo = "Doc", ArquivoUrl = "url" };
            _context.Documents.Add(doc);
            await _context.SaveChangesAsync();

            var result = await _service.DeleteAsync(doc.Id, "u1");

            Assert.True(result);
            Assert.Null(await _context.Documents.FindAsync(doc.Id));
        }

        [Fact]
        public async Task DeleteAsync_SemSolicitante_DeveRemover()
        {
            var doc = new Document { PetId = "pet-1", UsuarioId = "u1", Titulo = "Doc", ArquivoUrl = "url" };
            _context.Documents.Add(doc);
            await _context.SaveChangesAsync();

            var result = await _service.DeleteAsync(doc.Id);

            Assert.True(result);
        }
    }
}
