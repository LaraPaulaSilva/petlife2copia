﻿namespace PetLife.Api.Tests;

using PetLife.Api.Models;

public class RegisterTests
{
    [Fact]
    public void Register_ComSenhaEConfirmacaoIguais_DeveSerValido()
    {
        
        var register = new Register
        {
            Email = "teste@petlife.com",
            Name = "Matheus",
            Password = "SenhaForte123",
            ConfirmPassword = "SenhaForte123"
        };

        var senhasIguais = register.Password == register.ConfirmPassword;

      
        Assert.True(senhasIguais);
    }

    [Fact]
    public void Register_ComSenhasDiferentes_DeveSerInvalido()
    {
        
        var register = new Register
        {
            Email = "teste@petlife.com",
            Name = "Matheus",
            Password = "SenhaForte123",
            ConfirmPassword = "OutraSenha456"
        };

        
        var senhasIguais = register.Password == register.ConfirmPassword;

       
        Assert.False(senhasIguais);
    }
}
