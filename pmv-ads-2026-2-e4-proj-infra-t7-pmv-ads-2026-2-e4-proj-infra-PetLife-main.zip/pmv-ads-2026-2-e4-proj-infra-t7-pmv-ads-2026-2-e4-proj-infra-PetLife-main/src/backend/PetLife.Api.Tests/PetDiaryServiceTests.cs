using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;
using PetLife.Api.Services;
using Xunit;

namespace PetLife.Api.Tests
{
    public class PetDiaryServiceTests : IDisposable
    {
        private const string Tutor1 = "tutor-1";
        private const string Tutor2 = "tutor-2";

        private readonly ApplicationDbContext _context;
        private readonly PetDiaryService _service;

        public PetDiaryServiceTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationDbContext(options);
            _service = new PetDiaryService(_context);
        }

        public void Dispose()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
            GC.SuppressFinalize(this);
        }

        private async Task SemearPetsAsync()
        {
            _context.Pets.AddRange(
                new Pet { Id = "pet-1", Nome = "Rex", Especie = "Cachorro", TutorId = Tutor1 },
                new Pet { Id = "pet-2", Nome = "Mia", Especie = "Gato", TutorId = Tutor2 },
                new Pet { Id = "pet-123", Nome = "Thor", Especie = "Cachorro", TutorId = "user-abc" }
            );
            await _context.SaveChangesAsync();
        }

        [Fact]
        public async Task GetAllAsync_VeterinarioSemFiltro_DeveRetornarTodosOrdenadosPorDataDecrescente()
        {
            await SemearPetsAsync();
            _context.PetDiaries.AddRange(
                new PetDiaryEntry { PetId = "pet-1", DataRegistro = "2026-05-01T00:00:00.000Z", Registro = "Antigo" },
                new PetDiaryEntry { PetId = "pet-2", DataRegistro = "2026-09-01T00:00:00.000Z", Registro = "Mais recente" }
            );
            await _context.SaveChangesAsync();

            var entries = (await _service.GetAllAsync(Tutor1, isVeterinario: true)).ToList();

            Assert.Equal(2, entries.Count);
            Assert.Equal("Mais recente", entries[0].Registro);
            Assert.Equal("Antigo", entries[1].Registro);
        }

        [Fact]
        public async Task GetAllAsync_TutorSemFiltro_DeveRetornarApenasPetsDoTutor()
        {
            await SemearPetsAsync();
            _context.PetDiaries.AddRange(
                new PetDiaryEntry { PetId = "pet-1", DataRegistro = "2026-05-01T00:00:00.000Z", Registro = "Do tutor 1" },
                new PetDiaryEntry { PetId = "pet-2", DataRegistro = "2026-09-01T00:00:00.000Z", Registro = "Do tutor 2" }
            );
            await _context.SaveChangesAsync();

            var entries = (await _service.GetAllAsync(Tutor1, isVeterinario: false)).ToList();

            Assert.Single(entries);
            Assert.Equal("Do tutor 1", entries[0].Registro);
        }

        [Fact]
        public async Task GetAllAsync_ComPetId_DeveFiltrarPorPet()
        {
            await SemearPetsAsync();
            _context.PetDiaries.AddRange(
                new PetDiaryEntry { PetId = "pet-1", DataRegistro = "2026-05-01T00:00:00.000Z", Registro = "Pet 1 - Reg 1" },
                new PetDiaryEntry { PetId = "pet-1", DataRegistro = "2026-06-01T00:00:00.000Z", Registro = "Pet 1 - Reg 2" },
                new PetDiaryEntry { PetId = "pet-2", DataRegistro = "2026-07-01T00:00:00.000Z", Registro = "Pet 2 - Reg 1" }
            );
            await _context.SaveChangesAsync();

            var entries = (await _service.GetAllAsync(Tutor1, isVeterinario: false, "pet-1")).ToList();

            Assert.Equal(2, entries.Count);
            Assert.All(entries, e => Assert.Equal("pet-1", e.PetId));
        }

        [Fact]
        public async Task GetAllAsync_TutorComPetAlheio_DeveLancarUnauthorized()
        {
            await SemearPetsAsync();

            await Assert.ThrowsAsync<UnauthorizedAccessException>(
                () => _service.GetAllAsync(Tutor1, isVeterinario: false, "pet-2"));
        }

        [Fact]
        public async Task GetByIdAsync_Existente_DeveRetornarRegistro()
        {
            await SemearPetsAsync();
            var entry = new PetDiaryEntry
            {
                Id = "entry-1",
                PetId = "pet-1",
                DataRegistro = "2026-09-27T00:00:00.000Z",
                Registro = "Vômito após ração",
                Suspeita = "Intoxicação alimentar",
                Tags = new List<string> { "vomito", "alimentacao" }
            };
            _context.PetDiaries.Add(entry);
            await _context.SaveChangesAsync();

            var result = await _service.GetByIdAsync("entry-1", Tutor1, isVeterinario: false);

            Assert.NotNull(result);
            Assert.Equal("entry-1", result.Id);
            Assert.Equal("Vômito após ração", result.Registro);
            Assert.Equal(2, result.Tags.Count);
        }

        [Fact]
        public async Task GetByIdAsync_NaoExistente_DeveRetornarNull()
        {
            var result = await _service.GetByIdAsync("inexistente", Tutor1, isVeterinario: false);
            Assert.Null(result);
        }

        [Fact]
        public async Task CreateAsync_DadosValidos_DeveSalvarRegistro()
        {
            await SemearPetsAsync();
            var dto = new CreatePetDiaryDto
            {
                PetId = "pet-123",
                UsuarioId = "user-abc",
                PerfilAutor = "tutor",
                DataRegistro = "2026-09-27T10:00:00.000Z",
                Tags = new List<string> { "vacina", "febre" },
                Registro = "Pet ficou febril após vacina antirrábica.",
                Suspeita = "Reação vacinal"
            };

            var created = await _service.CreateAsync(dto, "user-abc");

            Assert.NotNull(created.Id);
            Assert.Equal("pet-123", created.PetId);
            Assert.Equal("tutor", created.PerfilAutor);
            Assert.Equal("user-abc", created.UsuarioId);
            Assert.Equal("Pet ficou febril após vacina antirrábica.", created.Registro);
            Assert.Equal("Reação vacinal", created.Suspeita);
            Assert.Equal(2, created.Tags.Count);

            var dbEntry = await _context.PetDiaries.FirstOrDefaultAsync(d => d.Id == created.Id);
            Assert.NotNull(dbEntry);
        }

        [Fact]
        public async Task CreateAsync_SemPetId_DeveLancarArgumentException()
        {
            var dto = new CreatePetDiaryDto
            {
                PetId = "",
                DataRegistro = "2026-09-27T10:00:00.000Z",
                Registro = "Teste"
            };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.CreateAsync(dto, Tutor1));
        }

        [Fact]
        public async Task CreateAsync_SemDataRegistro_DeveLancarArgumentException()
        {
            var dto = new CreatePetDiaryDto
            {
                PetId = "pet-1",
                DataRegistro = "",
                Registro = "Teste"
            };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.CreateAsync(dto, Tutor1));
        }

        [Fact]
        public async Task CreateAsync_SemRegistro_DeveLancarArgumentException()
        {
            var dto = new CreatePetDiaryDto
            {
                PetId = "pet-1",
                DataRegistro = "2026-09-27T10:00:00.000Z",
                Registro = ""
            };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.CreateAsync(dto, Tutor1));
        }

        [Fact]
        public async Task CreateAsync_PetInexistente_DeveLancarKeyNotFoundException()
        {
            var dto = new CreatePetDiaryDto
            {
                PetId = "pet-nao-existe",
                DataRegistro = "2026-09-27T10:00:00.000Z",
                Registro = "Teste"
            };

            await Assert.ThrowsAsync<KeyNotFoundException>(() => _service.CreateAsync(dto, Tutor1));
        }

        [Fact]
        public async Task CreateAsync_PetDeOutroTutor_DeveLancarUnauthorized()
        {
            await SemearPetsAsync();
            var dto = new CreatePetDiaryDto
            {
                PetId = "pet-2",
                DataRegistro = "2026-09-27T10:00:00.000Z",
                Registro = "Tentativa em pet alheio"
            };

            await Assert.ThrowsAsync<UnauthorizedAccessException>(() => _service.CreateAsync(dto, Tutor1));
        }

        [Fact]
        public async Task UpdateAsync_Existente_DeveAtualizarCampos()
        {
            await SemearPetsAsync();
            var entry = new PetDiaryEntry
            {
                Id = "entry-update",
                PetId = "pet-1",
                DataRegistro = "2026-09-20T00:00:00.000Z",
                Registro = "Registro inicial",
                Tags = new List<string> { "inicial" }
            };
            _context.PetDiaries.Add(entry);
            await _context.SaveChangesAsync();

            var updateDto = new UpdatePetDiaryDto
            {
                Registro = "Registro atualizado",
                Suspeita = "Nova observação",
                Tags = new List<string> { "atualizado", "alerta" }
            };

            var updated = await _service.UpdateAsync("entry-update", updateDto, Tutor1);

            Assert.NotNull(updated);
            Assert.Equal("Registro atualizado", updated.Registro);
            Assert.Equal("Nova observação", updated.Suspeita);
            Assert.Equal(2, updated.Tags.Count);
            Assert.Contains("atualizado", updated.Tags);
        }

        [Fact]
        public async Task UpdateAsync_NaoExistente_DeveRetornarNull()
        {
            var updateDto = new UpdatePetDiaryDto { Registro = "Novo" };
            var result = await _service.UpdateAsync("nao-existe", updateDto, Tutor1);
            Assert.Null(result);
        }

        [Fact]
        public async Task DeleteAsync_Existente_DeveRemoverRegistro()
        {
            await SemearPetsAsync();
            var entry = new PetDiaryEntry
            {
                Id = "entry-delete",
                PetId = "pet-1",
                DataRegistro = "2026-09-20T00:00:00.000Z",
                Registro = "Para deletar"
            };
            _context.PetDiaries.Add(entry);
            await _context.SaveChangesAsync();

            var result = await _service.DeleteAsync("entry-delete", Tutor1);

            Assert.True(result);
            var inDb = await _context.PetDiaries.FirstOrDefaultAsync(d => d.Id == "entry-delete");
            Assert.Null(inDb);
        }

        [Fact]
        public async Task DeleteAsync_NaoExistente_DeveRetornarFalse()
        {
            var result = await _service.DeleteAsync("inexistente", Tutor1);
            Assert.False(result);
        }
    }
}
