using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;
using PetLife.Api.Services;
using Xunit;

namespace PetLife.Api.Tests
{
    public class TreatmentServiceTests {
        [Fact]
        public async Task CreateAsync_SalvaTratamentoNoBanco() {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            using var context = new ApplicationDbContext(options);
            var service = new TreatmentService(context);
            var treatment = new Treatment { PetId = "123", Medicamento = "Dipirona", DataInicio = "2026-10-01" };

            var result = await service.CreateAsync(treatment);
            Assert.Equal("Dipirona", result.Medicamento);
            Assert.Equal(1, await context.Treatments.CountAsync());
        }
    }
}