using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Moq;
using PetLife.Api.Data;
using PetLife.Api.Models;
using PetLife.Api.Services;
using Xunit;

namespace PetLife.Api.Tests
{
    public class PetServiceTests : IDisposable
    {
        private readonly ApplicationDbContext _context;
        private readonly Mock<ICloudinaryService> _cloudinaryServiceMock;
        private readonly PetService _service;

        public PetServiceTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationDbContext(options);
            _cloudinaryServiceMock = new Mock<ICloudinaryService>();
            _service = new PetService(_context, _cloudinaryServiceMock.Object);
        }

        public void Dispose()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
            GC.SuppressFinalize(this);
        }

        [Fact]
        public async Task GetAllAsync_SemFiltro_DeveRetornarTodosOsPets()
        {
            _context.Pets.AddRange(
                new Pet { Nome = "Rex", Especie = "Cachorro", TutorId = "tutor-1" },
                new Pet { Nome = "Mia", Especie = "Gato", TutorId = "tutor-2" }
            );
            await _context.SaveChangesAsync();

            var pets = await _service.GetAllAsync();

            Assert.Equal(2, pets.Count());
        }

        [Fact]
        public async Task GetAllAsync_ComTutorId_DeveFiltrarPorTutor()
        {
            _context.Pets.AddRange(
                new Pet { Nome = "Rex", Especie = "Cachorro", TutorId = "tutor-1" },
                new Pet { Nome = "Bob", Especie = "Cachorro", TutorId = "tutor-1" },
                new Pet { Nome = "Mia", Especie = "Gato", TutorId = "tutor-2" }
            );
            await _context.SaveChangesAsync();

            var pets = await _service.GetAllAsync("tutor-1");

            Assert.Equal(2, pets.Count());
            Assert.All(pets, p => Assert.Equal("tutor-1", p.TutorId));
        }

        [Fact]
        public async Task GetByIdAsync_PetExistente_DeveRetornarPet()
        {
            var pet = new Pet { Nome = "Thor", Especie = "Cachorro", TutorId = "tutor-1" };
            _context.Pets.Add(pet);
            await _context.SaveChangesAsync();

            var result = await _service.GetByIdAsync(pet.Id);

            Assert.NotNull(result);
            Assert.Equal("Thor", result.Nome);
        }

        [Fact]
        public async Task GetByIdAsync_PetInexistente_DeveRetornarNull()
        {
            var result = await _service.GetByIdAsync("id-inexistente");

            Assert.Null(result);
        }

        [Fact]
        public async Task CreateAsync_DadosValidos_DeveSalvarERetornarPetComTrim()
        {
            var dto = new CreatePetDto
            {
                Nome = "  Mel  ",
                Especie = "  Gato  ",
                Raca = "  Persa  ",
                PesoKg = 3.8,
                Microchip = "  123456  ",
                FotoUrl = "https://cloudinary.com/mel.jpg"
            };

            var pet = await _service.CreateAsync(dto, "tutor-100");

            Assert.NotNull(pet);
            Assert.False(string.IsNullOrWhiteSpace(pet.Id));
            Assert.Equal("Mel", pet.Nome);
            Assert.Equal("Gato", pet.Especie);
            Assert.Equal("Persa", pet.Raca);
            Assert.Equal("123456", pet.Microchip);
            Assert.Equal("tutor-100", pet.TutorId);
            Assert.Equal(3.8, pet.PesoKg);

            var salvo = await _context.Pets.FindAsync(pet.Id);
            Assert.NotNull(salvo);
        }

        [Fact]
        public async Task CreateAsync_SemTutorId_DeveLancarArgumentException()
        {
            var dto = new CreatePetDto { Nome = "Bidu", Especie = "Cachorro" };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.CreateAsync(dto, ""));
        }

        [Fact]
        public async Task CreateAsync_NomeVazio_DeveLancarArgumentException()
        {
            var dto = new CreatePetDto { Nome = "   ", Especie = "Cachorro" };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.CreateAsync(dto, "tutor-1"));
        }

        [Fact]
        public async Task CreateAsync_EspecieVazia_DeveLancarArgumentException()
        {
            var dto = new CreatePetDto { Nome = "Bidu", Especie = "" };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.CreateAsync(dto, "tutor-1"));
        }

        [Fact]
        public async Task UpdateAsync_PetExistente_DeveAtualizarCamposValidos()
        {
            var pet = new Pet { Nome = "Belinha", Especie = "Cachorro", PesoKg = 10.0, TutorId = "tutor-1" };
            _context.Pets.Add(pet);
            await _context.SaveChangesAsync();

            var updateDto = new UpdatePetDto
            {
                Nome = "Belinha Silva",
                PesoKg = 11.2,
                Microchip = "987654"
            };

            var result = await _service.UpdateAsync(pet.Id, updateDto);

            Assert.NotNull(result);
            Assert.Equal("Belinha Silva", result.Nome);
            Assert.Equal(11.2, result.PesoKg);
            Assert.Equal("987654", result.Microchip);
            Assert.Equal("Cachorro", result.Especie); // Não alterado
        }

        [Fact]
        public async Task UpdateAsync_PetInexistente_DeveRetornarNull()
        {
            var updateDto = new UpdatePetDto { Nome = "Novo" };

            var result = await _service.UpdateAsync("id-inexistente", updateDto);

            Assert.Null(result);
        }

        [Fact]
        public async Task UpdateAsync_NomeVazio_DeveLancarArgumentException()
        {
            var pet = new Pet { Nome = "Pipoca", Especie = "Cachorro", TutorId = "tutor-1" };
            _context.Pets.Add(pet);
            await _context.SaveChangesAsync();

            var updateDto = new UpdatePetDto { Nome = "   " };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.UpdateAsync(pet.Id, updateDto));
        }

        [Fact]
        public async Task UpdateAsync_EspecieVazia_DeveLancarArgumentException()
        {
            var pet = new Pet { Nome = "Pipoca", Especie = "Cachorro", TutorId = "tutor-1" };
            _context.Pets.Add(pet);
            await _context.SaveChangesAsync();

            var updateDto = new UpdatePetDto { Especie = "" };

            await Assert.ThrowsAsync<ArgumentException>(() => _service.UpdateAsync(pet.Id, updateDto));
        }

        [Fact]
        public async Task DeleteAsync_PetExistente_DeveRemoverERetornarTrue()
        {
            var pet = new Pet { Nome = "Max", Especie = "Cachorro", TutorId = "tutor-1" };
            _context.Pets.Add(pet);
            await _context.SaveChangesAsync();

            var result = await _service.DeleteAsync(pet.Id);

            Assert.True(result);
            var petNoBanco = await _context.Pets.FindAsync(pet.Id);
            Assert.Null(petNoBanco);
        }

        [Fact]
        public async Task DeleteAsync_PetInexistente_DeveRetornarFalse()
        {
            var result = await _service.DeleteAsync("id-inexistente");

            Assert.False(result);
        }

        [Fact]
        public async Task UploadPhotoAsync_PetExistenteEArquivoValido_DeveAtualizarFotoUrlERetornarPet()
        {
            var pet = new Pet { Nome = "Luna", Especie = "Cachorro", TutorId = "tutor-1" };
            _context.Pets.Add(pet);
            await _context.SaveChangesAsync();

            var expectedUrl = "https://res.cloudinary.com/petlife/image/upload/v1/petlife/pets/luna.jpg";
            _cloudinaryServiceMock
                .Setup(c => c.UploadImageAsync(It.IsAny<IFormFile>(), "petlife/pets"))
                .ReturnsAsync(new CloudinaryUploadResult(expectedUrl, "petlife/pets/luna"));

            var fileMock = new Mock<IFormFile>();
            fileMock.Setup(f => f.Length).Returns(2048);
            fileMock.Setup(f => f.FileName).Returns("luna.jpg");

            var result = await _service.UploadPhotoAsync(pet.Id, fileMock.Object);

            Assert.NotNull(result);
            Assert.Equal(expectedUrl, result.FotoUrl);

            var petNoBanco = await _context.Pets.FindAsync(pet.Id);
            Assert.NotNull(petNoBanco);
            Assert.Equal(expectedUrl, petNoBanco.FotoUrl);
        }

        [Fact]
        public async Task UploadPhotoAsync_PetInexistente_DeveRetornarNull()
        {
            var fileMock = new Mock<IFormFile>();
            fileMock.Setup(f => f.Length).Returns(1024);

            var result = await _service.UploadPhotoAsync("id-inexistente", fileMock.Object);

            Assert.Null(result);
        }

        [Fact]
        public async Task UploadPhotoAsync_ArquivoNulo_DeveLancarArgumentException()
        {
            await Assert.ThrowsAsync<ArgumentException>(() => _service.UploadPhotoAsync("pet-1", null!));
        }

        [Fact]
        public async Task UploadPhotoAsync_ArquivoVazio_DeveLancarArgumentException()
        {
            var fileMock = new Mock<IFormFile>();
            fileMock.Setup(f => f.Length).Returns(0);

            await Assert.ThrowsAsync<ArgumentException>(() => _service.UploadPhotoAsync("pet-1", fileMock.Object));
        }

        [Fact]
        public async Task UploadPhotoAsync_PetIdVazio_DeveLancarArgumentException()
        {
            var fileMock = new Mock<IFormFile>();
            fileMock.Setup(f => f.Length).Returns(100);

            await Assert.ThrowsAsync<ArgumentException>(() => _service.UploadPhotoAsync("   ", fileMock.Object));
        }
    }
}
