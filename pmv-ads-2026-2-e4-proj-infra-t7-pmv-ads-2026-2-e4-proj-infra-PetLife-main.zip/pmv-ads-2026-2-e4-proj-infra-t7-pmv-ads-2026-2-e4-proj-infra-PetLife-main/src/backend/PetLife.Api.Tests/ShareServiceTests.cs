﻿using Microsoft.EntityFrameworkCore;
using PetLife.Api.Data;
using PetLife.Api.Models;
using PetLife.Api.Services;

namespace PetLife.Api.Tests
{
    public class ShareServiceTests: IDisposable
    {
        private readonly ApplicationDbContext _context;

        public ShareServiceTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationDbContext(options);
        }
        [Fact]
        public async Task GetProfilesAsync_ShouldReturn_VetProfiles()
        {
            var tutorId = "tutor-123";

            _context.Users.AddRange(
                new User { Id = "vet-1", Name = "Dr. Silva", Image = "silva.jpg" },
                new User { Id = "vet-2", Name = "Dra. Maria", Image = "maria.jpg" }
            );
            _context.Shares.AddRange(
                new Share { Id = "s1", TutorId = tutorId, VetId = "vet-1", PetId = "pet-1" },
                new Share { Id = "s2", TutorId = tutorId, VetId = "vet-2", PetId = "pet-1" }
            );
            await _context.SaveChangesAsync();

            var service = new ShareService(_context);

            var result = await service.GetProfilesAsync(tutorId);

            Assert.Equal( 2, result.Count );
        }

        [Fact]
        public async Task ValidateShareCode_WithValidCode_ShouldCreateShare()
        {
            var code = "VALID-123";
            var vetId = "vet-999";

            _context.ShareCodes.Add(new ShareCode
            {
                Id = "code-id-1",
                Code = code,
                TutorId = "tutor-1",
                PetId = "pet-1",
                ExpiresAt = DateTime.UtcNow.AddMinutes(10)
            });
            await _context.SaveChangesAsync();

            var service = new ShareService(_context);

            var result = await service.ValidateShareCode(code, vetId);

            Assert.NotNull(result);
            Assert.Equal(vetId, result.VetId);
            Assert.Equal("tutor-1", result.TutorId);
            var shareInDb = _context.Shares.FirstOrDefaultAsync(s => s.VetId == vetId);
            Assert.NotNull(shareInDb);
        }

        [Fact]
        public async Task ValidateShareCode_WithExpiredCode_ShouldReturnNull()
        {
            var code = "EXPIRED-123";

            _context.ShareCodes.Add(new ShareCode
            {
                Id = "code-id-2",
                Code = code,
                TutorId = "tutor-1",
                PetId = "pet-1",
                ExpiresAt = DateTime.UtcNow.AddMinutes(-5)
            });
            await _context.SaveChangesAsync();

            var service = new ShareService(_context);

            var result = await service.ValidateShareCode(code, "vet-1");

            Assert.Null( result );
        }

        [Fact]
        public async Task CreateShareAsync_ShouldPersist_NewShare()
        {
            var service = new ShareService(_context);
            var model = new Share { PetId = "pet-abc", VetId = "vet-abc" };
            var userId = "tutor-abc";

            var result = await service.CreateShareAsync(model, userId);

            Assert.NotNull( result );
            Assert.Equal(userId, result.TutorId);

            var shareInDb = await _context.Shares.FirstOrDefaultAsync(s => s.PetId == "pet-abc");
            Assert.NotNull(shareInDb);
        }

        [Fact]
        public async Task DeleteShareAsync_ExistingId_ShouldReturnTrue_And_RemoveItem()
        {
            var shareId = "share-delete-me";
            _context.Shares.Add(new Share { Id = shareId, PetId = "p1", VetId = "v1", TutorId = "t1" });
            await _context.SaveChangesAsync();

            var service = new ShareService(_context);

            var result = await service.DeleteShareAsync(shareId);

            Assert.True( result );
        }

        [Fact]
        public async Task CreateShareCodeAsync_ShouldPersist_NewShareCode()
        {
            var service = new ShareService(_context);
            var model = new ShareCode { PetId = "pet-xyz" };
            var userId = "tutor-xyz";

            var result = await service.CreateShareCodeAsync(model, userId);

            Assert.NotNull(result );
            Assert.Equal(userId, result.TutorId);

            var codeInDb = _context.ShareCodes.FirstOrDefaultAsync(c => c.PetId == "pet-xyz");
            Assert.NotNull (codeInDb);
        }
        public void Dispose()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
