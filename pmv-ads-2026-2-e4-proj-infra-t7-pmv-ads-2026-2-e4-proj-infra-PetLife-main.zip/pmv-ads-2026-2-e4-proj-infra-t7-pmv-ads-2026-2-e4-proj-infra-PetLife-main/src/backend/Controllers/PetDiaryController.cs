using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PetLife.Api.Models;
using PetLife.Api.Services;

namespace PetLife.Api.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/pet-diary")]
    [Route("api/pet-diaries")]
    [Route("api/diary")]
    [Route("api/diario-pet")]
    [Route("api/[controller]")]
    [Route("pet-diary")]
    [Route("pet-diaries")]
    [Route("diario-pet")]
    public class PetDiaryController(IPetDiaryService diaryService) : ControllerBase
    {
        private readonly IPetDiaryService _diaryService = diaryService;

        private string? ObterUserIdLogado()
        {
            return User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? User.FindFirst("sub")?.Value
                ?? User.FindFirst("id")?.Value
                ?? User.FindFirst("userId")?.Value;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll(
            [FromQuery(Name = "pet_id")] string? petIdSnake,
            [FromQuery(Name = "petId")] string? petIdCamel)
        {
            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuario nao identificado no token." });
            }

            try
            {
                var petId = !string.IsNullOrWhiteSpace(petIdSnake) ? petIdSnake : petIdCamel;
                var entries = await _diaryService.GetAllAsync(userId, User.IsInRole("Veterinário"), petId);
                return Ok(entries);
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { Message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao listar diário do pet: {ex.Message}" });
            }
        }

        [HttpGet("pet/{petId}")]
        [HttpGet("~/api/pets/{petId}/diary")]
        [HttpGet("~/pets/{petId}/diary")]
        public async Task<IActionResult> GetByPet(string petId)
        {
            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuario nao identificado no token." });
            }

            try
            {
                var entries = await _diaryService.GetAllAsync(userId, User.IsInRole("Veterinário"), petId);
                return Ok(entries);
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { Message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao listar diário do pet: {ex.Message}" });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuario nao identificado no token." });
            }

            try
            {
                var entry = await _diaryService.GetByIdAsync(id, userId, User.IsInRole("Veterinário"));
                if (entry == null)
                {
                    return NotFound(new { Message = "Registro do diário não encontrado." });
                }

                return Ok(entry);
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { Message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao buscar registro do diário: {ex.Message}" });
            }
        }

        [HttpPost]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> Create([FromBody] CreatePetDiaryDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuario nao identificado no token." });
            }

            model.UsuarioId = userId;
            model.PerfilAutor = "tutor";

            try
            {
                var created = await _diaryService.CreateAsync(model, userId);
                return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { Message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { Message = ex.Message });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao cadastrar registro no diário: {ex.Message}" });
            }
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> Update(string id, [FromBody] UpdatePetDiaryDto model)
        {
            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuario nao identificado no token." });
            }

            try
            {
                var updated = await _diaryService.UpdateAsync(id, model, userId);
                if (updated == null)
                {
                    return NotFound(new { Message = "Registro do diário não encontrado." });
                }

                return Ok(updated);
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { Message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { Message = ex.Message });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao atualizar registro no diário: {ex.Message}" });
            }
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> Delete(string id)
        {
            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuario nao identificado no token." });
            }

            try
            {
                var deleted = await _diaryService.DeleteAsync(id, userId);
                if (!deleted)
                {
                    return NotFound(new { Message = "Registro do diário não encontrado." });
                }

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { Message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao excluir registro do diário: {ex.Message}" });
            }
        }
    }
}
