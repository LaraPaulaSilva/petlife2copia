using Microsoft.AspNetCore.Mvc;
using PetLife.Api.Models;
using PetLife.Api.Services;

namespace PetLife.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Route("[controller]")]
    public class DocumentsController(
        IDocumentService documentService,
        ICloudinaryService cloudinaryService) : ControllerBase
    {
        private readonly IDocumentService _documentService = documentService;
        private readonly ICloudinaryService _cloudinaryService = cloudinaryService;

        [HttpGet]
        public async Task<IActionResult> GetAll(
            [FromQuery(Name = "pet_id")] string? petIdSnake,
            [FromQuery(Name = "petId")] string? petIdCamel)
        {
            try
            {
                var petId = !string.IsNullOrWhiteSpace(petIdSnake) ? petIdSnake : petIdCamel;
                var documents = await _documentService.GetAllAsync(petId);
                return Ok(documents);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao listar documentos: {ex.Message}" });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            try
            {
                var document = await _documentService.GetByIdAsync(id);
                if (document == null)
                {
                    return NotFound(new { Message = "Documento não encontrado." });
                }

                return Ok(document);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao buscar documento: {ex.Message}" });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateDocumentDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var created = await _documentService.CreateAsync(model);
                return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao enviar documento: {ex.Message}" });
            }
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new { Message = "Nenhum arquivo foi enviado." });
            }

            try
            {
                var result = await _cloudinaryService.UploadFileAsync(file, "petlife/documents");
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao fazer upload do documento: {ex.Message}" });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] UpdateDocumentDto model)
        {
            try
            {
                var updated = await _documentService.UpdateAsync(id, model);
                if (updated == null)
                {
                    return NotFound(new { Message = "Documento não encontrado." });
                }

                return Ok(updated);
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { Message = ex.Message });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao atualizar documento: {ex.Message}" });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(
            string id,
            [FromQuery(Name = "solicitante_id")] string? solicitanteIdSnake,
            [FromQuery(Name = "solicitanteId")] string? solicitanteIdCamel)
        {
            try
            {
                var solicitanteId = !string.IsNullOrWhiteSpace(solicitanteIdSnake) ? solicitanteIdSnake : solicitanteIdCamel;
                var deleted = await _documentService.DeleteAsync(id, solicitanteId);
                if (!deleted)
                {
                    return NotFound(new { Message = "Documento não encontrado." });
                }

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao excluir documento: {ex.Message}" });
            }
        }
    }
}
