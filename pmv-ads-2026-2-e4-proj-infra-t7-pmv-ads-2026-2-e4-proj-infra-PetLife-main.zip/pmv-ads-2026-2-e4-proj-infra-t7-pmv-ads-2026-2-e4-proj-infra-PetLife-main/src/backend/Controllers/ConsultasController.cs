using Microsoft.AspNetCore.Mvc;
using PetLife.Api.Models;
using PetLife.Api.Services;

namespace PetLife.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Route("[controller]")]
    public class ConsultasController(IConsultaService consultaService) : ControllerBase
    {
        private readonly IConsultaService _consultaService = consultaService;

        [HttpGet]
        public async Task<IActionResult> GetAll(
            [FromQuery(Name = "pet_id")] string? petIdSnake,
            [FromQuery(Name = "petId")] string? petIdCamel)
        {
            try
            {
                var petId = !string.IsNullOrWhiteSpace(petIdSnake) ? petIdSnake : petIdCamel;
                var consultas = await _consultaService.GetAllAsync(petId);
                return Ok(consultas);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao listar consultas: {ex.Message}" });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            try
            {
                var consulta = await _consultaService.GetByIdAsync(id);
                if (consulta == null)
                {
                    return NotFound(new { Message = "Consulta não encontrada." });
                }

                return Ok(consulta);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao buscar consulta: {ex.Message}" });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateConsultaDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var created = await _consultaService.CreateAsync(model);
                return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { Message = ex.Message });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao registrar consulta: {ex.Message}" });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] UpdateConsultaDto model)
        {
            try
            {
                var updated = await _consultaService.UpdateAsync(id, model);
                if (updated == null)
                {
                    return NotFound(new { Message = "Consulta não encontrada." });
                }

                return Ok(updated);
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { Message = ex.Message });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao atualizar consulta: {ex.Message}" });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(
            string id,
            [FromQuery(Name = "solicitante_id")] string? solicitanteIdSnake,
            [FromQuery(Name = "solicitanteId")] string? solicitanteIdCamel)
        {
            try
            {
                var solicitanteId = !string.IsNullOrWhiteSpace(solicitanteIdSnake) ? solicitanteIdSnake : solicitanteIdCamel;
                var deleted = await _consultaService.DeleteAsync(id, solicitanteId);
                if (!deleted)
                {
                    return NotFound(new { Message = "Consulta não encontrada." });
                }

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { Message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao excluir consulta: {ex.Message}" });
            }
        }
    }
}
