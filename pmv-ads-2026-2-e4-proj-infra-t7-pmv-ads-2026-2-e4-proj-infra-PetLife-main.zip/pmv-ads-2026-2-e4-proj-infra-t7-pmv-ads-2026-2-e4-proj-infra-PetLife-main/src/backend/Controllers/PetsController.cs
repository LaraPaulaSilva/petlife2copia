using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PetLife.Api.Models;
using PetLife.Api.Services;

namespace PetLife.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Route("[controller]")]
    [Authorize]
    public class PetsController(IPetService petService, UserManager<User> userManager, ICloudinaryService cloudinaryService) : ControllerBase
    {
        private readonly IPetService _petService = petService;
        private readonly UserManager<User> _userManager = userManager;
        private readonly ICloudinaryService _cloudinaryService = cloudinaryService;

        [HttpGet]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> GetAll(
            [FromQuery(Name = "tutor_id")] string? tutorIdSnake,
            [FromQuery(Name = "tutorId")] string? tutorIdCamel)
        {
            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuário não identificado no token." });
            }

            try
            {
                var requestedTutorId = !string.IsNullOrWhiteSpace(tutorIdSnake) ? tutorIdSnake : tutorIdCamel;
                if (!string.IsNullOrWhiteSpace(requestedTutorId)
                    && !string.Equals(requestedTutorId, userId, StringComparison.Ordinal))
                {
                    return StatusCode(403, new { Message = "Não é permitido listar pets de outro tutor." });
                }

                var pets = await _petService.GetAllAsync(userId);
                return Ok(pets);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao listar pets: {ex.Message}" });
            }
        }

        [HttpGet("shared")]
        [Authorize(Roles = "Veterinário")]
        public async Task<IActionResult> GetShared()
        {
            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuário não identificado no token." });
            }

            try
            {
                var pets = await _petService.GetSharedAsync(userId);
                var tutorIds = pets
                    .Select(p => p.TutorId)
                    .Where(id => !string.IsNullOrWhiteSpace(id))
                    .Distinct()
                    .ToList();

                var tutorNames = new Dictionary<string, string>(StringComparer.Ordinal);
                foreach (var tutorId in tutorIds)
                {
                    var tutor = await _userManager.FindByIdAsync(tutorId);
                    tutorNames[tutorId] = tutor?.Name ?? string.Empty;
                }

                var sharedPets = pets.Select(p => new SharedPetDto
                {
                    Id = p.Id,
                    Nome = p.Nome,
                    Especie = p.Especie,
                    Raca = p.Raca,
                    PesoKg = p.PesoKg,
                    DataNascimento = p.DataNascimento,
                    Microchip = p.Microchip,
                    FotoUrl = p.FotoUrl,
                    TutorId = p.TutorId,
                    CriadoAt = p.CriadoAt,
                    TutorNome = tutorNames.TryGetValue(p.TutorId, out var nome) ? nome : string.Empty
                });

                return Ok(sharedPets);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao listar pets: {ex.Message}" });
            }
        }

        [HttpGet("{id}")]
        [Authorize(Roles = "Tutor,Veterinário")]
        public async Task<IActionResult> GetById(string id)
        {
            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuário não identificado no token." });
            }

            try
            {
                var pet = await _petService.GetByIdAsync(id);
                if (pet == null)
                {
                    return NotFound(new { Message = "Pet não encontrado." });
                }

                var acesso = await PodeVisualizarPetAsync(pet, userId);
                if (!acesso)
                {
                    return StatusCode(403, new { Message = "Você não tem permissão para visualizar este pet." });
                }

                return Ok(pet);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao buscar pet: {ex.Message}" });
            }
        }

        [HttpPost]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> Create([FromBody] CreatePetDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var tutorId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(tutorId))
            {
                return Unauthorized(new { Message = "Usuário não identificado no token." });
            }

            try
            {
                var createdPet = await _petService.CreateAsync(model, tutorId);
                return CreatedAtAction(nameof(GetById), new { id = createdPet.Id }, createdPet);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao cadastrar pet: {ex.Message}" });
            }
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> Update(string id, [FromBody] UpdatePetDto model)
        {
            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuário não identificado no token." });
            }

            try
            {
                var acesso = await GarantirPetDoTutorAsync(id, userId);
                if (acesso != null)
                {
                    return acesso;
                }

                model.TutorId = null;
                var updatedPet = await _petService.UpdateAsync(id, model);
                if (updatedPet == null)
                {
                    return NotFound(new { Message = "Pet não encontrado." });
                }

                return Ok(updatedPet);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao atualizar pet: {ex.Message}" });
            }
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> Delete(string id)
        {
            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuário não identificado no token." });
            }

            try
            {
                var acesso = await GarantirPetDoTutorAsync(id, userId);
                if (acesso != null)
                {
                    return acesso;
                }

                var deleted = await _petService.DeleteAsync(id);
                if (!deleted)
                {
                    return NotFound(new { Message = "Pet não encontrado." });
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao excluir pet: {ex.Message}" });
            }
        }

        [HttpPost("{id}/photo")]
        [HttpPost("{id}/foto")]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> UploadPhoto(string id, IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new { Message = "Nenhum arquivo de imagem foi enviado." });
            }

            var userId = ObterUserIdLogado();
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized(new { Message = "Usuário não identificado no token." });
            }

            try
            {
                var acesso = await GarantirPetDoTutorAsync(id, userId);
                if (acesso != null)
                {
                    return acesso;
                }

                var updatedPet = await _petService.UploadPhotoAsync(id, file);
                if (updatedPet == null)
                {
                    return NotFound(new { Message = "Pet não encontrado." });
                }

                return Ok(updatedPet);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao fazer upload da foto do pet: {ex.Message}" });
            }
        }

        [HttpPost("upload-photo")]
        [HttpPost("upload-foto")]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> UploadStandalonePhoto(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new { Message = "Nenhum arquivo de imagem foi enviado." });
            }

            try
            {
                var result = await _cloudinaryService.UploadImageAsync(file, "petlife/pets");
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao fazer upload da imagem: {ex.Message}" });
            }
        }

        private string? ObterUserIdLogado()
        {
            return User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? _userManager.GetUserId(User);
        }

        private async Task<IActionResult?> GarantirPetDoTutorAsync(string petId, string userId)
        {
            var pet = await _petService.GetByIdAsync(petId);
            if (pet == null)
            {
                return NotFound(new { Message = "Pet não encontrado." });
            }

            if (!string.Equals(pet.TutorId, userId, StringComparison.Ordinal))
            {
                return StatusCode(403, new { Message = "Este pet não pertence ao tutor autenticado." });
            }

            return null;
        }

        private async Task<bool> PodeVisualizarPetAsync(Pet pet, string userId)
        {
            if (User.IsInRole("Tutor"))
            {
                return string.Equals(pet.TutorId, userId, StringComparison.Ordinal);
            }

            if (User.IsInRole("Veterinário"))
            {
                var sharedPets = await _petService.GetSharedAsync(userId);
                return sharedPets.Any(p => p.Id == pet.Id);
            }

            return false;
        }
    }
}
