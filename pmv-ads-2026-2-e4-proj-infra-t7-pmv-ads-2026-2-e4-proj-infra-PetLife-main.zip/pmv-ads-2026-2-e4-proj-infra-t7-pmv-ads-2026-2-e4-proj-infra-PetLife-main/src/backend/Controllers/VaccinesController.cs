using Microsoft.AspNetCore.Mvc;
using PetLife.Api.Models;
using PetLife.Api.Services;

namespace PetLife.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Route("[controller]")]
    public class VaccinesController(IVaccineService vaccineService) : ControllerBase
    {
        private readonly IVaccineService _vaccineService = vaccineService;

        [HttpGet]
        public async Task<IActionResult> GetAll(
            [FromQuery(Name = "pet_id")] string? petIdSnake,
            [FromQuery(Name = "petId")] string? petIdCamel)
        {
            try
            {
                var petId = !string.IsNullOrWhiteSpace(petIdSnake) ? petIdSnake : petIdCamel;
                var vaccines = await _vaccineService.GetAllAsync(petId);
                return Ok(vaccines);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao listar vacinas: {ex.Message}" });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            try
            {
                var vaccine = await _vaccineService.GetByIdAsync(id);
                if (vaccine == null)
                {
                    return NotFound(new { Message = "Vacina não encontrada." });
                }

                return Ok(vaccine);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao buscar vacina: {ex.Message}" });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateVaccineDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var created = await _vaccineService.CreateAsync(model);
                return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao registrar vacina: {ex.Message}" });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] UpdateVaccineDto model)
        {
            try
            {
                var updated = await _vaccineService.UpdateAsync(id, model);
                if (updated == null)
                {
                    return NotFound(new { Message = "Vacina não encontrada." });
                }

                return Ok(updated);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao atualizar vacina: {ex.Message}" });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                var deleted = await _vaccineService.DeleteAsync(id);
                if (!deleted)
                {
                    return NotFound(new { Message = "Vacina não encontrada." });
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao excluir vacina: {ex.Message}" });
            }
        }
    }
}
