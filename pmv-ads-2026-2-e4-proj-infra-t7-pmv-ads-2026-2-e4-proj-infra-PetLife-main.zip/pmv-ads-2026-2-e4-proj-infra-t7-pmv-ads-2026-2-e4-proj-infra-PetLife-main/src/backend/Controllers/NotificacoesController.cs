using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PetLife.Api.Models;
using PetLife.Api.Services;

namespace PetLife.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class NotificacoesController(INotificacaoService notificacaoService) : ControllerBase
    {
        private readonly INotificacaoService _notificacaoService = notificacaoService;

        private string? ObterUserIdLogado()
        {
            return User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? User.FindFirst("sub")?.Value
                ?? User.FindFirst("id")?.Value
                ?? User.FindFirst("userId")?.Value;
        }

        [HttpGet]
        public async Task<IActionResult> Listar([FromQuery] string? userId)
        {
            try
            {
                var userIdToken = ObterUserIdLogado();

                if (string.IsNullOrEmpty(userIdToken))
                    return Unauthorized(new { Message = "Usuário não identificado no token." });


                var userIdAlvo = string.IsNullOrEmpty(userId) ? userIdToken : userId;

                if (userIdAlvo != userIdToken)
                    return Forbid();

                var lista = await _notificacaoService.GetByUserAsync(userIdAlvo);
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao buscar notificações: {ex.Message}" });
            }
        }
       

        [HttpPatch("{id}/lida")]
        public async Task<IActionResult> MarcarComoLida(string id)
        {
            try
            {
                var sucesso = await _notificacaoService.MarcarComoLidaAsync(id);
                if (!sucesso)
                    return NotFound(new { Message = "Notificação não encontrada." });

                return Ok(new { Message = "Notificação marcada como lida." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao atualizar notificação: {ex.Message}" });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Apagar(string id)
        {
            try
            {
                var sucesso = await _notificacaoService.DeleteAsync(id);
                if (!sucesso)
                    return NotFound(new { Message = "Notificação não encontrada." });

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao apagar notificação: {ex.Message}" });
            }
        }

        [HttpGet("config")]
        public async Task<IActionResult> ObterPreferencias()
        {
            try
            {
                var userId = ObterUserIdLogado();
                if (string.IsNullOrEmpty(userId))
                    return Unauthorized(new { Message = "Usuário não identificado no token." });

                var config = await _notificacaoService.ObterPreferenciasAsync(userId);
                return Ok(config);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao obter preferências: {ex.Message}" });
            }
        }

        [HttpPut("config")]
        public async Task<IActionResult> SalvarPreferencias([FromBody] ConfiguracaoNotificacao config)
        {
            try
            {
                var userId = ObterUserIdLogado();
                if (string.IsNullOrEmpty(userId))
                    return Unauthorized(new { Message = "Usuário não identificado no token." });

                config.UserId = userId;

                var salvo = await _notificacaoService.SalvarPreferenciasAsync(config);
                return Ok(salvo);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao salvar preferências: {ex.Message}" });
            }
        }
    }
}
