﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PetLife.Api.Models;
using PetLife.Api.Services;

namespace PetLife.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class SharesController(IShareService shareService, UserManager<User> userManager) : ControllerBase
    {
        private readonly IShareService _shareService = shareService;
        private readonly UserManager<User> _userManager = userManager;

        [HttpGet("getprofiles")]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> GetProfiles()
        {
            var userId = _userManager.GetUserId(User);
            if (string.IsNullOrEmpty(userId)) return Unauthorized();

            var profiles = await _shareService.GetProfilesAsync(userId);
            return Ok(profiles);
        }

        [HttpGet("getshares")]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> GetShares()
        {
            var userId = _userManager.GetUserId(User);
            if (string.IsNullOrEmpty(userId)) return Unauthorized();

            var shares = await _shareService.GetSharesAsync(userId);
            return Ok(shares);
        }

        [HttpPost("createshare")]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> CreateShare([FromBody] Share model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var userId = _userManager.GetUserId(User);
            if (string.IsNullOrEmpty(userId)) return Unauthorized();

            var result = await _shareService.CreateShareAsync(model, userId);
            return Ok(result);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> DeleteShare(string id)
        {
            var success = await _shareService.DeleteShareAsync(id);
            if (!success)
            {
                return NotFound("Nenhum item foi encontrado para deletar.");
            }

            return NoContent();
        }

        [HttpPost("createsharecode")]
        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> CreateShareCode([FromBody] ShareCode model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var userId = _userManager.GetUserId(User);
            if (string.IsNullOrEmpty(userId)) return Unauthorized();

            var result = await _shareService.CreateShareCodeAsync(model, userId);
            return Ok(result);
        }
        [HttpPost("redeemsharecode")]
        [Authorize(Roles = "Veterinário")]
        public async Task<IActionResult> RedeemShareCode([FromBody] string code)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var userId = _userManager.GetUserId(User);
            if (string.IsNullOrEmpty(userId)) return Unauthorized();
            var result = await _shareService.ValidateShareCode(code, userId);
            if (result == null)
            {
                return NotFound(new { Message = "Código inválido ou expirado" });
            }
            return Ok(result);
        }
    }
}