using Microsoft.AspNetCore.Mvc;
using PetLife.Api.Models;
using PetLife.Api.Services;

namespace PetLife.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReportsController(IReportService service) : ControllerBase {
        
        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetByUser(string userId) => 
            Ok(await service.GetByUserIdAsync(userId));

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Report model) {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            return Ok(await service.CreateAsync(model));
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Report model) {
            var updated = await service.UpdateAsync(id, model);
            if (updated == null) return NotFound(new { Message = "Relatorio não encontrado." });
            return Ok(updated);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id) {
            if (!await service.DeleteAsync(id)) return NotFound();
            return NoContent();
        }
    }
}