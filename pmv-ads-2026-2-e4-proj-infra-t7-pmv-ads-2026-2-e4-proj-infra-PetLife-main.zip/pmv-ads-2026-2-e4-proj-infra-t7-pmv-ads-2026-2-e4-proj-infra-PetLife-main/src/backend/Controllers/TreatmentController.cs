using Microsoft.AspNetCore.Mvc;
using PetLife.Api.Models;
using PetLife.Api.Services;

namespace PetLife.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TreatmentsController(ITreatmentService service) : ControllerBase {
        [HttpGet("pet/{petId}")]
        public async Task<IActionResult> GetByPet(string petId) 
        {
            var treatments = await service.GetByPetAsync(petId);
            return Ok(treatments);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Treatment model) 
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var createdTreatment = await service.CreateAsync(model);
            return Ok(createdTreatment);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Treatment model)
        {
            var updated = await service.UpdateAsync(id, model);
            if (updated == null) return NotFound(new { Message = "Tratamento não encontrado." });
            return Ok(updated);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var deleted = await service.DeleteAsync(id);
            if (!deleted) return NotFound(new { Message = "Tratamento não encontrado." });
            return NoContent();
        }
    
    }
}