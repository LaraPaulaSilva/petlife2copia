using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PetLife.Api.Models;
using PetLife.Api.Services;

namespace PetLife.Api.Controllers
{
    [Authorize]  
    [Route("api/[controller]")]
    [ApiController]
    public class EventosRotinaController(IEventoRotinaService eventoRotinaService) : ControllerBase
    {
        private string? ObterUserIdLogado()
        {
            return User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? User.FindFirst("sub")?.Value
                ?? User.FindFirst("id")?.Value
                ?? User.FindFirst("userId")?.Value;
        }

        [Authorize]
        [HttpGet("debug")]
        public IActionResult Debug()
        {
            return Ok(new
            {
                userIdLido = ObterUserIdLogado(),
                claims = User.Claims.Select(c => new { c.Type, c.Value })
            });
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> CriarEvento([FromBody] EventoRotina evento)
        {
            try
            {
                var userId = ObterUserIdLogado();
                if (string.IsNullOrEmpty(userId))
                    return Unauthorized(new { Message = "Usuario nao identificado no token." });

                evento.UserId = userId;

                var novoEvento = await eventoRotinaService.CreateAsync(evento);
                return Ok(novoEvento);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao salvar evento: {ex.Message}" });
            }
        }

        [HttpGet("pet/{petId}")]
        public async Task<IActionResult> ListarPorPet(string petId)
        {
            try
            {
                var lista = await eventoRotinaService.GetByPetAsync(petId);
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao buscar eventos: {ex.Message}" });
            }
        }

        [HttpGet("usuario/{userId}")]
        public async Task<IActionResult> ListarPorUsuario(string userId)
        {
            try
            {
                var lista = await eventoRotinaService.GetByUserAsync(userId);
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao buscar eventos: {ex.Message}" });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> ObterPorId(string id)
        {
            try
            {
                var evento = await eventoRotinaService.GetByIdAsync(id);

                if (evento == null)
                    return NotFound(new { Message = "Evento nao encontrado." });

                return Ok(evento);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao buscar evento: {ex.Message}" });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Atualizar(string id, [FromBody] EventoRotina evento)
        {
            try
            {
                var atualizado = await eventoRotinaService.UpdateAsync(id, evento);

                if (atualizado == null)
                    return NotFound(new { Message = "Evento nao encontrado." });

                return Ok(atualizado);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao atualizar evento: {ex.Message}" });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Apagar(string id)
        {
            try
            {
                var apagado = await eventoRotinaService.DeleteAsync(id);

                if (!apagado)
                    return NotFound(new { Message = "Evento nao encontrado." });

                return Ok(new { Message = "Evento apagado." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao apagar evento: {ex.Message}" });
            }
        }
    }
}