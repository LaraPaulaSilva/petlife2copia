using CloudinaryDotNet.Actions;
using MailKit.Search;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using PetLife.Api.Models;
using PetLife.Api.Services;
using System.Text;

namespace PetLife.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Route("[controller]")]
    public class UsersController(
        UserManager<User> userManager,
        ITokenService tokenService, IMailService mailService) : ControllerBase
    {
        private readonly UserManager<User> _userManager = userManager;
        private readonly ITokenService _tokenService = tokenService;
        private readonly IMailService _mailService = mailService;

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Register model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var user = new User
            {
                UserName = model.Email.Trim(),
                Email = model.Email.Trim(),
                Name = model.Name.Trim(),
                Crmv = null,
                PhoneNumber = null,
                Cpf = null,
                Endereço = null,
                Image = null,
            };

            var result = await _userManager.CreateAsync(user, model.Password);

            if (result.Succeeded)
            {
                await _userManager.AddToRoleAsync(user, "Tutor");
                var token = _tokenService.GenerateToken(user, "Tutor");
                var expiresAt = _tokenService.GetExpirationDate();

                return CreatedAtAction(nameof(GetUserProfile), new AuthResponseDto 
                {
                    Token = token,
                    ExpiresAt = expiresAt,
                    User = new UserDto
                    {
                        Id = user.Id,
                        Name = user.Name,
                        Email = user.Email!,
                    }
                });
            }

            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }

            return BadRequest(ModelState);
        }

        [HttpPost("registerrole")]
        [Authorize]
        public async Task<IActionResult> RegisterRole([FromBody] string role)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound(new { Message = "Usuário não encontrado." });
            }
            if(role == "Tutor")
            {
                return Ok();
            }
            await _userManager.RemoveFromRoleAsync(user, "Tutor");
            await _userManager.AddToRoleAsync(user, "Veterinário");
            var token = _tokenService.GenerateToken(user, role);
            var expiresAt = _tokenService.GetExpirationDate();

            return Ok(new AuthResponseDto
            {
                Token = token,
                ExpiresAt = expiresAt,
                User = new UserDto
                {
                    Id = user.Id,
                    Name = user.Name,
                    Email = user.Email,
                    Role = role,
                    Crmv = user.Crmv,
                    Telefone = user.PhoneNumber,
                    Endereço = user.Endereço,
                    Cpf = user.Cpf,
                    Image = user.Image
                }
            });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Login request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var user = await _userManager.FindByEmailAsync(request.Email.Trim());
                if (user == null)
                {
                    return BadRequest(new { Message = "E-mail ou senha incorretos." });
                }

                var isPasswordValid = await _userManager.CheckPasswordAsync(user, request.Password);
                if (!isPasswordValid)
                {
                    return BadRequest(new { Message = "E-mail ou senha incorretos." });
                }

                var roles = await _userManager.GetRolesAsync(user);
                var role = roles.FirstOrDefault() ?? "Tutor";

                var token = _tokenService.GenerateToken(user, role);
                var expiresAt = _tokenService.GetExpirationDate();

                return Ok(new AuthResponseDto
                {
                    Token = token,
                    ExpiresAt = expiresAt,
                    User = new UserDto
                    {
                        Id = user.Id,
                        Name = user.Name,
                        Email = user.Email ?? request.Email,
                        Role = role,
                        Crmv = user.Crmv,
                        Telefone = user.PhoneNumber,
                        Endereço = user.Endereço,
                        Cpf = user.Cpf,
                        Image = user.Image
                    }
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao autenticar: {ex.Message}" });
            }
        }

        [HttpPost("forgotpassword")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPassword model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var user = await _userManager.FindByEmailAsync(model.Email.Trim());
            if (user == null)
            {
                return Ok(new { Message = "Um link de redefinição foi enviado." });
            }
            string token = await _userManager.GeneratePasswordResetTokenAsync(user);
            var callbackUrl = $"https://localhost:5173/resetpassword?user={WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(user.Email))}&token={WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(token))}";
            await _mailService.SendEmailAsync(
                toEmail: user.Email,
                subject: "Pet Life - Redefinição de senha",
                body: $"<h1>Pet Life - Redefinição de senha</h1><a href={callbackUrl}>Acesse para redefinir sua senha</a>"
                );

            return Ok(new { Message = "Um link de redefinição foi enviado." });
        }

        [HttpPost("resetpassword")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPassword model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var email = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(model.Email));
            var user = await _userManager.FindByEmailAsync(email);
            if (user == null)
            {
                return BadRequest(new { Message = "Requisição inválida." });
            }
            var token = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(model.Token));
            var result = await _userManager.ResetPasswordAsync(user, token, model.Password);
            if(result.Succeeded)
            {
                return Ok(new { Message = "Senha alterada com sucesso." });
            }
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(error.Code, error.Description);
            }
            return BadRequest(ModelState);
        }

        [HttpPost("changepassword")]
        [Authorize]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePassword model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    return NotFound(new { Message = "Usuário não encontrado." });
                }
                var result = await _userManager.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword);
                if (result.Succeeded)
                {
                    var roles = await _userManager.GetRolesAsync(user);
                    var role = roles.FirstOrDefault() ?? "Tutor";

                    return Ok(new {Message = "Senha alterada com sucesso."});
                } else
                {
                    return StatusCode(401, new { Message = "Senha atual incorreta." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao autenticar: {ex.Message}" });
            }
        }

        [HttpPost("changeprofile")]
        [Authorize]
        public async Task<IActionResult> ChangeProfile([FromBody] ChangeProfile model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    return NotFound(new { Message = "Usuário não encontrado." });
                }
                user.Name = model.Name;
                user.Crmv = model.Crmv;
                user.PhoneNumber = model.Telefone;
                user.Cpf = model.Cpf;
                user.Endereço = model.Endereço;
                user.Image = model.Image;
                var result = await _userManager.UpdateAsync(user);
                var roles = await _userManager.GetRolesAsync(user);
                var role = roles.FirstOrDefault() ?? "Tutor";

                if (result.Succeeded)
                {
                    return Ok(new UserDto
                    {
                        Id = user.Id,
                        Name = user.Name,
                        Email = user.Email,
                        Role = role,
                        Crmv = user.Crmv,
                        Telefone = user.PhoneNumber,
                        Endereço = user.Endereço,
                        Cpf = user.Cpf,
                        Image = user.Image
                    });
                }
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
                return BadRequest();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao autenticar: {ex.Message}" });
            }
        }

        [HttpGet("me")]
        [Authorize]
        public async Task<IActionResult> GetUserProfile()
        {
            try
            {
                var userId = _userManager.GetUserId(User);
                if (string.IsNullOrEmpty(userId))
                {
                    return Unauthorized(new { Message = "Usuário não identificado." });
                }

                var user = await _userManager.FindByIdAsync(userId);
                if (user == null)
                {
                    return NotFound(new { Message = "Usuário não encontrado." });
                }

                var roles = await _userManager.GetRolesAsync(user);
                var role = roles.FirstOrDefault() ?? "Tutor";

                return Ok(new UserDto
                {
                    Id = user.Id,
                    Name = user.Name,
                    Email = user.Email ?? string.Empty,
                    Role = role,
                    Crmv = user.Crmv,
                    Telefone = user.PhoneNumber,
                    Endereço = user.Endereço,
                    Cpf = user.Cpf,
                    Image = user.Image
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao obter perfil: {ex.Message}" });
            }
        }
        [HttpGet("vets")]
        [Authorize]
        public async Task<IActionResult> ListVets([FromQuery] string? search)
        {
            try
            {
                var userId = _userManager.GetUserId(User);
                if (string.IsNullOrEmpty(userId))
                {
                    return Unauthorized(new { Message = "Usuário não identificado." });
                }

                var user = await _userManager.FindByIdAsync(userId);
                if (user == null)
                {
                    return NotFound(new { Message = "Usuário não encontrado." });
                }
                var users = await _userManager.GetUsersInRoleAsync("Veterinário");

                if (string.IsNullOrWhiteSpace(search))
                {
                    var usersDto = users.Select(u => new UserDto
                    {
                        Id = u.Id,
                        Name = u.Name,
                        Email = u.Email ?? string.Empty,
                        Role = "Veterinário",
                        Crmv = u.Crmv,
                        Telefone = u.PhoneNumber,
                        Endereço = u.Endereço,
                        Cpf = u.Cpf,
                        Image = u.Image
                    });



                    return Ok(users);
                }
                string term = search.Trim().ToLower();
                var filteredUsers = users.Where(u => (u.Name.ToLower().Contains(term)) ||
                (u.Endereço != null && u.Endereço.ToLower().Contains(term)) ||
                (u.Crmv != null && u.Crmv.ToLower().Contains(term))
                );
                return Ok(filteredUsers);
                
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = $"Erro ao obter perfil: {ex.Message}" });
            }
        }
    }
}
