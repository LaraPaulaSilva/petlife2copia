# PetLife

`CURSO: Analise e Desenvolvimento de Sistemas`

`DISCIPLINA: Projeto - Desenvolvimento de uma Aplicação Distribuída`

`EIXO: 4`

O **PetLife** é uma plataforma distribuída para a gestão do prontuário eletrônico de animais de estimação, desenvolvida como projeto da disciplina de Desenvolvimento de uma Aplicação Distribuída. O sistema centraliza, em um único lugar, todo o histórico de saúde do pet — consultas, vacinas, tratamentos, documentos e registros de rotina —, conectando de forma segura os dois perfis de usuário do domínio: tutores e veterinários.

A motivação do projeto parte de um problema comum: as informações de saúde dos animais costumam ficar dispersas em papéis, carteirinhas e diferentes clínicas, o que dificulta o acompanhamento contínuo e a tomada de decisão clínica. O PetLife resolve isso oferecendo um prontuário unificado e sempre acessível, no qual o tutor acompanha a vida do seu pet e o veterinário registra o atendimento com praticidade, rastreabilidade e controle de acesso por perfil.

A solução é composta por três aplicações integradas: uma API RESTful (backend), uma interface web e uma aplicação mobile. O backend é construído em C# com ASP.NET Core e banco de dados NoSQL MongoDB, com autenticação via JWT, enquanto as aplicações cliente consomem os serviços da API para entregar a experiência ao usuário final. A arquitetura distribuída permite escalabilidade e manutenção independente de cada camada do sistema.

## Integrantes

- [Erison Guimarães](docs/atas/aluno1.md)
- [Lara Paula Silva](docs/atas/aluno2.md)
- [Lucas Costa](docs/atas/aluno3.md)
- [Mariana Gressi](docs/atas/aluno4.md)
- [Matheus Feliciano Andrade Bernardes](docs/atas/aluno5.md)

## Orientador

- Sinaide Nunes Bezerra

# Planejamento

|    Etapa    | Atividades (Documentação)                                 |        Painel de Feedback e Avaliação        |
| :---------: | --------------------------------------------------------- | :------------------------------------------: |
| **ETAPA 1** | [Documentação de Contexto](docs/contexto.md)              | [🔍 Ver Feedback 1](docs/feedback/etapa1.md) |
| **ETAPA 2** | [APIs, Web Services e Persistência](docs/backend-apis.md) | [🔍 Ver Feedback 2](docs/feedback/etapa2.md) |
| **ETAPA 3** | [Interface Web Responsiva](docs/frontend-web.md)          | [🔍 Ver Feedback 3](docs/feedback/etapa3.md) |
| **ETAPA 4** | [Interface Móvel Integrada](docs/frontend-mobile.md)      | [🔍 Ver Feedback 4](docs/feedback/etapa4.md) |
| **ETAPA 5** | [Apresentação e Checklist Final](presentation/README.md)  |             _Consolidado Final_              |

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.

# Código

<li><a href="src/README.md"> Código Fonte</a></li>

# Apresentação

<li><a href="presentation/README.md"> Apresentação da solução</a></li>
