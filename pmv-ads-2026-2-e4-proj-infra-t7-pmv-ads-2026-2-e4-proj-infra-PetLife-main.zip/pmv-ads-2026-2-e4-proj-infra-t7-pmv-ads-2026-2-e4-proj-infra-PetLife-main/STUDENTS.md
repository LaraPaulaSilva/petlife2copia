# 👥 Equipe e Configuração de Autoria do Repositório

Este arquivo centraliza as informações da equipe. É fundamental que cada membro preencha a tabela abaixo com o seu **Nome Completo** e o seu **Usuário do GitHub (Username)** exato.

Esses dados servem como chave primária para realizar o acompanhamento do repositório, mapear as contribuições reais (commits, arquivos modificados, conteúdo de documentação escrita) e preencher as páginas individuais de feedback e acompanhamento semanal pelas ferramentas de controle pedagógico da disciplina.

---

## 📋 Cadastro de Alunos e Autores do Repositório

*Alunos: substituam as linhas abaixo com os dados reais de cada participante do grupo. Removam linhas sobressalentes se o grupo possuir menos de 6 membros.*

| Aluno | Nome Completo | GitHub Username | Função Principal Pretendida |
| :---: | :--- | :--- | :--- |
| **Aluno 1** | [Insira Nome Completo] | `username_github_1` | [Ex: APIs Backend / DevOps] |
| **Aluno 2** | [Insira Nome Completo] | `username_github_2` | [Ex: Designer / Frontend Web] |
| **Aluno 3** | [Insira Nome Completo] | `username_github_3` | [Ex: Frontend Web / Testes] |
| **Aluno 4** | [Insira Nome Completo] | `username_github_4` | [Ex: APIs Backend / Banco de Dados] |
| **Aluno 5** | [Insira Nome Completo] | `username_github_5` | [Ex: Frontend Mobile] |
| **Aluno 6** | [Insira Nome Completo] | `username_github_6` | [Ex: Designer / Frontend Mobile] |

---

## 📋 Como funciona a Auditoria de Contribuição?

1. **Leitura dos Autores**: O sistema de acompanhamento lê esta tabela e descobre qual Username do GitHub pertence a cada estudante.
2. **Varredura do Git**: O processo percorre o histórico da branch principal correlacionando os commits com as respectivas etapas e entregas.
3. **Mapeamento de Rubricas por Contribuição Real**: Em vez de apenas contar commits, são avaliados o valor de engenharia e os documentos criados.
4. **Alimentação dos Relatórios de Acompanhamento**: São atualizados automaticamente os arquivos de acompanhamento individual na pasta [docs/atas/](docs/atas/) (que funcionam como portas de feedback e evolução individual continuada).
