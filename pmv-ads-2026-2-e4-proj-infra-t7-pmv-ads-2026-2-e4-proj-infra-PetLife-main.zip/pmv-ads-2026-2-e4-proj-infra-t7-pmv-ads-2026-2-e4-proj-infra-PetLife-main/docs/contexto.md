# 🏗️ Etapa 1: Contexto e Planejamento da Solução Distribuída

Este documento serve como diretriz mestre e repositório de evidências para a **Etapa 1: Contexto e Planejamento da Solução**. Ele foi estruturado de forma a facilitar o acompanhamento e auto-gestão das atividades pelos alunos.

---

## 🎯 Rubricas de Avaliação desta Etapa

Ao final desta Etapa, cada aluno será avaliado individualmente nestas 5 competências:

1. **H26a-ADS-CST: Definir o problema de forma clara e objetiva, apresentando os objetivos, a justificativa e a motivação da escolha**: Definir o problema de forma clara e objetiva, apresentando os objetivos, a justificativa e a motivação da escolha (Medido na seção [Catálogo de Serviços Web](#-catalogo-de-servicos-web)).
2. **H26b-ADS-CST - Identificar os perfis de usuários, investigar suas necessidades e elaborar Personas.**: Identificar os perfis de usuários, investigar suas necessidades e elaborar Personas. (Medido na seção [Arquitetura da Solução](#-arquitetura-da-solucao)).
3. **H26c-ADS-CST - Definir os requisitos funcionais e não funcionais do projeto de acordo com o contexto levantado**: Definir os requisitos funcionais e não funcionais do projeto de acordo com o contexto levantado (Medido na seção [Especificação de Contratos de APIs](#-especificacao-de-contratos-de-apis)).
4. **H24a-ADS-CST - Definir e documentar a arquitetura da aplicação distribuída**: Definir e documentar a arquitetura da aplicação distribuída (Medido na seção [Projeto do Frontend Web](#-projeto-do-frontend-web)).

---

## 📅 Cronograma do Semestre (Semana → Período)

Esta tabela é a referência única de planejamento semanal do projeto, usada por todas as Etapas. Ela usa **número relativo de semana** (Semana 1, Semana 2...), não datas fixas, para que o template continue válido em qualquer semestre — cada turma ancora a "Semana 1" na semana real de início da disciplina.

| Semana | Etapa | Atividade Prevista                                                           |
| :----: | :---: | :--------------------------------------------------------------------------- |
|   1    |   1   | Apresentação do Projeto                                                      |
|   2    |   1   | Definição dos Temas e Organização dos Grupos                                 |
|   3    |   1   | Especificações do Projeto                                                    |
|   4    |   1   | Arquitetura da Solução                                                       |
|   5    |   2   | Desenvolvimento de Funcionalidades - API (inclui apresentação da Etapa 1)    |
|   6    |   2   | Desenvolvimento de Funcionalidades - API                                     |
|   7    |   2   | Desenvolvimento de Funcionalidades - API                                     |
|   8    |   2   | Desenvolvimento de Funcionalidades - API                                     |
|   9    |   2   | Testes - API                                                                 |
|   10   |   3   | Desenvolvimento de Funcionalidades - Web (inclui apresentação da Etapa 2)    |
|   11   |   3   | Desenvolvimento de Funcionalidades - Web                                     |
|   12   |   3   | Desenvolvimento de Funcionalidades - Web                                     |
|   13   |   3   | Testes - Front-End Web                                                       |
|   14   |   4   | Desenvolvimento de Funcionalidades - Mobile (inclui apresentação da Etapa 3) |
|   15   |   4   | Desenvolvimento de Funcionalidades - Mobile                                  |
|   16   |   4   | Desenvolvimento de Funcionalidades - Mobile                                  |
|   17   |   4   | Testes - Front-End Mobile                                                    |
|   18   |   5   | Apresentação Final do Projeto                                                |

_As Semanas 1 e 2 não possuem tarefa de documentação associada (organização inicial do grupo e apresentação do projeto)._

---

## 📅 QUADRO DE CONTRIBUIÇÃO REAL (ETAPA 1)

**Atenção alunos:** Preencham esta tabela para atualizar o andamento das tarefas e quem foi o responsável por cada entrega. Garanta que o nome, usuário do GitHub e o link para a seção onde está o seu trabalho estejam devidamente preenchidos.

- **Status admitidos**: `⌛ Não Iniciado` | `📝 Em Progresso` | `✔️ Entregue`
- **Autoria Git**: Indica se há commits desse estudante modificando a seção correspondente.

**Atividades Semanais desta Etapa** (ver [Cronograma do Semestre](#-cronograma-do-semestre-semana--periodo)):

- `ATV1.1` — Especificações do Projeto (Semana 3)
- `ATV1.2` — Arquitetura da Solução (Semana 4)

| Rubrica Curricular | ID Tarefa | Atividade Semanal | Descrição Detalhada da Tarefa                        | Estudante Responsável | GitHub Username | Status de Entrega | Evidência/Seção Temática                                | Autoria Git |
| :----------------: | :-------: | :---------------: | :--------------------------------------------------- | :-------------------- | :-------------: | :---------------: | :------------------------------------------------------ | :---------: |
|      **H26a**      |  `T1.1`   |     `ATV1.1`      | Definição do Problema, Objetivos e Justificativa     | [Nome do Aluno 1]     |   `username1`   | `⌛ Não Iniciado` | [Seção 1](#11-problema-objetivos-e-justificativa)       |     [ ]     |
|      **H34a**      |  `T1.2`   |     `ATV1.1`      | Descrição das Personas e Mapa de Stakeholders        | [Nome do Aluno 2]     |   `username2`   | `⌛ Não Iniciado` | [Seção 1.2](#12-personas-e-stakeholders)                |     [ ]     |
|      **H34a**      |  `T1.3`   |     `ATV1.1`      | Definição de Requisitos Funcionais e Priorização     | [Nome do Aluno 3]     |   `username3`   | `⌛ Não Iniciado` | [Seção 2.1](#21-requisitos-funcionais-e-não-funcionais) |     [ ]     |
|      **H34a**      |  `T1.4`   |     `ATV1.1`      | Catálogo de Serviços Web e Acordos de SLA            | [Nome do Aluno 1]     |   `username1`   | `⌛ Não Iniciado` | [Seção 3.0](#-catalogo-de-servicos-web)                 |     [ ]     |
|      **H35a**      |  `T1.5`   |     `ATV1.2`      | Diagrama de Componentes Físico e Lógico da Solução   | [Nome do Aluno 4]     |   `username4`   | `⌛ Não Iniciado` | [Seção 4.1](#41-diagrama-de-arquitetura)                |     [ ]     |
|      **H35a**      |  `T1.6`   |     `ATV1.2`      | Definição das Tecnologias Distribuídas e Hospedagem  | [Nome do Aluno 5]     |   `username5`   | `⌛ Não Iniciado` | [Seção 4.2](#42-tecnologias-e-hospedagem)               |     [ ]     |
|      **H36a**      |  `T1.7`   |     `ATV1.2`      | Especificação de Contratos de API (Endpoints/Verbos) | [Nome do Aluno 6]     |   `username6`   | `⌛ Não Iniciado` | [Seção 5.0](#-especificacao-de-contratos-de-apis)       |     [ ]     |
|      **H37a**      |  `T1.8`   |     `ATV1.2`      | Wireframes do Frontend Web e Fluxograma de Navegação | [Nome do Aluno 3]     |   `username3`   | `⌛ Não Iniciado` | [Seção 6.0](#-projeto-do-frontend-web)                  |     [ ]     |
|      **H38a**      |  `T1.9`   |     `ATV1.2`      | Wireframes do Frontend Móvel e Fluxo de Gestos       | [Nome do Aluno 2]     |   `username2`   | `⌛ Não Iniciado` | [Seção 7.0](#-projeto-do-frontend-movel)                |     [ ]     |

---

# 1. Introdução e Contexto

O cuidado com a saúde de animais de estimação passou a ser uma prioridade para diversas famílias, exigindo um acompanhamento tão rigoroso quanto o dedicado a seres humanos. Contudo, o panorama atual do cuidado animal é caracterizado pela pulverização de informações veterinárias e pela ausência de controle sobre quem manuseia esses dados médicos. A questão central está na desorganização e no extravio de dados relevantes, além do risco associado a tutores que administram posologias e prescrições sem o cuidado necessário, o que acarreta consequências diretas na saúde do animal.

Esse cenário ganhou peso legal com a Resolução nº 1.653/2025 do CFMV, que tornou o prontuário veterinário um documento técnico-legal obrigatório, exigindo evolução diária assinada eletronicamente pelo veterinário, anexação de laudos e prazo máximo de 5 dias úteis para entrega de cópias. Isso, somado à lógica de Saúde Única (One Health), torna a gestão manual ou descentralizada inviável.

Diante desse cenário, este projeto tem como propósito geral construir o "Prontuário Pet Inteligente", uma aplicação distribuída formada por versões Web e mobile que reúne toda a saúde do animal em um só lugar, com permissões de acesso rígidas que distinguem a observação cotidiana da prescrição médica. Essa distribuição entre diferentes perfis de usuário, meios de acesso e módulos funcionais independentes possibilita que o sistema funcione de forma desacoplada e escalável, preservando, ao mesmo tempo, um histórico único e coerente por animal.

A justificativa para este desenvolvimento sustenta-se na necessidade de eliminar falhas na imunização, prevenir erros de tratamento e fornecer dados precisos para diagnósticos. O público-alvo abrange tutores contemporâneos com necessidades variadas e médicos veterinários que prec

## 1.1. Problema, Objetivos e Justificativa

- **O Problema**:

No cenário atual da rotina de cuidados animais, a gestão da saúde do pet sofre com a descontinuidade da informação e a ausência de centralização. O tutor frequentemente perde ou não localiza informações essenciais, como carteiras de vacinação, registros de alergias ou resultados de exames anteriores em momentos críticos, o que compromete e atrasa os atendimentos de urgência.

Analisando de ponta a ponta, essa desorganização não é apenas uma questão burocrática, mas um sério gerador de risco clínico. Sem uma gestão bem definida, ocorrem falhas na imunização por descuido, necessidade de repetir exames invasivos sem necessidade real (com custo financeiro e físico duplicado) e, sobretudo, uma alta probabilidade de erros de tratamento, nos quais o tutor pode equivocar-se em doses ou horários de medicamentos prescritos.

Além disso, no cotidiano da casa do tutor, surge o problema da invisibilidade dos padrões. O dono do animal presencia acontecimentos isolados, como uma mudança na alimentação seguida de um episódio de vômito horas depois, mas não consegue organizar essas observações. Como resultado, o tutor toma decisões sem fundamento e o veterinário não recebe as informações necessárias para converter esses indícios em medicina preventiva e diagnósticos precisos.

- **Objetivo Geral**:
  Desenvolver uma aplicação distribuída, nos formatos Web e mobile, que atue como o dossiê de saúde definitivo do animal, solucionando o problema da fragmentação de registros através da centralização de dados dispersos em informação acionável e acessível em segundos.

- **Objetivos Críticos Específicos (Mínimo de 3)**:

  1.Garantir a segurança em tratamentos e imunizações através de governança de dados: Desenvolver módulos de "Vacinas" e "Medicamentos" onde a criação e edição das prescrições (posologia exata, frequência, cálculo de próxima dose) sejam de acesso exclusivo do perfil Veterinário, restabelecendo ao Tutor apenas a função de visualização e confirmação (check) da administração, mitigando os erros de tratamento.

  2.Implementar um diário de Rotina: Criar um "Diário do Pet" gerido integralmente pelo tutor para o registro de sintomas e rotina diária (vômitos, coceiras), permitindo que o sistema ilumine padrões de causa e efeito que serão visualizados de forma estruturada pelo médico veterinário em consultas.

  3.Estabelecer uma Memória Clínica interoperável: Construir um repositório digital de "Histórico Clínico e Exames" onde tanto tutores quanto veterinários possam adicionar documentos e eventos médicos colaborativamente, garantindo que o histórico acompanhe o animal de forma unificada e ágil.

  4.Estruturar o módulo de Consulta: disponibilizar um módulo dedicado às consultas, no qual o Veterinário mantenha controle completo sobre os registros clínicos gerados, e o Tutor acesse as informações conforme as regras de permissão estabelecidas para o seu perfil.

  5.Estruturar o módulo Financeiro: implementar o controle financeiro do sistema, de acesso exclusivo ao perfil Veterinário, com visibilidade concedida ao Tutor conforme a necessidade de cada situação.

  6.Disponibilizar relatórios: permitir que tutores e veterinários gerem e acompanhem relatórios consolidados a partir dos dados registrados no sistema, apoiando decisões clínicas e o acompanhamento do histórico do animal.

- **Justificativa**:
  A motivação principal para o desenvolvimento desta aplicação é transcender a simples "organização" para entregar segurança real e eliminar a ansiedade da gestão de saúde animal. O desenvolvimento de um sistema com permissões baseadas em papéis justifica-se pelo fato de que a ausência de gestão centralizada gera o risco real de erros de dose. Um problema que não é hipotético: um estudo conduzido no Hospital Veterinário da Universidade Federal Rural da Amazônia, que analisou 406 receituários eletrônicos prescritos por veterinários residentes, constatou que todas as prescrições continham pelo menos um erro, sendo os mais frequentes a ausência da quantidade total de medicamento, siglas e abreviaturas incorretas e falhas na concentração informada. Outra fonte técnica estima que erros de dosagem afetam cerca de 10% dos casos clínicos na rotina veterinária, reforçando que mesmo profissionais experientes estão sujeitos a falhas de cálculo sob pressão de tempo.

Ao aprofundar a aplicação em restrições onde apenas o veterinário insere a dose exata e o tutor apenas consome o alerta ativo, o software elimina a dependência da memória do tutor, garantindo que o tratamento seja seguido à risca.

Além disso, a escolha de focar em um histórico médico colaborativo justifica-se pela premissa de que o "histórico acompanha o animal, não a clínica". Isso assegura aos donos a certeza de que, em uma emergência ou viagem, um novo veterinário de referência receberá imediatamente o perfil compartilhado completo com exames e cirurgias, tendo tudo o que precisa para salvar o animal; eliminando a fragmentação de dados entre diferentes clínicas que hoje compromete a continuidade do cuidado.

---

## 1.2. Personas e Stakeholders

## 1. Médica veterinária de clínica geral

<img width="870" height="510" alt="layer-clinica-geral" src="https://github.com/user-attachments/assets/de23d07b-6161-48a0-a38c-14daef5f20b7" />

**Nome:** Mariana Costa
**Idade:** 34 anos
**Experiência:** 9 anos
**Contexto:** Trabalha em uma clínica veterinária de médio porte e atende aproximadamente 15 animais por dia.

**Objetivos**

- Consultar rapidamente o histórico dos pacientes.
- Registrar informações durante ou após uma consulta.
- Acompanhar tratamentos e medicamentos prescritos.
- Verificar se vacinas estão atualizadas.
- Organizar sua agenda de consultas.

**Dificuldades**

- Informações dos pacientes ficam espalhadas entre fichas, mensagens e sistemas diferentes.
- Perde tempo procurando resultados ou informações de consultas anteriores.
- Tutores frequentemente não lembram quais medicamentos o animal está utilizando.

**Necessidades no sistema**

- Histórico de saúde centralizado.
- Visualização rápida de medicamentos, vacinas e consultas.
- Registro de diagnóstico e observações.
- Agenda organizada por dia.

**Uso de tecnologia:** Alto.

## 2. Médico veterinário e proprietário de clínica

<img width="678" height="452" alt="images" src="https://github.com/user-attachments/assets/7ee3586c-7d51-4daf-a7c5-9c7ba7d8e62d" />

**Nome:** Roberto Almeida
**Idade:** 41 anos
**Experiência:** 16 anos
**Contexto:** Além de realizar atendimentos, administra uma clínica com outros veterinários.

**Objetivos**

- Tornar o atendimento mais organizado.
- Evitar perda de informações dos pacientes.
- Facilitar a continuidade do atendimento entre diferentes veterinários.
- Reduzir registros em papel.

**Dificuldades**

- Um mesmo animal pode ser atendido por diferentes profissionais.
- Informações podem ficar incompletas ou duplicadas.
- A equipe perde tempo buscando fichas antigas.

**Necessidades no sistema**

- Prontuário centralizado.
- Histórico atualizado.
- Identificação clara das consultas realizadas.
- Agenda de pacientes.

**Uso de tecnologia:** Médio-alto.

## 3. Professora aposentada

<img width="547" height="365" alt="images (1)" src="https://github.com/user-attachments/assets/fc8bed4f-0ebf-45a6-a987-735de8ed4261" />

**Nome:** Dona Helena Martins
**Idade:** 63 anos
**Pet:** Bob, cão de 11 anos
**Contexto:** Bob é um animal idoso e possui problemas de saúde que exigem acompanhamento frequente e uso contínuo de medicamentos.

**Objetivos**

- Acompanhar o tratamento do Bob.
- Consultar quais medicamentos ele utiliza.
- Registrar mudanças no comportamento ou alimentação.
- Acompanhar consultas frequentes.

**Dificuldades**

- Tem dificuldade para lembrar nomes de medicamentos.
- Pode se confundir com diferentes horários e dosagens.
- Não possui tanta familiaridade com sistemas complexos.

**Necessidades no sistema**

- Interface simples e legível.
- Informações objetivas.
- Histórico de medicamentos.
- Registro fácil de observações.

**Uso de tecnologia:** Médio-baixo.

## 4. Família viajante

<img width="713" height="429" alt="images (2)" src="https://github.com/user-attachments/assets/bba40d1e-c3e6-4e8d-b6c4-a2e475761395" />

**Nomes:** Fernanda e João Castro
**Idades:** 29 e 31 anos
**Contexto:** Casal de nômades digitais, tutores do "Zeus", um Border Collie que os acompanha em todas as trilhas e viagens, estão sempre cruzando fronteiras estaduais e frequentando novos ambientes com o pet.

**Objetivos**

- Ter acesso imediato à carteira de vacinação digital em aeroportos, hotéis e postos de fiscalização.
- Garantir que a "Memória Clínica" do Zeus esteja disponível em qualquer cidade caso ele precise de atendimento urgente.
- Centralizar resultados de exames de sangue e laudos para evitar repetições desnecessárias de procedimentos em novas clínicas.

**Dificuldades**

- Insegurança ao frequentar novos veterinários que não conhecem o histórico de alergias do Zeus.
- Dificuldade em carregar pastas físicas de documentos durante as viagens.
- Risco de atrasar diagnósticos por falta de comunicação entre diferentes clínicas de diferentes regiões.

**Necessidades no sistema**

- Acesso rápido e offline-friendly ao histórico de saúde do pet.
- Compartilhamento do perfil do pet com novos veterinários.
- Repositório centralizado de exames e laudos.

**Uso de tecnologia:** Alto.

## 5. Estudante universitária

<img width="711" height="431" alt="images (3)" src="https://github.com/user-attachments/assets/fa1acb33-a041-42b2-9783-7e8bc58d027b" />

**Nome:** Ana Beatriz Santos
**Idade:** 24 anos
**Pet:** Luna, gata de 3 anos
**Contexto:** Mora sozinha com sua gata e utiliza principalmente o celular para organizar compromissos.

**Objetivos**

- Acompanhar vacinas da Luna.
- Marcar consultas pelo celular.
- Registrar informações sobre comportamento e sintomas.
- Consultar rapidamente recomendações do veterinário.

**Dificuldades**

- Esquece datas de vacinação.
- Perde documentos físicos da clínica.
- Nem sempre lembra quando determinado sintoma começou.

**Necessidades no sistema**

- Aplicativo mobile simples.
- Histórico de saúde.
- Anotações.
- Agenda de consultas.
- Informações sobre medicamentos e vacinas.

**Uso de tecnologia:** Muito alto.

## Mapa de Interesses dos Stakeholders

**Stakeholders Diretos (Atores principais):**

<img width="1968" height="1084" alt="mapa_stakeholders_pet_life (1)" src="https://github.com/user-attachments/assets/632dd5f6-e1b8-49fb-838a-b21df3725b67" />

## 1.3.Histórias de Usuário

| ID | Eu como... | Quero/preciso... | Para... |
|----|-----------|-------------------|---------|
| **TUT-01** | Tutor | criar, visualizar, editar e excluir minha conta de tutor | administrar meus dados e utilizar as funcionalidades de acompanhamento dos meus pets. |
| **TUT-02** | Tutor | criar, visualizar, editar e excluir o cadastro do meu pet, contendo nome, foto, peso, microchip, idade, espécie e raça | manter um perfil centralizado que conecte todas as informações de saúde e bem-estar do animal. |
| **TUT-03** | Tutor | visualizar o histórico de vacinação e inserir vacinas anteriores ao primeiro uso do sistema | iniciar o acompanhamento com um histórico completo e reduzir o risco de falhas na imunização. |
| **TUT-04** | Tutor | marcar como administrada cada dose de um medicamento prescrito | acompanhar diariamente o tratamento do meu pet sem alterar a prescrição realizada pelo veterinário. |
| **TUT-05** | Tutor | enviar, visualizar, atualizar e excluir documentos clínicos, como exames, imagens e receitas | centralizar os documentos de saúde do meu pet e evitar a perda de informações importantes. |
| **TUT-06** | Tutor | registrar e manter eventos médicos, como consultas, cirurgias e internações, na linha do tempo do pet | manter seu histórico de saúde completo e disponível para atendimentos futuros. |
| **TUT-07** | Tutor | criar, visualizar, editar e excluir registros diários sobre sintomas e comportamentos, como vômitos, coceiras e alterações alimentares | identificar padrões e fornecer informações mais precisas ao veterinário. |
| **TUT-08** | Tutor | criar, visualizar, editar e excluir eventos de rotina, como banho, tosa e outros cuidados recorrentes, incluindo agendamento e recorrência | organizar os cuidados de bem-estar do meu pet e evitar o esquecimento de compromissos. |
| **TUT-09** | Tutor | cadastrar, editar e remover contatos de veterinários ou clínicas e conceder ou revogar o acesso deles ao perfil do meu pet | facilitar o compartilhamento das informações de saúde mantendo o controle sobre a privacidade dos dados. |
| **TUT-10** | Tutor | agendar, visualizar e cancelar consultas veterinárias para meus pets | organizar os atendimentos de saúde sem precisar utilizar outros meios de comunicação com a clínica. |
| **VET-01** | Veterinário | criar, visualizar, editar e excluir minha conta de veterinário | utilizar o sistema para acompanhar os pacientes sob meus cuidados. |
| **VET-02** | Veterinário | visualizar os dados cadastrais do pet, como nome, espécie, raça, idade, peso e microchip | obter rapidamente o contexto necessário durante consultas e emergências sem alterar informações cadastradas pelo tutor. |
| **VET-03** | Veterinário | registrar, editar e remover vacinas aplicadas, informando tipo e data, com cálculo da próxima dose e possibilidade de adicionar comprovantes | manter um histórico vacinal confiável e auxiliar o tutor no acompanhamento dos próximos reforços. |
| **VET-04** | Veterinário | criar, editar e encerrar tratamentos, definindo medicamento, dose, frequência e duração, inclusive para medicamentos recorrentes | garantir que o tratamento prescrito seja registrado de maneira clara e reduzir o risco de erros durante sua execução. |
| **VET-05** | Veterinário | adicionar, consultar, editar e remover exames e documentos clínicos do pet | manter uma base documental completa para apoiar diagnósticos e evitar a repetição desnecessária de exames. |
| **VET-06** | Veterinário | registrar diagnósticos e eventos clínicos, como consultas, cirurgias e internações, na linha do tempo do paciente | consolidar seu histórico clínico e apoiar decisões em retornos e emergências. |
| **VET-07** | Veterinário | visualizar as anotações realizadas pelo tutor no diário do pet | identificar padrões, sintomas ou gatilhos que possam contribuir para diagnósticos e condutas preventivas sem alterar os registros do tutor. |
| **VET-08** | Veterinário | visualizar os eventos e cuidados registrados na rotina do pet | compreender seus hábitos e cuidados recorrentes para fornecer orientações mais adequadas sem modificar a agenda criada pelo tutor. |
| **VET-09** | Veterinário | visualizar os perfis de pets cujo acesso foi compartilhado comigo | consultar rapidamente histórico, exames, vacinas e tratamentos dos pacientes autorizados pelo tutor. |
| **VET-10** | Veterinário | visualizar minhas consultas agendadas e acessar o perfil do respectivo paciente | organizar meus atendimentos e consultar previamente as informações clínicas necessárias para cada consulta. |
---

# 2. Especificações do Projeto

## 2.1. Requisitos Funcionais, Não Funcionais e Restriçoes

### Requisitos Funcionais (RF)

|    ID     | Descrição do Requisito                                                                                                                                   | Canal Prático (Onde ocorre?) | Prioridade | Rubrica Associada |
| :-------: | :------------------------------------------------------------------------------------------------------------------------------------------------------- | :--------------------------: | :--------: | :---------------: |
| **RF-01** | O sistema deve permitir o gerenciamento completo de contas de usuários cadastrados na plataforma.                                                        |         Web / Móvel          |    Alta    |    H37a, H38a     |
| **RF-02** | O sistema deve permitir o gerenciamento completo do cadastro de animais, armazenando informações fixas e variáveis.                                      |         Web / Móvel          |    Alta    |    H37a, H38a     |
| **RF-03** | O sistema deve permitir o gerenciamento completo do histórico de vacinação, incluindo registro de doses e upload de comprovantes digitais.               |         Web / Móvel          |    Alta    |    H37a, H38a     |
| **RF-04** | O sistema deve permitir o gerenciamento completo de tratamentos temporários, crônicos e recorrentes, incluindo a atualização do status de administração. |         Web / Móvel          |    Alta    |    H37a, H38a     |
| **RF-05** | O sistema deve permitir o gerenciamento completo de um repositório digital para armazenamento de exames, cirurgias, diagnósticos e documentos médicos.   |         Web / Móvel          |    Alta    |    H37a, H38a     |
| **RF-06** | O sistema deve permitir o gerenciamento completo de registros de consultas clínicas.                                                                     |         Web / Móvel          |    Alta    |    H37a, H38a     |
| **RF-07** | O sistema deve permitir o gerenciamento completo de agendamentos no calendário, incluindo consultas e rotinas com suporte a recorrência automática.      |         Web / Móvel          |   Média    |    H37a, H38a     |
| **RF-08** | O sistema deve permitir o gerenciamento completo de um diário para o registro de ocorrências e observações rotineiras do animal.                         |         Web / Móvel          |   Média    |    H37a, H38a     |
| **RF-09** | O sistema deve permitir o gerenciamento completo de contatos de referência e autorizações para o compartilhamento de perfis.                             |         Web / Móvel          |   Média    |    H37a, H38a     |
| **RF-10** | O sistema deve permitir a configuração e o disparo automático de notificações por e-mail e push sobre eventos importantes.                               |        API / Backend         |   Média    |       H36a        |
| **RF-11** | O sistema deve permitir o gerenciamento completo da geração e exportação de relatórios baseados nas informações armazenadas.                             |             Web              |   Baixa    |       H37a        |
| **RF-12** | O sistema deve permitir o gerenciamento completo de um módulo financeiro voltado para controle de receitas, despesas e faturamentos.                     |             Web              |   Baixa    |       H37a        |

### Requisitos Não Funcionais (RNF)

|     ID     | Descrição do Requisito Técnico                                                                                                                                                                                                                                                |    Categoria    | Prioridade | Rubrica Associada |
| :--------: | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :-------------: | :--------: | :---------------: |
| **RNF-01** | O sistema deve operar de forma híbrida ou nativa nos sistemas operacionais móveis Android e iOS, além de ser acessível através dos principais navegadores web do mercado (Google Chrome, Safari, Firefox e Edge).                                                             |  Portabilidade  |    Alta    |    H37a, H38a     |
| **RNF-02** | A interface da versão web deve ser totalmente responsiva (adaptando-se a resoluções de desktop, tablets e smartphones), enquanto o aplicativo móvel deve seguir as diretrizes de usabilidade e design de interface (UI/UX) específicas para telas de toque.                   |   Usabilidade   |    Alta    |    H37a, H38a     |
| **RNF-03** | O sistema deve garantir a privacidade dos usuários em conformidade com a Lei Geral de Proteção de Dados (LGPD), utilizando criptografia ponta a ponta para o armazenamento de senhas e dados sensíveis de tutores e veterinários.                                             |    Segurança    |    Alta    |    H35a, H36a     |
| **RNF-04** | O sistema deve processar e retornar operações básicas de CRUD e transições de tela em um tempo máximo de 3 segundos, independentemente de o acesso estar sendo feito via web ou aplicativo móvel (considerando uma conexão de internet estável).                              |   Desempenho    |    Alta    |    H35a, H36a     |
| **RNF-05** | O sistema deve utilizar uma arquitetura de banco de dados e armazenamento de arquivos (como fotos, exames e comprovantes de vacina) hospedada em nuvem, garantindo a sincronização em tempo real entre as plataformas web e mobile e permitindo a escalabilidade do servidor. |   Arquitetura   |   Média    |       H35a        |
| **RNF-06** | O sistema deve possuir uma arquitetura que garanta alta disponibilidade, com um tempo de atividade (uptime) mínimo de 99,9% ao mês, assegurando que o histórico clínico e de emergências do pet estejam acessíveis sempre que necessário.                                     | Disponibilidade |   Baixa    |       H35a        |

### Restrições (RT)

| ID | Restrição |
| :--- | :--- |
| **RT-01** | O back-end do sistema deve ser obrigatoriamente estruturado em uma arquitetura de microsserviços, dividindo as regras de negócio em domínios independentes (ex: Serviço de Autenticação, Serviço Clínico, Serviço de Notificações). É expressamente proibido o desenvolvimento de uma arquitetura monolítica. |
| **RT-02** | Cada microsserviço deve possuir seu próprio banco de dados isolado. O acesso ou alteração de dados de um microsserviço por outro deve ser feito de forma indireta, sendo vetado o compartilhamento de um único banco de dados centralizado para todo o sistema. |
| **RT-03** | A comunicação do front-end (aplicativo mobile e interface web) com os microsserviços, bem como a comunicação síncrona entre os próprios microsserviços, deve ocorrer exclusivamente através de APIs RESTful (utilizando protocolos HTTP/HTTPS e formato JSON). |

## 2.2 Tabela de Rastreabilidade (Relacionamentos)

Esta tabela rastreia cada história de usuário até os requisitos funcionais que ela origina e indica quais requisitos não funcionais se aplicam a ela.


| ID | RF-01 | RF-02 | RF-03 | RF-04 | RF-05 | RF-06 | RF-07 | RF-08 | RF-09 | RF-10 | RF-11 | RF-12 | RNF-01 | RNF-02 | RNF-03 | RNF-04 | RNF-05 | RNF-06 | RNF-07 | RNF-08 |
|----|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **TUT-01** | X |   |   |   |   |   |   |   |   |   |   |   |   | X |   | X |   | X | X |   |
| **TUT-02** |   | X |   |   |   |   |   |   |   |   |   |   |   |   |   | X |   | X |   |   |
| **TUT-03** |   |   | X |   |   |   |   |   |   |   |   |   | X |   | X |   |   |   |   | X |
| **TUT-04** |   |   |   | X |   |   |   |   |   |   |   |   | X |   | X |   |   |   |   | X |
| **TUT-05** |   |   |   |   | X |   |   |   |   |   |   |   | X | X |   |   |   |   | X | X |
| **TUT-06** |   |   |   |   |   | X |   |   |   |   |   |   | X |   |   |   |   |   |   | X |
| **TUT-07** |   |   |   |   |   |   |   | X |   |   |   |   |   |   |   | X |   |   |   |   |
| **TUT-08** |   |   |   |   |   |   | X |   |   |   |   |   | X |   | X |   | X |   |   |   |
| **TUT-09** |   |   |   |   |   |   |   |   | X |   |   |   |   | X |   |   |   |   | X |   |
| **TUT-10** |   |   |   |   |   |   | X |   |   |   |   |   | X |   | X |   | X |   |   |   |
| **VET-01** | X |   |   |   |   |   |   |   |   |   |   |   |   | X |   | X |   | X | X |   |
| **VET-02** |   | X |   |   |   |   |   |   |   |   |   |   |   |   |   | X |   | X |   |   |
| **VET-03** |   |   | X |   |   |   |   |   |   |   |   |   | X |   | X |   |   |   |   | X |
| **VET-04** |   |   |   | X |   |   |   |   |   |   |   |   | X |   | X |   |   |   |   | X |
| **VET-05** |   |   |   |   | X |   |   |   |   |   |   |   | X | X |   |   |   |   | X | X |
| **VET-06** |   |   |   |   |   | X |   |   |   |   |   |   | X |   |   |   |   |   |   | X |
| **VET-07** |   |   |   |   |   |   |   | X |   |   |   |   |   |   |   | X |   |   |   |   |
| **VET-08** |   |   |   |   |   |   | X |   |   |   |   |   | X |   | X |   | X |   |   |   |
| **VET-09** |   |   |   |   |   |   |   |   | X |   |   |   |   | X |   |   |   |   | X |   |
| **VET-10** |   |   |   |   |   |   | X |   |   |   |   |   | X |   | X |   | X |   |   |   |


---

## 2.3. Diagrama de caso de uso

![alt text](<img/Diagrama de caso de uso prontuário pet 3.drawio.png>)

##2.3. Gerenciamento de Projeto

##2.3.1 Gerenciamento de Tempo

Desenvolvemos um gráfico de Gantt no  para gerenciar o tempo do projeto. A ferramenta permite acompanhar o progresso das etapas por meio de um código de cores que indica o status das atividades, facilitando o monitoramento do cronograma e garantindo o cumprimento dos prazos ao longo dos 5 meses do projeto.

<img width="8304" height="4090" alt="gantt_petlife_2026-2_legivel" src="https://github.com/user-attachments/assets/0cc64c29-4cdd-4596-8898-ce38f144c7ae" />

##2.3.2 Gerenciamento de Equipe

O gerenciamento adequado de tarefas contribuirá para que o projeto alcance altos níveis de produtividade. Por isso, é fundamental que ocorra a gestão de tarefas e de pessoas, de modo que os times envolvidos no projeto possam ser facilmente gerenciados.

<img width="1585" height="1386" alt="Captura de tela 2026-08-18 182840" src="https://github.com/user-attachments/assets/65106bfe-a41a-49cf-a9ad-dcb578157485" />

##2.3.1 Gestão de Orçamento

Para um projeto com esse nível de governança de dados e perfis distintos, estimamos um cronograma de 18 semanas (aprox. 5 meses), considerando uma squad

<img width="2253" height="1005" alt="Captura de tela 2026-08-18 175140" src="https://github.com/user-attachments/assets/ae5e250b-c493-4013-81c3-7e24bdcd6a28" />

# 3. Catálogo de Serviços Web

_(Esta seção atende diretamente à rubrica **H34a**)_

[Análise técnica de como a lógica de TI será gerenciada. No contexto de Aplicações Distribuídas, descreva quais serviços do sistema são executados como processos independentes ou acoplados].

Use a tabela abaixo para mapear a Gestão de Serviços de TI que o grupo irá disponibilizar:

| Serviço de TI                                       | Canal de Comunicação |    Nível de Serviço (SLA) Esperado     | Mecanismo de Monitoração                     |   Responsável   |
| :-------------------------------------------------- | :------------------: | :------------------------------------: | :------------------------------------------- | :-------------: |
| **Serviço de Autenticação Centralizado (Identity)** |     JSON / HTTPS     | 99.9% de uptime / Up em < 2s pós queda | LOGs de Auditoria / Middleware de telemetria | [Nome do Aluno] |
| **Serviço de Processamento de Pagamento**           |  Mensageria / AMQP   | Processamento em no máximo 10 segundos | Fila Morta (Dead Letter Queues)              | [Nome do Aluno] |
| **Serviço de Geolocalização em Tempo Real**         |      WebSockets      | Latência máxima de sincronismo < 300ms | Heartbeats a cada 5 segundos                 | [Nome do Aluno] |

---

# 4. Arquitetura da Solução

_(Esta seção atende diretamente à rubrica **H35a**)_

## 4.1. Diagrama de Arquitetura

O Prontuário Pet Inteligente foi concebido sob o modelo de Aplicação Distribuída e Desacoplada, articulando clientes heterogêneos (Web e Mobile), um Backend centralizado em serviços de domínio e uma camada de serviços externos especializados. Essa abordagem garante alta escalabilidade, manutenibilidade e separação clara de responsabilidades, atendendo simultaneamente aos requisitos de alta disponibilidade para o ecossistema clínico e de agilidade no acompanhamento cotidiano por parte dos tutores.

```mermaid
flowchart TD
    subgraph clientes [Clientes]
        mobile["Aplicativo mobile<br/>Expo / React Native"]
        web["Aplicação web<br/>Next.js"]
    end

    subgraph backend [Backend]
        api["API REST<br/>.NET"]
        domain["Serviços de domínio<br/>Pets e permissões"]
        scheduler["Scheduler<br/>Jobs agendados"]
    end

    subgraph externos [Serviços externos]
        keycloak["Keycloak<br/>OIDC / JWT"]
        mongo["MongoDB Atlas<br/>Banco principal"]
        cloudinary["Cloudinary<br/>Upload assinado"]
        notify["Notificações<br/>FCM + SendGrid"]
    end

    mobile -->|"HTTPS / REST + JWT"| api
    web -->|"HTTPS / REST + JWT"| api
    mobile -->|"OIDC"| keycloak
    web -->|"OIDC"| keycloak
    api --> keycloak
    api --> domain
    api --> scheduler
    domain --> mongo
    domain --> cloudinary
    scheduler --> notify
```

### App Mobile: Expo / React Native 

Justificativa: O público-alvo de tutores necessita de uma solução nativa e fluida para o uso cotidiano no smartphone (registro de sintomas no Diário do Pet, alertas de medicação e visualização rápida da carteira de vacinação). A escolha do ecossistema React Native com Expo permite o desenvolvimento unificado para Android e iOS a partir de uma única base de código, reduzindo o Time-to-Market. Além disso, a plataforma oferece integração nativa simplificada com APIs do dispositivo (câmera para captura de laudos e sistema de Notificações Push locais/remotas), garantindo uma excelente experiência de uso (UX).

### Web: Next.js (React) 

Justificativa: A rotina técnica dos médicos veterinários (consultas detalhadas, emissão de prontuários, gestão do Módulo Financeiro e visualização de relatórios consolidados) exige telas densas, navegação ágil e foco em produtividade desktop. O Next.js foi selecionado por combinar a reatividade do React com recursos avançados de Server-Side Rendering (SSR) e Static Site Generation (SSG). Isso assegura alto desempenho de carregamento, roteamento robusto e otimização de renderização para dashboards complexos e gestão de formulários clínicos.

### Backend: .Net 

Justificativa: O .NET (C#) foi escolhido como motor principal do backend devido ao seu desempenho de alto nível em concorrência, tipagem estática forte e maturidade para a implementação de arquiteturas orientadas ao domínio (Domain-Driven Design - DDD) e nossa familiaridade, visto que, já foi utilizado em semestres passados. A robustez do .NET facilita o isolamento das regras de negócio do Prontuário, Diário, Vacinas e Financeiro. A tipagem estática e o ecossistema de validações e segurança do .NET minimizam falhas em tempo de execução na manipulação de cálculos de doses e regras fiscais/financeiras.

### Scheduler (Jobs Agendados) 

Justificativa: A prevenção de falhas no tratamento e a adesão ao plano vacinal dependem de rotinas assíncronas. O componente Scheduler integrado à aplicação backend é responsável por orquestrar tarefas em segundo plano (Background Jobs), tais como: 

- Cálculo e disparo de notificações para próximas doses de medicamentos e reforços vacinais.
- Geração e envio de resumos e relatórios consolidados periódicos.
- Processamento assíncrono de conciliações financeiras e limpezas de estado.

- ### Banco de Dados Principal: MongoDB Atlas 

Justificativa: O MongoDB Atlas foi selecionado como repositório principal devido à flexibilidade de schema inerente aos bancos orientados a documentos NoSQL. O histórico de saúde de um pet é altamente dinâmico: diferentes espécies e casos clínicos exigem estruturas de dados variáveis no Diário do Pet, laudos com campos heterogêneos e evoluções médicas sem estrutura fixa. A escalabilidade nativa em nuvem e a capacidade do MongoDB de lidar com documentos agregados e complexos otimizam a leitura rápida do histórico completo do animal em segundos durante emergências. (Nota: Para garantir a consistência de operações do Módulo Financeiro e atualizações simultâneas de prontuário, são utilizadas as transações ACID multi-documento nativas do MongoDB).

### Armazenamento de Arquivos: Cloudinary (Upload Assinado) 

Justificativa: Exames de imagem, laudos laboratoriais em PDF e fotos anexadas ao diário geram volumosos dados binários. Ao integrar o Cloudinary, a aplicação adota a estratégia de Upload Assinado: o backend .NET autoriza a transação gerando uma assinatura segura, e o cliente (Web ou Mobile) realiza o upload diretamente para o Cloudinary. Isso reduz o consumo de banda e recursos do servidor de API, acelera a entrega de arquivos via rede de distribuição de conteúdo (CDN) e garante a otimização automática de imagens. 

### Keycloak (IAM)

Justificativa: Para a camada de Autenticação e Autorização, foi adotado o Keycloak como Gerenciador de Identidades e Acessos (Identity and Access Management - IAM) dedicado. Essa decisão isola a complexidade de segurança da API principal e alinha a arquitetura aos padrões de mercado OAuth 2.0 e OpenID Connect (OIDC).

---

## 4.2. Tecnologias e Hospedagem

Descreva e justifique as escolhas da pilha de desenvolvimento distribuída:

- **Backend / API**: [Ex: Node.js (TypeScript) ou .NET 8 (C#) ou Spring Boot (Java)]. _Justificativa técnica baseada em performance concorrente._
- **Frontend Web**: [Ex: React ou Angular]. _Justificativa com foco no dinamismo e Single Page Application._
- **Frontend Móvel**: [Ex: React Native via Expo]. _Enquadramento das características nativas necessárias (câmera, sensores, offline)._
- **Banco de Dados**: [Ex: PostgreSQL e Redis]. _Papel de persistência relacional ácida e cache em memória distributed._
- **Hospedagem em Nuvem**: [Ex: AWS para API e Banco de Dados, Vercel para interface Web, e Expo Go / APK para Mobile].

---

# 5. Especificação de Contratos de APIs

_(Esta seção atende diretamente à rubrica **H36a**)_

[Definição formal dos endpoints chaves de comunicação que servirão para o desenvolvimento na Etapa 2.]

### Endpoint Exemplo 1: Autenticação de Usuários (`/api/v1/auth/login`)

- **Método**: `POST`
- **Payload de Requisição**:
  ```json
  {
    "email": "user@pucminas.br",
    "password": "hashed_password"
  }
  ```
- **Resposta Sucesso (`200 OK`)**:
  ```json
  {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expiresIn": 3600,
    "user": { "id": 123, "nome": "Aluno Exemplar", "funcao": "admin" }
  }
  ```

### Endpoint Exemplo 2: Recuperação de Dados do Usuário (`/api/v1/users/{id}`)

- **Método**: `GET`
- ...

---

# 6. Projeto do Frontend Web

_(Esta seção atende diretamente à rubrica **H37a**)_

[Aqui o grupo deve descrever as interações que o usuário do canal Web executará de forma responsiva.]

### 6.1. Relação de Telas do Sistema Web:

- **Tela 1: Dashboard Administrativo**: [Descreva que informações e gráficos estarão expostos na console]
- **Tela 2: Cadastro de Entidades**: ...

### 6.2. Wireframes Web:

[Insira aqui os esboços que demonstram visualmente os layouts desktop, explicando onde haverá consumo assíncrono das APIs mapeadas]

---

# 7. Projeto do Frontend Móvel

_(Esta seção atende diretamente à rubrica **H38a**)_

[Aqui deve ser demonstrada a preocupação espacial e gestual exclusiva do ecossistema móvel.]

### 7.1. Fluxograma de Navegação (Navegabilidade):

- **Tela 1: Tela de Entrada e Login**: [Explique o formulário nativo]
- **Tela 2: Tela Principal com Mapa / Listagem Interativa**: ...

### 7.2. Wireframes Móveis:

[Insira aqui o link ou imagens dos wireframes desenhados para telefones. Demonstre usabilidade focada em uma mão, menus hamburguer, navegação por guias (tabs) e comportamentos de transição de tela.]

---

# 8. Referências Acadêmicas e de Engenharia

[Utilize literatura formal para dar suporte técnico ao seu planejamento.]

1. **SOMMERVILLE, Ian**. _Engenharia de Software_. 10. ed. São Paulo: Pearson, 2011.
2. **COULOURIS, George et al**. _Sistemas Distribuídos: conceitos e projeto_. 5. ed. Porto Alegre: Bookman, 2013.
3. **FIELDING, Roy Thomas**. _Architectural Styles and the Design of Network-based Software Architectures_. Dissertação (Doutorado) - University of California, Irvine, 2000.
