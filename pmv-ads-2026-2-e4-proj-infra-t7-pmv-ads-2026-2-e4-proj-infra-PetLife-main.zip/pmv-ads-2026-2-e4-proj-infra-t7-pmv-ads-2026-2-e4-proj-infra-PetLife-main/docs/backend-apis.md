# ⚙️ Etapa 2: APIs, Web Services e Persistência de Dados Distribuída

Este documento serve como diretriz mestre de engenharia e repositório de evidências para a **Etapa 2: Desenvolvimento de APIs, Web Services e Persistência**. Ele foi estruturado para orientar o desenvolvimento prático do backend distribuído e permitir o acompanhamento e auto-gestão das atividades pelos alunos.

---

## 🎯 Rubricas de Avaliação desta Etapa

Ao final desta Etapa, cada aluno será avaliado individualmente nestas 6 competências (incluindo oportunidades de desenvolvimento e reavaliação):

1. **H21a-ADS-CST - Aplicar corretamente os padrões de codificação para o desenvolvimento da API.**: Gerenciar e documentar serviços de TI, de forma clara e objetiva (Reavaliação teórica e prática a partir do gerenciamento de serviços no backend em [src/backend/](src/backend/)).
2. **H23a-ADS-CST - Modelar os dados da API dentro do contexto levantado.**: Desenvolver uma arquitetura de aplicação distribuída (Medido no código em [src/backend/](src/backend/) e na seção [Modelagem da Aplicação e Arquitetura de Dados](#2-modelagem-da-aplicacao-e-arquitetura-de-dados)).
3. **H23b-ADS-CST - Definir corretamente os recursos e as rotas da API.**: Gerenciar uma arquitetura de aplicação distribuída, testando, implantando e avaliando a solução (Medido na seção [Instruções de Implantação e DevOps](#5-instrucoes-de-implantacao-e-devops)).
4. **H23d-ADS-CST - Implementar o processo de autenticação de usuário do sistema.**: Desenvolver APIs e Web Services (Medido na seção [Especificação Avançada de Endpoints](#3-especificacao-avancada-de-endpoints) e atualizações no design de contratos).
5. **H24a-ADS-CST - Definir e documentar a arquitetura da aplicação distribuída.**: Planejar e documentar APIs e Web Services, de forma clara e objetiva (Medido em [src/backend/](src/backend/) e na construção real dos endpoints).
6. **H24b-ADS-CST - Projetar a arquitetura baseada em API.**: Gerenciar APIs e Web Services, testando, implantando e avaliando a solução (Medido na seção [Estratégia e Relatório de Testes Automatizados](#4-estrategia-e-relatorio-de-testes-automatizados)).
7. **H25a-ADS-CST - Selecionar e avaliar corretamente o modelo de dados NoSQL para o contexto da aplicação distribuída.**: Planejar e documentar Banco de dados No-SQL, de forma clara e objetiva (Medido em [src/backend/](src/backend/) e na construção real dos endpoints).
8. **H25b-ADS-CST - Implementar corretamente as funcionalidades que envolvem o banco de dados NoSQL para armazenamento e recuperação de dados.**: Planejar e documentar Banco de dados No-SQL, de forma clara e objetiva (Medido em [src/backend/](src/backend/) e na construção real dos endpoints).
9. **H27a-ADS-CST - Desenvolver testes de unidade.**: Gerenciar APIs e Web Services, testando, implantando e avaliando a solução (Medido na seção [Estratégia e Relatório de Testes Automatizados](#4-estrategia-e-relatorio-de-testes-automatizados)).

---

## 📅 QUADRO DE CONTRIBUIÇÃO REAL (ETAPA 2)

**Atenção alunos:** Preencham esta tabela para atualizar o andamento das tarefas e quem foi o responsável técnico pela construção do backend. Os nomes, usuários e links de evidências devem corresponder aos entregáveis em [src/backend/](src/backend/).

- **Status admitidos**: `⌛ Não Iniciado` | `📝 Em Progresso` | `✔️ Entregue`
- **Autoria Git**: Indica se há commits desse estudante nos arquivos da tarefa.

**Atividades Semanais desta Etapa** (ver [Cronograma do Semestre](contexto.md#-cronograma-do-semestre-semana--periodo)):

- `ATV2.1` — Desenvolvimento de Funcionalidades - API (Semanas 5 a 8)
- `ATV2.2` — Testes - API (Semana 9)

| Rubrica Curricular | ID Tarefa | Atividade Semanal | Descrição Detalhada da Tarefa                                  | Estudante Responsável | GitHub Username | Status de Entrega | Evidência/Seção Temática                                                     | Autoria Git |
| :----------------: | :-------: | :---------------: | :------------------------------------------------------------- | :-------------------- | :-------------: | :---------------: | :--------------------------------------------------------------------------- | :---------: |
|      **H36b**      |  `T2.1`   |     `ATV2.1`      | Configuração do Boilerplate da API, Roteamento e Inicialização | [Nome do Aluno 1]     |   `username1`   | `⌛ Não Iniciado` | [Instalação/README](src/backend/README.md)                                   |     [ ]     |
|      **H36b**      |  `T2.2`   |     `ATV2.1`      | Modelagem e Persistência de Dados (Conexão DB, ORM, Schemas)   | [Nome do Aluno 2]     |   `username2`   | `⌛ Não Iniciado` | [Seção 2.1](#21-schema-e-diagrama-entidade-relacionamento)                   |     [ ]     |
|      **H36b**      |  `T2.3`   |     `ATV2.1`      | Implementação de Endpoints CRUD e Lógica de Negócios Principal | [Nome do Aluno 3]     |   `username3`   | `⌛ Não Iniciado` | [Seção 3.0](#3-especificacao-avancada-de-endpoints)                          |     [ ]     |
|      **H36b**      |  `T2.4`   |     `ATV2.1`      | Mecanismo de Segurança da API (Autenticação/Autorização JWT)   | [Nome do Aluno 4]     |   `username4`   | `⌛ Não Iniciado` | [Seção 3.3](#33-seguranca-e-autorizacao)                                     |     [ ]     |
|      **H35b**      |  `T2.5`   |     `ATV2.1`      | Gateway, Integração de Serviços Web e Clientes HTTP Externos   | [Nome do Aluno 5]     |   `username5`   | `⌛ Não Iniciado` | [Seção 2.2](#22-integracao-e-infraestrutura-distribuida)                     |     [ ]     |
|      **H36c**      |  `T2.6`   |     `ATV2.2`      | Desenvolvimento de Testes Automatizados (Unitários/Integração) | [Nome do Aluno 6]     |   `username6`   | `⌛ Não Iniciado` | [Seção 4.0](#4-estrategia-e-relatorio-de-testes-automatizados)               |     [ ]     |
|      **H35c**      |  `T2.7`   |     `ATV2.1`      | Construção de Dockerfile e Configuração de docker-compose      | [Nome do Aluno 1]     |   `username1`   | `⌛ Não Iniciado` | [Seção 5.1](#51-conteinerizacao-de-servicos)                                 |     [ ]     |
|      **H36c**      |  `T2.8`   |     `ATV2.2`      | Proposta de Implantação e Pipeline de CI/CD Backend            | [Nome do Aluno 5]     |   `username5`   | `⌛ Não Iniciado` | [Seção 5.2](#52-proposta-de-infraestrutura-de-deploy-e-ambiente-em-producao) |     [ ]     |

---

# 1. Escopo e Objetivos do Backend

### Introdução e Arquitetura do Backend (PetLife API)

O backend da plataforma **PetLife** é uma API RESTful desenvolvida para centralizar o processamento e a persistência de dados das aplicações cliente (Mobile/Web). O sistema mantém o prontuário unificado de animais de estimação e gere o controle de acesso para dois perfis principais: **Tutores** e **Veterinários**.

**Arquitetura e Módulos**
A solução utiliza o padrão de **Monólito Modular**, dividida nos seguintes domínios:

- **IAM (Identity & Access Management):** Registo de utilizadores, autenticação e autorização via JWT.
- **Pet Core:** Cadastro de pets e gestão de permissões entre tutores e clínicos.
- **Prontuário Eletrónico:** Gestão de Consultas, Vacinas, Tratamentos, Diário do Pet e upload de Documentos.
- **Notificações & Rotina:** Agendamento de eventos recorrentes e geração de relatórios.

**Stack Tecnológica**

- **Linguagem e Framework:** C# com ASP.NET Core (Web API) – garante alta performance e processamento assíncrono (_non-blocking_).
- **Banco de Dados:** MongoDB (NoSQL) – oferece flexibilidade de esquemas para dados dinâmicos.
- **ORM:** Entity Framework Core (EF Core) integrado ao MongoDB.
- **Armazenamento de Ficheiros:** Cloudinary – para gestão e distribuição de imagens e PDFs.
- **Testes:** xUnit com Moq e bases em memória para validação unitária.

**Volumetria e Escalabilidade**

- **Perfil de Carga:** Sistema _Read-Heavy_ (maior volume de leituras para consultas de rotina e históricos).
- **Escalabilidade Física:** Arquitetura _stateless_, preparada para escalabilidade horizontal através de instâncias atrás de um _Load Balancer_.
- **Desempenho:** O uso integrado de C# assíncrono e MongoDB permite processar alta concorrência e picos transacionais com latência na ordem dos milissegundos.

---

# 2. Modelagem da Aplicação e Arquitetura de Dados

_(Esta seção atende diretamente à rubrica **H35b**)_

## 2.1. Schema e Diagrama Entidade-Relacionamento

D.E.R
<img width="8192" height="5071" alt="D e r - PetLife" src="https://github.com/user-attachments/assets/7bccf2ff-1c28-46c2-a77f-44316dbb3f6d" />

## Diagrama de classes

![Diagrama de classes](img/diagrama-classes-v4.png)

## 2.2. Integração e Infraestrutura Distribuída

### Gerenciamento de Concorrência e Escalabilidade Física

A **PetLife API** foi arquitetada para manter a estabilidade e o baixo tempo de resposta sob alta concorrência através das seguintes estratégias:

**1. Processamento Assíncrono (Non-blocking I/O)**

Toda a aplicação utiliza o padrão `async/await` do C#. Operações de I/O (MongoDB, Cloudinary) não bloqueiam a execução, libertando o servidor (Kestrel) para processar requisições simultâneas e otimizando o consumo de CPU e memória.

**2. Pool de Conexões (Database Pooling)**

O driver nativo do MongoDB e o EF Core mantêm um _Pool_ de conexões TCP. O reaproveitamento automático destas ligações reduz a latência drásticamente e previne o esgotamento de portas do servidor durante picos de acesso.

**3. Escalabilidade Horizontal e Stateless**

A API é totalmente _stateless_ (sem estado), gerindo as sessões exclusivamente via **Tokens JWT**. Esta abordagem permite o _Scale-out_ imediato: a infraestrutura pode instanciar múltiplos servidores atrás de um _Load Balancer_ sem necessidade de "afinidade de sessão" (sticky sessions).

**4. Preparação para Evolução Arquitetural**

Apesar de operar como um **Monólito Modular** focado em alta coesão e deploy facilitado, a arquitetura isola o domínio na camada de _Services_, estando pronta para evolução:

- **Mensageria:** Pronta para adoção de filas (RabbitMQ/Kafka) para disparo assíncrono de notificações e e-mails por _Background Workers_.
- **Cache:** Estruturada para receber injeção de **Redis** em consultas intensivas (perfil, relatórios), prevenindo sobrecarga na base de dados principal.

---

# 3. Especificação Avançada de Endpoints

_(Esta seção atende diretamente à rubrica **H36b**)_

Abaixo devem estar listados os contratos reais que foram ou serão implementados no diretório [src/backend/](src/backend/). Cada endpoint deve ser detalhado descrevendo métodos HTTP, URLs, payloads aceitos e possíveis status codes.

### 3.1. Relação Geral de Endpoints

| Método / Verbo | Caminho da Rota (URI)                 | Descrição do Recurso / Ação                                          | Reclama Autenticação? | Responsável Técnico |
| :------------: | :------------------------------------ | :------------------------------------------------------------------- | :-------------------: | :-----------------: |
|     `POST`     | `/api/users/register`                 | Criação de novos usuários na plataforma                              |          Não          |  Erison Guimarães   |
|     `POST`     | `/api/users/login`                    | Autenticação e geração de JWT                                        |          Não          |  Erison Guimarães   |
|     `GET`      | `/api/users/me`                       | Obtenção de dados do usuário logado                                  |          Sim          |  Erison Guimarães   |
|     `POST`     | `/api/users/changepassword`           | Alteração de senha                                                   |          Sim          |  Erison Guimarães   |
|     `POST`     | `/api/users/changeprofile`            | Alteração de perfil de usuário                                       |          Sim          |  Erison Guimarães   |
|     `POST`     | `/api/users/forgotpassword`           | Envio de email para recuperação de senha                             |          Não          |  Erison Guimarães   |
|     `POST`     | `/api/users/resetpassword`            | Recuperação de senha                                                 |          Sim          |  Erison Guimarães   |
|     `POST`     | `/api/treatments`                     | Criação de um novo tratamento contínuo ou prescrição para um pet     |          Sim          |   Mariana Gressi    |
|     `GET`      | `/api/treatments/pet/{pet_id}`        | Listagem de todos os tratamentos vinculados a um pet específico      |          Sim          |   Mariana Gressi    |
|     `PUT`      | `/api/treatments/{id}`                | Atualização dos dados ou status de um tratamento existente           |          Sim          |   Mariana Gressi    |
|    `DELETE`    | `/api/treatments/{id}`                | Exclusão de um tratamento do prontuário do sistema                   |          Sim          |   Mariana Gressi    |
|     `POST`     | `/api/reports`                        | Geração de um novo relatório dinâmico com base em filtros            |          Sim          |   Mariana Gressi    |
|     `GET`      | `/api/reports/user/{user_id}`         | Listagem dos relatórios previamente gerados por um utilizador        |          Sim          |   Mariana Gressi    |
|     `PUT`      | `/api/reports/{id}`                   | Atualização dos parâmetros ou filtros de um relatório existente      |          Sim          |   Mariana Gressi    |
|    `DELETE`    | `/api/reports/{id}`                   | Exclusão de um relatório da conta do utilizador                      |          Sim          |   Mariana Gressi    |
|     `POST`     | `/api/consultas`                      | Registra uma nova consulta no histórico clínico do pet               |          Sim          |  Matheus Bernardes  |
|     `GET`      | `/api/consultas?pet_id={id}`          | Lista as consultas de um pet                                         |          Sim          |  Matheus Bernardes  |
|     `GET`      | `/api/consultas/{id}`                 | Busca uma consulta específica por id                                 |          Sim          |  Matheus Bernardes  |
|     `PUT`      | `/api/consultas/{id}`                 | Atualiza os dados de uma consulta                                    |          Sim          |  Matheus Bernardes  |
|    `DELETE`    | `/api/consultas/{id}`                 | Exclui uma consulta (consulta REALIZADA é mantida no histórico)      |          Sim          |  Matheus Bernardes  |
|     `POST`     | `/api/vaccines`                       | Registra uma vacina aplicada ou histórica de um pet                  |          Sim          |  Matheus Bernardes  |
|     `GET`      | `/api/vaccines?pet_id={id}`           | Lista as vacinas de um pet                                           |          Sim          |  Matheus Bernardes  |
|     `GET`      | `/api/vaccines/{id}`                  | Busca uma vacina específica por id                                   |          Sim          |  Matheus Bernardes  |
|     `PUT`      | `/api/vaccines/{id}`                  | Atualiza os dados de uma vacina                                      |          Sim          |  Matheus Bernardes  |
|    `DELETE`    | `/api/vaccines/{id}`                  | Exclui uma vacina do prontuário do pet                               |          Sim          |  Matheus Bernardes  |
|     `POST`     | `/api/documents`                      | Envia um documento (anexo) do pet, podendo vinculá-lo a uma consulta |          Sim          |  Matheus Bernardes  |
|     `GET`      | `/api/documents?pet_id={id}`          | Lista os documentos de um pet                                        |          Sim          |  Matheus Bernardes  |
|     `GET`      | `/api/documents/{id}`                 | Busca um documento específico por id                                 |          Sim          |  Matheus Bernardes  |
|     `PUT`      | `/api/documents/{id}`                 | Atualiza os dados de um documento                                    |          Sim          |  Matheus Bernardes  |
|    `DELETE`    | `/api/documents/{id}`                 | Exclui um documento do prontuário do pet                             |          Sim          |  Matheus Bernardes  |
|     `POST`     | `/api/EventosRotina`                  | Cria um novo evento de rotina/agendamento para um pet                |          Sim          |     Lara Silva      |
|     `GET`      | `/api/EventosRotina/pet/{petId}`      | Lista todos os eventos de rotina de um pet específico                |          Sim          |     Lara Silva      |
|     `GET`      | `/api/EventosRotina/usuario/{userId}` | Lista todos os eventos de rotina de um usuário                       |          Sim          |     Lara Silva      |
|     `GET`      | `/api/EventosRotina/{id}`             | Busca um evento de rotina específico por id                          |          Sim          |     Lara Silva      |
|     `PUT`      | `/api/EventosRotina/{id}`             | Atualiza os dados ou status de um evento de rotina                   |          Sim          |     Lara Silva      |
|    `DELETE`    | `/api/EventosRotina/{id}`             | Exclui um evento de rotina da agenda do pet                          |          Sim          |     Lara Silva      |
|     `GET`      | `/api/Notificacoes?userId={id}`       | Lista as notificações de um usuário                                  |          Sim          |     Lara Silva      |
|    `PATCH`     | `/api/Notificacoes/{id}/lida`         | Marca uma notificação como lida                                      |          Sim          |     Lara Silva      |
|    `DELETE`    | `/api/Notificacoes/{id}`              | Exclui uma notificação                                               |          Sim          |     Lara Silva      |
|     `GET`      | `/api/Notificacoes/config`            | Obtém as preferências de notificação do usuário                      |          Sim          |     Lara Silva      |
|     `PUT`      | `/api/Notificacoes/config`            | Salva/atualiza as preferências (email, push, token)                  |          Sim          |     Lara Silva      |
|     `POST`     | `/api/users/login`                    | Autenticação do usuário e geração do JWT (Tutor ou Veterinário)      |          Não          |     Lucas Costa     |
|     `POST`     | `/api/pets`                           | Cadastra um novo pet vinculado ao tutor autenticado                  |          Sim          |     Lucas Costa     |
|     `GET`      | `/api/pets`                           | Lista os pets do tutor autenticado                                   |          Sim          |     Lucas Costa     |
|     `GET`      | `/api/pets/shared`                    | Lista os pets compartilhados com o veterinário autenticado           |          Sim          |     Lucas Costa     |
|     `GET`      | `/api/pets/{id}`                      | Busca um pet por id (tutor dono ou veterinário com share)            |          Sim          |     Lucas Costa     |
|     `PUT`      | `/api/pets/{id}`                      | Atualiza os dados cadastrais do pet                                  |          Sim          |     Lucas Costa     |
|    `DELETE`    | `/api/pets/{id}`                      | Exclui um pet do tutor autenticado                                   |          Sim          |     Lucas Costa     |
|     `POST`     | `/api/pets/{id}/photo`                | Envia a foto do pet e atualiza a URL no cadastro                     |          Sim          |     Lucas Costa     |
|     `POST`     | `/api/pets/upload-photo`              | Faz upload avulso de imagem (sem vincular a um pet)                  |          Sim          |     Lucas Costa     |
|     `POST`     | `/api/pet-diary`                      | Cria um registro no diário do pet                                    |          Sim          |     Lucas Costa     |
|     `GET`      | `/api/pet-diary?pet_id={id}`          | Lista os registros do diário (filtro opcional por pet)               |          Sim          |     Lucas Costa     |
|     `GET`      | `/api/pet-diary/pet/{petId}`          | Lista o diário de um pet específico                                  |          Sim          |     Lucas Costa     |
|     `GET`      | `/api/pet-diary/{id}`                 | Busca um registro do diário por id                                   |          Sim          |     Lucas Costa     |
|     `PUT`      | `/api/pet-diary/{id}`                 | Atualiza um registro do diário                                       |          Sim          |     Lucas Costa     |
|    `DELETE`    | `/api/pet-diary/{id}`                 | Exclui um registro do diário                                         |          Sim          |     Lucas Costa     |
|     `POST`     | `/api/shares/createshare`             | Cria um compartilhamento de pet com veterinário                      |          Sim          |  Erison Guimarães   |
|    `DELETE`    | `/api/shares/{id}`                    | Deleta um compartilhamento                                           |          Sim          |  Erison Guimarães   |
|     `POST`     | `/api/shares/createsharecode`         | Gera um código de compartilhamento                                   |          Sim          |  Erison Guimarães   |
|     `POST`     | `/api/shares/redeemsharecode`         | Resgata um código de compartilhamento                                |          Sim          |  Erison Guimarães   |
|     `GET`      | `/api/shares/getprofiles`             | Lista veterinários que possuem acesso ao perfil do pet               |          Sim          |  Erison Guimarães   |

---

### 3.2. Detalhamento dos Payloads de Requisição e Resposta (Exemplos)

[Registro de teste.docx.pdf](https://github.com/user-attachments/files/33314764/Registro.de.teste.docx.pdf)


### 3.3. Segurança e Autorização

**1. Segurança do Canal de Comunicação**

Toda a comunicação entre as aplicações cliente (Mobile/Web) e a API ocorre obrigatoriamente sobre o protocolo **HTTPS**. Isto garante a criptografia de ponta a ponta via **TLS**, protegendo os dados em trânsito contra intercetações (_Man-in-the-Middle_).

**2. Geração de Token e Criptografia (JWT)**

A autenticação segue o padrão _stateless_ utilizando JSON Web Tokens (JWT).

- **Algoritmo de Assinatura:** O token é gerado e assinado digitalmente utilizando o algoritmo simétrico **HS256** (HMAC com SHA-256), a partir de uma chave secreta (Secret Key) mantida em segurança no servidor.
- **Expiração:** Para mitigar riscos de roubo de sessão, os tokens possuem uma expiração (Expiration Time) configurada para **24 horas** após a emissão.

**3. Controle de Acesso Baseado em Perfis (RBAC)**

O sistema segrega permissões e funcionalidades utilizando RBAC, distinguindo os utilizadores em dois perfis de negócio:

- **Tutor:** Perfil padrão de cliente. Tem permissão para registar pets, adicionar entradas no diário e consultar históricos.
- **Veterinário:** Perfil profissional (valida CRMV). Tem acesso a operações clínicas sensíveis, como prescrição de Tratamentos, agendamento de Consultas e registo de Vacinas.

**4. Implementação Estrutural**

A segurança é blindada na camada de Controladores (_Controllers_) através da anotação `[Authorize]`.

- **Restrição de Rota:** Acesso a rotas específicas é controlado via anotações como `[Authorize(Roles = "Veterinário")]`.
- **Prevenção de Spoofing:** A API valida a identidade extraindo o ID do utilizador de forma segura e direta a partir do _payload_ criptografado do Token JWT (através das _Claims_), ignorando IDs enviados de forma vulnerável no corpo da requisição.

---

# 4. Estratégia e Relatório de Testes Automatizados

_(Esta seção atende diretamente à rubrica **H36c**)_

### Estratégia de Testes e Execução Local

A estratégia de testes do backend da **PetLife** valida os fluxos de autenticação, autorização (RBAC) e a integridade dos endpoints RESTful dos módulos.

#### 1. Abordagem e Ferramentas

- **Testes de Integração/Endpoints (HTTP Client):** Validação de ponta a ponta dos verbos HTTP, ciclo de vida do CRUD, conexão com o MongoDB e rejeição de acessos não autorizados utilizando o ficheiro integrado `PetLife.Api.http` no VS Code.
- **Testes Unitários Automatizados:** Implementados na camada de serviços com simulação de dependências (_mocking_).
- **Ferramenta de Asserção Utilizada:** **xUnit** (framework de testes para .NET) em conjunto com **FluentAssertions** (para asserções legíveis e expressivas) e **Moq** (para isolamento de dependências).

#### 2. Método de Execução do Comando de Teste

Para executar a suíte de testes automatizados e verificar o comportamento da aplicação localmente, utilize o comando padrão do .NET CLI na raiz do projeto:

```bash
dotnet test

```

#### 3. Cobertura Esperada / Alcançada

- **Cobertura Alvo:** Mínimo de **80%** de cobertura de código sobre as regras de negócio críticas (validações de serviços, regras de permissão de tutores/veterinários e fluxos de autenticação).
- **Métricas Avaliadas:** O relatório de cobertura gerado por ferramentas como _Coverlet_ foca-se na validação de caminhos de controle, garantindo testes robustos para fluxos principais (_happy paths_) e cenários de exceção (tratamento de erros e bloqueios de segurança por token).

### Quadro de Cobertura de Testes

| Módulo do Sistema     | Tipo de Teste (Unitário/Integração)                 | Cenários Avaliados                                                                                                                                                                                                                                                                                                                                        | Status da Suíte |
| :-------------------- | :-------------------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :-------------: |
| **TokenService**      | Unitário                                            | JWT de Tutor com claims (`nameid`, e-mail, role); JWT de Veterinário com `crmv`; expiração em 12h via configuração (`TokenServiceTests.cs`, 3 testes)                                                                                                                                                                                                     |    ✔️ Passou    |
| **PetService**        | Unitário (EF InMemory + Moq do Cloudinary)          | Listar/filtrar por tutor; CRUD; validação de nome, espécie e `tutor_id`; upload de foto (sucesso, pet inexistente, arquivo nulo/vazio) (`PetServiceTests.cs`, 19 testes)                                                                                                                                                                                  |    ✔️ Passou    |
| **PetDiaryService**   | Unitário (EF InMemory)                              | Listagem do veterinário vs. só pets do tutor; filtro por `pet_id`; CRUD; pet inexistente (404); pet de outro tutor (403) (`PetDiaryServiceTests.cs`, 16 testes)                                                                                                                                                                                           |    ✔️ Passou    |
| **ShareService**      | Unitário (EF InMemory)                              | CRUD; Código expirado; Excluir código resgatado; Listar veterinários (`ShareServiceTests.cs`, 6 testes)                                                                                                                                                                                                                                                   |    ✔️ Passou    |
| **UserManager**       | Unitário (EF InMemory)                              | Senha com confirmação correta; Senha com confirmação incorreta (`RegisterTests.cs`, 2 testes)                                                                                                                                                                                                                                                             |    ✔️ Passou    |
| **TreatmentsService** | Unitário (EF InMemory)                              | CRUD completo de tratamentos e prescrições por pet; validação de doses administradas e status ativo/inativo (`TreatmentsServiceTests.cs`, 8 testes)                                                                                                                                                                                                       |    ✔️ Passou    |
| **ReportsService**    | Unitário (EF InMemory)                              | Geração de relatórios dinâmicos com filtros customizados; listagem por utilizador; atualização e exclusão (`ReportsServiceTests.cs`, 6 testes)                                                                                                                                                                                                            |    ✔️ Passou    |
| **VaccineService**    | Unitário (EF InMemory)                              | Listar/filtrar por pet; CRUD; cálculo automático da próxima dose; regra do tutor (apenas registros históricos); validação de existência de pet e veterinário (`VaccineServiceTests.cs`, 10 testes)                                                                                                                                                        |    ✔️ Passou    |
| **ConsultaService**   | Unitário (EF InMemory)                              | CRUD; autoria (só o autor edita/exclui); descrição clínica exclusiva do veterinário; consulta REALIZADA não pode ser excluída; validação de existência de pet, autor, tutor e veterinário (`ConsultaServiceTests.cs`, 10 testes)                                                                                                                          |    ✔️ Passou    |
| **DocumentService**   | Unitário (EF InMemory)                              | CRUD; autoria; vínculo opcional com consulta via `consulta_id`; validação de existência de pet, usuário e consulta (`DocumentServiceTests.cs`, 9 testes)                                                                                                                                                                                                  |    ✔️ Passou    |
| EventoRotinaService   | Unitário (EF InMemory + fake do NotificacaoService) | CRUD; listagem por pet e por usuário; geração automática de Id; disparo de notificação ao criar; mapeamento de tipo (vacina→proxima_vacina); evento inexistente (null/false) (EventoRotinaServiceTests.cs, 12 testes)                                                                                                                                     |    ✔️ Passou    |
| NotificacaoService    | Unitário (EF InMemory + Moq do IMailService)        | Criação com e-mail e push (config ativa, sem config, só e-mail, só push); disparo de e-mail ao usuário cadastrado; listagem por usuário ordenada por data; marcar como lida (existente/inexistente); exclusão (existente/inexistente); obter preferências (com/sem config); salvar preferências (criar/atualizar) (NotificacaoServiceTests.cs, 16 testes) |    ✔️ Passou    |

---

# 5. Instruções de Implantação e DevOps

_(Esta seção atende diretamente à rubrica **H35c**)_

Abaixo detalhe como a aplicação backend é empacotada de forma portável e como seria o processo ideal de implantação/hospedagem em nuvem (proposta teórica). **Nota:** Não há cobrança de deploy prático em nuvem nesta disciplina; a avaliação consiste na demonstração teórica da arquitetura física proposta e nas automações de build/testes locais.

## 5.1. Conteinerização de Serviços

A API foi conteinerizada para permitir a execução local de forma portável e auto-contida, sem depender de instalações manuais na máquina do desenvolvedor.

O **Dockerfile** do backend utiliza _build multi-stage_: um primeiro estágio com o SDK do .NET 9 compila e publica a aplicação em modo `Release`, e um segundo estágio usa a imagem enxuta do ASP.NET Core apenas com o runtime, o que reduz o tamanho final da imagem e a superfície de ataque (a aplicação ainda roda como usuário não-root).

O **docker-compose.yml** orquestra dois contêineres na mesma rede (`petlife-net`):

- **`api`**: a aplicação backend, construída a partir do Dockerfile, exposta em `http://localhost:5210`.
- **`mongo`**: uma instância local do MongoDB, usada no lugar do Atlas durante o desenvolvimento, com volume próprio para persistir os dados e _healthcheck_ para a API só subir após o banco estar pronto.

A conexão entre os contêineres é feita por variável de ambiente (`MongoDB__ConnectionString`), apontando a API para o serviço `mongo` da rede interna. Dessa forma, todo o ambiente (API + banco) sobe com um único comando:

```bash
docker compose up --build
```

- **Caminho do Dockerfile do Backend**: [src/backend/Dockerfile](../src/backend/Dockerfile)
- **Caminho do Docker Compose**: [docker-compose.yml](../docker-compose.yml)

---

## 5.2. Proposta de Infraestrutura de Deploy e Ambiente em Produção

**Modelo de CI/CD (implementado)**

O projeto já conta com uma esteira de Integração Contínua no **GitHub Actions**, definida em [.github/workflows/backend-ci.yml](../.github/workflows/backend-ci.yml). A pipeline é disparada automaticamente a cada _push_ e _pull request_ direcionado à branch `main` e executa, em ambiente `ubuntu-latest` com o SDK .NET 9, as seguintes etapas:

1. **Restore** das dependências do projeto (`dotnet restore`).
2. **Build** da solução em modo `Release` (`dotnet build`).
3. **Execução dos testes unitários** (`dotnet test`).

Com isso, qualquer alteração que quebre a compilação ou os testes é identificada antes do _merge_, mantendo a `main` sempre estável.

**Arquitetura Física Proposta (deploy em nuvem)**

Como evolução futura, a topologia de implantação proposta seria:

- **API**: publicada em um serviço de contêiner gerenciado (ex.: Render, Azure App Service ou AWS), a partir da mesma imagem Docker já utilizada localmente.
- **Banco de Dados**: MongoDB Atlas (NoSQL gerenciado na nuvem), que já é usado em ambiente de desenvolvimento.
- **Variáveis sensíveis** (connection string do Mongo, segredo do JWT, credenciais do Cloudinary): configuradas como _secrets_ de ambiente na plataforma de hospedagem, nunca versionadas no repositório.
- **Pipeline de Deploy**: a mesma esteira do GitHub Actions poderia ser estendida para, após os testes passarem, construir a imagem e publicá-la automaticamente no ambiente de produção (_continuous deployment_).

---

# 6. Referências Acadêmicas e de Engenharia

[Registre as referências que deram suporte técnico para a modelagem lógica, banco de dados ou metodologias de automação do backend das APIs.]

1. **DATE, C. J**. _Introdução a Sistemas de Bancos de Dados_. Rio de Janeiro: Elsevier, 2004.
2. **RICHARDSON, Leonard; RUBY, Sam**. _RESTful Web Services_. O'Reilly Media, 2007.
3. [Adicione referências de documentação oficial, SGBDs ou bibliotecas utilizadas].
